from pathlib import Path
p=Path('src/quod_physics.erl');s=p.read_text();s=s.replace('maps:with([authority,epoch,generation,run_token,structure],Spec).','maps:with([authority,epoch,generation,run_token,structure,budget],Spec).',1)
old='''    {request,Sample,_,_,_} = Custody,
    {door_sample,_,_,_,A,E,G,T,Structure,_,_,_,_,_,_} = Sample,
    Basis = #{authority => A,epoch => E,generation => G,run_token => T,structure => Structure},
    O = #{request => R,state => resolving,ref => Ref,prior => Custody,basis => Basis,'''
new='''    O = #{request => R,state => resolving,ref => Ref,prior => Custody,
          basis => observation_basis(Spec),'''
assert old in s;s=s.replace(old,new,1);p.write_text(s)
p=Path('test/quod_physics_tests.erl');s=p.read_text();s=s.replace('observation_edit_delivery_order_test_() ->\n    [','''observation_edit_delivery_order_test_() ->
    observation_edit_delivery_order(#{structure => 2}).

observation_budget_delivery_order_test_() ->
    observation_edit_delivery_order(#{budget => 2500}).

observation_edit_delivery_order(Change) ->
    [''',1).replace('Select = {physics_selected,self(),make_ref(),Spec#{structure => 2}},','Select = {physics_selected,self(),make_ref(),maps:merge(Spec,Change)},',1);p.write_text(s)
