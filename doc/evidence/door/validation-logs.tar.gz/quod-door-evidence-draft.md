# Obstructed-door integration evidence — 2026-10-05

The door slice uses the retained authority-host simulator, ordinary signed
actions and the existing transaction, reaction and outcome owners. Changes are
uncommitted. This evidence is not deployment or commit approval.

## Scope

A versioned class is resolved through an authorized action and materialized as
world-local leaf, frame and hinge facts. Closing drives the retained native
hinge. Its bounded signed sample produces one atomic blocked/closed result,
stopped-angle checkpoint and event. Durable proofs never read native physics.
Server-side checks of immutable committed outcomes govern replacement of saved
observation requests. Pending and unavailable outcomes are not rejection.

[The adapter contract](../../physics-native.md) describes installation, policy,
request custody, cancellation and restoration. The implementation preserves
normal Prolog event-pattern unification. A private physics request additionally
requires signed-request preparation, preventing a generic observed callback
from consuming the required consequence.

## Acceptance coverage

The production runtime/actor/ingress fixtures exercise obstruction and clear
closure; exact duplicate resolution; delayed and malformed signed samples;
competing obstacle edits with a prepared consequence; actor queue saturation;
expired queued evidence followed by a fresh completed-step sample; runtime
queue saturation followed by sleep and actual capacity release; restart with
original operation custody; pending-request cancellation; and authorized shared
class resolution followed by purely local selection.

Unchanged door selection is traced through the real owner: no native world
recreation, ledger fold/open, file write, sync or datasync. A real edit still
installs its revision. Native coverage includes two independent hinges,
mechanical braking, retained pose and fresh-resource checkpoint restoration.

Two negative controls are retained: discarding the capacity wait on a later
sleeping status leaves the close unfinished; allowing a generic observed(_)
clause to consume a private request also leaves it unfinished. Both regressions
pass with the fixes. No timeout or assertion was weakened.

## Review and limits

Claude Fable reviewed the plan read-only, at the user's request. The implementation
keeps matching in the runtime, uses the existing actor custody lane, supports
both blocked and closed results, avoids a fixed hinge population ceiling and
separates restore angles from structural row identity. The user's decision to
require server-verified rejection supersedes the suggestion to replace older
custody merely because a new run fenced it.

A saved-but-never-submitted request may have no terminal outcome. The door stays
held with visible pending status; authorized cancellation is the explicit exit.
No unknown request is resubmitted. This profile adds neither client motion
transport nor hot controls or impact-occurrence semantics.

Production code adds 921 and removes 83 lines (net **+838**, excluding Rust unit
tests). The growth implements the hinge mechanics, Prolog door model and bounded
observation/custody lifecycle within existing owners; it adds no executor,
broker or independently owned domain inventory.
