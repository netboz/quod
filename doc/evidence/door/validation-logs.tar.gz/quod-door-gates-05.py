import os,subprocess,hashlib,json,sys
root='/tmp/quod-door-gates-05'
os.environ['REBAR_BASE_DIR']='/tmp/quod-door-clean-build-05'
os.mkdir(root)
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
with open(root+'/tree.json','w') as f: json.dump({p:hashlib.sha256(open(p,'rb').read()).hexdigest() for p in paths},f,indent=2)
commands=[('clean',['rebar3','clean']),('native-test',['cargo','test','--manifest-path','native/quod_physics/Cargo.toml','--locked']),('native-clippy',['cargo','clippy','--manifest-path','native/quod_physics/Cargo.toml','--locked','--all-targets','--','-D','warnings']),('eunit',['rebar3','as','test','eunit']),('ct',['rebar3','as','test','ct']),('xref',['rebar3','xref']),('dialyzer',['rebar3','dialyzer']),('release',['rebar3','as','prod','release'])]
for name,cmd in commands:
 print('Starting '+name,flush=True)
 with open(root+'/'+name+'.log','w') as f: result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 with open(root+'/results.jsonl','a') as f: f.write(json.dumps({'gate':name,'command':cmd,'exit':result.returncode})+'\n')
 print(name+' exit '+str(result.returncode),flush=True)
 if result.returncode: sys.exit(result.returncode)
 if os.path.exists(root+'/STOPPED.txt'): sys.exit(130)
 if name == 'eunit' and '0 failures' not in open(root+'/'+name+'.log').read():
  print('Missing successful EUnit completion summary',flush=True);sys.exit(1)
