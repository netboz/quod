from pathlib import Path
import subprocess
source=Path('test/quod_names_tests.erl').read_text().replace('-module(quod_names_tests).','-module(quod_door_names_probe).')
source=source.replace('First = Run(crypto:strong_rand_bytes(32)),','First = Run(<<1:256>>),').replace('Others = [Run(crypto:strong_rand_bytes(32)) || _ <- lists:seq(1, 6)],','Others = [Run(<<I:256>>) || I <- lists:seq(2, 7)],')
Path('/tmp/quod_door_names_probe.erl').write_text(source)
probe='''{ok,quod_door_names_probe}=compile:file("/tmp/quod_door_names_probe.erl",[export_all,debug_info,{outdir,"/tmp"},{i,"/home/yan/src/quod/include"}]),code:add_patha("/tmp"),{reductions,R0}=process_info(self(),reductions),{Us,ok}=timer:tc(quod_door_names_probe,saltless_draw_test,[]),{reductions,R1}=process_info(self(),reductions),io:format("fixed-proof draw batch ~p us ~p reductions~n",[Us,R1-R0]),halt().'''
for name,root in [('baseline','/tmp/quod-door-baseline-01/_build'),('modified','/tmp/quod-door-clean-build-06')]:
 paths=sorted(str(p) for p in Path(root+'/test/lib').glob('*/ebin'))+[root+'/test/lib/quod/test']
 with open('/tmp/quod-door-names-draw-cost-'+name+'-01.log','w') as out:
  r=subprocess.run(['erl','-noshell','-pa']+paths+['-eval',probe],stdout=out,stderr=subprocess.STDOUT)
 print(name,'exit',r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
