from pathlib import Path
import subprocess
source=Path('test/quod_names_tests.erl').read_text().replace('-module(quod_names_tests).','-module(quod_door_names_probe).')
Path('/tmp/quod_door_names_probe.erl').write_text(source)
probe='''
{ok,quod_door_names_probe}=compile:file("/tmp/quod_door_names_probe.erl",[export_all,debug_info,{outdir,"/tmp"},{i,"/home/yan/src/quod/include"}]),
code:add_patha("/tmp"),
quod_door_names_probe:with_names(fun(St) ->
 lists:foreach(fun({C,G}) ->
  Count=quod_door_names_probe:value({'N'},{count,C,<<"personal">>,G,{'N'}},St),
  lists:foreach(fun(I) ->
   {reductions,R0}=process_info(self(),reductions),
   {Us,ok}=timer:tc(fun() ->
     N=quod_door_names_probe:value({'N'},{name_nth,C,<<"personal">>,G,I,{'N'}},St),
     true=is_binary(N),true=lists:member({C,<<"personal">>,G},quod_door_names_probe:selections(N,St)),ok
   end),
   {reductions,R1}=process_info(self(),reductions),
   io:format("~s ~s ~p ~p ~p~n",[C,G,I,Us,R1-R0])
  end,[0,Count div 2,Count-1])
 end,[{<<"orc">>,<<"female">>},{<<"primitive">>,<<"male">>},{<<"primitive">>,<<"female">>},{<<"gnome">>,<<"female">>},{<<"elf">>,<<"male">>},{<<"faerie">>,<<"female">>},{<<"siren">>,<<"female">>},{<<"dwarf">>,<<"male">>}])
end),halt().
'''
for name,root in [('baseline','/tmp/quod-door-baseline-01/_build'),('modified','/tmp/quod-door-clean-build-05')]:
 paths=sorted(str(p) for p in Path(root+'/test/lib').glob('*/ebin'))+[root+'/test/lib/quod/test']
 with open('/tmp/quod-door-names-query-cost-'+name+'-01.log','w') as out:
  r=subprocess.run(['erl','-noshell','-pa']+paths+['-eval',probe],stdout=out,stderr=subprocess.STDOUT)
 print(name,'exit',r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
