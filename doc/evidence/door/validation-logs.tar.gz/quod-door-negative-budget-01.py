from pathlib import Path
import subprocess
p=Path('src/quod_physics.erl');saved=p.read_text();assert 'run_token,structure,budget' in saved
try:
 p.write_text(saved.replace('run_token,structure,budget','run_token,structure',1))
 with open('/tmp/quod-door-negative-budget-01.log','w') as out:
  r=subprocess.run(['rebar3','eunit','--generator=quod_physics_tests:observation_budget_delivery_order_test_'],stdout=out,stderr=subprocess.STDOUT)
 print('budget negative exit',r.returncode,flush=True)
 if r.returncode==0:raise RuntimeError('negative control passed')
finally:p.write_text(saved)
