from pathlib import Path
import subprocess
p=Path('src/quod_physics.erl');saved=p.read_text()
try:
 assert 'run_token,structure,budget' in saved
 p.write_text(saved.replace('run_token,structure,budget','run_token,structure',1))
 with open('/tmp/quod-door-negative-budget-02-compile.log','w') as out:
  r=subprocess.run(['rebar3','as','test','compile'],stdout=out,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError('compile failed')
 paths=sorted(str(p.resolve()) for p in Path('_build/test/lib').glob('*/ebin'))+[str(Path('_build/test/lib/quod/test').resolve())]
 expression='R=eunit:test(hd(quod_physics_tests:observation_budget_delivery_order_test_()),[verbose]),case R of ok -> halt(0); error -> halt(1) end.'
 with open('/tmp/quod-door-negative-budget-02.log','w') as out:
  r=subprocess.run(['erl','-noshell','-pa']+paths+['-eval',expression],stdout=out,stderr=subprocess.STDOUT)
 text=Path('/tmp/quod-door-negative-budget-02.log').read_text()
 assert r.returncode==1 and 'required_observation_lost' in text and 'Failed: 1.' in text,text[-1200:]
 print('budget negative: one intended failure, exit 1',flush=True)
finally:p.write_text(saved)
