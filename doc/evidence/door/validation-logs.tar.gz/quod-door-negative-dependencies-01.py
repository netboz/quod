from pathlib import Path
import subprocess,json
cases=[('extraction','src/quod_erlog_db_local_prove.erl','quod_read_set:kind(Key) =/= invalid','is_tuple(Key) andalso tuple_size(Key) =:= 2 andalso is_integer(element(2,Key))',['--test=quod_dtx_tests:outcome_reads_survive_extraction_and_sealing_test']),('reconcile','src/quod_runtime.erl','case maps:get(needs_reconciliation, Entry, false) of\n                            true -> send_physics_selection(Entry, New);','case maps:get(status, Entry) of\n                            {unavailable, _} -> send_physics_selection(Entry, New);',['--generator=quod_physics_tests:sleeping_does_not_erase_explicit_reconciliation_test_'])]
for label,path,new,old,args in cases:
 p=Path(path);saved=p.read_text();assert new in saved
 try:
  p.write_text(saved.replace(new,old,1))
  with open('/tmp/quod-door-negative-'+label+'-01.log','w') as out:
   r=subprocess.run(['rebar3','eunit']+args,stdout=out,stderr=subprocess.STDOUT)
  print(json.dumps({'negative':label,'exit':r.returncode}),flush=True)
  if r.returncode==0: raise RuntimeError('negative control unexpectedly passed')
 finally:p.write_text(saved)
