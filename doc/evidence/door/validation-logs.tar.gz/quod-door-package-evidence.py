from pathlib import Path
import json, hashlib, shutil, subprocess, tarfile
root = Path('/home/yan/src/quod')
gates = Path('/tmp/quod-door-gates-09')
out = root / 'doc/evidence/door'
results = [json.loads(line) for line in (gates/'results.jsonl').read_text().splitlines()]
assert [r['gate'] for r in results] == ['clean','native-test','native-clippy','eunit','ct','xref','dialyzer','release']
assert all(r['exit'] == 0 for r in results)
manifest = json.loads((gates/'tree.json').read_text())
assert set(manifest) == set(subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest() == h for p,h in manifest.items())
assert '3751 tests, 0 failures' in (gates/'eunit.log').read_text()
assert 'All 145 tests passed' in (gates/'ct.log').read_text()
summary = """Clean campaign **09** passed every gate on the same frozen tree:

- Native tests: **2 passed**; Clippy with warnings denied: passed.
- Full EUnit: **3,751 tests, zero failures**.
- Common Test: **145/145 passed**.
- xref, Dialyzer and production release packaging: passed.

Base commit: `fbad63f2707d2ebfd6df48f9825e1d5a395eca4b`.
"""
readme = Path('/tmp/quod-door-evidence-readme-final.md').read_text().replace('FINAL_GATE_RESULTS', summary.rstrip())
assert 'FINAL_GATE_RESULTS' not in readme
(out/'README.md').write_text(readme)
shutil.copyfile('/tmp/quod-door-review-disposition-final.md', out/'review-disposition.md')
shutil.copyfile(gates/'tree.json', out/'source-manifest.json')
shutil.copyfile('/tmp/quod-door-final-delta.json', out/'production-delta.json')
Path('/tmp/quod-door-final-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=root))
files = [p for p in Path('/tmp').glob('quod-door-*') if p.is_file() and p.suffix in {'.log','.py','.json','.status','.txt','.md','.patch'}]
files += [Path('/tmp/quod_door_names_probe.erl')]
for d in list(Path('/tmp').glob('quod-door-gates-*')) + list(Path('/tmp').glob('quod-door-supplemental-*')):
    if d.is_dir(): files += [p for p in d.rglob('*') if p.is_file()]
with tarfile.open(out/'validation-logs.tar.gz','w:gz') as archive:
    for p in sorted(set(files)):
        archive.add(p, arcname=p.relative_to('/tmp'))
reports = Path('/tmp/quod-door-clean-build-09/test/logs')
assert reports.is_dir()
with tarfile.open(out/'common-test-reports.tar.gz','w:gz') as archive:
    archive.add(reports,arcname='common-test')
checksums = []
for p in sorted(out.iterdir()):
    if p.is_file() and p.name != 'SHA256SUMS':
        checksums.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name)
(out/'SHA256SUMS').write_text('\n'.join(checksums)+'\n')
print('Packaged',len(files),'validation files; source manifest matches all',len(manifest),'tracked changes.')
