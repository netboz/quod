from pathlib import Path
import subprocess, json
probe = 'Results=[begin {Us,R}=timer:tc(eunit,test,[{quod_foreign_log_tests,material_network_dependency_stops_route_failover_test},[verbose]]),io:format("peer case attempt=~p us=~p result=~p~n",[I,Us,R]),R end || I <- lists:seq(1,3)],halt(case lists:usort(Results) of [ok] -> 0; _ -> 1 end).'
for name,root in [('baseline','/tmp/quod-door-baseline-01/_build'),('modified','/tmp/quod-door-clean-build-08')]:
 paths=sorted(str(p) for p in Path(root+'/test/lib').glob('*/ebin'))+[root+'/test/lib/quod/test']
 with open('/tmp/quod-door-peer-start-'+name+'-01.log','w') as out:
  result=subprocess.run(['erl','-noshell','-pa']+paths+['-eval',probe],stdout=out,stderr=subprocess.STDOUT)
 with open('/tmp/quod-door-peer-start-triage-01.status','a') as out:
  out.write(json.dumps({'tree':name,'exit':result.returncode})+'\n')
 print(name,'exit',result.returncode,flush=True)
 if result.returncode: raise SystemExit(result.returncode)
