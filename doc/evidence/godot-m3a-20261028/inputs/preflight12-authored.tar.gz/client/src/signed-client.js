import { b64url, fromB64url } from './key-provider.js'
import { signedOperationJournal } from './operation-journal.js'
import { SIGNED_GOAL_LIMITS } from './protocol-limits.js'
import { binary, compound, renderTerm, variable } from './prolog-term.js'

const encoder = new TextEncoder()
const GOAL_DOMAIN = encoder.encode('quod.agent.goal.v1\0')
const CHALLENGE_DOMAIN = encoder.encode('quod.agent.challenge.v1\0')
const REQUEST_TTL_MS = 5 * 60_000
const PARSER_VERSION = 3
const MODE_TAG = { read: 0, execute: 1, cursor: 2, control: 3 }
const cursorOperations = new Map()

// Authenticate one key through the same challenge flow used by every browser
// surface. The returned object is also the only input accepted by signedGoal.
export async function authenticateKey(provider, options = {}) {
  assertCrypto()
  const post = options.post || postJson
  const clientNonce = crypto.getRandomValues(new Uint8Array(32))
  const challenge = await post('/api/auth/challenge', {
    public_key: b64url(provider.publicKey),
    client_nonce: b64url(clientNonce),
  })
  const signature = new Uint8Array(await provider.sign(
    challengeBytes(challenge, provider.publicKey, clientNonce),
  ))
  const session = await post('/api/auth/complete', {
    challenge_id: challenge.challenge_id,
    signature: b64url(signature),
  })
  return { provider, session, networkId: fromB64url(challenge.network_id) }
}

// Discover system ontologies from this network's root catalogue. Registration
// identifies installed services; ordinary goal reads still determine readiness.
export async function readSystemOntologies(identity, options = {}) {
  const response = await (options.fetch || fetch)('/api/ontologies/system')
  if (!response.ok) throw new Error('The system catalogue is unavailable.')
  const catalogue = await response.json()
  if (catalogue.network_id !== b64url(identity.networkId)) {
    throw new Error('The system catalogue belongs to another network.')
  }
  if (!Array.isArray(catalogue.ontologies)) throw new Error('The system catalogue is invalid.')
  return catalogue.ontologies
}

// Sign and submit one ordinary Prolog goal. Modes select proof behaviour only;
// they do not classify predicates or create a second authorization path.
export async function signedGoal(identity, { mode, agent, goal }, options = {}) {
  options.signal?.throwIfAborted()
  const post = options.post || postJson
  const request = goalRequestBytes(identity, { mode, agent, goal })
  const signature = new Uint8Array(await identity.provider.sign(request))
  options.signal?.throwIfAborted()
  const body = signedBody(identity, request, signature)
  if (mode === 'read') return post('/api/goals/read', body)
  // Lossy commands are never journaled or automatically replayed.
  if (mode === 'control') return post('/api/goals/control', body)

  const operation = await operationRow(identity, request, signature)
  options.signal?.throwIfAborted()
  if (options.context) operation.context = options.context
  if (mode === 'execute') {
    const journal = options.journal || signedOperationJournal()
    return submitDurable(journal, operation, '/api/goals/execute', body, post, options)
  }
  const reply = await post('/api/goals/cursors', body)
  if (reply.result === 'solution' && typeof reply.cursor === 'string') {
    cursorOperations.set(
      reply.cursor,
      { journal: options.journal || null, operation },
    )
  }
  return reply
}

// The human signs an attempt-now instruction. Only the hosted actor can sign
// the exact enclosed operation; neither this client nor recovery dispatches it.
export async function personalGoal(identity, { human, agent, key, target, goal }, options = {}) {
  options.signal?.throwIfAborted()
  if (!target?.namespace || !target.anchor) throw new Error('Select an exact target ontology.')
  const operationId = crypto.getRandomValues(new Uint8Array(32))
  const expires = Math.min(identity.session.expires_ms, Date.now() + REQUEST_TTL_MS)
  const targetName = renderTerm(binary(encoder.encode(target.namespace)))
  const anchor = typeof target.anchor === 'string' ? fromB64url(target.anchor) : target.anchor
  const atTarget = `current_ontology_identity(${targetName}, ${renderTerm(binary(anchor))}), (${goal.replace(/\.\s*$/, '')})`
  // Admission of the retained instruction covers this exact source goal.
  // A self-hop would ask admission again for a different inner goal.
  const anchored = target.namespace === agent.namespace
    ? `${atTarget}.` : `${targetName}::(${atTarget}).`
  const targetBytes = encodeGoalRequest({ networkIdentity: identity.networkId,
    signingPublicKey: key, operationId, agentNamespace: agent.namespace,
    agentAnchor: typeof agent.anchor === 'string' ? fromB64url(agent.anchor) : agent.anchor,
    agentInstanceText: agent.instanceText, mode: 'execute', notAfterMs: expires, goal: anchored })
  const request = goalRequestBytes(identity, { mode: 'read', agent: human,
    goal: `${renderTerm(compound('personal_instruction_accept', [binary(targetBytes), variable('Signature')]))}.` })
  const signature = new Uint8Array(await identity.provider.sign(request))
  options.signal?.throwIfAborted()
  const row = await operationRow(identity, request, signature)
  row.instruction = b64url(operationId)
  if (options.context) row.context = options.context
  return submitDurable(options.journal || signedOperationJournal(), row,
    '/api/agents/instructions', signedBody(identity, request, signature),
    (url, body) => (options.post || postJson)(url, body, 'POST', { signal: options.signal }), options)
}

export async function resolvePersonalInstruction(identity, human, id, options = {}) {
  options.signal?.throwIfAborted()
  const request = goalRequestBytes(identity, { mode: 'read', agent: human,
    goal: `${renderTerm(compound('personal_instruction_lookup', [
      binary(typeof id === 'string' ? fromB64url(id) : id), variable('Bytes'), variable('Signature'),
    ]))}.` })
  const signature = new Uint8Array(await identity.provider.sign(request))
  options.signal?.throwIfAborted()
  return (options.post || postJson)('/api/agents/instructions/outcomes',
    signedBody(identity, request, signature), 'POST', { signal: options.signal })
}

export async function signedCursorCommand(identity, cursor, command) {
  if (!['next', 'accept', 'stop'].includes(command)) {
    throw new Error('invalid cursor command')
  }
  const suffix = command === 'stop' ? '' : `/${command}`
  const url = `/api/goals/cursors/${encodeURIComponent(cursor)}${suffix}`
  const body = { session_id: identity.session.session_id }
  const tracked = cursorOperations.get(cursor)
  if (command === 'accept') {
    if (!tracked) throw new Error('this cursor is not bound to its signed request')
    const journal = tracked.journal || signedOperationJournal()
    try {
      await journal.put(tracked.operation)
      const reply = writeReply(await postJson(url, body))
      if (reply.result === 'pending') await retainPendingReference(journal, tracked.operation, reply)
      else await journal.delete(tracked.operation.id)
      cursorOperations.delete(cursor)
      return reply.result === 'pending' ? { ...reply, operationId: tracked.operation.id } : reply
    } catch (error) {
      if (error.outcomeUnknown) error.operationId = tracked.operation.id
      if (!error.outcomeUnknown) await journal.delete(tracked.operation.id)
      const retryableCursor = error.message === 'cursor_busy' ||
        error.message === 'cursor_not_ready'
      if (!retryableCursor) cursorOperations.delete(cursor)
      throw error
    }
  }
  const reply = await postJson(url, body, command === 'stop' ? 'DELETE' : 'POST')
  if (command === 'stop' || reply.result !== 'solution') cursorOperations.delete(cursor)
  return reply
}

// Reconcile every unresolved write belonging to this exact key and network.
// The same signed bytes are sent only to the outcome endpoint, never to the
// proof endpoint again.
export async function resolveSignedOperations(identity, options = {}) {
  const journal = options.journal || signedOperationJournal()
  const rows = await pendingSignedOperations(identity, { journal })
  const results = []
  for (const row of rows) {
    if (options.operationId && options.operationId !== row.id) continue
    try {
      const reply = row.instruction
        ? await resolvePersonalInstruction(identity, { ...row.agent,
            instanceText: row.agent.instance_text }, row.instruction, options)
        : await (options.post || postJson)('/api/goals/outcomes', {
        session_id: identity.session.session_id,
        request: row.request,
        signature: row.signature,
        ...(row.outcome_ref ? { outcome_ref: row.outcome_ref } : {}),
      })
      if (reply.terminal === true) await settleOperation(journal, row, reply, options)
      results.push({ id: row.id, operation: row, reply })
    } catch (error) {
      results.push({ id: row.id, operation: row, error })
    }
  }
  return results
}

export async function pendingSignedOperations(identity, options = {}) {
  const journal = options.journal || signedOperationJournal()
  const signingKey = b64url(identity.provider.publicKey)
  const network = b64url(identity.networkId)
  return (await journal.list()).filter(
    row => row.signing_key === signingKey && row.network === network,
  )
}

export function goalRequestBytes(identity, { mode, agent, goal }) {
  assertCrypto()
  return encodeGoalRequest({
    networkIdentity: identity.networkId,
    signingPublicKey: identity.provider.publicKey,
    operationId: crypto.getRandomValues(new Uint8Array(32)),
    agentNamespace: agent.namespace,
    agentAnchor: typeof agent.anchor === 'string' ? fromB64url(agent.anchor) : agent.anchor,
    agentInstanceText: agent.instanceText,
    mode,
    notAfterMs: Math.min(identity.session.expires_ms, Date.now() + REQUEST_TTL_MS),
    goal,
  })
}

async function submitDurable(journal, operation, url, body, post, options) {
  if (options.replaceOperation) await journal.replace(options.replaceOperation, operation)
  else await journal.put(operation)
  let reply
  try {
    options.signal?.throwIfAborted()
    reply = writeReply(await post(url, body))
  } catch (error) {
    if (!error.outcomeUnknown) await journal.delete(operation.id)
    throw error
  }
  // Saving a returned reference or handing off to the next operation is part
  // of consuming the result. A local callback failure must retain recovery
  // evidence, not masquerade as a rejected server write.
  if (reply.result === 'pending') await retainPendingReference(journal, operation, reply)
  else await settleOperation(journal, operation, reply, options)
  return reply
}

async function retainPendingReference(journal, operation, reply) {
  if (reply.group_id === undefined) return
  const { ns, anchor, coordinator, coordinator_admission, group_id } = reply
  try {
    await journal.put({ ...operation,
      outcome_ref: { ns, anchor, coordinator, coordinator_admission, group_id } })
  } catch (cause) {
    const error = new Error('could not retain the submitted group reference; its outcome remains unknown', { cause })
    error.outcomeUnknown = true
    throw error
  }
}

async function settleOperation(journal, operation, reply, options) {
  if (options.onTerminal) {
    if (await options.onTerminal(reply, operation) === false) return
  }
  else if (operation.context) return
  await journal.delete(operation.id)
}

async function operationRow(identity, request, signature) {
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', request))
  const decoded = decodeRequestIdentity(request)
  return {
    version: 2,
    id: b64url(digest),
    signing_key: b64url(identity.provider.publicKey),
    network: b64url(identity.networkId),
    agent: decoded,
    request: b64url(request),
    signature: b64url(signature),
    created_at_ms: Date.now(),
  }
}

function decodeRequestIdentity(request) {
  let offset = GOAL_DOMAIN.length + 32 + 32 + 32
  const namespaceLength = new DataView(
    request.buffer, request.byteOffset + offset, 2,
  ).getUint16(0, false)
  offset += 2
  const namespace = new TextDecoder().decode(request.slice(offset, offset + namespaceLength))
  offset += namespaceLength
  const anchor = b64url(request.slice(offset, offset + 32))
  offset += 32
  const instanceLength = new DataView(
    request.buffer, request.byteOffset + offset, 4,
  ).getUint32(0, false)
  offset += 4
  const instance_text = new TextDecoder().decode(request.slice(offset, offset + instanceLength))
  return { namespace, anchor, instance_text }
}

function signedBody(identity, request, signature) {
  return {
    session_id: identity.session.session_id,
    request: b64url(request),
    signature: b64url(signature),
  }
}

// Pure cross-language encoder. Keeping the random operation ID and clock in
// goalRequestBytes leaves this exact protocol function fixture-testable.
export function encodeGoalRequest({
  networkIdentity,
  signingPublicKey,
  operationId,
  agentNamespace,
  agentAnchor,
  agentInstanceText,
  mode,
  notAfterMs,
  goal,
}) {
  const modeTag = MODE_TAG[mode]
  const namespaceBytes = encoder.encode(agentNamespace)
  const instanceBytes = encoder.encode(agentInstanceText)
  const goalBytes = encoder.encode(goal)
  const deadline = BigInt(notAfterMs)
  if (goalBytes.length > SIGNED_GOAL_LIMITS.goalTextBytes) {
    throw new Error(`signed goal text exceeds byte encoding limit (${goalBytes.length} > ${SIGNED_GOAL_LIMITS.goalTextBytes})`)
  }
  if (modeTag === undefined || namespaceBytes.length < 1 ||
      namespaceBytes.length > SIGNED_GOAL_LIMITS.namespaceBytes ||
      instanceBytes.length < 1 ||
      instanceBytes.length > SIGNED_GOAL_LIMITS.agentInstanceTextBytes ||
      goalBytes.length < 1 ||
      agentAnchor?.length !== 32 ||
      networkIdentity?.length !== 32 || signingPublicKey?.length !== 32 ||
      operationId?.length !== 32 || deadline < 1n || deadline > 0xffffffffffffffffn) {
    throw new Error('invalid signed goal')
  }
  const namespaceLength = uint16(namespaceBytes.length)
  const instanceLength = uint32(instanceBytes.length)
  const goalLength = uint32(goalBytes.length)
  const expiry = uint64(deadline)
  return joinBytes(
    GOAL_DOMAIN,
    networkIdentity,
    signingPublicKey,
    operationId,
    namespaceLength,
    namespaceBytes,
    agentAnchor,
    instanceLength,
    instanceBytes,
    new Uint8Array([modeTag, PARSER_VERSION]),
    expiry,
    goalLength,
    goalBytes,
  )
}

export function assertCrypto() {
  if (globalThis.crypto?.subtle) return
  throw new Error(globalThis.isSecureContext === false
    ? 'this page must be served over https for the browser to allow key handling'
    : 'this browser does not provide Web Crypto')
}

// Exported for non-browser callers that need to supply an absolute URL while
// retaining the client's one HTTP error/uncertain-outcome boundary.
// Optional traceparent is transport metadata, never part of the signed body.
export async function postJson(url, body, method = 'POST', { traceparent, signal } = {}) {
  let response, payload
  try {
    response = await fetch(url, {
      method,
      signal,
      headers: {
        'content-type': 'application/json',
        ...(traceparent ? { traceparent } : {}),
      },
      body: JSON.stringify(body),
    })
    payload = await response.json()
    if (!payload || typeof payload !== 'object' || Array.isArray(payload) ||
        (!response.ok && typeof payload.error !== 'string')) {
      throw new Error('invalid server response')
    }
  } catch (cause) {
    // The browser cannot know whether the server accepted a write before the
    // connection failed. Mark that uncertainty so a caller never turns it
    // into a fresh operation by retrying the goal.
    throw unknownOutcome(cause)
  }
  if (!response.ok) {
    const message = payload.error === 'effect_custody_limit' && payload.resource === 'prepared_bytes'
      ? `Prepared action needs ${payload.actual} bytes; root policy allows ${payload.limit} bytes.`
      : payload.error
    const error = new Error(message)
    error.status = response.status
    throw error
  }
  return payload
}

function writeReply(reply) {
  if (reply?.result === 'operation_outcome' && reply.status === 'pending' && reply.terminal === false) {
    return { ...reply, result: 'pending' }
  }
  // Only a complete, recognized write result may retire recovery evidence.
  if (!reply || !['ok', 'fail', 'pending'].includes(reply.result)) {
    throw unknownOutcome(new Error('invalid signed write response'))
  }
  return reply
}

function unknownOutcome(cause) {
  const error = new Error('the request outcome is unknown; do not resubmit it', { cause })
  error.outcomeUnknown = true
  return error
}

function challengeBytes(challenge, publicKey, clientNonce) {
  const expiry = uint64(BigInt(challenge.expires_ms))
  return joinBytes(
    CHALLENGE_DOMAIN,
    fromB64url(challenge.network_id),
    fromB64url(challenge.node_key),
    fromB64url(challenge.challenge_id),
    publicKey,
    clientNonce,
    fromB64url(challenge.server_nonce),
    expiry,
  )
}

function uint16(value) {
  const bytes = new Uint8Array(2)
  new DataView(bytes.buffer).setUint16(0, value, false)
  return bytes
}

function uint32(value) {
  const bytes = new Uint8Array(4)
  new DataView(bytes.buffer).setUint32(0, value, false)
  return bytes
}

function uint64(value) {
  const bytes = new Uint8Array(8)
  new DataView(bytes.buffer).setBigUint64(0, value, false)
  return bytes
}

function joinBytes(...parts) {
  const length = parts.reduce((total, part) => total + part.length, 0)
  const result = new Uint8Array(length)
  let offset = 0
  for (const part of parts) {
    result.set(part, offset)
    offset += part.length
  }
  return result
}
