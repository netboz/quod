import { MeshBuilder } from '@babylonjs/core/Meshes/meshBuilder.js'
// CreateForMesh uses Babylon's registered standard-material factory.
import '@babylonjs/core/Materials/standardMaterial.js'
import '@babylonjs/core/Culling/ray.js'
import { AdvancedDynamicTexture } from '@babylonjs/gui/2D/advancedDynamicTexture.js'
import { StackPanel } from '@babylonjs/gui/2D/controls/stackPanel.js'
import { TextBlock } from '@babylonjs/gui/2D/controls/textBlock.js'
import { InputText } from '@babylonjs/gui/2D/controls/inputText.js'
import { InputTextArea } from '@babylonjs/gui/2D/controls/inputTextArea.js'
import { Button } from '@babylonjs/gui/2D/controls/button.js'
import { ScrollViewer } from '@babylonjs/gui/2D/controls/scrollViewers/scrollViewer.js'
import { VirtualKeyboard } from '@babylonjs/gui/2D/controls/virtualKeyboard.js'
import { Rectangle } from '@babylonjs/gui/2D/controls/rectangle.js'
import { Image } from '@babylonjs/gui/2D/controls/image.js'
import { createRenderResources } from './render-resources.js'
import { Slider } from '@babylonjs/gui/2D/controls/sliders/slider.js'
import { createNumericControl } from './numeric-control.js'
import { textFeedback, guiValueKind, choiceValues, choiceDraft, guiContainer, guiDisplay } from './gui-values.js'
import { cancelGuiPointer } from './gui-pointer.js'
import { WebXRTrackingState } from '@babylonjs/core/XR/webXRTypes.js'

// A spatial adapter for semantic GUI forms. The controller owns drafts and
// proofs; these controls only display values and invoke its explicit actions.
export function createWorkspacePanel(scene, appearanceSettings = { opacity: 0.78, scale: 1, distance: 1.6 }, sharedResources = null) {
  const resources = sharedResources ?? createRenderResources(scene)
  const mesh = MeshBuilder.CreatePlane('workspace', { width: 1.8, height: 1.7 }, scene)
  mesh.isVisible = false
  const texture = AdvancedDynamicTexture.CreateForMesh(mesh, 1280, 1440)
  // Opacity belongs to the panel's background, never the control hierarchy.
  texture.background = 'rgba(25,43,50,0.78)'
  const form = new StackPanel('workspace-form')
  form.width = '1200px'
  texture.addControl(form)
  let model = null
  let synchronizing = false
  let schema = null
  let lastView = null
  let fields = new Map()
  let moving = null
  let selectedTabs = new Map()
  let transients = new Map()
  const visible = control => {
    for (let node = control; node; node = node.parent) if (!node.isVisible || !node.isEnabled) return false
    return control.host === texture
  }
  const canvas = scene.getEngine().getRenderingCanvas()
  const escape = event => {
    if (event.key !== 'Escape' || !mesh.isVisible) return
    const open = [...transients.values()].reverse().find(item => visible(item.pane))
    if (open) { event.preventDefault(); event.stopPropagation(); open.close() }
  }
  canvas?.addEventListener('keydown', escape)

  function image(field, parent, compact = false) {
    const control = new Image(`${field.role}-image`)
    control.height = compact ? '48px' : '220px'
    control.width = compact ? '48px' : '90%'
    control.stretch = Image.STRETCH_UNIFORM
    if (compact) control.horizontalAlignment = 0
    const feedback = new TextBlock(`${field.role}-image-status`, 'Loading image…')
    feedback.height = '40px'; feedback.fontSize = 20; feedback.color = '#F5F1EB'
    if (!compact) parent.addControl(feedback)
    parent.addControl(control)
    let active = true, domImage = null
    const lease = resources.acquireImage(field.image)
    const failed = () => {
      if (!active) return
      feedback.text = 'Image unavailable'
      if (compact) parent.textBlock.text = `${field.label} (image unavailable)`
    }
    control.onDisposeObservable.addOnce(() => {
      active = false; domImage?.removeEventListener('error', failed)
      lease.release()
      if (compact) feedback.dispose()
    })
    control.onImageLoadedObservable.add(() => { if (active) feedback.isVisible = false })
    lease.ready.then(url => {
      if (!active || !url) return
      control.source = url
      domImage = control.domImage
      domImage.addEventListener('error', failed)
    }, failed)
  }

  function place() {
    const camera = scene.activeCamera
    if ('trackingState' in camera && camera.trackingState !== WebXRTrackingState.TRACKING) return
    const direction = camera.getForwardRay().direction
    const position = camera.globalPosition
    mesh.position.copyFrom(position.add(direction.scale(appearanceSettings.distance)))
    mesh.setDirection(scene.useRightHandedSystem
      ? position.subtract(mesh.position) : mesh.position.subtract(position))
  }

  function stopMoving() {
    if (moving) scene.onBeforeRenderObservable.remove(moving)
    moving = null
    move.textBlock.text = 'Move panel'
  }

  function label(name, height, size) {
    const control = new TextBlock(name)
    control.height = `${height}px`
    control.fontSize = size
    control.color = '#F5F1EB'
    control.textWrapping = true
    form.addControl(control)
    return control
  }

  const title = label('workspace-title', 56, 32)
  const scope = label('workspace-scope', 54, 20)
  const appearance = new StackPanel('workspace-appearance')
  appearance.isVertical = false
  appearance.height = '70px'
  form.addControl(appearance)
  const opacityLabel = new TextBlock('workspace-opacity-label')
  opacityLabel.width = '290px'
  opacityLabel.color = '#F5F1EB'
  opacityLabel.fontSize = 24
  appearance.addControl(opacityLabel)
  const opacity = new Slider('workspace-opacity')
  opacity.minimum = 0.5
  opacity.maximum = 1
  opacity.step = 0.01
  opacity.value = appearanceSettings.opacity
  opacity.width = '460px'
  opacity.height = '48px'
  opacity.color = '#F9C80E'
  opacity.background = '#0F1B20'
  opacity.thumbWidth = '48px'
  const showOpacity = () => {
    const percent = Math.round(opacity.value * 100)
    appearanceSettings.opacity = opacity.value
    opacityLabel.text = `Panel opacity: ${percent}%`
    texture.background = `rgba(25,43,50,${percent / 100})`
  }
  opacity.onValueChangedObservable.add(showOpacity)
  appearance.addControl(opacity)
  button('workspace-opacity-less', '−', appearance, () => { opacity.value -= 0.05 }, '90px')
  button('workspace-opacity-more', '+', appearance, () => { opacity.value += 0.05 }, '90px')
  button('workspace-opaque', 'Opaque', appearance, () => { opacity.value = 1 }, '200px')
  showOpacity()
  const placement = new StackPanel('workspace-placement')
  placement.isVertical = false
  placement.height = '70px'
  form.addControl(placement)
  button('workspace-recenter', 'Recenter', placement, place)
  const move = button('workspace-move', 'Move panel', placement, () => {
    if (moving) stopMoving()
    else {
      moving = scene.onBeforeRenderObservable.add(place)
      move.textBlock.text = 'Place panel'
    }
  })
  const scale = delta => {
    appearanceSettings.scale = Math.max(1, Math.min(2, appearanceSettings.scale + delta))
    mesh.scaling.setAll(appearanceSettings.scale)
    schema = null; lastView = null
    if (model) panel.update(model, mesh.isVisible)
  }
  button('workspace-text-smaller', 'Text −', placement, () => scale(-0.25), '140px')
  button('workspace-text-larger', 'Text +', placement, () => scale(0.25), '140px')
  const depth = delta => {
    appearanceSettings.distance = Math.max(0.6, Math.min(4, appearanceSettings.distance + delta))
    place()
  }
  button('workspace-nearer', 'Nearer', placement, () => depth(-0.2))
  button('workspace-farther', 'Farther', placement, () => depth(0.2))
  mesh.scaling.setAll(appearanceSettings.scale)
  const content = new StackPanel('workspace-fields')
  const viewport = new ScrollViewer('workspace-scroll')
  viewport.height = '580px'
  viewport.barSize = 24
  viewport.addControl(content)
  form.addControl(viewport)
  const actions = new StackPanel('workspace-actions')
  actions.isVertical = true
  actions.height = '70px'
  const actionViewport = new ScrollViewer('workspace-action-scroll')
  actionViewport.height = '70px'
  actionViewport.barSize = 24
  actionViewport.addControl(actions)
  form.addControl(actionViewport)
  const keyboard = new VirtualKeyboard('workspace-keyboard')
  keyboard.defaultButtonWidth = '70px'
  keyboard.defaultButtonHeight = '48px'
  keyboard.defaultButtonColor = '#F5F1EB'
  keyboard.defaultButtonBackground = '#304C56'
  keyboard.fontSize = 23
  for (const row of [
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '←'],
    ['a', 'z', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
    ['q', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm'],
    ['⇧', 'w', 'x', 'c', 'v', 'b', 'n', '_', ' ', '↵'],
    ['(', ')', '[', ']', ',', '.', ':', ';', "'", '"', '\\'],
    ['=', '-', '+', '*', '/', '<', '>', '|', '!', '?', '%'],
  ]) keyboard.addKeysRow(row)
  form.addControl(keyboard)

  function button(name, text, parent, invoke, width = '165px') {
    const control = Button.CreateSimpleButton(name, text)
    control.width = width
    control.height = '58px'
    control.fontSize = 24
    control.textBlock.textWrapping = true
    control.color = '#F5F1EB'
    control.background = '#304C56'
    control.disabledColor = '#243B43'
    control.disabledColorItem = '#BAC9CC'
    control.onPointerClickObservable.add(() => { if (control.isEnabled) invoke() })
    parent.addControl(control)
    return control
  }

  function action(name, text, invoke) {
    // Wrap by available panel width, not by the number of domain actions.
    const columns = Math.floor(1200 / 165)
    let row = actions.children.at(-1)
    if (!row || row.children.length >= columns) {
      row = new StackPanel(`workspace-action-row-${actions.children.length}`)
      row.isVertical = false
      row.height = '70px'
      actions.addControl(row)
      actions.height = `${actions.children.length * 70}px`
      actionViewport.height = `${Math.min(140, actions.children.length * 70)}px`
    }
    return button(name, text, row, invoke)
  }

  function rebuild(view) {
    const previousTransients = new Set([...transients].filter(([, item]) => item.pane.isVisible).map(([role]) => role))
    // Blur while the old control and keyboard still own their observers.
    // Babylon's control disposal does not clear the texture's focused control.
    texture.focusedControl = null
    keyboard.disconnect()
    for (const child of [...content.children, ...actions.children]) child.dispose()
    fields = new Map()
    const previousTabs = selectedTabs
    selectedTabs = new Map()
    transients = new Map()
    const component = (field, parent, width, inheritedEnabled = true, localActions = false) => {
      const { role, kind } = field
      const active = inheritedEnabled && field.enabled !== false
      if (guiContainer(kind)) {
        if (kind === 'menu' || kind === 'dialog') {
          const pane = new StackPanel(`${role}-popup`)
          let restore = null
          const close = () => {
            texture.focusedControl = null
            for (const entry of fields.values()) entry.numeric?.cancel()
            pane.isVisible = false
            if (restore && visible(restore)) texture.focusedControl = restore
            restore = null
          }
          const opener = button(`${role}-open`, `Open ${field.label}`, parent, () => {
            restore = texture.focusedControl
            texture.focusedControl = null
            pane.isVisible = true
          }, `${width - 60}px`)
          opener.isEnabled = active
          parent.addControl(pane)
          pane.isVisible = previousTransients.has(role)
          transients.set(role, { pane, close })
          component({ ...field, kind: 'panel' }, pane, width, active, true)
          button(`${role}-close`, `${kind === 'dialog' ? 'Cancel' : 'Close'} ${field.label}`, pane, close, `${width - 60}px`)
          return
        }
        const group = new StackPanel(role)
        group.width = `${width}px`
        parent.addControl(group)
        if (field.label) {
          const heading = new TextBlock(`${role}-label`, field.label)
          heading.height = '40px'; heading.fontSize = 24; heading.color = '#F5F1EB'
          group.addControl(heading)
        }
        if (field.help) {
          const help = new TextBlock(`${role}-help`, field.help)
          help.fontSize = 20; help.color = '#F5F1EB'; help.textWrapping = true; help.resizeToFit = true
          group.addControl(help)
        }
        const children = field.children ?? []
        if (kind === 'tabs') {
          const header = new ScrollViewer(`${role}-tabs`)
          header.height = `${Math.min(3, Math.max(1, children.length)) * 58}px`; header.barSize = 28
          const buttons = new StackPanel(`${role}-tab-buttons`)
          header.addControl(buttons); group.addControl(header)
          const panes = children.map(child => {
            const pane = new StackPanel(`${child.role}-tab-pane`)
            group.addControl(pane); component(child, pane, width, active, true)
            return { child, pane, control: button(`${role}-tab-${child.role}`, child.label,
              buttons, () => {
                texture.focusedControl = null
                for (const field of fields.values()) field.numeric?.cancel()
                selectedTabs.set(role, child.role); showTab()
              }, `${width - 60}px`) }
          })
          const previous = previousTabs.get(role)
          selectedTabs.set(role, children.some(child => child.role === previous) ? previous : children[0]?.role)
          const showTab = () => {
            for (const { child, pane, control } of panes) {
              const selected = selectedTabs.get(role) === child.role
              pane.isVisible = selected
              control.textBlock.text = `${selected ? '● ' : '○ '}${child.label}`
              control.isEnabled = active
            }
          }
          showTab()
          return
        }
        let target = group
        if (kind === 'scroll') {
          const scroll = new ScrollViewer(`${role}-scroll`)
          scroll.height = `${(field.visibleRows ?? 6) * 58}px`; scroll.barSize = 28
          target = new StackPanel(`${role}-content`)
          scroll.addControl(target); group.addControl(scroll)
        }
        // Wrap composed rows by available readable control width. Adding fields
        // must not shrink hit targets or put controls outside the panel.
        const columns = ['row', 'grid'].includes(field.layout) && appearanceSettings.scale === 1
          ? Math.max(1, Math.min(children.length, field.layout === 'grid' ? field.columns ?? 2 : Infinity, Math.floor(width / 560))) : 1
        const childWidth = width / columns
        if (columns === 1) {
          for (const child of children) component(child, target, width, active, localActions)
          return
        }
        let row
        for (const [index, child] of children.entries()) {
          if (index % columns === 0) {
            row = new StackPanel(`${role}-row-${index}`)
            row.isVertical = false
            row.adaptHeightToChildren = true
            target.addControl(row)
          }
          const cell = new StackPanel(`${child.role}-cell`)
          cell.width = `${childWidth}px`
          row.addControl(cell)
          component(child, cell, childWidth, active, localActions)
        }
        return
      }
      if (guiDisplay(kind)) {
        const text = new TextBlock(role, kind === 'progress' ? `${field.label}: ${field.percent}%` : field.label)
        text.height = '48px'; text.fontSize = 24; text.textWrapping = true; text.resizeToFit = true
        text.color = kind === 'error' ? '#FFB8BD' : kind === 'status' ? '#C5E7A0' : '#F5F1EB'
        parent.addControl(text)
        if (field.image) image(field, parent)
        if (kind === 'progress' || kind === 'separator') {
          const bar = new Rectangle(`${role}-bar`)
          bar.height = kind === 'separator' ? '2px' : '24px'
          bar.width = `${width - 60}px`; bar.thickness = 0; bar.background = '#0F1B20'
          if (kind === 'progress') {
            const fill = new Rectangle(`${role}-fill`)
            fill.width = field.percent / 100; fill.horizontalAlignment = 0
            fill.thickness = 0; fill.background = '#C5E7A0'; bar.addControl(fill)
          } else bar.background = '#BAC9CC'
          parent.addControl(bar)
        }
        if (field.help) {
          const help = new TextBlock(`${role}-help`, field.help)
          help.fontSize = 20; help.color = '#F5F1EB'; help.textWrapping = true; help.resizeToFit = true
          parent.addControl(help)
        }
        return
      }
      if (kind === 'button') {
        const control = localActions
          ? button(role, field.label, parent, () => model.invoke(role), `${width - 60}px`)
          : action(role, field.label, () => model.invoke(role))
        if (field.image) { control.textBlock.paddingLeft = '52px'; image(field, control, true) }
        fields.set(role, { kind, active, control })
        return
      }
      const caption = new TextBlock(`${role}-label`, field.unit ? `${field.label} (${field.unit})` : field.label)
      caption.height = '36px'
      caption.fontSize = 22
      caption.color = '#F5F1EB'
      caption.textWrapping = true
      caption.resizeToFit = true
      parent.addControl(caption)
      if (field.help) {
        const help = new TextBlock(`${role}-help`, field.help)
        help.fontSize = 20; help.color = '#F5F1EB'; help.textWrapping = true; help.resizeToFit = true
        parent.addControl(help)
      }
      if (guiValueKind(kind) === 'number') {
        const numeric = createNumericControl(field, parent, width, button, keyboard,
          value => { if (model && !model.locked) model.edit(role, value) })
        fields.set(role, { kind, active, readonly: field.readonly, numeric })
        return
      }
      if (guiValueKind(kind) === 'boolean') {
        const control = button(role, field.label, parent, () => {
          if (!model.locked && active && !field.readonly) model.edit(role,
            model.values[role] === 'true' ? 'false' : 'true')
        }, `${width - 60}px`)
        const feedback = new TextBlock(`${role}-error`)
        feedback.height = '36px'; feedback.fontSize = 20; feedback.color = '#FFD7A8'
        feedback.text = 'This field must be confirmed.'
        parent.addControl(feedback)
        fields.set(role, { boolean: () => {
          const checked = model.values[role] === 'true'
          feedback.isVisible = !!field.required && !checked
          control.textBlock.text = kind === 'toggle' ? `${checked ? 'On' : 'Off'} — ${field.label}`
            : `${checked ? '☑' : '☐'} ${field.label}`
          control.isEnabled = !model.locked && active && !field.readonly
        } })
        return
      }
      if (kind === 'editor' || guiValueKind(kind) === 'text') {
        const control = kind !== 'text_box' ? new InputTextArea(role) : new InputText(role)
        control.height = kind !== 'text_box' ? '260px' : '54px'
        control.width = `${width - 60}px`
        control.fontSize = 24
        control.color = '#F5F1EB'
        control.background = '#0F1B20'
        control.focusedBackground = '#0F1B20'
        control.disabledColor = '#243B43'
        control.autoStretchHeight = false
        control.disableMobilePrompt = true
        control.onTextChangedObservable.add(() => {
          if (!synchronizing && control.isEnabled && model && !model.locked) model.edit(role, control.text)
        })
        parent.addControl(control)
        keyboard.connect(control)
        let feedback
        if (guiValueKind(kind) === 'text') {
          feedback = new TextBlock(`${role}-error`)
          feedback.height = '36px'; feedback.fontSize = 20; feedback.color = '#FFD7A8'
          feedback.textWrapping = true
          parent.addControl(feedback)
        }
        fields.set(role, { kind, active, readonly: field.readonly, control, feedback,
          required: field.required, maxBytes: field.maxBytes })
      } else if (kind === 'bindings') {
        const scroll = new ScrollViewer(`${role}-scroll`)
        scroll.height = '180px'
        scroll.barSize = 28
        scroll.background = '#0F1B20'
        const control = new TextBlock(role)
        control.color = '#F5F1EB'
        control.fontSize = 22
        control.textWrapping = true
        control.resizeToFit = true
        control.textHorizontalAlignment = 0
        scroll.addControl(control)
        parent.addControl(scroll)
        fields.set(role, { kind, control })
      } else if (guiValueKind(kind) === 'choice' || kind === 'catalogue_selection') {
        const selected = new TextBlock(`${role}-value`)
        selected.height = '48px'; selected.fontSize = 24; selected.color = '#F5F1EB'
        selected.background = '#0F1B20'
        selected.textWrapping = true
        parent.addControl(selected)
        const scroll = new ScrollViewer(`${role}-options`)
        scroll.width = `${width - 60}px`; scroll.barSize = 28
        scroll.background = '#0F1B20'
        const list = new StackPanel(role)
        scroll.addControl(list)
        parent.addControl(scroll)
        let signature = null
        let buttons = []
        fields.set(role, { kind, choices: () => {
          const options = model.choices?.[role] ?? field.options ?? []
          const current = JSON.stringify(options)
          if (signature !== current) {
            for (const child of [...list.children]) child.dispose()
            buttons = options.map((option, index) => ({ option,
              control: button(`${role}-option-${index}`, option.label, list, () => {
                if (!model.locked && active && !field.readonly) {
                  texture.focusedControl = null
                  model.edit(role, choiceDraft({ ...field, options }, model.values[role], option.value))
                }
              }, `${width - 110}px`),
            }))
            if (kind === 'table') for (const { control } of buttons) {
              // Labelled rows remain readable at every panel width/text scale.
              control.height = `${Math.max(58, (field.headings.length + 1) * 32)}px`
            }
            scroll.height = `${Math.min(3, Math.max(1, options.length)) * (kind === 'table' ? Math.max(58, (field.headings.length + 1) * 32) : 58)}px`
            signature = current
          }
          const selectedValues = choiceValues({ ...field, options }, model.values[role])
          selected.text = selectedValues?.length
            ? options.filter(option => selectedValues.includes(option.value)).map(option => option.label).join(', ') : 'Choose a value'
          for (const { option, control } of buttons) {
            const chosen = selectedValues?.includes(option.value)
            control.textBlock.text = `${chosen ? '● ' : '○ '}${kind === 'table'
              ? field.headings.map((heading, index) => `${heading}: ${option.cells[index]}`).join('\n') : option.label}`
            control.background = chosen ? '#496A78' : '#304C56'
            control.isEnabled = !model.locked && active && !field.readonly
          }
        } })
      } else {
        throw new Error(`Unsupported spatial GUI component: ${kind}`)
      }
    }
    component({ kind: 'container', role: 'workspace-content-root', label: '',
      layout: view.layout, children: view.fields }, content, 1200, view.enabled !== false)
    action('close-workspace', 'Close panel', () => model.close())
  }

  const panel = {
    owns: node => node === mesh,
    cancelPointer: id => cancelGuiPointer(texture, id),
    update(next, visible) {
      model = next
      if (lastView !== next.view) {
        const signature = JSON.stringify(next.view)
        if (schema !== signature) { rebuild(next.view); schema = signature }
        lastView = next.view
      }
      if (visible && !mesh.isVisible) {
        place()
      }
      mesh.isVisible = visible
      mesh.isPickable = visible
      if (!visible) {
        stopMoving()
        texture.focusedControl = null
        opacity._onCanvasBlur()
        for (const field of fields.values()) field.numeric?.cancel()
      }
      synchronizing = true
      title.text = next.view.title
      scope.text = next.scope
      keyboard.isEnabled = !next.locked
      for (const [role, field] of fields) {
        if (field.kind === 'button') {
          field.control.isEnabled = field.active && !!next.enabled[role]
          field.control.alpha = 1
        } else if (field.boolean) {
          field.boolean()
        } else if (field.choices) {
          field.choices()
        } else if (field.numeric) {
          field.numeric.update(next.values[role], !next.locked && field.active && !field.readonly)
        } else {
          const value = next.values[role] ?? ''
          field.control.text = value
          if (field.kind === 'editor' || guiValueKind(field.kind) === 'text') field.control.isEnabled = !next.locked && field.active && !field.readonly
          if (field.feedback) {
            field.feedback.text = textFeedback(field, value)
            field.feedback.isVisible = !!field.feedback.text
          }
        }
      }
      if (texture.focusedControl && !texture.focusedControl.isEnabled) texture.focusedControl = null
      synchronizing = false
    },
    dispose() {
      stopMoving()
      model = null
      texture.focusedControl = null
      opacity._onCanvasBlur()
      keyboard.disconnect()
      texture.dispose()
      mesh.dispose(false, true)
      canvas?.removeEventListener('keydown', escape)
      if (!sharedResources) resources.dispose()
    },
  }
  return panel
}
