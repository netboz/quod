import { strict as assert } from 'node:assert'
import { test } from 'node:test'
import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { createRenderResources, createSurface } from '../src/render-resources.js'
import { NullEngine } from '@babylonjs/core/Engines/nullEngine.js'
import { Scene } from '@babylonjs/core/scene.js'
import { Material } from '@babylonjs/core/Materials/material.js'

const bytes = new TextEncoder().encode('verified asset fixture')
const digest = createHash('sha256').update(bytes).digest('hex')
const binding = { digest, slot: 'base_colour', repeat: [1, 2.5] }

test('generated terrain uses shared verified model resources and real engine disposal', async () => {
  const payload = readFileSync(new URL('./fixtures/voxel-plane.qvt', import.meta.url))
  const terrain = { digest: createHash('sha256').update(payload).digest('hex'), profile: 'qvt1',
    payload, palette: new Map([[9, { colour: '#447722', metallic: 0, roughness: 0.9, emission: 0, textures: [] }]]),
    allowed: [500000, 1000000, 20000, 10000], bounds: [0, 0, 0, 4000, 4000, 4000] }
  const engine = new NullEngine(), scene = new Scene(engine)
  scene.useRightHandedSystem = true
  const resources = createRenderResources(scene, { fetchAsset: () => { throw new Error('terrain fetched a public asset') } })
  try {
    const a = resources.acquireModel(terrain), b = resources.acquireModel(terrain)
    const model = await a.ready
    assert.equal(await b.ready, model)
    assert.equal(model.meshes.length, 1)
    assert.equal(model.meshes[0].getTotalVertices(), 384)
    // Native upward triangles must be front-facing from above in the actual
    // right-handed scene, including after the model becomes an instance.
    assert.equal(model.meshes[0].sideOrientation, Material.CounterClockWiseSideOrientation)
    assert.equal(scene.meshes.length, 0)
    const instance = model.instantiateModelsToScene()
    assert.equal(instance.rootNodes.length, 1)
    assert.equal(instance.rootNodes[0].sideOrientation, Material.CounterClockWiseSideOrientation)
    assert.equal(scene.meshes.length, 1)
    a.release()
    assert.equal(model.meshes[0].isDisposed(), false)
    instance.dispose()
    const mesh = model.meshes[0]
    b.release()
    assert.equal(mesh.isDisposed(), true)
  } finally { resources.dispose(); scene.dispose(); engine.dispose() }
})

test('terrain verification and cancellation precede engine allocation', async () => {
  const payload = readFileSync(new URL('./fixtures/voxel-plane.qvt', import.meta.url))
  const terrain = { digest: createHash('sha256').update(payload).digest('hex'), profile: 'qvt1',
    payload, palette: new Map([[9, { colour: '#447722', metallic: 0, roughness: 0.9, emission: 0, textures: [] }]]),
    allowed: [500000, 1000000, 20000, 10000], bounds: [0, 0, 0, 4000, 4000, 4000] }
  let decodes = 0
  const resources = createRenderResources(null, { decodeTerrain: () => { decodes++; throw new Error('unexpected decoding') } })
  const cancelled = resources.acquireModel(terrain)
  cancelled.release()
  assert.equal(await cancelled.ready, null)
  const corrupt = resources.acquireModel({ ...terrain, digest: '0'.repeat(64) })
  await assert.rejects(corrupt.ready, /digest mismatch/)
  corrupt.release()
  const limited = resources.acquireModel({ ...terrain, allowed: [500000, 1, 20000, 10000] })
  await assert.rejects(limited.ready, /geometry bytes exceeded/)
  limited.release()
  assert.equal(decodes, 0)
  resources.dispose()
})
function fixture() {
  let reads = 0
  const decoded = []
  const resources = createRenderResources(null, {
    fetchAsset: async () => { reads++; return new Response(bytes) },
    decode: () => {
      const texture = { disposed: 0, dispose() { this.disposed++ } }
      decoded.push(texture)
      return { texture, ready: Promise.resolve() }
    },
  })
  return { resources, decoded, reads: () => reads }
}

test('terrain and ordinary surfaces share texture custody and preserve independent optical properties', async () => {
  const payload = Uint8Array.from(readFileSync(new URL('./fixtures/voxel-plane.qvt', import.meta.url)))
  const data = new DataView(payload.buffer)
  for (let t = 64; t < 128; t++) data.setUint16(16 + 38 * t + 36, 10)
  const definition = { colour: '#FFFFFF', metallic: 0.1, roughness: 0.6, emission: 0,
    textures: [binding] }
  const engine = new NullEngine(), scene = new Scene(engine)
  let fetches = 0, disposals = 0
  const shared = createRenderResources(scene, { fetchAsset: async () => { fetches++; return new Response(bytes) },
    decode: () => ({ texture: { dispose() { disposals++ } }, ready: Promise.resolve() }) })
  const ordinary = createSurface(scene, 'ordinary', definition, shared)
  const terrain = shared.acquireModel({ digest: createHash('sha256').update(payload).digest('hex'), profile: 'qvt1',
    payload, palette: new Map([[9, definition], [10, { ...definition, roughness: 0.9 }]]),
    originMm: [2n ** 100n, -4000n, 0n], allowed: [500000, 1000000, 20000, 10000], bounds: [0, 0, 0, 4000, 4000, 4000] })
  try {
    const model = await terrain.ready
    await ordinary.ready
    assert.equal(fetches, 1)
    assert.deepEqual(model.materials.map(m => m.roughness), [0.6, 0.9])
    assert.equal(model.meshes[0].subMeshes.length, 2)
    assert.equal(model.materials[0].albedoTexture, ordinary.material.albedoTexture)
    assert.equal(model.materials[1].albedoTexture, ordinary.material.albedoTexture)
    terrain.release()
    assert.equal(disposals, 0)
    ordinary.material.dispose()
    assert.equal(disposals, 1)
  } finally { terrain.release(); ordinary.material.dispose(); shared.dispose(); scene.dispose(); engine.dispose() }
})

test('shared bindings retain textures until their last consumer leaves', async () => {
  const { resources, decoded, reads } = fixture()
  const a = resources.acquire(binding)
  const b = resources.acquire(binding)
  const [one, two] = await Promise.all([a.ready, b.ready])
  assert.equal(one, two)
  assert.equal(reads(), 1)
  assert.equal(decoded.length, 1)
  assert.equal(one.gammaSpace, true)
  assert.equal(one.vScale, 2.5)
  a.release()
  assert.equal(one.disposed, 0)
  const c = resources.acquire(binding)
  assert.equal(await c.ready, one)
  assert.equal(reads(), 1)
  b.release(); c.release(); c.release()
  assert.equal(one.disposed, 1)
  resources.dispose()
})

test('different bindings share verified bytes and keep independent sampling', async () => {
  const { resources, decoded, reads } = fixture()
  const a = resources.acquire(binding)
  const b = resources.acquire({ ...binding, slot: 'normal', repeat: [3, 4] })
  const [one, two] = await Promise.all([a.ready, b.ready])
  assert.equal(reads(), 1)
  assert.equal(decoded.length, 2)
  assert.notEqual(one, two)
  assert.equal(one.gammaSpace, true)
  assert.equal(two.gammaSpace, false)
  assert.equal(two.vScale, 4)
  resources.dispose()
  a.release(); b.release()
  assert.equal(one.disposed, 1)
  assert.equal(two.disposed, 1)
  assert.throws(() => resources.acquire(binding), /disposed/)
})

test('corrupted bytes fail before image decoding', async () => {
  let decodes = 0
  const resources = createRenderResources(null, {
    fetchAsset: async () => new Response('wrong bytes'),
    decode: () => { decodes++; throw new Error('must not decode') },
  })
  const lease = resources.acquire(binding)
  await assert.rejects(lease.ready, /digest mismatch/)
  assert.equal(decodes, 0)
  lease.release(); resources.dispose()
})

test('last release cancels fetch; a late fetch response cannot create a texture', async () => {
  let complete, signal, decodes = 0
  const resources = createRenderResources(null, {
    fetchAsset: (_url, options) => {
      signal = options.signal
      return new Promise(resolve => { complete = resolve })
    },
    decode: () => { decodes++; throw new Error('must not decode') },
  })
  const lease = resources.acquire(binding)
  lease.release()
  assert.equal(signal.aborted, true)
  complete(new Response(bytes))
  assert.equal(await lease.ready, null)
  assert.equal(decodes, 0)
  resources.dispose()
})

test('release during decode disposes immediately and ignores late completion', async () => {
  let complete, started
  const loading = new Promise(resolve => { started = resolve })
  const texture = { disposed: 0, dispose() { this.disposed++ } }
  const resources = createRenderResources(null, {
    fetchAsset: async () => new Response(bytes),
    decode: () => {
      started()
      return { texture, ready: new Promise(resolve => { complete = resolve }) }
    },
  })
  const lease = resources.acquire(binding)
  await loading
  lease.release()
  assert.equal(texture.disposed, 1)
  complete()
  assert.equal(await lease.ready, null)
  resources.dispose()
})

const modelBytes = readFileSync(new URL('./fixtures/asymmetric.glb', import.meta.url))
const modelDigest = createHash('sha256').update(modelBytes).digest('hex')
const allowed = [8000000, 16000000, 250000, 250000, 1024, 256, 16000000]
const model = { digest: modelDigest, profile: 'gltf2-static-v1', allowed,
  bounds: [-300, 0, -400, 1200, 1400, 300] }

test('two model occurrences share verified bytes and one decoded template', async () => {
  let fetched = 0, decoded = 0, disposed = 0
  const resources = createRenderResources(null, {
    fetchAsset: async path => {
      assert.equal(path, `/assets/models/${modelDigest}.glb`)
      fetched++
      return new Response(modelBytes)
    },
    decodeModel: async () => {
      decoded++
      return { dispose() { disposed++ } }
    },
  })
  const a = resources.acquireModel(model)
  const b = resources.acquireModel(model)
  const [one, two] = await Promise.all([a.ready, b.ready])
  assert.equal(one, two)
  assert.deepEqual([fetched, decoded], [1, 1])
  a.release()
  assert.equal(disposed, 0)
  const c = resources.acquireModel(model)
  assert.equal(await c.ready, one)
  assert.deepEqual([fetched, decoded], [1, 1])
  b.release(); c.release()
  assert.equal(disposed, 1)
  resources.dispose()
})

test('measured costs deny decode and a stricter occurrence independently', async () => {
  let decoded = 0
  const resources = createRenderResources(null, {
    fetchAsset: async () => new Response(modelBytes),
    decodeModel: async () => { decoded++; return { dispose() {} } },
  })
  const denied = resources.acquireModel({ ...model,
    allowed: [modelBytes.length, 96, 6, 1, 3, 2, 4] })
  await assert.rejects(denied.ready, /triangles exceeded/)
  assert.equal(decoded, 0)
  denied.release()
  const granted = resources.acquireModel(model)
  assert.ok(await granted.ready)
  assert.equal(decoded, 1)
  granted.release(); resources.dispose()
})

test('a declared frame must match bounds measured from the verified asset', async () => {
  let decoded = 0
  const resources = createRenderResources(null, {
    fetchAsset: async () => new Response(modelBytes),
    decodeModel: async () => { decoded++; return { dispose() {} } },
  })
  const lease = resources.acquireModel({ ...model,
    bounds: [-400, -100, -800, 1300, 1800, 500] })
  await assert.rejects(lease.ready, /asset-local bounds differ/)
  assert.equal(decoded, 0)
  lease.release(); resources.dispose()
})

test('a late model decode cannot restore a released template', async () => {
  let complete, begun, disposed = 0
  const loading = new Promise(resolve => { begun = resolve })
  const resources = createRenderResources(null, {
    fetchAsset: async () => new Response(modelBytes),
    decodeModel: () => {
      begun()
      return new Promise(resolve => { complete = resolve })
    },
  })
  const lease = resources.acquireModel(model)
  await loading
  lease.release()
  complete({ dispose() { disposed++ } })
  assert.equal(await lease.ready, null)
  assert.equal(disposed, 1)
  resources.dispose()
})

test('a model digest mismatch stops before GLB parse and Babylon decode', async () => {
  let decoded = 0
  const resources = createRenderResources(null, {
    fetchAsset: async () => new Response('corrupt GLB'),
    decodeModel: async () => { decoded++; throw new Error('must not decode') },
  })
  const lease = resources.acquireModel(model)
  await assert.rejects(lease.ready, /digest mismatch/)
  assert.equal(decoded, 0)
  lease.release(); resources.dispose()
})

test('model transfer allowance stops the stream before GLB parsing or decode', async () => {
  let decoded = 0
  const resources = createRenderResources(null, {
    fetchAsset: async () => new Response(modelBytes),
    decodeModel: async () => { decoded++; throw new Error('must not decode') },
  })
  const lease = resources.acquireModel({ ...model, allowed: [20, ...allowed.slice(1)] })
  await assert.rejects(lease.ready, /transfer bytes exceeded/)
  assert.equal(decoded, 0)
  lease.release(); resources.dispose()
})

test('GUI image leases share verified texture bytes and revoke only at last release', async () => {
  const { resources, reads } = fixture()
  const texture = resources.acquire(binding)
  const a = resources.acquireImage(digest), b = resources.acquireImage(digest)
  const [url, same] = await Promise.all([a.ready, b.ready, texture.ready])
  assert.equal(url, same)
  assert.equal(reads(), 1)
  assert.deepEqual(new Uint8Array(await (await fetch(url)).arrayBuffer()), bytes)
  a.release(); texture.release()
  assert.equal((await fetch(url)).ok, true)
  const c = resources.acquireImage(digest)
  assert.equal(await c.ready, url)
  assert.equal(reads(), 1)
  b.release(); c.release(); c.release()
  await assert.rejects(fetch(url))
  resources.dispose()
  assert.throws(() => resources.acquireImage(digest), /disposed/)
})

test('retired GUI image completion never creates a URL and corruption is rejected', async () => {
  let complete
  const resources = createRenderResources(null, { fetchAsset: () => new Promise(resolve => { complete = resolve }) })
  const retired = resources.acquireImage(digest)
  retired.release(); complete(new Response(bytes))
  assert.equal(await retired.ready, null)
  const corrupt = resources.acquireImage(digest)
  complete(new Response('wrong bytes'))
  await assert.rejects(corrupt.ready, /digest mismatch/)
  corrupt.release(); resources.dispose()
})
