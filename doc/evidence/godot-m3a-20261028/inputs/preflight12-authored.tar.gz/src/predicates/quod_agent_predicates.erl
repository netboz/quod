-module(quod_agent_predicates).
-moduledoc """
Governed bridges for an ontology containing hosted agents. The containing
ontology explicitly declares this installed module; domain actions and policy remain Prolog.

`current_principal(-Principal)` reuses the authenticated-principal bridge.
Request signing uses the universal runtime bridge's exact proof scope; it
does not obtain identity from a live node observation.

Key preparation is an explicitly authorized read-only service over that same
scope. It retains stable encrypted custody without assigning or activating an
agent. The destination is explicit and its preparation policy is pure Prolog.
The optional receipt binds its result to this executor for a later assignment;
verification uses supplied immutable bytes and that proof's bound signer only.
""".

-include_lib("erlog/src/erlog_int.hrl").

-export([quod_predicate_module/0, load/1,
         sign_agent_request/3, reconcile_agent_hosts/3, reconcile_agent_observers/3,
         local_node_agent/3, installed_agent_reaction/3, prepare_agent_key_custody/3,
         prepared_agent_key_custody/3]).

quod_predicate_module() -> true.

-spec load(tuple()) -> tuple().
load(Est) ->
    WithLocalNode = quod_predicates:register(Est, {local_node_agent, 1}, query,
                                             ?MODULE, local_node_agent),
    WithCustody = quod_predicates:register(WithLocalNode, {prepare_agent_key_custody, 5}, query,
                                           ?MODULE, prepare_agent_key_custody),
    WithReceipt = quod_predicates:register(WithCustody, {prepare_agent_key_custody, 6}, query,
                                           ?MODULE, prepare_agent_key_custody),
    WithVerification = quod_predicates:register(WithReceipt, {prepared_agent_key_custody, 6},
                                           query, proof_bound, ?MODULE, prepared_agent_key_custody),
    WithSigning = quod_predicates:register(WithVerification, {sign_agent_request, 2}, query,
                                           ?MODULE, sign_agent_request),
    WithHandler = quod_predicates:register(WithSigning, {installed_agent_reaction, 5}, query,
                                            ?MODULE, installed_agent_reaction),
    WithHosting = quod_predicates:register(WithHandler, {reconcile_agent_hosts, 1}, query,
                                            ?MODULE, reconcile_agent_hosts),
    quod_predicates:register(WithHosting, {reconcile_agent_observers, 1}, query,
                              ?MODULE, reconcile_agent_observers).

-doc "Observe the installed local node identity; this is not committed proof authority.".
-spec local_node_agent(term(), term(), tuple()) -> term().
local_node_agent({local_node_agent, Node}, Next, St) ->
    case quod_node_actor:reference() of
        {ok, NodeRef} ->
            erlog_int:unify_prove_body(Node, NodeRef, Next, St);
        _ -> quod_predicates:fail_reason(node_actor_unavailable,St)
    end.

%% This observation stays inside native read-only preparation. It grants no
%% reaction authority and cannot turn current installation into a material read.
installed_agent_reaction({installed_agent_reaction, I0, E0, K0, C0, Token}, Next,
                         St = #est{bs = Bs}) ->
    Context = quod_predicates:context(St),
    case quod_predicates:ctx_kind(Context) of
        proof -> ok;
        Kind -> erlog_int:erlog_error(
            {context_violation, installed_agent_reaction, query, Kind}, St)
    end,
    case quod_proof_session:read_only_state(St) of
        true -> ok;
        false -> erlog_int:erlog_error(
            {context_violation, installed_agent_reaction, query, write_proof}, St)
    end,
    [Instance, Epoch, Key, Clause] = erlog_int:dderef([I0,E0,K0,C0], Bs),
    case quod_wire_term:is_ground([Instance,Epoch,Key]) of
        true -> ok;
        false -> erlog_int:instantiation_error(St)
    end,
    case {Epoch, Key, Clause} of
        {E, <<_:256>>, {':-', {react_on, _, _}, _}} when is_integer(E), E > 0 -> ok;
        _ -> erlog_int:domain_error(agent_handler, {Instance,Epoch,Key,Clause}, St)
    end,
    case quod_runtime_predicates:scope_identity(St) of
        {ok, {Ns, Anchor}} ->
            Remaining = case quod_scope_session:remaining_ms() of
                {ok, Budget} -> Budget;
                error -> quod_proof_context:remaining_ms()
            end,
            case quod_runtime:installed_agent_reaction(
                   Ns, Anchor, quod_predicates:ctx_height(Context),
                   {agent,Instance,Epoch,Key}, Clause, quod_time:mono_ms()+Remaining) of
                {ok, Incarnation} ->
                    Digest = crypto:hash(sha256,term_to_binary(Incarnation)),
                    erlog_int:unify_prove_body(Token,Digest,Next,St);
                {error, Reason} -> quod_predicates:fail_reason(Reason,St)
            end;
        error -> quod_predicates:fail_reason(scope_identity_unavailable,St)
    end.

-doc "Ask the existing resource owner to reconcile from its own committed selection.".
reconcile_agent_hosts({reconcile_agent_hosts, Scope}, Next, St) ->
    quod_runtime_predicates:request_resource(agent_hosts, Scope, Next, St).

reconcile_agent_observers({reconcile_agent_observers, Scope}, Next, St) ->
    quod_runtime_predicates:request_resource(agent_observers, Scope, Next, St).

-doc "Prepare stable custody for an exact prior assignment, including none/0.".
prepare_agent_key_custody({prepare_agent_key_custody, A0, H0, E0, N0, K0}, Next,
                          St) ->
    custody_read_context(St),
    Finish = fun(PublicKey) -> erlog_int:unify_prove_body(K0, PublicKey, Next, St) end,
    prepare_custody(A0, H0, E0, N0, K0, Finish, St);
prepare_agent_key_custody({prepare_agent_key_custody, A0, H0, E0, N0, K0, Receipt}, Next,
                          St = #est{bs = Bs}) ->
    custody_read_context(St),
    case erlog_int:dderef(Receipt,Bs) of
        {_} -> ok;
        Value -> erlog_int:domain_error(custody_receipt_output,Value,St)
    end,
    case quod_proof_session:signer_from_state(St) of
        #{pubkey := <<_:256>>} = Signer ->
            Finish = fun(PublicKey) ->
                [Agent, Host, Epoch, Node] = erlog_int:dderef([A0,H0,E0,N0], Bs),
                {ok,Bytes} = custody_bytes(Agent, Host, Epoch, Node, PublicKey),
                Signature = quod_identity:sign(Bytes, Signer),
                erlog_int:unify_prove_body([K0,Receipt], [PublicKey,Signature], Next, St)
            end,
            prepare_custody(A0, H0, E0, N0, K0, Finish, St);
        none -> quod_predicates:fail_reason(custody_executor_unavailable, St)
    end.

custody_read_context(St) ->
    Context = quod_predicates:context(St),
    case quod_predicates:ctx_kind(Context) of
        proof -> ok;
        Kind -> erlog_int:erlog_error(
            {context_violation, prepare_agent_key_custody, query, Kind}, St)
    end.

prepare_custody(A0, H0, E0, N0, K0, Finish,
                          St = #est{bs = Bs}) ->
    case quod_proof_session:read_only_state(St) of
        true -> ok;
        false -> erlog_int:erlog_error(
            {context_violation, prepare_agent_key_custody, query, write_proof}, St)
    end,
    [Agent, Host, Epoch, Node, Key] = erlog_int:dderef([A0,H0,E0,N0,K0], Bs),
    case quod_wire_term:is_ground([Agent,Host,Epoch,Node]) of
        true -> ok;
        false -> erlog_int:instantiation_error(St)
    end,
    case {Agent, Epoch, Key} of
        {{agent_instance_ref, Ns, <<_:256>> = Anchor, Instance}, E, {_}}
          when is_binary(Ns), byte_size(Ns) > 0, is_integer(E), E >= 0, E < (1 bsl 64) ->
            case quod_runtime_predicates:scope_identity(St) of
                {ok, {Ns, Anchor}} ->
                    case local_destination(Node) of
                        true -> authorize_custody(Agent, Instance, Host, Epoch, Node, Finish, St);
                        false -> quod_predicates:fail_reason(custody_destination_unavailable, St)
                    end;
                _ -> erlog_int:erlog_error(
                    {context_violation, prepare_agent_key_custody, query, foreign_scope}, St)
            end;
        _ -> erlog_int:domain_error(agent_key_preparation, {Agent,Host,Epoch,Node,Key}, St)
    end.

local_destination(Node) ->
    quod_node_actor:reference() =:= {ok, Node}.

authorize_custody(Agent, Instance, Host, Epoch, Node, Finish, St = #est{vn = Vn}) ->
    Blob = case quod_wire_term:encode_canonical(Agent) of
        {ok, Encoded} ->
            case quod_agent_ref:decode(Encoded) of
                {ok, _} -> Encoded;
                _ -> erlog_int:domain_error(agent_reference, Agent, St)
            end;
        _ -> erlog_int:domain_error(agent_reference, Agent, St)
    end,
    {succeed, PrincipalState} = erlog_int:prove_goal({current_principal, {Vn}}, St),
    Caller = erlog_int:dderef({Vn}, PrincipalState#est.bs),
    Policy = {agent_key_preparation, Caller, Instance, Host, Epoch, Node},
    case quod_ask:committed_authorization_result(Policy, St) of
        allowed ->
            Deadline = case quod_scope_session:remaining_ms() of
                {ok, Remaining} -> quod_time:mono_ms() + Remaining;
                error -> quod_proof_context:deadline_ms()
            end,
            case quod_agent_vault:prepare(Blob, Epoch, Deadline) of
                {ok, PublicKey} ->
                    %% The installed destination may have withdrawn while the
                    %% vault was busy. Its staged key remains inert and reusable.
                    case local_destination(Node) of
                        true -> Finish(PublicKey);
                        false -> quod_predicates:fail_reason(custody_destination_unavailable, St)
                    end;
                {error, Reason} -> quod_predicates:fail_reason({agent_custody_unavailable, Reason}, St)
            end;
        denied -> erlog_int:fail(St);
        invalid -> erlog_int:erlog_error(invalid_custody_policy, St)
    end.

%% Verification uses only supplied immutable bytes and the executor already
%% bound to this proof. It never observes, prepares or repairs live custody.
%% Domain policy still decides whether this exact prior assignment is allowed.
prepared_agent_key_custody({prepared_agent_key_custody, A0,H0,E0,N0,K0,R0}, Next,
                           St = #est{bs = Bs}) ->
    [Agent,Host,Epoch,Node,Key,Receipt] = erlog_int:dderef([A0,H0,E0,N0,K0,R0], Bs),
    case quod_wire_term:is_ground([Agent,Host,Epoch,Node,Key,Receipt]) of
        false -> erlog_int:instantiation_error(St);
        true ->
            case {Agent, Key, Receipt, quod_runtime_predicates:scope_identity(St),
                  quod_proof_session:signer_from_state(St)} of
                {{agent_instance_ref,Ns,Anchor,_}, <<_:256>>, <<_:512>>,
                 {ok,{Ns,Anchor}}, #{pubkey := Executor}} ->
                    case custody_bytes(Agent,Host,Epoch,Node,Key) of
                        {ok,Bytes} ->
                            case quod_identity:verify(Receipt,Bytes,Executor) of
                                true -> erlog_int:prove_body(Next, St);
                                false -> quod_predicates:fail_reason(invalid_custody_receipt, St)
                            end;
                        error -> quod_predicates:fail_reason(invalid_custody_receipt, St)
                    end;
                _ -> quod_predicates:fail_reason(invalid_custody_receipt, St)
            end
    end.

custody_bytes(Agent,Host,Epoch,Node,Key) ->
    case quod_wire_term:encode_canonical([Agent,Host,Epoch,Node,Key]) of
        {ok,Bytes} -> {ok,<<"quod.prepared-agent-custody.v1",0,Bytes/binary>>};
        {error,_} -> error
    end.

-doc "Authorize one canonical request in a committed read-only session before releasing its signature.".
-spec sign_agent_request(term(), term(), tuple()) -> term().
sign_agent_request({sign_agent_request, Typed0, Signature}, Next, #est{bs = Bs} = St) ->
    case quod_proof_session:read_only_state(St) of
        true -> sign_typed(erlog_int:dderef(Typed0, Bs), Signature, Next, St);
        false -> erlog_int:erlog_error({context_violation,sign_agent_request,query,write_proof},St)
    end.

sign_typed(Typed, Signature, Next, St) ->
    case quod_wire_term:is_ground(Typed) of
        false -> erlog_int:instantiation_error(St);
        true ->
            case quod_client_goal:encode_typed(Typed) of
                {error, _} -> erlog_int:domain_error(agent_request, Typed, St);
                {ok, #{agent_namespace := Ns, agent_genesis_anchor := Anchor} = Request, _} ->
                    case quod_runtime_predicates:scope_identity(St) of
                        error -> quod_predicates:fail_reason({scope_identity_unavailable,Ns},St);
                        {ok,{Ns,Anchor}} ->
                            case quod_node_actor:principal() of
                                {ok,NodePrincipal} ->
                                    case quod_agent_ref:materialize_principal(NodePrincipal) of
                                        {ok,NodeRef} ->
                                            authorize_sign(Request,Typed,NodeRef,Signature,Next,St);
                                        _ -> erlog_int:domain_error(agent_request,Typed,St)
                                    end;
                                _ -> quod_predicates:fail_reason(node_actor_unavailable,St)
                            end;
                        {ok,_} -> erlog_int:erlog_error(
                            {context_violation,sign_agent_request,query,foreign_scope},St)
                    end
            end
    end.

authorize_sign(Request, Typed, NodeRef,
               Signature, Next, #est{vn = Vn} = St) ->
    %% All arguments except the engine-authenticated caller are ground. The
    %% existing interpreter evaluates the ordinary ontology policy against this
    %% immutable read-only session; no staged grant can authorize this release.
    Now = quod_time:mono_ms(),
    Remaining = case quod_scope_session:remaining_ms() of
        {ok, Budget} -> Budget;
        error -> quod_proof_context:remaining_ms()
    end,
    Deadline = Now + Remaining,
    Policy = {',', {current_principal, {Vn}},
              {can_sign_agent_request, {Vn}, NodeRef, Typed}},
    case quod_ask:authorization_result(Policy, St) of
        allowed ->
            case quod_agent_vault:sign(Request, Deadline) of
                {ok, _Bytes, Signed} ->
                    erlog_int:unify_prove_body(Signature, Signed, Next, St);
                {error,Reason} -> quod_predicates:fail_reason({agent_signing_unavailable,Reason},St)
            end;
        denied -> erlog_int:fail(St);
        invalid -> erlog_int:erlog_error(invalid_signing_policy,St)
    end.
