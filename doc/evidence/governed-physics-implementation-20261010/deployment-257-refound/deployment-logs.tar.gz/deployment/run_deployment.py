from pathlib import Path
import json,os,shutil,subprocess,sys,time
out=Path('/home/yan/src/quod/_build/quod27-release-257/deployment')
state=out/'execution';state.mkdir()
def run(label,args,env=None):
 with (state/(label+'.intent.json')).open('x') as f: json.dump({'command':args},f,indent=2)
 print('Starting '+label,flush=True);start=time.monotonic()
 with (state/(label+'.log')).open('x') as log:
  result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'label':label,'command':args,'exit':result.returncode,'seconds':time.monotonic()-start}
 (state/(label+'.exit.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
 if result.returncode:
  (state/'STOP.json').write_text(json.dumps(row,indent=2)+'\n');raise SystemExit(result.returncode)
def script(label):run(label,[sys.executable,str(out/(label+'.py'))])
script('build')
script('prepare_refound')
refound=out/'refound'
for name in ('quod_fresh_systems.erl','quod_fresh_systems.beam','fresh_system_operator.py'):
 shutil.copy2(out/name,refound/name)
script('create_new_volumes')
script('bootstrap')
operator=refound/'fresh_system_operator.py'
for phase in ('load','root-info'):
 run(phase,[sys.executable,str(operator),phase])
root=json.loads((refound/'root-info.json').read_text())['root_anchor']
assert root != '3F88D70B7714366EE11D38764231DD2F6EE8AAFC58EB8C0559146543E5280F26', 'Old root was retained after refound'
for phase in ('found','publish'):
 run(phase+'-node',[sys.executable,str(operator),phase,'node'])
for phase in ('policy-node','request-enrollment','wait-principal','enrollment-evidence'):
 run(phase,[sys.executable,str(operator),phase])
script('install_remaining')
for phase in ('policy-apps','delegate-signup','final-gate'):
 run(phase,[sys.executable,str(operator),phase])
script('scale_out')
script('watch_deployment')
script('fleet_probe')
script('discover_client')
env=dict(os.environ,NODE_TLS_REJECT_UNAUTHORIZED='0')
run('signed-source-check',['node',str(out/'signed_source_check.mjs')],env=env)
(state/'PASSED.json').write_text(json.dumps({'passed':True,'release':'0.7.257','scope':'candidate network only','signed_smoke_ledger_writes':0},indent=2)+'\n')
print('Deployment, refound and signed release checks passed.',flush=True)
