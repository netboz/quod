from pathlib import Path
import json,urllib.request
out=Path('/home/yan/src/quod/_build/quod27-release-258/deployment/refound')
address='http://192.168.1.10:4646'
probe=json.loads((out/'fleet-probe.json').read_text());assert probe['passed']
allocation=probe['allocations'][0]['allocation']
with urllib.request.urlopen(address+'/v1/allocation/'+allocation,timeout=30) as response: detail=json.load(response)
ports=detail['AllocatedResources']['Shared']['Ports']
client=[p for p in ports if p['Label']=='client'];assert len(client)==1,ports
p=client[0];origin='https://'+p['HostIP']+':'+str(p['Value'])
record={'origin':origin,'allocation':allocation,'root_anchor':json.loads((out/'root-info.json').read_text())['root_anchor']}
(out/'client-endpoint.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
