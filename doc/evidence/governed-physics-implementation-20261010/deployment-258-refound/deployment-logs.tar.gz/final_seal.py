from pathlib import Path
import base64,json,subprocess,urllib.request,datetime
p=Path(__file__).resolve().parent
out=p/'final-seal';out.mkdir()
fleet=json.loads((p/'refound/fleet-probe.json').read_text())
def get(path):return json.loads(urllib.request.urlopen('http://192.168.1.10:4646'+path).read())
candidate=get('/v1/job/quod-finality-candidate-v6-20260926');main=get('/v1/job/quod')
volumes=get('/v1/volumes?type=host')
old='quod-finality-candidate-v6-20260926-refound-20261011-v4'
old_rows=[v for v in volumes if old in json.dumps(v)]
assert not old_rows
rows=[]
for i,node in enumerate(fleet['allocations'][:2]):
 expr='Cleanup=[#{module=>M,deleted=>code:delete(M),purged=>code:soft_purge(M)}||M<-[quod_remote_collider_evidence,quod_fresh_systems]], #{root_applied=>quod_prolog:applied(<<"quod:root">>),world_state=>iolist_to_binary(io_lib:format("~0p",[quod_ontology:local_state(<<"acceptance:physics:258:gallery">>)])),source_state=>iolist_to_binary(io_lib:format("~0p",[quod_ontology:local_state(<<"acceptance:physics:258:objects">>)])),cleanup=>Cleanup}'
 command=['nomad','alloc','exec','-i=false','-t=false','-address=http://192.168.1.10:4646','-task','quod',node['allocation'],'/opt/quod/bin/quod','eval','binary_to_list(base64:encode(iolist_to_binary(json:encode(begin '+expr+' end)))).']
 (out/(str(i)+'.intent.json')).write_text(json.dumps({'command':command},indent=2)+'\n')
 r=subprocess.run(command,capture_output=True,text=True)
 (out/(str(i)+'.stdout')).write_text(r.stdout);(out/(str(i)+'.stderr')).write_text(r.stderr)
 (out/(str(i)+'.exit.json')).write_text(json.dumps({'child_exit':r.returncode})+'\n');assert r.returncode==0
 wire=json.loads(r.stdout)
 if isinstance(wire,list):wire=bytes(wire).decode()
 answer=json.loads(base64.b64decode(wire));rows.append(answer)
 assert answer['root_applied']==62 and answer['world_state']=='{ok,not_hosted}' and answer['source_state']=='{ok,not_hosted}'
 assert all(row['purged'] for row in answer['cleanup'])
seal={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':{'version':candidate['Version'],'modify_index':candidate['JobModifyIndex']},'main':{'version':main['Version'],'modify_index':main['JobModifyIndex']},'old_volume_family_absent':old,'checks':rows}
(out/'seal.json').write_text(json.dumps(seal,indent=2)+'\n')
assert seal['candidate']=={'version':61,'modify_index':845205}
assert seal['main']=={'version':246,'modify_index':826727}
print(json.dumps(seal,indent=2))
