from pathlib import Path
import subprocess,json,time,datetime,hashlib
p=Path(__file__).resolve().parent
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
command=['python3',str(p/'long-movement.py')]
with (p/'movement.log').open('x') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
record={'command':command,'started':start,'exit':r.returncode,'seconds':time.monotonic()-t,'script_sha256':hashlib.sha256((p/'long-movement.py').read_bytes()).hexdigest()}
with (p/'movement-exit.json').open('x') as out:json.dump(record,out,indent=2);out.write('\n')
print(json.dumps(record),flush=True)
raise SystemExit(r.returncode)
