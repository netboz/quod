from pathlib import Path
import json,subprocess,sys,time,datetime
p=Path(__file__).resolve().parent
label,key,ms=sys.argv[1:]
keys={'up':'\ue013','down':'\ue015','left':'\ue012','right':'\ue014','down-left':'\ue015\ue012','up-right':'\ue013\ue014'}
assert key in keys and 0<int(ms)<=3000
command=[sys.executable,str(p/'visible-step.py'),label,keys[key],ms]
t=time.monotonic()
with (p/(label+'.log')).open('x') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
receipt={'command':command,'exit':r.returncode,'seconds':time.monotonic()-t,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (p/(label+'-exit.json')).open('x') as out:json.dump(receipt,out,indent=2)
if (p/(label+'-summary.json')).exists():print((p/(label+'-summary.json')).read_text())
else:print(json.dumps(receipt))
raise SystemExit(r.returncode)
