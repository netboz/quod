"""Derive the desktop acceptance receipt from retained browser observations."""
from pathlib import Path
import hashlib, json, math, re

p = Path(__file__).resolve().parent
def read(name):
    return json.loads((p / name).read_text())

def frames(label):
    return [r['data']['frame'] for r in read(label + '-frames.json')
            if r['data']['type'] == 'simulation_frame']

def pose(frame):
    body = next(r for r in frame['poses'] if r['body'] == '2')
    assert body['revision'] == '1'
    return body['position']

def contacts(frame):
    return set(re.findall(r'contact\((\d+),', frame['control_state']['result']))

def checked_step(label):
    assert read(label + '-exit.json')['exit'] == 0
    responses = read(label + '-control-responses.json')
    assert responses and all(r['result'] == 'ok' for r in responses)
    result = frames(label)
    assert result
    return result

initial = next(r['data'] for r in read('signed-view-before.json')['events']
               if r['data']['type'] == 'projection')
fence_keys = ['world', 'authority', 'epoch', 'generation', 'schema', 'incarnation', 'structure']
fence = {key: initial['frame'][key] for key in fence_keys}
for source in p.glob('*-frames.json'):
    for row in json.loads(source.read_text()):
        if row['data']['type'] != 'simulation_frame':
            continue
        frame = row['data']['frame']
        assert {key: frame[key] for key in fence_keys} == fence, source
        pose(frame)

console = checked_step('console-contact-01')
console_contacts = [f for f in console if '4' in contacts(f)]
assert console_contacts
roof = checked_step('low-roof-contact-08')
roof_contacts = [f for f in roof if '3' in contacts(f)]
assert len(roof_contacts) >= 2
assert math.dist(pose(roof_contacts[0]), pose(roof_contacts[-1])) < 1e-9
opening = []
for label in ['opening-approach-15', 'opening-traverse-16', 'opening-crossed-17']:
    opening.extend(checked_step(label))
assert all(contacts(f) == {'1'} for f in opening)
assert pose(opening[0])[2] < 5.3 and pose(opening[-1])[2] > 8.0
assert all(2.5 < math.hypot(pose(f)[0], pose(f)[2]) < 8.3 for f in opening)
parked = checked_step('park-inward-18')
final = read('final-parked-19.json')
final_frame = next(r['data']['frame'] for r in final['events']
                   if r['data']['type'] in ['simulation_frame', 'projection'])
assert {key: final_frame[key] for key in fence_keys} == fence
assert pose(final_frame) == pose(parked[-1])
assert final['camera']['position'] == [0, 0, 0]
assert math.isclose(final['camera']['parent'][1] - pose(final_frame)[1], 0.7)
assert final['camera']['inputs'] == ['mouse']
assert 'Physical space ready.' in final['dom']['text']
marks = read('final-mark-verification.json')
assert marks['same_six_authored_mark_nodes'] and marks['same_camera_local']
identities = read('retained-view-identities.json')
assert identities['same_authored_scene'] and identities['same_control_binding_and_authored_viewpoint']
assert hashlib.sha256(initial['marks'].encode()).hexdigest() == identities['marks_sha256']
movement = read('analysis.json')
assert movement['acceptance'] == 'passed' and all(movement['checks'].values())
assert movement['movement_child_exit'] == 0
reconnect = read('ordinary-reconnect-11-check.json')
assert all(reconnect[k] for k in ['normal_reload', 'same_camera_mount_position',
           'same_run_generation_and_incarnation', 'same_body_revision', 'ready',
           'no_input_sent_by_failed_steps'])
for label in reconnect['prior_input_guard_failures']:
    assert read(label + '-exit.json')['exit'] == 1
    assert not (p / (label + '-frames.json')).exists()
    assert not (p / (label + '-control-responses.json')).exists()
closed = read('browser-exit.json')
assert closed['harness_exit'] == 0 and closed['browser_process_gone']
console_text = read('console-read.json')['dom']['text']
assert 'current_principal(P).' in console_text and 'human:5pU3X8evhfH09g1ctl0LRRP80zmhd6M7g8OQ7DyOeaE' in console_text
receipt = {
    'passed': True, 'release': '0.7.263', 'same_fence_all_short_steps': True,
    'world_and_run': fence, 'body': '2', 'body_revision': '1',
    'console': {'contact_frames': len(console_contacts), 'sample': console_contacts[-1],
                'ordinary_read_succeeded': True},
    'roof': {'contact_frames': len(roof_contacts), 'blocked_pose': pose(roof_contacts[-1]),
             'sample': roof_contacts[-1]},
    'opening': {'frame_count': len(opening), 'start': pose(opening[0]),
                'end': pose(opening[-1]), 'only_floor_contacts': True},
    'movement': movement, 'reconnect': reconnect,
    'authored_identity_and_scene': identities,
    'final_parked_body_position': pose(final_frame), 'camera_eye_offset_y': 0.7,
    'browser_closed': closed,
    'retained_harness_corrections': ['interaction-harness-notes.json', 'final-mark-verification.json'],
    'limits': ['Bounded desktop sample, not a guarantee of zero pauses under every load.',
               'Sign-in expiry remains a hard stop; ordinary reload reauthenticates.',
               'Vive/WebXR and durable real-world door consequences are separate acceptance.']}
with (p / 'PASSED.json').open('x') as f:
    json.dump(receipt, f, indent=2)
    f.write('\n')
print(json.dumps({'passed': True, 'console_contact_frames': len(console_contacts),
                  'roof_contact_frames': len(roof_contacts), 'opening_frames': len(opening),
                  'movement_seconds': movement['elapsed_seconds'],
                  'parked_body': pose(final_frame), 'browser_closed': True}))
