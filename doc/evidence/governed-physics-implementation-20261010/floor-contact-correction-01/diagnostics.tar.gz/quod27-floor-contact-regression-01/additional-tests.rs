
    #[test]
    fn separating_floor_keeps_close_walls_in_the_same_mesh() {
        for (roll,yaw,offset) in [(0.0,0.0,(0.0,0.0,0.0)),(-0.37,0.83,(13.4,-7.0,12.5))] {
            for (start,delta) in [((2.9485,0.7510,2.7),Vector::new(0.04,0.02,0.0)),
                                  ((2.9485,0.7510,2.9485),Vector::new(0.04,0.02,0.04))] {
                let (mut world,frame)=surface_world(start,roll,yaw,offset,true);
                let answer=apply(&mut world,2,1,Query::Travel(tuple(frame.rotation*delta),(0.0,0.0,0.0)),(0.002,0.0,8,128));
                eprintln!("close-mesh roll={roll} start={start:?}: {answer:?}");
                let p=end(answer);
                let local=frame.inverse_transform_point(Vector::new(p.0 as f32,p.1 as f32,p.2 as f32));
                assert!(local.x<=2.9501 && local.z<=2.9501,"wall missed: {local:?}");
                assert!(local.y>0.77,"separating travel blocked: {local:?}");
                assert!(surface_distance(&world)>=0.0);
            }
            let (mut world,frame)=surface_world((2.9485,0.7510,2.9485),roll,yaw,offset,true);
            let start=*world.bodies[world.rows[&2].1].translation();
            let result=apply(&mut world,2,1,Query::Travel(tuple(frame.rotation*Vector::new(-0.04,0.02,-0.04)),(0.0,0.0,0.0)),(0.002,0.0,8,128));
            let p=end(result);let local=frame.rotation.inverse()*(Vector::new(p.0 as f32,p.1 as f32,p.2 as f32)-start);
            assert!(local.x < -0.039 && local.z < -0.039 && local.y>0.019,"separating contact blocked: {local:?}");
        }
    }

    #[test]
    fn contact_preflight_preserves_authored_hole() {
        let (world,_)=surface_world((0.0,0.8,0.0),0.0,0.0,(0.0,0.0,0.0),false);
        let p=end(evaluate(&world,2,1,Query::Travel((0.0,-1.0,0.0),(0.0,0.0,0.0)),(0.002,0.0,8,128)));
        assert!(p.1 < -0.19,"hole filled: {p:?}");
        assert_eq!(evaluate(&world,2,1,Query::Land((0.0,0.8,0.0),1.0,1.0,0.9),(0.002,0.0,8,128)),Answer::NoSupport);
    }

    #[test]
    fn added_contact_queries_obey_the_existing_allowance() {
        let (world,_)=surface_world((5.128269672393799,0.7517002820968628,1.5401973724365234),0.0,0.0,(0.0,0.0,0.0),false);
        let make=||Query::Travel((-0.007050141,-0.002725109001090001,-0.032567318),(0.0,0.0,0.0));
        let full=evaluate(&world,2,1,make(),(0.002,0.0,8,128));
        let Answer::Clipped(_,_,used)=full else {panic!("unexpected {full:?}")};
        assert!(used>0);
        assert_eq!(evaluate(&world,2,1,make(),(0.002,0.0,8,used)),full);
        assert_eq!(evaluate(&world,2,1,make(),(0.002,0.0,8,used-1)),Answer::Exhausted);
    }
