
    #[test]
    fn long_reciprocal_surface_walk_makes_progress() {
        for (roll,yaw,offset) in [(0.0,0.0,(0.0,0.0,0.0)),(-0.37,0.83,(13.4,-7.0,12.5))] {
            let (mut world,frame)=surface_world((5.2685847,0.751785,1.8875018),roll,yaw,offset,false);
            let mut total=0;
            for cycle in 0..42 {
                for (x,z,ticks) in [(-0.423,-1.954,36),(0.423,1.954,36),(-1.954,0.423,16),(1.954,-0.423,16)] {
                    for _ in 0..ticks {
                        let before=world.bodies[world.rows[&2].1].translation();
                        let delta=frame.rotation*Vector::new(x*0.016667,-0.002725109,z*0.016667);
                        let answer=apply(&mut world,2,1,Query::Travel(tuple(delta),(0.0,0.0,0.0)),(0.002,0.0,8,128));
                        let p=match answer {
                            Answer::Clear((p,_),_) | Answer::Clipped((p,_),_,_) => p,
                            _ => panic!("roll={roll} cycle={cycle} step={total} before={before:?}: {answer:?}"),
                        };
                        let progress=frame.rotation.inverse()*(Vector::new(p.0 as f32,p.1 as f32,p.2 as f32)-before);
                        assert!(progress.x.hypot(progress.z)>0.03,"floor stall roll={roll} step={total}: {progress:?}");
                        assert!(surface_distance(&world)>=0.0,"overlap roll={roll} step={total}: {p:?}");
                        world.step().unwrap();total+=1;
                    }
                }
            }
            eprintln!("walk roll={roll} steps={total} end={:?}",world.bodies[world.rows[&2].1].translation());
        }
    }
