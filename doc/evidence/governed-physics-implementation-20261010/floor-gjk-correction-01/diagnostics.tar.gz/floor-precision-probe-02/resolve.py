from pathlib import Path
import subprocess,json,datetime
b=Path(__file__).resolve().parent
args=['cargo','metadata','--format-version','1','--manifest-path',str(b/'crate/Cargo.toml')]
with (b/'metadata.json').open('xb') as out,(b/'resolve.log').open('xb') as err:r=subprocess.run(args,stdout=out,stderr=err)
(b/'resolve-exit.json').write_text(json.dumps({'child_exit':r.returncode,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print(json.dumps({'child_exit':r.returncode}));raise SystemExit(r.returncode)
