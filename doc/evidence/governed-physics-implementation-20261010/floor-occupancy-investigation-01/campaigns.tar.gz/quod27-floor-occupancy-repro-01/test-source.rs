
    #[test]
    fn captured_clear_floor_travel_makes_progress() {
        let cases = [
            ((5.128269672393799,0.7517002820968628,1.5401973724365234),(-0.423,-1.954)),
            ((5.241491794586182,0.751920759677887,2.8427703380584717),(-1.954,0.423)),
            ((5.593716621398926,0.751710057258606,1.9480516910552979),(0.423,1.954)),
        ];
        let mut failures = Vec::new();
        for (start,(x,z)) in cases {
            let (mut world,_) = surface_world(start,0.0,0.0,(0.0,0.0,0.0),false);
            let delta = (x*0.016667,-9.81*0.016667*0.016667,z*0.016667);
            let before = surface_distance(&world);
            let answer = apply(&mut world,2,1,Query::Travel(delta,(0.0,0.0,0.0)),(0.002,0.0,8,128));
            eprintln!("captured start={start:?} delta={delta:?} distance={before:?} answer={answer:?}");
            match answer {
                Answer::Clear((p,_),_) | Answer::Clipped((p,_),_,_) => {
                    if (p.0-start.0).hypot(p.2-start.2) < 0.03 { failures.push(start); }
                }
                _ => failures.push(start),
            }
        }
        assert!(failures.is_empty(),"clear floor failed to advance: {failures:?}");
    }
