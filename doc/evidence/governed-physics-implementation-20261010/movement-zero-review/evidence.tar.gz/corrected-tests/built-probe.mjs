import assert from 'node:assert/strict';
const motion=await import(process.argv[1]+'/locomotion--uMNyio1.js');
const terms=await import(process.argv[1]+'/world-CblDwDXV.js');
assert.equal(terms.y(motion.t([0,-0,2])), 'drive(vector(0, 0, 2000), angular(0, 0, 0)).');
assert.equal(terms.y(motion.t([-0,-0.0009,0.0009],[-0.0001,-0,0])), 'drive(vector(0, 0, 0), angular(0, 0, 0)).');
assert.equal(terms.y(motion.a([-0,-0.0009,0.0009])), 'teleport(vector(0, 0, 0)).');
assert.equal(terms.y(terms.S(-0)), '(-0.0).');
console.log(JSON.stringify({built_bundle:true,backward_drive:true,sub_milli:true,teleport:true,generic_negative_zero_preserved:true}));
