from pathlib import Path
import shutil,json,hashlib
b=Path(__file__).resolve().parent;s=b.parent/'quod27-floor-gjk-final-01'
for d in ['crate','parry3d']:shutil.copytree(s/d,b/d)
shutil.copy2(s/'run.py',b/'run.py')
f=b/'crate/src/motion.rs';t=f.read_text();test=r'''
    #[test]
    fn grazing_near_a_single_triangle_edge() {
        for speed in [2.0_f64,4.0,8.0] {
            let start=(-2.826486825942993,0.751575,2.83035945892334);
            let (mut world,_)=surface_world(start,0.0,0.0,(0.0,0.0,0.0),false);
            let mut rows:Vec<_>=world.rows.values().map(|(row,_)|row.clone()).collect();
            let ground=rows.iter_mut().find(|row|row.0==1).unwrap();ground.1=2;
            let Geometry::Surface(points,faces)=annular_surface(false) else {unreachable!()};
            let (a,b,c)=faces[18];ground.4=Geometry::Surface(vec![points[a as usize],points[b as usize],points[c as usize]],vec![(0,1,2)]);
            world.install(rows).unwrap();world.step().unwrap();
            let d=speed*0.016667/std::f64::consts::SQRT_2;
            let answer=apply(&mut world,2,1,Query::Travel((d,-0.002725109,-d),(0.0,0.0,0.0)),(0.002,0.0,8,128));
            eprintln!("SINGLE_EDGE speed={speed} answer={answer:?}");
            let p=end(answer);assert!((p.0-start.0).hypot(p.2-start.2)>speed*0.016667*0.9);
            assert!(!surface_intersects(&world));
        }
    }
''';t=t.rstrip();f.write_text(t[:-1]+test+'\n}\n')
f=b/'run.py';f.write_text(f.read_text().replace("'--offline','--'","'--offline','grazing_near_a_single_triangle_edge','--'"))
files=list((b/'crate').rglob('*.rs'))+[b/'crate/Cargo.toml',b/'crate/Cargo.lock',b/'parry3d/src/query/gjk/gjk.rs']
(b/'source-manifest.json').write_text(json.dumps({str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
