from pathlib import Path
import shutil,json,hashlib,subprocess
b=Path(__file__).resolve().parent;s=b.parent/'quod27-floor-gjk-edge-01'
shutil.copytree(s/'crate',b/'crate')
base=Path('/home/yan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/parry3d-f64-0.31.1');shutil.copytree(base,b/'parry3d',ignore=shutil.ignore_patterns('.cargo-ok'))
# The same minimal algorithm fix, no float32/f64 runtime branch.
shutil.copy2(Path('native/quod_physics/vendor/parry3d/src/query/gjk/gjk.rs'),b/'parry3d/src/query/gjk/gjk.rs')
for f in (b/'crate/src').glob('*.rs'):
 t=f.read_text().replace('f32','Real');f.write_text(t)
f=b/'crate/Cargo.toml';t=f.read_text().replace('rapier3d = { version', 'rapier3d = { package = "rapier3d-f64", version').replace('"f32"','"f64"').replace('parry3d = { path','parry3d-f64 = { path');f.write_text(t)
lock=(b.parent/'quod27-floor-precision-probe-02/crate/Cargo.lock').read_text();(b/'crate/Cargo.lock').write_text(lock)
r=subprocess.run(['cargo','update','--manifest-path',str(b/'crate/Cargo.toml'),'-p','parry3d-f64','--offline'],text=True,capture_output=True)
(b/'resolve.log').write_text(r.stdout+r.stderr);(b/'resolve-exit.json').write_text(json.dumps({'exit':r.returncode})+'\n');r.check_returncode()
run=(b.parent/'quod27-floor-gjk-final-01/run.py').read_text();(b/'run.py').write_text(run)
files=list((b/'crate').rglob('*.rs'))+[b/'crate/Cargo.toml',b/'crate/Cargo.lock',b/'parry3d/src/query/gjk/gjk.rs']
(b/'source-manifest.json').write_text(json.dumps({str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
