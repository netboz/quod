from pathlib import Path
import shutil,json,hashlib
b=Path(__file__).resolve().parent;s=b.parent/'quod27-floor-gjk-precision-03'
for d in ['crate','parry3d']:shutil.copytree(s/d,b/d)
shutil.copy2(s/'run.py',b/'run.py')
f=b/'run.py';f.write_text(f.read_text().replace("'--offline','--'","'--offline','sliding_keeps_obstacles_in_the_same_surface','--'"))
f=b/'crate/src/motion.rs';t=f.read_text().replace('let Answer::Clipped((p,_),_,checks) = answer else {panic!("missed obstacle: {answer:?}")};','eprintln!("PRECISION_SLIDE roll={roll} desired={desired:?} answer={answer:?}");\n                let Answer::Clipped((p,_),_,checks) = answer else {panic!("missed obstacle: {answer:?}")};')
f.write_text(t)
files=list((b/'crate').rglob('*.rs'))+[b/'crate/Cargo.toml',b/'crate/Cargo.lock',b/'parry3d/src/query/gjk/gjk.rs']
(b/'source-manifest.json').write_text(json.dumps({str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
