from pathlib import Path
import subprocess,datetime,time,json,hashlib,os
p=Path(__file__).resolve().parent
cmd=['cargo','test','--manifest-path',str(p/'crate/Cargo.toml'),'--locked','--offline','sliding_keeps_obstacles_in_the_same_surface','--','--nocapture']
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
env={k:v for k,v in os.environ.items() if k not in ['LD_LIBRARY_PATH','LD_PRELOAD']};env['CARGO_TARGET_DIR']=str(p.parent/'quod27-floor-occupancy-repro-01/target');env['CARGO_BUILD_JOBS']='4'
with (p/'before.log').open('x') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
manifest=json.loads((p/'source-manifest.json').read_text());same=all(hashlib.sha256((p/f).read_bytes()).hexdigest()==v for f,v in manifest.items())
receipt={'command':cmd,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-t,'child_exit':r.returncode,'inputs_unchanged':same}
(p/'before-exit.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));raise SystemExit(r.returncode or (0 if same else 1))
