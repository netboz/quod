use crate::math::{Pose, Real, Vector};
use crate::query::details;
use crate::query::details::ShapeCastOptions;
use crate::query::gjk::{self, VoronoiSimplex};
use crate::query::{ShapeCastHit, ShapeCastStatus};
use crate::shape::{RoundShapeRef, SupportMap};
use num::Zero;

/// Time of impacts between two support-mapped shapes under translational movement.
pub fn cast_shapes_support_map_support_map<G1, G2>(
    pos12: &Pose,
    vel12: Vector,
    g1: &G1,
    g2: &G2,
    options: ShapeCastOptions,
) -> Option<ShapeCastHit>
where
    G1: ?Sized + SupportMap,
    G2: ?Sized + SupportMap,
{
    let gjk_result = if options.target_distance > 0.0 {
        let round_g1 = RoundShapeRef {
            inner_shape: g1,
            border_radius: options.target_distance,
        };
        gjk::directional_distance(pos12, &round_g1, g2, vel12, &mut VoronoiSimplex::new())
    } else {
        gjk::directional_distance(pos12, g1, g2, vel12, &mut VoronoiSimplex::new())
    };

    if gjk_result.is_none() { gjk::trace_refinement(0); }
    gjk_result.and_then(|(time_of_impact, normal1, witness1, witness2)| {
        if time_of_impact > options.max_time_of_impact {
            gjk::trace_refinement(1);
            None
        } else if (options.compute_impact_geometry_on_penetration || !options.stop_at_penetration)
            && time_of_impact < 1.0e-4
        {
            // The GJK-derived normal becomes unreliable for very small TOIs — typically
            // when the cast starts at (or very close to) the `target_distance` boundary
            // with a direction nearly tangent to the contact. Fall back on the contact
            // query, which gives a robust closest-point normal and lets us detect the
            // case where the cast direction is actually moving away from the contact.
            let Some(contact) = details::contact_support_map_support_map(pos12, g1, g2, Real::MAX) else {gjk::trace_refinement(2);return None;};
            let normal_vel = contact.normal1.dot(vel12);

            if !options.stop_at_penetration && normal_vel >= 0.0 {
                gjk::trace_refinement(3);
                None
            } else {
                gjk::trace_refinement(4);
                Some(ShapeCastHit {
                    time_of_impact,
                    normal1: contact.normal1,
                    normal2: contact.normal2,
                    witness1: contact.point1,
                    witness2: contact.point2,
                    // A cast starting exactly touching, neither penetrating nor within
                    // the target distance, converged like ball-ball does.
                    status: if contact.dist < options.target_distance {
                        ShapeCastStatus::PenetratingOrWithinTargetDist
                    } else {
                        ShapeCastStatus::Converged
                    },
                    subshape1: 0,
                    subshape2: 0,
                })
            }
        } else {
            gjk::trace_refinement(5);
            Some(ShapeCastHit {
                time_of_impact,
                normal1,
                normal2: pos12.rotation.inverse() * -normal1,
                witness1: witness1 - normal1 * options.target_distance,
                witness2: pos12.inverse_transform_point(witness2),
                status: if time_of_impact.is_zero() {
                    // A zero TOI means either a real penetration (or a start within the
                    // target distance) or a mere touching contact; only the former is
                    // `PenetratingOrWithinTargetDist`, as for ball-ball.
                    match details::contact_support_map_support_map(pos12, g1, g2, Real::MAX) {
                        Some(contact) if contact.dist >= options.target_distance => {
                            ShapeCastStatus::Converged
                        }
                        _ => ShapeCastStatus::PenetratingOrWithinTargetDist,
                    }
                } else {
                    ShapeCastStatus::Converged
                },
                subshape1: 0,
                subshape2: 0,
            })
        }
    })
}
