from pathlib import Path
import json,hashlib,shutil,difflib
root=Path('/home/yan/src/quod');b=Path(__file__).resolve().parent
vp=root/'native/quod_physics/vendor/parry3d';gf=vp/'src/query/gjk/gjk.rs';text=gf.read_text()
stock=Path('/home/yan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/parry3d-0.31.1/src/query/gjk/gjk.rs').read_text()
start='        if max_bound - min_bound <= _eps_rel * max_bound {';end='        let _ = simplex.add_point'
pos=text.index(start,text.index('fn minkowski_ray_cast'));finish=text.index(end,pos)
s=stock.index(start,stock.index('fn minkowski_ray_cast'));e=stock.index(end,s)
text=text[:pos]+stock[s:e]+text[finish:];gf.write_text(text)
(root/'native/quod_physics/vendor/parry3d.patch').write_text(''.join(difflib.unified_diff(stock.splitlines(True),text.splitlines(True),fromfile='a/src/query/gjk/gjk.rs',tofile='b/src/query/gjk/gjk.rs')))
(root/'_build/quod27-release-263/gates-03/NOT-FOR-RELEASE.json').write_text(json.dumps({'reason':'Opus implementation review rejected bound-convergence hunk and requested exit/refinement tracing, normal-error and caller audit. Full run may finish, but cannot authorize release.','review':'_build/quod27-floor-gjk-implementation-review-01/opus-review.md'},indent=2)+'\n')
(b/'crate/src').mkdir(parents=True)
for p in (root/'native/quod_physics/src').glob('*.rs'):shutil.copy2(p,b/'crate/src'/p.name)
for name in ['Cargo.toml','Cargo.lock']:
 t=(root/'native/quod_physics'/name).read_text().replace('vendor/parry3d','../parry3d');(b/'crate'/name).write_text(t)
shutil.copytree(vp,b/'parry3d')
f=b/'parry3d/src/query/gjk/gjk.rs';t=f.read_text();head,body=t.split('fn minkowski_ray_cast',1)
body=body.replace('return None;', 'return trace_exit(0,None);',1)
body=body.replace('return Some((ltoi / ray_length, ldir));', 'return trace_exit(1,Some((ltoi / ray_length, ldir)));',1)
body=body.replace('return None;', 'return trace_exit(4,None);',1)
body=body.replace('return Some((ltoi / ray_length, ldir));', 'return trace_exit(if ltoi==0.0 {2}else{3},Some((ltoi / ray_length, ldir)));',1)
body=body.replace('return None;', 'return trace_exit(4,None);',1)
body=body.replace('// miss\n                    return None;', '// miss\n                    return trace_exit(5,None);')
body=body.replace('if last_chance {\n            return None;', 'if last_chance {\n            return trace_exit(6,None);')
body=body.replace('return Some((ltoi / ray_length, ldir));\n            } else {\n                return None;', 'return trace_exit(7,Some((ltoi / ray_length, ldir)));\n            } else {\n                return trace_exit(8,None);',1)
body=body.replace('return None;\n            } else {\n                return Some((ltoi / ray_length, ldir)); // Vector inside of the cso.', 'return trace_exit(9,None);\n            } else {\n                return trace_exit(10,Some((ltoi / ray_length, ldir))); // Vector inside of the cso.',1)
body=body.replace('return conservative.then_some((ltoi / ray_length, ldir));','return trace_exit(11,conservative.then_some((ltoi / ray_length, ldir)));')
t=head+'fn minkowski_ray_cast'+body
instrument='''
std::thread_local! {
    static TRACE_EXIT: core::cell::Cell<usize> = const { core::cell::Cell::new(12) };
    static TRACE_COUNTS: core::cell::RefCell<[[u64;6];13]> = const { core::cell::RefCell::new([[0;6];13]) };
}
fn trace_exit(kind:usize,result:Option<(Real,Vector)>)->Option<(Real,Vector)> {
    TRACE_EXIT.with(|x|x.set(kind));result
}
pub fn trace_refinement(outcome:usize) {
    TRACE_EXIT.with(|kind| TRACE_COUNTS.with(|rows|rows.borrow_mut()[kind.get()][outcome]+=1));
}
pub fn trace_snapshot()->[[u64;6];13] {
    TRACE_COUNTS.with(|rows|*rows.borrow())
}
'''
f.write_text(t+instrument)
f=b/'parry3d/src/query/shape_cast/shape_cast_support_map_support_map.rs';t=f.read_text();t=t.replace('    gjk_result.and_then','    if gjk_result.is_none() { gjk::trace_refinement(0); }\n    gjk_result.and_then',1)
t=t.replace('if time_of_impact > options.max_time_of_impact {\n            None','if time_of_impact > options.max_time_of_impact {\n            gjk::trace_refinement(1);\n            None',1)
t=t.replace('let contact = details::contact_support_map_support_map(pos12, g1, g2, Real::MAX)?;','let Some(contact) = details::contact_support_map_support_map(pos12, g1, g2, Real::MAX) else {gjk::trace_refinement(2);return None;};',1)
t=t.replace('if !options.stop_at_penetration && normal_vel >= 0.0 {\n                None','if !options.stop_at_penetration && normal_vel >= 0.0 {\n                gjk::trace_refinement(3);\n                None',1)
t=t.replace('            } else {\n                Some(ShapeCastHit {','            } else {\n                gjk::trace_refinement(4);\n                Some(ShapeCastHit {',1)
t=t.replace('        } else {\n            Some(ShapeCastHit {','        } else {\n            gjk::trace_refinement(5);\n            Some(ShapeCastHit {',1);f.write_text(t)
f=b/'crate/src/motion.rs';t=f.read_text()
# Record all exits/refinements in three independently scoped production-seam tests.
t=t.replace('assert!(failures.is_empty(),"clear floor failed to advance: {failures:?}");','eprintln!("TRACE captured {:?}",rapier3d::parry::query::gjk::trace_snapshot());\n        assert!(failures.is_empty(),"clear floor failed to advance: {failures:?}");')
t=t.replace('    #[test]\n    fn skin_boundary_travel_and_landing_paths_remain_clear()', '    #[test]\n    fn skin_boundary_travel_and_landing_paths_remain_clear()')
t=t.replace('let mut count=0;let mut queries=0;', 'let mut count=0;let mut queries=0;let mut max_angle=0.0_f64;\n        for (speed_scale,down) in [(1.0,-0.002725109),(2.0,-0.002725109),(4.0,-0.002725109),(1.0,0.0),(4.0,0.0)] {')
t=t.replace('frame.rotation*Vector::new(vx*0.016667,-0.002725109,vz*0.016667)','frame.rotation*Vector::new(vx*0.016667*speed_scale,down,vz*0.016667*speed_scale)')
t=t.replace('                        count+=1;', '''                        if let Answer::Clipped(_,contacts,_) = &answer {
                            for (_,n) in contacts {
                                let local=frame.rotation.inverse()*Vector::new(n.0 as f32,n.1 as f32,n.2 as f32);
                                max_angle=max_angle.max((local.y as f64/(local.length() as f64)).clamp(-1.0,1.0).acos());
                            }
                        }
                        count+=1;''')
t=t.replace('if (v.x as f64-x).hypot(v.z as f64-z)<0.03','if (v.x as f64-x).hypot(v.z as f64-z)<0.03*speed_scale as f64')
t=t.replace('v=({vx},{vz})', 'v=({vx},{vz}) scale={speed_scale} down={down}')
t=t.replace('        eprintln!("SUMMARY count=', '''        }
        eprintln!("TRACE sweep {:?}",rapier3d::parry::query::gjk::trace_snapshot());
        eprintln!("MAX_ANGLE used_floor_contact={max_angle}");
        eprintln!("SUMMARY count=''',1)
t=t.replace('            }\n        }\n    }\n\n    #[test]\n    fn skin_boundary_travel', '            }\n        }\n        eprintln!("TRACE reciprocal {:?}",rapier3d::parry::query::gjk::trace_snapshot());\n    }\n\n    #[test]\n    fn skin_boundary_travel',1)
f.write_text(t)
run=(root/'_build/quod27-floor-gjk-candidate-04/run.py').read_text().replace("'--','--nocapture'","'--','--nocapture','--test-threads=1'")
(b/'run.py').write_text(run)
files=list((b/'crate').rglob('*.rs'))+[b/'crate/Cargo.toml',b/'crate/Cargo.lock',b/'parry3d/src/query/gjk/gjk.rs',b/'parry3d/src/query/shape_cast/shape_cast_support_map_support_map.rs']
(b/'source-manifest.json').write_text(json.dumps({str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
