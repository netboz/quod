from pathlib import Path
import shutil,json,hashlib
b=Path(__file__).resolve().parent;s=b.parent/'quod27-floor-gjk-trace-04'
for d in ['crate','parry3d']:shutil.copytree(s/d,b/d)
shutil.copy2(s/'run.py',b/'run.py')
f=b/'parry3d/src/query/gjk/gjk.rs';t=f.read_text();t+='''
std::thread_local! {
    static USED_ANGLES: core::cell::RefCell<[f64;2]> = const { core::cell::RefCell::new([0.0;2]) };
}
pub fn trace_used_normal(time:Real,n:Vector) {
    let angle=(n.x as f64).hypot(n.z as f64).atan2(n.y as f64);
    USED_ANGLES.with(|rows| {let i=usize::from(time>=1.0e-4);let mut r=rows.borrow_mut();r[i]=r[i].max(angle);});
}
pub fn trace_used_angles()->[f64;2] {USED_ANGLES.with(|rows|*rows.borrow())}
''';f.write_text(t)
f=b/'crate/src/motion.rs';t=f.read_text();t=t.replace('let normal = other.position().rotation * hit.normal2;','rapier3d::parry::query::gjk::trace_used_normal(hit.time_of_impact,hit.normal2);\n                let normal = other.position().rotation * hit.normal2;',1)
t=t.replace('eprintln!("MAX_ANGLE used_floor_contact={max_angle}");','eprintln!("MAX_ANGLE used_floor_contact={max_angle} split={:?}",rapier3d::parry::query::gjk::trace_used_angles());')
# Include an independent analytic endpoint assertion for both floor frames.
t=t.replace('let v=frame.inverse_transform_point(Vector::new(p.0 as f32,p.1 as f32,p.2 as f32));\n                                if ', 'let v=frame.inverse_transform_point(Vector::new(p.0 as f32,p.1 as f32,p.2 as f32));\n                                assert!(v.y>=0.75,"analytic floor penetration: {v:?}");\n                                if ')
probe=r'''
    #[test]
    fn analytic_contact_normal_probe() {
        use rapier3d::parry::shape::{Capsule,Triangle};
        let Geometry::Surface(points,faces)=annular_surface(false) else {unreachable!()};
        let capsule=Capsule::new_y(0.5,0.25);
        let positions=[(5.1282697,1.5401974),(5.241492,2.8427703),(5.5937166,1.9480517),
            (5.0,0.0),(4.829629,1.294095),(4.330127,2.5),(3.535534,3.535534),
            (0.0,5.0),(-4.0,3.0),(-5.0,0.0),(0.0,-5.0)];
        let mut count=0;let mut within_worst=(0.0,String::new());let mut all_worst=(0.0,String::new());let mut missing=0;
        for (x,z) in positions {
            for gap_step in 0..=40 {
                let y=0.7515+gap_step as f64*0.000025;
                let pose=Pose::translation(x as f32,y as f32,z as f32);
                let pos=(pose.translation.x as f64,pose.translation.z as f64);
                for (i,&(a,b,c)) in faces.iter().enumerate() {
                    let v=|k|Vector::new(points[k as usize].0 as f32,0.0,points[k as usize].2 as f32);
                    let [a,b,c]=[v(a),v(b),v(c)];
                    let cross=|u:Vector,v:Vector| (v.x-u.x) as f64*(pos.1-u.z as f64)-(v.z-u.z) as f64*(pos.0-u.x as f64);
                    let signs=[cross(a,b),cross(b,c),cross(c,a)];
                    if !(signs.iter().all(|s|*s>=-1.0e-9)||signs.iter().all(|s|*s<=1.0e-9)){continue;}
                    count+=1;
                    let tri=Triangle::new(a,b,c);
                    if let Some(contact)=query::details::contact_support_map_support_map(&pose,&tri,&capsule,f32::MAX) {
                        let n=contact.normal1;
                        let angle=(n.x as f64).hypot(n.z as f64).atan2(n.y as f64);
                        let row=format!("x={x} y={y} z={z} triangle={i} normal={n:?} dist={}",contact.dist);
                        if angle>all_worst.0 {all_worst=(angle,row.clone());}
                        if pose.translation.y-0.75<=0.002 && angle>within_worst.0 {within_worst=(angle,row);}
                    }else{missing+=1;}
                }
            }
        }
        eprintln!("ANALYTIC_CONTACT count={count} missing={missing} within={within_worst:?} all={all_worst:?}");
    }
'''
t=t.rstrip();t=t[:-1]+probe+'\n}\n';f.write_text(t)
files=list((b/'crate').rglob('*.rs'))+[b/'crate/Cargo.toml',b/'crate/Cargo.lock',b/'parry3d/src/query/gjk/gjk.rs',b/'parry3d/src/query/shape_cast/shape_cast_support_map_support_map.rs']
(b/'source-manifest.json').write_text(json.dumps({str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
