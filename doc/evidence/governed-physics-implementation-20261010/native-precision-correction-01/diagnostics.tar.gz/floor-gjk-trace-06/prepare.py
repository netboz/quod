from pathlib import Path
import shutil,json,hashlib
b=Path(__file__).resolve().parent;s=b.parent/'quod27-floor-gjk-trace-05'
for d in ['crate','parry3d']:shutil.copytree(s/d,b/d)
shutil.copy2(s/'run.py',b/'run.py')
f=b/'crate/src/motion.rs';t=f.read_text()
t=t.replace('(0.0,5.0),(-4.0,3.0),(-5.0,0.0),(0.0,-5.0)];','(0.0,5.0),(-4.0,3.0),(-5.0,0.0),(0.0,-5.0),\n            (5.155712127685547,1.3666876554489136),(-2.826486825942993,2.83035945892334)];')
t=t.replace('for gap_step in 0..=40 {\n                    let start=(x,0.7515+gap_step as f64*0.000025,z);','for y in (0..=40).map(|gap_step|0.7515+gap_step as f64*0.000025).chain([0.7517002820968628,0.751920759677887,0.751710057258606,0.7522839307785034,0.7521604299545288]) {\n                    let start=(x,y,z);')
t=t.replace('for gap_step in 0..=40 {\n                let y=0.7515+gap_step as f64*0.000025;','for y in (0..=40).map(|gap_step|0.7515+gap_step as f64*0.000025).chain([0.7517002820968628,0.751920759677887,0.751710057258606,0.7522839307785034,0.7521604299545288]) {')
f.write_text(t)
files=list((b/'crate').rglob('*.rs'))+[b/'crate/Cargo.toml',b/'crate/Cargo.lock',b/'parry3d/src/query/gjk/gjk.rs',b/'parry3d/src/query/shape_cast/shape_cast_support_map_support_map.rs']
(b/'source-manifest.json').write_text(json.dumps({str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
