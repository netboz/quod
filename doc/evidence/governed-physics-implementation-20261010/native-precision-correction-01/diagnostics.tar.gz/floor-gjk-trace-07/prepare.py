from pathlib import Path
import shutil,json,hashlib
b=Path(__file__).resolve().parent;s=b.parent/'quod27-floor-gjk-trace-06'
for d in ['crate','parry3d']:shutil.copytree(s/d,b/d)
shutil.copy2(s/'run.py',b/'run.py')
f=b/'crate/src/motion.rs';t=f.read_text()
t=t.replace('let signs=[cross(a,b),cross(b,c),cross(c,a)];\n                    if !(signs.iter().all(|s|*s>=-1.0e-9)||signs.iter().all(|s|*s<=1.0e-9)){continue;}','''let signs=[cross(a,b),cross(b,c),cross(c,a)];
                    let inside=signs.iter().all(|s|*s>=-1.0e-9)||signs.iter().all(|s|*s<=1.0e-9);
                    let q=if inside {pos} else {
                        [(a,b),(b,c),(c,a)].map(|(u,v)| {
                            let (ux,uz,vx,vz)=(u.x as f64,u.z as f64,v.x as f64,v.z as f64);
                            let t=(((pos.0-ux)*(vx-ux)+(pos.1-uz)*(vz-uz))/((vx-ux).powi(2)+(vz-uz).powi(2))).clamp(0.0,1.0);
                            (ux+t*(vx-ux),uz+t*(vz-uz))
                        }).into_iter().min_by(|u,v| (pos.0-u.0).hypot(pos.1-u.1).total_cmp(&(pos.0-v.0).hypot(pos.1-v.1))).unwrap()
                    };
                    let expected=[pos.0-q.0,pose.translation.y as f64-0.5,pos.1-q.1];
                    let length=expected.iter().map(|x|x*x).sum::<f64>().sqrt();
                    let true_gap=length-0.25;
                    if true_gap>0.0025 {continue;}
                    let expected=Vector::new((expected[0]/length) as f32,(expected[1]/length) as f32,(expected[2]/length) as f32);''')
t=t.replace('let angle=(n.x as f64).hypot(n.z as f64).atan2(n.y as f64);\n                        let row=format!("x={x} y={y} z={z} triangle={i} normal={n:?} dist={}",contact.dist);','let angle=(n.cross(expected).length() as f64).atan2(n.dot(expected) as f64);\n                        let row=format!("x={x} y={y} z={z} triangle={i} normal={n:?} expected={expected:?} true_gap={true_gap} dist={}",contact.dist);')
t=t.replace('if pose.translation.y-0.75<=0.002 && angle>within_worst.0','if true_gap<=0.002 && angle>within_worst.0')
f.write_text(t)
files=list((b/'crate').rglob('*.rs'))+[b/'crate/Cargo.toml',b/'crate/Cargo.lock',b/'parry3d/src/query/gjk/gjk.rs',b/'parry3d/src/query/shape_cast/shape_cast_support_map_support_map.rs']
(b/'source-manifest.json').write_text(json.dumps({str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2)+'\n')
