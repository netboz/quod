%% Shared lobby and device classes. Recipes are pure descriptions; concrete
%% device instances and ownership live in each personal lobby ontology.
acl_sovereign(quod:lobby).

can_invoke(Goal, _, _, _) :- lobby_query(Goal).
can_invoke((current_ontology_identity(_, _), Goal), _, _, _) :- lobby_query(Goal).
can_invoke(Goal, _, _, _) :- system_source_query(Goal).
can_invoke(_, node(Key), _, _) :- peer_admitted(Key, _, _, Key).
can_join(_, _, Key) :- peer_ready(Key).

lobby_query(lobby_recipe(_, _, _)).
lobby_query(lobby_modes(_)).
lobby_query(device_menu(_, _)).
lobby_query(device_eidolons(_, _, _, _)).
lobby_query(isa(_, _)).
lobby_query(class_eidolon(_, _, _, _)).
lobby_query(eidolon(_, _, _)).
lobby_query(lobby_options(_, _)).
lobby_query(ontology_creation_allowed(_, _, _)).
lobby_query(Goal) :- public_source_query(Goal).

%% A user's editable facts cannot grant names outside its own personal lobby.
%% The pending requirement is read in the same proof as the prepared creation.
ontology_creation_allowed(Owner, Name, Options) :-
    current_principal(Owner),
    Owner = agent_instance_ref(UserNamespace, UserAnchor, Instance),
    binary_codes(UserNamespace, UserBytes),
    append(UserBytes, [47,108,111,98,98,121], LobbyBytes),
    binary_codes(Name, LobbyBytes),
    UserNamespace::(current_ontology_identity(UserNamespace, UserAnchor),
                    instance_of(human_user, Instance),
                    lobby_provisioning(Instance, pending(Name))),
    lobby_options(Owner, Options).

%% A template is reviewed founding source stored in this ontology, not a path
%% read from whichever node happens to receive the creation request.
%% Founding supplies instance_template/1 and exact modelling/GUI references.
lobby_options(Owner,
    [source(Source),
     terms([lobby_owner(Owner), instance_of(lobby, personal_lobby),
            instance_of(sky_sphere, personal_sky),
            attribute(personal_sky, panorama, belfast_sunset_puresky),
            attribute(personal_sky, diameter, 80000),
            attribute(personal_sky, rotation, 75),
            attribute(personal_sky, brightness, 120),
            attribute(personal_sky, tint, <<"#FFFFFF">>),
            instance_of(prolog_console, console),
            lobby_device(personal_lobby, console),
            device_placement(console, <<"console">>, transform(0, 0, 3850, 0, 0, 0)),
            instance_of(lobby_roof, personal_roof),
            lobby_device(personal_lobby, personal_roof),
            device_placement(personal_roof, <<"roof">>, transform(0, 0, 0, 0, 0, 0)),
            lobby_vocabulary(Namespace, Anchor),
            modelling_vocabulary(ModellingNamespace, ModellingAnchor),
            environment_vocabulary(EnvironmentNamespace, EnvironmentAnchor),
            gui_vocabulary(GuiNamespace, GuiAnchor)]),
     external_predicate_modules([quod_agent_predicates])]) :-
    term_variables(Owner, []),
    Owner = agent_instance_ref(_, _, _),
    current_ontology_identity(Namespace, Anchor),
    instance_template(Source),
    modelling_vocabulary(ModellingNamespace, ModellingAnchor),
    environment_vocabulary(EnvironmentNamespace, EnvironmentAnchor),
    gui_vocabulary(GuiNamespace, GuiAnchor).

isa(lobby, thing).
isa(device, thing).
isa(prolog_console, device).
isa(imported_artifact, device).
isa(lobby_roof, thing).
%% Class associations name ordinary, anchored Prolog recipe entry points.
class_eidolon(Class, Mode, Style, recipe(Ns, Anchor, Recipe)) :-
    isa(Class, Class),
    device_eidolons([Class], Mode, Style, Recipes),
    member(recipe(Ns, Anchor, Recipe), Recipes).

device_eidolons(Classes, Mode, Style, Recipes) :-
    findall(purpose(M, S), device_eidolon(_, M, S, _), RawPurposes),
    sort(RawPurposes, Purposes), member(purpose(Mode, Style), Purposes),
    findall(candidate(Class, Recipe), device_eidolon(Class, Mode, Style, Recipe), Candidates),
    findall(Class, member(candidate(Class, _), Candidates), Owners),
    most_specific_classes(Classes, Owners, Selected),
    current_ontology_identity(Ns, Anchor),
    findall(recipe(Ns, Anchor, Recipe),
            (member(candidate(Class, Recipe), Candidates), member(Class, Selected)), Raw),
    sort(Raw, Recipes).

device_eidolon(prolog_console, playing, solid, console_playing).
device_eidolon(prolog_console, edition, solid, console_edition).
device_eidolon(imported_artifact, playing, solid, imported_artifact_playing).
device_eidolon(lobby_roof, playing, solid, lobby_roof).
device_eidolon(lobby_roof, edition, solid, lobby_roof).

lobby_modes(Modes) :-
    findall(Mode, device_eidolon(_, Mode, solid, _), Offered), sort(Offered, Modes).

device_menu(Classes, Entries) :-
    findall(candidate(Class, Menu), class_device_menu(Class, Menu), Candidates),
    findall(Class, member(candidate(Class, _), Candidates), Owners),
    most_specific_classes(Classes, Owners, Selected),
    findall(Entry, (member(candidate(Class, Menu), Candidates),
                   member(Class, Selected), member(Entry, Menu)), Raw),
    sort(Raw, Entries).

class_device_menu(prolog_console,
    [menu_entry(prove_goal, <<"Prove a goal">>, open_view(proof_console))]).

%% Every placed device is selected by class; repeated instances share recipes.
lobby_recipe(Mode, lobby(Ns, Anchor, Sky, Devices), [SkyPart, Floor | Parts]) :-
    environment_parts(Mode, Sky, Ns, Anchor, [SkyPart]),
    Floor = part(<<"floor">>,
                 mesh_asset(asset(<<"6520d8b8c35a72cf99cd061c05f6badda2aa8d357446b9856f247ab06d4eb07f">>,
                                  <<"model/gltf-binary">>),
                            <<"gltf2-static-v1">>, scale(1000),
                            frame(aabb(-9000, -450, -9000, 9000, 1000, 9000),
                                  pivot(0, 0, 0), front(<<"-z">>)),
                            resources(1660388, 1658880, 46080, 46080, 1, 2, 1)),
                 transform(0, 0, 0, 0, 0, 0), asset_surfaces, unlabelled, depicts_nothing),
    device_parts(Devices, Mode, Ns, Anchor, Parts).

environment_parts(Mode, Sky, Ns, Anchor, Parts) :-
    environment_eidolons(EidolonNs, EidolonAnchor),
    EidolonNs::(current_ontology_identity(EidolonNs, EidolonAnchor),
                class_eidolon(sky_sphere, Mode, panoramic,
                              recipe(RecipeNs, RecipeAnchor, Recipe))),
    RecipeNs::(current_ontology_identity(RecipeNs, RecipeAnchor),
               eidolon(Recipe, environment(Sky, Ns, Anchor), Parts)).
device_parts([], _, _, _, []).
device_parts([device(Classes, Entity, Id, At) | Devices], Mode, Ns, Anchor, Parts) :-
    device_eidolons(Classes, Mode, solid, Recipes),
    device_model(Recipes, Entity, Model),
    modelling_vocabulary(MNs, MA),
    MNs::(current_ontology_identity(MNs, MA),
          place_model(Id, At, depicts(Ns, Anchor, Entity), Model, Placed)),
    device_parts(Devices, Mode, Ns, Anchor, Rest), append(Placed, Rest, Parts).

device_model([recipe(Ns, Anchor, Recipe)], Entity, Model) :-
    current_ontology_identity(Ns, Anchor), eidolon(Recipe, device(Entity), Model).
device_model([], _, Parts) :- device_eidolon_status(<<"No matching eidolon">>, Parts).
device_model([_, _ | _], _, Parts) :-
    device_eidolon_status(<<"Choose an eidolon">>, Parts).
device_eidolon_status(Text,
    [part(<<"eidolon-status">>, group, transform(0, 0, 0, 0, 0, 0),
          no_surface, label(Text, <<"above">>), depicts_nothing)]).

material_surface(Material, Surface) :-
    material_eidolons(Ns, Anchor),
    Ns::(current_ontology_identity(Ns, Anchor),
         class_eidolon(Material, playing, solid, recipe(RecipeNs, RecipeAnchor, Recipe))),
    RecipeNs::(current_ontology_identity(RecipeNs, RecipeAnchor),
               eidolon(Recipe, material(Material), Surface)).

%% Roof and ground are separate appearance assets, not physical body identities.
eidolon(lobby_roof, device(_),
    [part(<<"model">>,
          mesh_asset(asset(<<"e2342ad365f644003e22372f41a25e833541c6c30b314ac539534e5c3a077121">>,
                           <<"model/gltf-binary">>),
                     <<"gltf2-static-v1">>, scale(1000),
                     frame(aabb(-8875, 1000, -8852, 8875, 5250, 8852),
                           pivot(0, 0, 0), front(<<"-z">>)),
                     resources(942164, 940032, 20160, 38016, 1, 2, 1)),
          transform(0, 0, 0, 0, 0, 0), asset_surfaces, unlabelled, depicts_nothing)]).
%% Playing depicts the packaged console model; edition exposes its structure.
eidolon(console_playing, device(_),
    [part(<<"model">>,
          mesh_asset(asset(<<"2be70465da809e6e29b8b12aae01a568e54cd150e86f35f790e06a61fc82bc04">>,
                           <<"model/gltf-binary">>),
                     <<"gltf2-static-v1">>, scale(1000),
                     frame(aabb(-921, -929, -898, 881, 904, 894),
                           pivot(0, -929, 0), front(<<"-z">>)),
                     resources(5357484, 1227580, 31379, 50000, 1, 1, 4194304)),
          transform(0, 0, 0, 0, 0, 0), asset_surfaces,
          label(<<"PROLOG CONSOLE">>, <<"above">>), depicts_nothing)]).
eidolon(console_edition, device(_), Parts) :- console_parts(Parts).
%% The packaged public GLB is a sample recipe; the enclosing placed instance
%% remains the only source of its anchored subject and interaction rights.
eidolon(imported_artifact_playing, device(_),
    [part(<<"model">>,
          mesh_asset(asset(<<"ad1f1cbe8c100fd774e315b629d0bb1082820c9a7abe2a2a999aef846d675064">>,
                           <<"model/gltf-binary">>),
                     <<"gltf2-static-v1">>, scale(1000),
                     frame(aabb(-300, 0, -400, 1200, 1400, 300),
                           pivot(200, 0, -100), front(<<"+x">>)),
                     resources(1452, 96, 6, 2, 3, 2, 4)),
          transform(0, 0, 0, 0, 0, 0), asset_surfaces,
          label(<<"Imported model">>, <<"above">>), depicts_nothing)]).
console_parts(
    [part(<<"plinth">>, box(2000, 140, 1000), transform(0, 70, 120, 0, 0, 0),
          Shell, BaseLabel, depicts_nothing),
     part(<<"deck">>, box(1840, 70, 840), transform(0, 175, 80, 0, 0, 0),
          Wood, unlabelled, depicts_nothing),
     part(<<"support">>, box(760, 820, 480), transform(0, 590, 120, 0, 0, 0),
          Shell, SupportLabel, depicts_nothing),
     part(<<"support-face">>, box(620, 650, 70),
          relative(<<"support">>, transform(0, 0, -275, 0, 0, 0)),
          Bronze, unlabelled, depicts_nothing),
     part(<<"body">>, box(1900, 1100, 320), transform(0, 1450, 0, 0, 0, 0),
          Shell, BodyLabel, depicts_nothing),
     part(<<"left-cheek">>, box(160, 1040, 380),
          relative(<<"body">>, transform(-870, 0, 0, 0, 0, 0)),
          Wood, unlabelled, depicts_nothing),
     part(<<"right-cheek">>, box(160, 1040, 380),
          relative(<<"body">>, transform(870, 0, 0, 0, 0, 0)),
          Wood, unlabelled, depicts_nothing),
     part(<<"bezel">>, box(1540, 810, 90),
          relative(<<"body">>, transform(0, 40, -195, 0, 0, 0)),
          Inset, unlabelled, depicts_nothing),
     part(<<"screen">>, plane(1400, 680), relative(<<"bezel">>, ScreenAt),
          Screen, ScreenLabel, depicts_nothing),
     part(<<"shelf">>, box(1900, 180, 580),
          relative(<<"body">>, transform(0, -620, -180, 350, 0, 0)),
          Shell, ShelfLabel, depicts_nothing),
     part(<<"shelf-trim">>, box(1800, 50, 540),
          relative(<<"shelf">>, transform(0, 85, 0, 0, 0, 0)),
          Bronze, unlabelled, depicts_nothing),
     part(<<"status">>, sphere(55),
          relative(<<"shelf">>, transform(700, 70, -300, 0, 0, 0)),
          Glow, unlabelled, depicts_nothing),
     part(<<"status-ring">>, torus(110, 18),
          relative(<<"shelf">>, transform(700, 70, -310, 90, 0, 0)),
          Bronze, ControlLabel, depicts_nothing),
     part(<<"control-knob">>, cylinder(100, 55),
          relative(<<"shelf">>, transform(520, 70, -315, 90, 0, 0)),
          Bronze, unlabelled, depicts_nothing),
     part(<<"top-sign">>, box(900, 100, 80),
          relative(<<"body">>, transform(0, 650, -150, 0, 0, 0)),
          Bronze, label(Title, <<"above">>), depicts_nothing)]) :-
    material_surface(oak_wood, Wood), material_surface(bronze, Bronze),
    Shell = surface(<<"#253239">>,650,420,0,[]),
    Inset = surface(<<"#10191E">>,250,300,40,[]),
    Screen = surface(<<"#071419">>,0,350,120,[]),
    Glow = surface(<<"#F4B942">>,0,350,700,[]),
    console_layout(Gap, Title, BaseLabel, SupportLabel, BodyLabel,
                   ScreenLabel, ShelfLabel, ControlLabel),
    modelling_vocabulary(Ns, Anchor),
    Ns::(current_ontology_identity(Ns, Anchor),
         align(plane(1400, 680), centre, box(1540, 810, 90), front, Gap, ScreenAt)).
console_layout(350, <<"CONSOLE PARTS">>,
               label(<<"WEIGHTED BASE">>, <<"above">>),
               label(<<"CENTRAL SUPPORT">>, <<"above">>),
               label(<<"DISPLAY HOUSING">>, <<"above">>),
               label(<<"SCREEN">>, <<"above">>),
               label(<<"CONTROL SHELF">>, <<"above">>),
               label(<<"STATUS CONTROL">>, <<"above">>)).
