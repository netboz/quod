from pathlib import Path
import datetime, hashlib, json, subprocess
import signed as s

p = Path(__file__).resolve().parent

def save(name, value):
    with (p / name).open('x') as f:
        json.dump(value, f, indent=2)

def parse(name):
    result = subprocess.run(['escript', str(p/'check-goal.escript'), str(p/name)],
                            capture_output=True, text=True)
    with (p/(name+'.parse.log')).open('x') as f:
        f.write(result.stdout+result.stderr)
    assert result.returncode == 0 and result.stdout.rstrip().endswith('parsed=ok'), result.stdout

def accept(label, goal):
    proof = s.run(label+'-proof', 'cursor', goal)
    assert proof.get('result') == 'solution', proof
    outcome = s.run(label+'-accepted', 'command', proof['cursor'], 'accept')
    assert outcome.get('result') == 'ok', outcome
    print(json.dumps({'step': label, 'operation_id': proof['operation_id'],
                      'outcome': outcome['result']}), flush=True)
    return outcome

def hex_literal(value):
    return '<<"'+''.join('\\x'+value[i:i+2]+'\\' for i in range(0,len(value),2))+'">>'

def main():
    completed = json.loads((p/'source-publication-02-complete.json').read_text())
    assert completed['predicates'] == 170 and completed['native_or_agents_allocated'] is False
    manifest = json.loads((p/'publication-02-inputs.json').read_text())
    for row in manifest['files']:
        assert hashlib.sha256((p/row['path']).read_bytes()).hexdigest() == row['sha256'], row
    save('activation-inputs.json', {'started': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'files': [{'path': name, 'sha256': hashlib.sha256((p/name).read_bytes()).hexdigest()}
                  for name in ['activate-once.py', 'first-key-grant.prolog', 'first-key-read.prolog',
                               'activation-source-pin.prolog', 'activation-template.prolog']]})
    assert s.run('activation-renew', 'renew').get('renewed')
    parse('first-key-grant.prolog')
    accept('first-key-grant', (p/'first-key-grant.prolog').read_text())
    parse('first-key-read.prolog')
    key = s.run('first-key-prepared', 'read', (p/'first-key-read.prolog').read_text())
    assert key.get('result') == 'ok', key
    key_text = s.run('first-key-formatted', 'format', key['bindings'][0]['PublicKey'])
    assert key_text.endswith('.')
    parse('activation-source-pin.prolog')
    pin = s.run('activation-source-pin', 'read', (p/'activation-source-pin.prolog').read_text())
    assert pin.get('result') == 'ok', pin
    pin_text = s.run('activation-pin-formatted', 'format', pin['bindings'][0]['Expected'])
    assert pin_text.endswith('.')
    template = (p/'activation-template.prolog').read_text()
    assert template.count(hex_literal('01'*32)) == 2 and template.count(hex_literal('02'*32)) == 1
    actual = template.replace(hex_literal('01'*32), key_text[:-1]).replace(hex_literal('02'*32), pin_text[:-1])
    with (p/'activation-submitted.prolog').open('x') as f:
        f.write(actual)
    parse('activation-submitted.prolog')
    accept('physical-activation', actual)
    save('activation-committed.json', {'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'atomic': True, 'installed': 'not yet established', 'mechanically_fulfilled': 'not yet established'})

if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        save('activation-STOP.json', {'type': type(error).__name__, 'reason': str(error),
            'rule': 'Resolve the original operation. Never rerun this driver.'})
        raise
