#!/usr/bin/env escript
%%! +S 4:4
-mode(compile).
main([Root,Out]) ->
 [code:add_patha(P)||P<-filelib:wildcard(Root++"/_build/test/lib/*/ebin")],
 code:add_patha(Root++"/_build/test/lib/quod/test"),
 {ok,quod_physics_tests,Tests}=compile:file(Root++"/test/quod_physics_tests.erl",[binary,export_all,{i,Root++"/include"}]),
 {module,quod_physics_tests}=code:load_binary(quod_physics_tests,"local-acceptance-helper",Tests),
 {ok,Text}=file:read_file(Out++"/activation-template.prolog"),
 {ok,#{goal:=Wire}}=quod_client_goal_parser:parse(Text,3),
 {ok,{'::',WorldNs,Target}}=quod_wire_term:materialize_symbols(Wire),
 {ok,RefsBytes}=file:read_file(Out++"/references.json"),Refs=json:decode(RefsBytes),
 Term=fun(Name)->{ok,#{goal:=W}}=quod_client_goal_parser:parse(<<(maps:get(Name,Refs))/binary,".">>,3),{ok,T}=quod_wire_term:materialize_symbols(W),T end,
 {ok,BaseBytes}=file:read_file(Out++"/baseline.json"),Base=json:decode(BaseBytes),
 WorldAnchor=Term(<<"anchor">>),Host=Term(<<"host">>),Human=Term(<<"human">>),Authority=Term(<<"authority">>),
 Transform=fun(Rules)->[R||R<-Rules,not lists:member(element(1,R),[instance_of,physics_space,physics_run,physics_structure,physics_next_body,physics_allowances,physics_body_definition,can_invoke])] end,
 Fun=fun(#{namespace:=Ns,node:=Node,reference:=Ref,key:=Key,identity:=Identity}) ->
   Map=#{WorldNs=>Ns,WorldAnchor=>element(3,Ref),Host=>Node,Human=>Node,Authority=>Ref,
         binary:decode_hex(maps:get(<<"root_anchor">>,Base))=><<42:256>>,
         binary:copy(<<1>>,32)=>Key,physics_authority=>actor,personal_lobby=>room},

   quod_physics_tests:commit(Ns,{',',{retract,{can_request_agent_signature,Node,actor,{'_'}}},
      {assertz,{can_assign_agent_host,Node,actor,none,0,Node,Key}}}),
   HashGoal={findall,{'D'},{',',{findall,{'C'},{'$quod_source_chunk',8192,{'C'}},{'Cs'}},{term_digest,{'Cs'},{'D'}}},[{'Expected'}]},
   {CanonicalHash,_,_}=erlog_int:term_instance(HashGoal,0),
   {ok,HB,HS}=quod_node_actor:signed_goal(read,{'::',Ns,CanonicalHash},crypto:strong_rand_bytes(32),quod_time:now_ms()+10000),
   {ok,_,{normalized,{read,_,{answers,_,[HA]}}}}=quod_client_goal_ingress:submit(HB,HS),
   {ok,HValues}=quod_client_result:decode_binding(HA),
   [Digest]=[V||{_,V}<-HValues,is_binary(V),byte_size(V)=:=32],
   _Goal=replace(Target,Map#{binary:copy(<<2>>,32)=>Digest}),
   Fmt=fun(T)->{ok,S}=quod_client_goal_parser:format_clause(T),string:trim(S,trailing,".\n") end,
   Pairs=[{maps:get(<<"authority">>,Refs),Fmt(Ref)},{maps:get(<<"human">>,Refs),Fmt(Node)},
      {maps:get(<<"host">>,Refs),Fmt(Node)},{maps:get(<<"namespace">>,Refs),Fmt(Ns)},
      {maps:get(<<"anchor">>,Refs),Fmt(element(3,Ref))},
      {hex_text(binary:decode_hex(maps:get(<<"root_anchor">>,Base))),Fmt(<<42:256>>)},
      {hex_text(binary:copy(<<1>>,32)),Fmt(Key)},{hex_text(binary:copy(<<2>>,32)),Fmt(Digest)}],
   Text0=lists:foldl(fun({Old,New},Acc)->binary:replace(Acc,Old,New,[global]) end,Text,Pairs),
   Text1=binary:replace(binary:replace(Text0,<<"physics_authority">>,<<"actor">>,[global]),<<"personal_lobby">>,<<"room">>,[global]),
   Request=#{network_identity=><<42:256>>,agent_namespace=>element(2,Node),agent_genesis_anchor=>element(3,Node),
      agent_instance_text=><<"physical_node.">>,signing_public_key=>maps:get(pubkey,Identity),operation_id=>crypto:strong_rand_bytes(32),
      not_after_ms=>quod_time:now_ms()+10000,mode=>execute,parser_version=>3,goal_text=>Text1},
   {ok,RequestBytes}=quod_client_goal:encode(Request),
   Signature=quod_identity:sign(RequestBytes,Identity),
   ok=file:write_file(Out++"/local-activation-submitted.prolog",Text1),
   true=quod_reg:subscribe({physics,Ns}),
   Result=quod_client_goal_ingress:submit(RequestBytes,Signature),
   ok=file:write_file(Out++"/local-activation-result.term",term_to_binary(Result)),
   io:format("activation: ~0p~n",[case Result of {ok,_,{normalized,{committed,Answers,Ref0}}}->{committed,length(Answers),Ref0};{ok,_,{normalized,R}}->R;E->E end]),
   {ok,_,{normalized,{committed,_,_}}}=Result,
   {Pid,World}=quod_physics_tests:installed(Ns),
   #{World:=#{spec:=Spec}}=quod_physics_tests:worlds(Ns),
   Status=gen_server:call(Pid,status),
   #{navigation_ready:=true,phase:=active}=Status,
   Bodies=maps:get(bodies,Spec),true=length(Bodies)=:=4,
   ok=file:write_file(Out++"/local-installed.term",term_to_binary(Spec)),
   Report=#{passed=>true,world=>iolist_to_binary(io_lib:format("~0p",[World])),
      bodies=>length(Bodies),status=>iolist_to_binary(io_lib:format("~0p",[Status])),
      concrete_signed_activation=>true,private_signing_grant_removed=>true},
   ok=file:write_file(Out++"/local-validation.json",json:encode(Report)),
   io:format("~s~n",[json:encode(Report)])
 end,
 quod_physics_tests:with_world(<<"personal-activation-validation">>,Fun,Transform).
replace(T,M) -> case maps:find(T,M) of {ok,R}->R;error->replace_children(T,M) end.
replace_children(T,M) when is_tuple(T)->list_to_tuple([replace(X,M)||X<-tuple_to_list(T)]);
replace_children([H|T],M)->[replace(H,M)|replace(T,M)];
replace_children(T,_)->T.

hex_text(B) -> iolist_to_binary(["<<\"",[["\\x",binary:encode_hex(<<X>>),"\\"]||<<X>><=B],"\">>"]).
