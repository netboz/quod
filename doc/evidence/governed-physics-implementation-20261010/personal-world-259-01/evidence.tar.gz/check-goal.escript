#!/usr/bin/env escript
%%! +S 4:4
-mode(compile).
main([File]) ->
 [code:add_patha(P)||P<-filelib:wildcard("/home/yan/src/quod/_build/test/lib/*/ebin")],
 {ok,B}=file:read_file(File),T=case filename:extension(File) of ".json"->json:decode(B);_->B end,
 io:format("bytes=~p parsed=~0p~n",[byte_size(T),case quod_client_goal_parser:parse(T,3) of {ok,_}->ok;E->E end]).
