from pathlib import Path
import base64, json, sys
import browser as b

p=Path(__file__).resolve().parent
label,key,duration=sys.argv[1],sys.argv[2],int(sys.argv[3])
assert 0 < duration <= 10000
with (p/(label+'.intent.json')).open('x') as f:
 json.dump({'kind':'normal desktop keyboard input','key':key,'held_ms':duration},f)
if not b.evaluate('return document.pointerLockElement===document.querySelector("canvas.world-canvas")'):
 b.command('/actions',{'actions':[{'type':'pointer','id':'mouse','parameters':{'pointerType':'mouse'},'actions':[
  {'type':'pointerMove','origin':'viewport','x':1500,'y':850},
  {'type':'pointerDown','button':0},{'type':'pointerUp','button':0}]}]})
assert b.evaluate('return document.pointerLockElement===document.querySelector("canvas.world-canvas")'),'pointer lock absent'
b.command('/actions',{'actions':[{'type':'key','id':'desktop','actions':[
 {'type':'keyDown','value':key},{'type':'pause','duration':duration},{'type':'keyUp','value':key}]}]})
state=b.inspect()
with (p/(label+'-dom.json')).open('x') as f:json.dump(state,f,indent=2)
with (p/(label+'.png')).open('xb') as f:f.write(base64.b64decode(b.command('/screenshot',method='GET')))
frames=[];requests=[]
for row in b.command('/log',{'type':'performance'}):
 m=json.loads(row['message'])['message'];v=m.get('params',{})
 if m['method']=='Network.webSocketFrameReceived':
  try:payload=json.loads(v['response']['payloadData'])
  except (ValueError,KeyError):continue
  if payload.get('type') in ['projection','simulation_frame','refresh','unavailable']:
   frames.append({'timestamp':v.get('timestamp'),'request_id':v.get('requestId'),'data':payload})
 if m['method']=='Network.requestWillBeSent' and '/api/' in v['request']['url']:
  requests.append({'id':v['requestId'],'method':v['request']['method'],'url':v['request']['url'].split('?')[0]})
for suffix,value in [('frames',frames),('requests',requests)]:
 with (p/(label+'-'+suffix+'.json')).open('x') as f:json.dump(value,f,indent=2)
poses=[x['data']['frame'] for x in frames if x['data'].get('frame')]
summary={'frames':len(poses),'position_first':poses[0]['poses'][0]['position'] if poses else None,
 'position_last':poses[-1]['poses'][0]['position'] if poses else None,
 'last_feedback':poses[-1].get('control_state') if poses else None,
 'contact_bodies':sorted({body for frame in poses for body in ['1','3','4']
  if 'contact('+body+',' in frame.get('control_state',{}).get('result','')}),
 'signed_control_requests':sum('/api/goals/control' in r['url'] for r in requests),
 'status':state['text']}
with (p/(label+'-summary.json')).open('x') as f:json.dump(summary,f,indent=2)
print(json.dumps(summary))
