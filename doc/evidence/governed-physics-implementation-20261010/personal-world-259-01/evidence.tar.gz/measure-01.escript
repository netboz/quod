#!/usr/bin/env escript
%%! +S 4:4
-mode(compile).
-include("/home/yan/src/quod/_build/test/lib/erlog/src/erlog_int.hrl").
main([Root,Out]) ->
 [code:add_patha(P)||P<-filelib:wildcard(Root++"/_build/test/lib/*/ebin")],
 {ok,Text}=file:read_file(Out++"/activation-template.prolog"),
 Parsed=quod_client_goal_parser:parse(Text,3),
 io:format("parser: ~p~n",[case Parsed of {ok,_}->ok;Error->Error end]),
 {ok,#{goal:=Goal}}=Parsed,
 {ok,B}=quod_wire_term:encode_canonical(Goal),
 {ok,Symbols}=quod_wire_term:goal_symbol_names(Goal),
 {ok,GeoText}=file:read_file(Out++"/geometry.prolog"),
 {ok,#{goal:=Geo,variables:=Vars}}=quod_client_goal_parser:parse(GeoText,3),
 {ok,Material}=quod_wire_term:materialize([Geo]),
 [MGeo]=Material,
 {succeed,Done}=erlog_int:prove_goal(MGeo,quod_committed_projection:new_est()),
 Bindings=maps:from_list([{Name,erlog_int:dderef({V},Done#est.bs)}||{Name,V}<-Vars]),
 Bodies=[{1,fixed,{vector,0,0,0},maps:get(<<"Floor">>,Bindings)},
         {2,controlled,{vector,0,760,2800},{capsule,500,250}},
         {3,fixed,{vector,0,0,0},maps:get(<<"Roof">>,Bindings)},
         {4,fixed,{vector,0,0,3850},maps:get(<<"Console">>,Bindings)}],
 Est0=quod_committed_projection:new_est(),
 Db=lists:foldl(fun erlog_int:assertz_clause/2,Est0#est.db,quod_prolog:read_terms(Root++"/priv/ontologies/quod_physics.pl")),
 [begin {succeed,_}=erlog_int:prove_goal({physics_valid_body,I,K,P,S,1,1000000},Est0#est{db=Db}) end||{I,K,P,S}<-Bodies],
 {ok,Result}=quod_durable_term:encode_result(Bindings),
 Diff=quod_prolog:terms_to_diff([{physics_body_definition,personal_lobby,I,1,K,P,{owned,S,1}}||{I,K,P,S}<-Bodies]),
 Measurements=#{goal_text_bytes=>byte_size(Text),goal_canonical_bytes=>byte_size(B),callable_symbols=>length(Symbols),geometry_result_bytes=>byte_size(Result),bodies=>length(Bodies),geometry_diff_bytes=>byte_size(term_to_binary(Diff)),floor_vertices=>length(element(2,maps:get(<<"Floor">>,Bindings))),roof_vertices=>length(element(2,maps:get(<<"Roof">>,Bindings)))},
 ok=file:write_file(Out++"/measurements.json",json:encode(Measurements)),
 ok=file:write_file(Out++"/prepared-local.term",term_to_binary(#{goal=>Goal,geometry=>Bindings})),
 io:format("~s~n",[json:encode(Measurements)]).
