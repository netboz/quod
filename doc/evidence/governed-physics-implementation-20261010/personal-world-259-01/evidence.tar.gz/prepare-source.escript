#!/usr/bin/env escript
%%! +S 4:4
-mode(compile).
main([Root,Out]) ->
 [code:add_patha(P)||P<-filelib:wildcard(Root++"/_build/test/lib/*/ebin")],
 code:add_patha(Root++"/_build/test/lib/quod/test"),
 {ok,quod_lobby_tests,Bin}=compile:file(Root++"/test/quod_lobby_tests.erl",[binary,export_all,{i,Root++"/include"}]),
 {module,quod_lobby_tests}=code:load_binary(quod_lobby_tests,"local-source-preparation",Bin),
 Source=iolist_to_binary([begin {ok,B}=file:read_file(Root++"/priv/ontologies/"++F),B end||F<-["agent_instance.pl","quod_physics.pl"]]),
 Drafts=quod_lobby_tests:source_predicate_drafts(Source),
 Rows=[begin {ok,I}=quod_client_goal_parser:format_clause(Indicator),
        #{indicator=>string:trim(I,trailing,".\n"),draft=>D} end||{Indicator,D}<-Drafts],
 ok=file:write_file(Out++"/source-drafts.json",json:encode(Rows)),
 Goal=quod_lobby_tests:authored_space_composition_goal(),
 {ok,Text}=quod_client_goal_parser:format_clause(Goal),
 ok=file:write_file(Out++"/space-composition-template.prolog",Text),
 io:format("~s~n",[json:encode(#{predicates=>length(Rows),last=>lists:sublist(lists:reverse(Rows),3),space_goal_bytes=>byte_size(Text)})]).
