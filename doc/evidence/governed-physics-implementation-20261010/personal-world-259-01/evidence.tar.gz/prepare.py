from pathlib import Path
import base64,json,math
p=Path(__file__).resolve().parent
base=json.loads((p/'baseline.json').read_text());catalogue=json.loads((p/'catalogue-anchors.json').read_text())
def bintext(s):return '<<"'+s+'">>'
def binaryhex(h):return '<<"'+''.join('\\x'+h[i:i+2]+'\\' for i in range(0,len(h),2))+'">>'
def anchor(s):return binaryhex(base64.urlsafe_b64decode(s+'='*((-len(s))%4)).hex())
w=base['dependencies'][1];a=base['dependencies'][0]
ns=bintext(w['ns']);wa=binaryhex(w['anchor_hex']);human=f'agent_instance_ref({bintext(a["ns"])},{binaryhex(a["anchor_hex"])},me)'
host='agent_instance_ref(<<"node:617e237fd538bc0f14e0d65389d9e2e9646bab3a16c782ab0a6d0900172f4d8e">>,'+binaryhex('61BD2995AA7118B7E31AE3A4EEA117D87EEA4679940265B828E19AB92E235457')+',me)'
authority=f'agent_instance_ref({ns},{wa},physics_authority)'
(p/'references.json').write_text(json.dumps({'namespace':ns,'anchor':wa,'human':human,'host':host,'authority':authority,'rendering':anchor(catalogue['Rendering']),'editor':anchor(catalogue['Editor'])},indent=2))
# These are explicitly authored low-detail physical surfaces, not decoded GLBs.
# Integer directions avoid introducing a new trigonometric runtime predicate.
dirs=','.join(f'd({round(1000000*math.cos(2*math.pi*j/24))},{round(1000000*math.sin(2*math.pi*j/24))},{round(1000*((1+math.cos(12*math.pi*j/24))/2)**1.5)})' for j in range(24))
indices=','.join(map(str,range(24)))
geometry=f'''findall(surface(Vertices,Triangles),
 (Directions = [{dirs}], member(Rings,[[ring(2200,0,0),ring(9000,0,0)],
                [ring(2250,4650,0),ring(5500,4325,181),ring(8950,3350,2900)]]),
  findall(vector(X,Y,Z),(member(ring(R,H,Drop),Rings),member(d(C,S,Q),Directions),
    X is R*C//1000000,Z is R*S//1000000,Y is H-Drop*Q//1000),Vertices),
  length(Rings,RingCount),
  findall(Triangle,(member(Row,[0,1]),Row < RingCount-1,member(J,[{indices}]),
    A is Row*24+J,B is (Row+1)*24+J,Cn is (J+1) mod 24,
    C is (Row+1)*24+Cn,D is Row*24+Cn,
    member(Triangle,[triangle(A,C,B),triangle(A,D,C)])),Triangles)),[Floor,Roof]),
Console = parts([part(vector(0,70,120),box(1000,70,500)),
 part(vector(0,175,80),box(920,35,420)),
 part(vector(0,590,120),box(380,410,240)),
 part(vector(0,1450,0),box(950,550,210))])'''
rows=[
'instance_of(physical_space,personal_lobby)','instance_of(agent,physics_authority)',
'physics_space(personal_lobby,enabled,physics_authority)','physics_run(personal_lobby,0,none)',
'physics_structure(personal_lobby,1)','physics_next_body(personal_lobby,5)',
'physics_allowances(personal_lobby,limits(16,16,128,1000000,geometry(32,256,256)),16667,-9810,10000)',
'physics_body_definition(personal_lobby,1,1,fixed,vector(0,0,0),owned(Floor,1))',
'physics_body_definition(personal_lobby,2,1,controlled,vector(0,760,2800),owned(capsule(500,250),1))',
'physics_body_definition(personal_lobby,3,1,fixed,vector(0,0,0),owned(Roof,1))',
'physics_body_definition(personal_lobby,4,1,fixed,vector(0,0,3850),owned(Console,1))',
'instance_of(agent,pilot)',
'physics_agent(personal_lobby,pilot,1,2,motion(grounded(900),2000,1600,500,query_limits(2,0,8,128),[]))',
'physics_viewpoint(personal_lobby,pilot,eye,2,pose(vector(0,700,0),rotation(0,0,0)),tracking(view_only,500))',
f'can_view_physics(personal_lobby,{human})',f'can_control_physics_agent(personal_lobby,{human},pilot)',
f'can_request_agent_signature({host},physics_authority,agent_goal_v1({binaryhex(base["root_anchor"])},{authority},_,_,_,_,execute,3,_))',
f'can_invoke((agent_hosted(physics_authority,{host},1,_),sign_agent_request(_, _)),{host},_,{ns})',
f'can_read_physics_body(personal_lobby,{human},2)',
f'can_invoke(physics_store_request(personal_lobby,_,_,_,_,_),{authority},_,{ns})',
f'can_invoke(physics_activate(personal_lobby,_,_),{authority},_,{ns})',
f'can_cancel_physics_activation(personal_lobby,{human})']
checks=['physics_checked_body(1,fixed,vector(0,0,0),Floor,1,1000000)',
'physics_checked_body(2,controlled,vector(0,760,2800),capsule(500,250),1,1000000)',
'physics_checked_body(3,fixed,vector(0,0,0),Roof,1,1000000)',
'physics_checked_body(4,fixed,vector(0,0,3850),Console,1,1000000)']
key=binaryhex('01'*32)
goals=[f'current_ontology_identity({ns},{wa})',"findall(Digest,(findall(Chunk,'$quod_source_chunk'(8192,Chunk),Chunks),term_digest(Chunks,Digest)),["+binaryhex('02'*32)+"])",'\\+ physics_space(_,_,_)','\\+ agent_host(_,_,_,_)',f'assertz(can_assign_agent_host({human},physics_authority,none,0,{host},{key}))',f'goal(agent_hosted(physics_authority,{host},1,{key}))',geometry]+checks+['assertz('+r+')' for r in rows]+['physics_control_agent(personal_lobby,0,none,controlled(pilot,eye))']
text=ns+'::transaction((\n'+',\n'.join(goals)+'\n)).\n'
(p/'activation-template.prolog').write_text(text)
(p/'geometry.prolog').write_text(geometry+'.\n')
(p/'geometry-design.json').write_text(json.dumps({'units':'millimetres','floor':{'surface':'annulus','inner_radius':2200,'outer_radius':9000,'angular_segments':24,'height':0},'roof':{'surface':'six scalloped openings and central oculus','rings':[[2250,4650,0],[5500,4325,181],[8950,3350,2900]],'purpose':'coarse conservative underside; 600mm downwards allowance, openings preserved','angular_segments':24},'spawn':[0,760,2800],'camera_local':[0,700,0],'console_body':4,'floor_body':1,'roof_body':3,'avatar_body':2,'body_revisions':1,'collision_authority':'explicit Prolog; independently authored coarse draft, not GLB or picking bounds'},indent=2))
print({'activation_bytes':len(text.encode()),'geometry_bytes':len(geometry.encode()),'physical_rows':len(rows)})
