from pathlib import Path
import base64,datetime,json,subprocess,sys
import browser as b
import signed as s
p=Path(__file__).resolve().parent
refs=json.loads((p/'references.json').read_text())
rows=json.loads((p/'source-drafts.json').read_text())
ns=json.loads((p/'baseline.json').read_text())['dependencies'][1]['ns']
auditdir=p/'publication-owner-checks-02';auditdir.mkdir(exist_ok=True)
def text_binary(value):
 return '<<"'+value.replace('\\','\\\\').replace('"','\\"').replace('\n','\\n').replace('\r','\\r').replace('\t','\\t')+'">>'
def audit(label):
 expression='Ns = <<"'+ns+'">>,H=quod_prolog:applied(Ns),D=quod_time:mono_ms()+10000,'+\
 'ok=quod_runtime:reconcile_resource(Ns,H,agent_hosts,all,D),ok=quod_runtime:reconcile_resource(Ns,H,physics_worlds,all,D),'+\
 '{Owner,[]}=quod_runtime:agents(Ns),0=map_size(gen_server:call(Owner,physics_worlds)),'+\
 'Stats=quod_runtime:stats(Ns),#{resource_failures:=Failures,reaction_failures:=0,reactions_executed:=0,reconcile_failures:=0}=Stats,'+\
 '0=map_size(Failures),#{height=>H,owner=>list_to_binary(pid_to_list(Owner)),stats=>Stats,inactive=>true}'
 command=['nomad','alloc','exec','-i=false','-t=false','-address=http://192.168.1.10:4646','-task','quod',
 '54af69b0-7ec7-34d7-725e-6dc3fbee0950','/opt/quod/bin/quod','eval',
 'binary_to_list(base64:encode(iolist_to_binary(json:encode(try begin '+expression+' end catch C:R -> #{error=>iolist_to_binary(io_lib:format("~0p",[{C,R}]))} end)))).']
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 result=subprocess.run(command,capture_output=True,text=True)
 (auditdir/(label+'.stdout')).write_text(result.stdout);(auditdir/(label+'.stderr')).write_text(result.stderr)
 (auditdir/(label+'.exit.json')).write_text(json.dumps({'exit':result.returncode,'started':start,'expression':expression},indent=2))
 assert result.returncode==0,(label,result.stderr)
 wire=json.loads(result.stdout)
 if isinstance(wire,list):wire=bytes(wire).decode()
 answer=json.loads(base64.b64decode(wire));(auditdir/(label+'.json')).write_text(json.dumps(answer,indent=2))
 assert answer.get('inactive') is True,(label,answer)
 return answer

def main():
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 assert s.run('renew-source-authoring-02','renew').get('renewed')
 script='''const done=arguments[arguments.length-1];import('/explorer/assets/world-CblDwDXV.js').then(m=>{
 quod27Evidence.format=binding=>m.y(m.h(binding));
 const c=m.v,a=m.g,v=m.T,n=m.S;const empty=m._(new Uint8Array());
 const shape=(t,f,k)=>t?.type==='compound'&&t.functor===f&&t.args.length===k;
 quod27Evidence.guard=binding=>{const e=m.h(binding);if(!shape(e,'::',2)||!shape(e.args[1],',',2))throw Error('unexpected compiler scope');const pair=e.args[1],tx=pair.args[1];if(!shape(tx,'transaction',1))throw Error('unexpected compiler transaction');
 const guards=[c('\\\\+',[c('physics_space',[v('GuardSpace'),v('GuardMode'),v('GuardAuthority')])]),c('\\\\+',[c('agent_host',[v('GuardAgent'),v('GuardHost'),v('GuardEpoch'),v('GuardKey')])]),c('$quod_predicate_source',[c('/',[a('physics_space'),n(3)]),empty]),c('$quod_predicate_source',[c('/',[a('agent_host'),n(4)]),empty])];
 const body=guards.reduceRight((r,g)=>c(',',[g,r]),tx.args[0]);return m.y(c('::',[e.args[0],c(',',[pair.args[0],c('transaction',[body])])]))};
 quod27Evidence.source=binding=>new TextDecoder('utf-8',{fatal:true}).decode(m.h(binding).value);done({ready:true})},e=>done({error:String(e)}));'''
 ready=b.command('/execute/async',{'script':script,'args':[]});assert ready.get('ready'),ready
 audit('before')
 for index,row in enumerate(rows,1):
  label='source02-'+str(index).zfill(3)
  if index%20==0:assert s.run(label+'-renew','renew').get('renewed')
  target='ontology_ref('+refs['namespace']+','+refs['anchor']+')'
  prefix='<<"quod:prolog">>::(current_ontology_identity(<<"quod:prolog">>,'+refs['editor']+'),'
  compile_goal=prefix+'prolog_edit_goal('+target+','+row['indicator']+',<<"">>,'+text_binary(row['draft'])+',Edit)).'
  compiled=s.run(label+'-compile','read',compile_goal);assert compiled.get('result')=='ok',(label,compiled)
  guarded=s.run(label+'-guard','guard',compiled['bindings'][0]['Edit']);assert isinstance(guarded,str)
  parsed=subprocess.run(['escript',str(p/'check-goal.escript'),str(p/(label+'-guard.json'))],capture_output=True,text=True);(p/(label+'-parse.log')).write_text(parsed.stdout+parsed.stderr);assert parsed.returncode==0 and parsed.stdout.rstrip().endswith('parsed=ok'),(label,parsed.stdout,parsed.stderr)
  proof=s.run(label+'-proof','cursor',guarded);assert proof.get('result')=='solution',(label,proof)
  outcome=s.run(label+'-accepted','command',proof['cursor'],'accept');assert outcome.get('result')=='ok',(label,outcome)
  read=s.run(label+'-readback','read',prefix+'prolog_source('+target+','+row['indicator']+',Source)).');assert read.get('result')=='ok',(label,read)
  canonical=s.run(label+'-canonical','source',read['bindings'][0]['Source']);assert canonical==row['draft'],(label,'source mismatch')
  check=audit(label)
  print(json.dumps({'index':index,'total':len(rows),'predicate':row['indicator'],'operation_id':proof['operation_id'],'world_height':check['height'],'inactive':True}),flush=True)
 (p/'source-publication-02-complete.json').write_text(json.dumps({'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'predicates':len(rows),'native_or_agents_allocated':False},indent=2))
if __name__=='__main__':
 try:main()
 except BaseException as e:
  (p/'source-publication-02-STOP.json').write_text(json.dumps({'type':type(e).__name__,'reason':str(e),'rule':'Resolve original operation; never rerun this driver'},indent=2));raise
