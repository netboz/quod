from pathlib import Path
import math,json
p=Path(__file__).resolve().parent
# Compare against authored procedural design, never load GLB collision geometry.
pts={s:[] for s in [-1,1]}
for i in range(33):
 t=i/32
 for j in range(288):
  a=2*math.pi*j/288;c=math.cos(a);s=math.sin(a);r=1.4+4.1*t;q=(1+math.cos(6*a))/2
  drop=3.6*q**1.5;y=5.2-1.6*t*t-drop*t**4
  dr=(-3.2*t-4*drop*t**3)/4.1;da=3.6*.75*6*math.sqrt(q)*math.sin(6*a)*t**4
  n=[-dr*c+da*s/r,1,-dr*s-da*c/r];mag=math.hypot(*n);n=[x/mag for x in n]
  for sign in [-1,1]:pts[sign].append([r*c+sign*.04*n[0],y+sign*.04*n[1],r*s+sign*.04*n[2]])
lo=min(x[1] for x in pts[-1]);crown=max(x[1] for x in pts[1])-lo
rs=8.75/math.hypot(pts[-1][32*288][0],pts[-1][32*288][2]);vs=(crown-1)/crown
bottom=[[x*rs*1000,(1+(y-lo)*vs)*1000,z*rs*1000] for x,y,z in pts[-1]]
def geometry(outer,offset):
 v=[]
 for r,h,d in [(2250,5250,0),(5500,4925,181),(outer,3950,2900)]:
  for j in range(24):
   a=2*math.pi*j/24;c=round(1e6*math.cos(a));s=round(1e6*math.sin(a));q=round(1000*((1+math.cos(6*a))/2)**1.5)
   v.append([int(r*c/1e6),h-d*q//1000-offset,int(r*s/1e6)])
 tris=[]
 for row in range(2):
  for j in range(24):
   a=row*24+j;b=(row+1)*24+j;c=(row+1)*24+(j+1)%24;d=row*24+(j+1)%24
   tris += [[v[k] for k in ids] for ids in [(a,c,b),(a,d,c)]]
 return tris
def height(x,z,tri):
 a,b,c=tri;den=(b[2]-c[2])*(a[0]-c[0])+(c[0]-b[0])*(a[2]-c[2])
 u=((b[2]-c[2])*(x-c[0])+(c[0]-b[0])*(z-c[2]))/den
 v=((c[2]-a[2])*(x-c[0])+(a[0]-c[0])*(z-c[2]))/den
 if min(u,v,1-u-v)<-1e-6:return None
 return u*a[1]+v*b[1]+(1-u-v)*c[1]
reports=[]
for outer,offset in [(8750,0),(8950,250),(8950,600)]:
 tris=geometry(outer,offset);low=[v for v in bottom if v[1]<=1800];missing=[];gaps=[]
 for x,y,z in low:
  ys=[h for tri in tris if (h:=height(x,z,tri)) is not None]
  if not ys:missing.append([x,y,z])
  else:gaps.append(min(ys)-y)
 reports.append({'outer_radius_mm':outer,'underside_offset_mm':offset,'design_samples_below_1800':len(low),'uncovered_low_samples':len(missing),'maximum_physical_minus_design_height_mm':max(gaps),'minimum_physical_minus_design_height_mm':min(gaps)})
(p/'roof-coverage.json').write_text(json.dumps({'basis':'authored formula in client/tools/build-lobby-roof.mjs; sampled validation, not continuous proof','reports':reports},indent=2));print(json.dumps(reports))
