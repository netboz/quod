{cases,"/home/yan/src/quod/_build/quod27-release-258/gates-01/tree/test",
       quod_agent_failover_SUITE,
       [validator_host_loss_recovers_state,abrupt_host_loss_recovers_state,
        suspended_host_retires_stale_process,
        uncertain_claim_recovers_after_quorum_loss,
        uncertain_claim_recovers_after_target_restart]}.
