acl_sovereign('grow:d').
can_invoke(_Goal, _Principal, _Chain, _Ns).
can_join(_Ns, _Addr, _Pk).
