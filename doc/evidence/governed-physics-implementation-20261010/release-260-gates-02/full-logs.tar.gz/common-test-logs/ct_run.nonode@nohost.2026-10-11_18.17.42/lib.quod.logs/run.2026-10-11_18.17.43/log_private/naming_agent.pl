can_invoke(_Goal, _Principal, _CallChain, _Ns).
can_join(_Ns, _Addr, Pk) :- peer_ready(Pk).
label_me(Salt, Name) :- quod:names::draw(Salt, Name).
