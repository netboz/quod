%% Coordinates: right-handed, Y up, console front -Z. Local rotations apply
%% X, then Y, then Z, before translation and parent composition. Lengths are
%% integer millimetres; angles degrees; optical factors and UV repeat permille.
%% Surface texture slots: base_colour is sRGB; normal is OpenGL tangent space;
%% orm is linear R=occlusion/G=roughness/B=metallic. JPEG assets use SHA-256.
%% quod:rendering — the marks a renderer may be asked to draw.
%%
%% A mark is a visual occurrence. It is not the thing it shows: several marks
%% may depict one entity, and a mark may depict nothing at all. Keeping the two
%% identities apart is what lets a bounded scene tree show a domain graph that
%% is not a tree, and what lets selection resolve through the entity rather
%% than through a mesh name.
%%
%% Nothing here is a rendering command. There are no verbs, no handles, no
%% engine API: a descriptor says what is there, and applying it is the client's
%% idempotent business. Babylon is one adapter; another engine reads the same
%% descriptors without any durable truth changing.
%%
%% Every number is a whole number. Lengths and offsets are millimetres, angles
%% are whole degrees. No float and no rational appears in a descriptor: ten
%% nodes must agree bit for bit, and the renderer is free to convert at its own
%% edge where approximation is harmless.
%%
%% Every identifier — a kind, a field, a colour, a placement, an ontology name —
%% is a binary. Only the predicates and the descriptor functors are symbolic.
%%
%% Model:
%%   mark_kind(Kind)                    one of the bounded geometries
%%   geometry_field(Kind, At, Field)    the fields that kind takes, in order
%%   placement(Placement)               where a label sits on its mark
%%   limit(What, Max)                   the bound a descriptor may not exceed
%%
%% The descriptor:
%%   mark(Id, Kind, Size, Transform, Material, Label, Depicts)
%%     Id        a view-scoped occurrence identity, not a domain name
%%     Size      ordered integer-mm fields, or a typed mesh_asset descriptor
%%     Transform transform(X,Y,Z,RX,RY,RZ) | body_pose(Id, Revision)
%%               | relative(Parent, transform(...)) | relative(Parent, body_pose(...))
%%     Material  surface(Colour, Metal, Rough, Emission, Textures) |
%%               asset_surfaces for meshes | no_surface for groups.
%%               Optical factors/repeats are permille.
%%     Label     label(Text, Placement) | unlabelled
%%     Depicts   depicts(Ontology, Anchor, Entity) | depicts_nothing
%%               Unanchored depicts(Ontology, Entity) is display-only.
%%
%% Asked:
%%   well_formed_mark(+Mark)            one descriptor against its schema
%%   well_formed_scene(+Marks)          a bounded list with distinct ids
%%   depicted(+Marks, ?Id, ?Ns, ?Thing) which mark shows what
%%
%% Interactive subjects carry the exact history anchor. The client proves that
%% identity in the selected scope before reading its menu or workspace.

acl_sovereign(quod:rendering).

%% Anyone may read the vocabulary and check a descriptor against it. Changing
%% the vocabulary stays with admitted nodes, as in the other system ontologies.
can_invoke(Goal, _Principal, _CallChain, _Ns) :- rendering_query(Goal).
can_invoke((current_ontology_identity(_, _), Goal), _Principal, _CallChain, _Ns) :-
    rendering_query(Goal).
can_invoke(Goal, _, _, _) :- system_source_query(Goal).
can_invoke(_Goal, node(NodeKey), _CallChain, _Ns) :-
    peer_admitted(NodeKey, _, _, NodeKey).
can_join(_Ns, _Addr, Pk) :- peer_ready(Pk).

rendering_query(mark_kind(_)).
rendering_query(geometry_field(_, _, _)).
rendering_query(placement(_)).
rendering_query(limit(_, _)).
rendering_query(well_formed_mark(_)).
rendering_query(well_formed_scene(_)).
rendering_query(depicted(_, _, _, _)).
rendering_query(depicted(_, _, _, _, _)).
rendering_query(isa(_, _)).
rendering_query(instance_of(_, _)).
rendering_query(have_attribute(_, _, _)).
rendering_query(attribute(_, _, _)).
rendering_query(Goal) :- public_source_query(Goal).

%% --- the geometries -----------------------------------------------------------
%% Seven bounded parameterized shapes, a transform group and an asset mesh.
%% Primitive fields are declared once, in order, so the client never has to
%% know that a box's three numbers happen to be width, height and depth.

mark_kind(<<"box">>).
mark_kind(<<"sphere">>).
mark_kind(<<"plane">>).
mark_kind(<<"cylinder">>).
mark_kind(<<"capsule">>).
mark_kind(<<"torus">>).
mark_kind(<<"sky_sphere">>).
mark_kind(<<"group">>).
mark_kind(<<"mesh">>).

geometry_field(<<"box">>, 1, <<"width">>).
geometry_field(<<"box">>, 2, <<"height">>).
geometry_field(<<"box">>, 3, <<"depth">>).
geometry_field(<<"sphere">>, 1, <<"diameter">>).
geometry_field(<<"plane">>, 1, <<"width">>).
geometry_field(<<"plane">>, 2, <<"height">>).
geometry_field(<<"cylinder">>, 1, <<"diameter">>).
geometry_field(<<"cylinder">>, 2, <<"height">>).
geometry_field(<<"capsule">>, 1, <<"diameter">>).
geometry_field(<<"capsule">>, 2, <<"height">>).
geometry_field(<<"torus">>, 1, <<"diameter">>).
geometry_field(<<"torus">>, 2, <<"thickness">>).
geometry_field(<<"sky_sphere">>, 1, <<"diameter">>).


placement(<<"above">>).
placement(<<"centre">>).
placement(<<"below">>).

%% --- the bounds ---------------------------------------------------------------
%% Every bound a descriptor is held to, in one place, readable by whoever
%% produces descriptors so no producer has to guess or keep its own copy.
%%
%% `label` is deliberately short. A label is display text, never an identity —
%% the identity is in `depicts` — so a producer may shorten one to fit.

limit(<<"scene">>, 512).
%% Structural occurrence paths include their instance and named parts.
limit(<<"mark_id">>, 256).
limit(<<"label">>, 24).
limit(<<"ontology">>, 64).
limit(<<"extent">>, 100000).
limit(<<"offset">>, 1000000).
limit(<<"mesh_scale">>, 100000).
%% Asset allowances are ontology policy. The client checks measured GLB costs.
limit(<<"mesh_transfer_bytes">>, 8000000).
limit(<<"mesh_geometry_bytes">>, 16000000).
limit(<<"mesh_vertices">>, 250000).
limit(<<"mesh_triangles">>, 250000).
limit(<<"mesh_nodes">>, 1024).
limit(<<"mesh_materials">>, 256).
limit(<<"mesh_pixels">>, 16000000).

%% --- a descriptor against its schema ------------------------------------------

%% well_formed_mark(+Mark): every part is present, declared, and within bounds.
well_formed_mark(mark(Id, Kind, Size, Transform, Material, Label, Depicts)) :-
    bounded_text(Id, <<"mark_id">>),
    mark_kind(Kind),
    findall(Field, geometry_field(Kind, _, Field), Fields),
    geometry(Kind, Fields, Size),
    geometry_constraint(Kind, Size),
    placed(Transform),
    appearance(Kind, Material, Label),
    refers(Depicts).

%% The fields arrive in the kind's declared order and each carries one positive
%% extent. A missing field, an extra field or a reordered one has no answer.
sized([], []).
sized([Field | Fields], [f(Field, Extent) | Rest]) :-
    integer(Extent),
    Extent > 0,
    limit(<<"extent">>, Max),
    Extent =< Max,
    sized(Fields, Rest).

geometry(<<"mesh">>, [],
         mesh_asset(asset(Digest, <<"model/gltf-binary">>), <<"gltf2-static-v1">>,
                    scale(Scale), frame(aabb(MinX, MinY, MinZ, MaxX, MaxY, MaxZ),
                                        pivot(PX, PY, PZ), front(Front)),
                    resources(Transfer, Geometry, Vertices, Triangles, Nodes, Materials, Pixels))) :-
    binary_codes(Digest, Bytes), length(Bytes, 64), digest_hex(Bytes),
    integer(Scale), Scale > 0, limit(<<"mesh_scale">>, MaxScale), Scale =< MaxScale,
    offset(MinX), offset(MinY), offset(MinZ),
    offset(MaxX), offset(MaxY), offset(MaxZ),
    MinX < MaxX, MinY < MaxY, MinZ < MaxZ,
    offset(PX), offset(PY), offset(PZ),
    mesh_extent(MinX, MaxX, PX, Scale),
    mesh_extent(MinY, MaxY, PY, Scale),
    mesh_extent(MinZ, MaxZ, PZ, Scale),
    member(Front, [<<"-z">>, <<"+z">>, <<"+x">>, <<"-x">>]),
    resource(Transfer, <<"mesh_transfer_bytes">>),
    resource(Geometry, <<"mesh_geometry_bytes">>),
    resource(Vertices, <<"mesh_vertices">>),
    resource(Triangles, <<"mesh_triangles">>),
    resource(Nodes, <<"mesh_nodes">>),
    resource(Materials, <<"mesh_materials">>),
    resource(Pixels, <<"mesh_pixels">>).
geometry(Kind, Fields, Size) :- Kind \== <<"mesh">>, sized(Fields, Size).

resource(Allowed, Name) :-
    integer(Allowed), Allowed > 0, limit(Name, Maximum), Allowed =< Maximum.

mesh_extent(Min, Max, Pivot, Scale) :-
    limit(<<"extent">>, Maximum), Bound is Maximum * 1000,
    Span is (Max - Min) * Scale, Span =< Bound,
    Low is abs((Min - Pivot) * Scale), Low =< Bound,
    High is abs((Max - Pivot) * Scale), High =< Bound.

%% These two shapes have relationships between their dimensions which field
%% validation alone cannot express. A capsule's total height contains both
%% rounded ends; a torus tube must fit inside its overall diameter.
geometry_constraint(<<"capsule">>, [f(<<"diameter">>, D), f(<<"height">>, H)]) :-
    H >= D.
geometry_constraint(<<"torus">>, [f(<<"diameter">>, D), f(<<"thickness">>, T)]) :-
    T < D.
geometry_constraint(Kind, _) :-
    mark_kind(Kind), Kind \== <<"capsule">>, Kind \== <<"torus">>.

placed(body_pose(Body, Revision)) :-
    integer(Body), Body >= 0, Body < 18446744073709551616,
    integer(Revision), Revision > 0, Revision < 18446744073709551616.
placed(transform(X, Y, Z, RX, RY, RZ)) :-
    offset(X), offset(Y), offset(Z),
    turn(RX), turn(RY), turn(RZ).
placed(relative(Parent, Transform)) :-
    bounded_text(Parent, <<"mark_id">>),
    attachment_pose(Transform).
attachment_pose(transform(X,Y,Z,RX,RY,RZ)) :- placed(transform(X,Y,Z,RX,RY,RZ)).
attachment_pose(body_pose(Body, Revision)) :- placed(body_pose(Body, Revision)).

offset(V) :-
    integer(V),
    limit(<<"offset">>, Max),
    V =< Max,
    Least is 0 - Max,
    V >= Least.

turn(V) :- integer(V), V >= 0, V < 360.

surfaced(surface(Colour, Metallic, Roughness, Emission, Textures)) :-
    colour(Colour), fraction(Metallic), fraction(Roughness), fraction(Emission),
    texture_bindings(Textures, []).

%% One binding per semantic slot. Assets are verified JPEG bytes, addressed by
%% lowercase SHA-256; references never carry a URL or executable engine code.
texture_bindings([], _).
texture_bindings([texture(Slot, asset(Digest, <<"image/jpeg">>), repeat(U, V)) | Rest], Seen) :-
    texture_slot(Slot), \+ member(Slot, Seen),
    binary_codes(Digest, Bytes), length(Bytes, 64), digest_hex(Bytes),
    integer(U), U > 0, integer(V), V > 0,
    texture_bindings(Rest, [Slot | Seen]).
texture_slot(<<"base_colour">>).
texture_slot(<<"normal">>).
texture_slot(<<"orm">>).
digest_hex([]).
digest_hex([C | Cs]) :- digest_digit(C), digest_hex(Cs).
digest_digit(C) :- C >= 48, C =< 57.
digest_digit(C) :- C >= 97, C =< 102.

fraction(N) :- integer(N), N >= 0, N =< 1000.

appearance(<<"group">>, no_surface, Label) :- labelled(Label).
%% Embedded accepted glTF materials are preserved; source material names never
%% acquire domain identity or permission.
appearance(<<"mesh">>, asset_surfaces, Label) :- labelled(Label).
appearance(Kind, Material, Label) :-
    Kind \== <<"group">>, Kind \== <<"mesh">>, surfaced(Material), labelled(Label).

%% A colour is written the way a designer writes it: 35 is "#", and the six
%% digits are upper-case hex so one colour has one spelling.
colour(Colour) :-
    binary_codes(Colour, [Hash | Digits]),
    Hash =:= 35,
    length(Digits, 6),
    hex(Digits).

hex([]).
hex([Code | Rest]) :- hex_digit(Code), hex(Rest).

hex_digit(Code) :- Code >= 48, Code =< 57.
hex_digit(Code) :- Code >= 65, Code =< 70.

labelled(unlabelled).
labelled(label(Text, Placement)) :-
    bounded_text(Text, <<"label">>),
    placement(Placement).

%% A mark that shows a domain thing names the ontology it belongs to and the
%% ground term that identifies it there. A mark that shows nothing — a rule, a
%% ground plane — says so rather than inventing a subject.
refers(depicts_nothing).
refers(depicts(Ontology, Thing)) :-
    bounded_text(Ontology, <<"ontology">>),
    term_variables(Thing, []).
refers(depicts(Ontology, Anchor, Thing)) :-
    refers(depicts(Ontology, Thing)),
    binary_codes(Anchor, Bytes), length(Bytes, 32).

bounded_text(Text, What) :-
    binary_codes(Text, Codes),
    length(Codes, Count),
    Count > 0,
    limit(What, Max),
    Count =< Max.

%% --- a scene ------------------------------------------------------------------

%% well_formed_scene(+Marks): a bounded list of well-formed marks whose ids are
%% distinct. Nothing here requires the subjects to be distinct: several marks
%% depicting one entity is ordinary, and forbidding it would forbid showing the
%% same thing twice.
well_formed_scene(Marks) :-
    term_variables(Marks, []),
    limit(<<"scene">>, Max),
    length(Marks, Count),
    Count =< Max,
    every_mark(Marks),
    findall(Id, member(mark(Id, _, _, _, _, _, _), Marks), Ids),
    sort(Ids, Distinct),
    length(Distinct, Count),
    parent_order(Marks, []).

%% Parents precede their children. This also excludes dangling references,
%% self-parenting and cycles, without a second graph traversal per occurrence.
parent_order([], _Seen).
parent_order([mark(Id, _, _, At, _, _, _) | Rest], Seen) :-
    available_parent(At, Seen), parent_order(Rest, [Id | Seen]).
available_parent(transform(_, _, _, _, _, _), _Seen).
available_parent(body_pose(_, _), _Seen).
available_parent(relative(Parent, _), Seen) :- member(Parent, Seen).

every_mark([]).
every_mark([Mark | Rest]) :- well_formed_mark(Mark), every_mark(Rest).

%% depicted(+Marks, ?Id, ?Ontology, ?Thing): which mark shows what. Leave Id
%% unbound and bind Thing to enumerate every mark depicting one entity.
depicted(Marks, Id, Ontology, Thing) :-
    member(mark(Id, _, _, _, _, _, depicts(Ontology, Thing)), Marks).

%% Exact-history introspection preserves the subject anchor.
depicted(Marks, Id, Ontology, Anchor, Thing) :-
    member(mark(Id, _, _, _, _, _, depicts(Ontology, Anchor, Thing)), Marks).

%% --- the class view -----------------------------------------------------------
%% The house vocabulary of doc/outdated/content-layer-design.md, derived from the
%% relations above rather than stored beside them, so the two views cannot
%% disagree.

isa(mark, thing).
isa(geometry, thing).

instance_of(geometry, Kind) :- mark_kind(Kind).

have_attribute(geometry, field, binary).
have_attribute(mark, depicts, term).

attribute(Kind, field, Field) :- geometry_field(Kind, _, Field).

isa(eidolon, thing).
isa(model_eidolon, eidolon).
isa(surface_eidolon, eidolon).
isa(gui_eidolon, eidolon).
