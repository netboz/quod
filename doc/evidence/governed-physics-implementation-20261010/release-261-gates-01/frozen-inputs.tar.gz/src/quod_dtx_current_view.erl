-module(quod_dtx_current_view).
-moduledoc """
Committee corroboration for DTX recovery, independent operations and sealed reads.

Applied verification freezes the committee certified by the exact Resolve and
asks distinct members of that committee for signed replies. `f + 1` replies
form one portable certificate that source validators can verify locally. Public
outcome lookup retains its separate certified-current-view rule. In both cases,
one Byzantine responder can never decide a claim or outcome.

Routes are identity-pinned transport hints, never committee evidence. There is
no owner process, second history cache, or retained proof object: every call
uses the shared `quod_foreign_log` cache and bounded temporary probes, and
returns `retry` whenever history, routing, membership, application, or a reply
is uncertain. One probe is created per validator key; that probe tries the
shared key resolver's current endpoint, the existing live candidates, and the
certified historical fallback sequentially after deduplication. The transport
still authenticates the expected key; no endpoint creates another vote or
request id.

Read certification uses the same frozen-view routing and quorum collector. A
target validator checks the sealed read-only plan through shared plan admission
at its current committed head, then signs the plan digest and the
immutable claim of its certified ledger anchor. Different valid finality-proof
subsets for that same claim remain interchangeable evidence. The collector
keeps the plan vocabulary opaque.

Independent application certificates bind the exact applied entry to its
historical committee. A successful application response may carry the exact
entry already read by that target and that responder's signed result vote.
Both pass through the ordinary exact-entry and vote verifiers, then seed the
same quorum collector; they create no second authority or recovery path.
Uncertain delivery is never retried at a different endpoint. Observation votes
do not authorize a new submission.
""".

-include("quod_proof_limits.hrl").
-include("quod_ledger.hrl").

-export([submit_claim_application/5,
         submit_operation_to/5,
         certify_applied_many/3, certify_reads/3, lookup_outcome/4,
         operation_result/5, certify_operation_evidence/6]).

-ifdef(TEST).
-export([test_certify_applied/6, test_certify_applied_many/4,
         test_certify_operation/5,
         test_certify_reads/4,
         test_lookup_outcome/5,
         test_production_dependencies/0,
         test_read_anchor_source/4,
         test_endpoint_failure_disposition/2,
         test_submit_operation_candidates/2]).
-endif.

-define(MAX_UINT64, 16#FFFFFFFFFFFFFFFF).
-define(PROBE_CLEANUP_MS, 1000).

-type identity() :: {binary(), <<_:256>>}.
-type local_source() :: quod_simplex:history_view().
-type source() ::
        {local, local_source()} |
        {remote, [{<<_:256>>, [term()]}]}.
-type claim() ::
        #{target := identity(),
          group_id := <<_:256>>,
          resolve_ref := quod_dtx:certified_ref(),
          generation := non_neg_integer(),
          verdict := commit | abort}.
-type many_result() :: {verified, quod_applied_certificate:applied_certificate()} | retry.
-type outcome_result() ::
        {ok, map()} | {error, retry | invalid_request}.

%% The co-hosted and remote cases share one correlated submission walk.
%% Routes remain hints; the target independently verifies foreign evidence.
-spec submit_operation(binary(), identity(), quod_dtx_endpoint:request(),
                       pos_integer()) ->
          {ok, quod_dtx_endpoint:response()} |
          {ok, quod_dtx_endpoint:response(),
           [quod_dtx_endpoint:validation_item()]} |
          {error, busy | not_ready | invalid_request | timeout |
                  connection_lost}.
submit_operation(OwnerNs, {TargetNs, <<_:256>> = Anchor} = Target,
                 Request, TimeoutMs)
  when is_binary(OwnerNs), byte_size(OwnerNs) > 0,
       is_binary(TargetNs), byte_size(TargetNs) > 0,
       is_integer(TimeoutMs), TimeoutMs > 0 ->
    BoundedTimeout = min(
                       TimeoutMs,
                       ?QUOD_DTX_ENDPOINT_WORKER_TIMEOUT_MS),
    case quod_dtx_endpoint:encode_request(TargetNs, Request, []) of
        {ok, _} ->
            submit_operation_target(
              OwnerNs, Target, Anchor, Request,
              quod_time:mono_ms() + BoundedTimeout);
        {error, _} ->
            {error, invalid_request}
    end;
submit_operation(_OwnerNs, _Target, _Request, _TimeoutMs) ->
    {error, invalid_request}.

-doc "Submit a claimed application through the route implied by its effect custody.".
-spec submit_claim_application(binary(), identity(), tuple(),
                               quod_dtx_endpoint:request(), pos_integer()) ->
          {ok, quod_dtx_endpoint:response(),
           [quod_dtx_endpoint:validation_item()]} |
          {error, busy | not_ready | invalid_request | timeout |
                  connection_lost}.
submit_claim_application(OwnerNs, Target, Claim,
                         {apply_claim, _, Target, _} = Request, TimeoutMs) ->
    case quod_transaction:remote_claim_route(Claim, Target) of
        shared ->
            submit_operation(OwnerNs, Target, Request, TimeoutMs);
        {private, TargetNode} ->
            submit_operation_to(
              OwnerNs, Target, TargetNode, Request, TimeoutMs);
        error ->
            {error, invalid_request}
    end;
submit_claim_application(_OwnerNs, _Target, _Claim, _Request, _TimeoutMs) ->
    {error, invalid_request}.

-doc "Submit to one exact authenticated target node, for private custody recovery.".
-spec submit_operation_to(binary(), identity(), <<_:256>>,
                          quod_dtx_endpoint:request(), pos_integer()) ->
          {ok, quod_dtx_endpoint:response()} |
          {ok, quod_dtx_endpoint:response(),
           [quod_dtx_endpoint:validation_item()]} |
          {error, busy | not_ready | invalid_request | timeout |
                  connection_lost}.
submit_operation_to(OwnerNs, {TargetNs, <<_:256>> = Anchor} = Target,
                    <<_:256>> = TargetNode, Request, TimeoutMs)
  when is_binary(OwnerNs), byte_size(OwnerNs) > 0,
       is_binary(TargetNs), byte_size(TargetNs) > 0,
       is_integer(TimeoutMs), TimeoutMs > 0 ->
    BoundedTimeout = min(TimeoutMs, ?QUOD_DTX_ENDPOINT_WORKER_TIMEOUT_MS),
    case quod_dtx_endpoint:encode_request(TargetNs, Request, []) of
        {ok, _} ->
            submit_operation_exact_target(
              OwnerNs, Target, Anchor, TargetNode, Request,
              quod_time:mono_ms() + BoundedTimeout);
        {error, _} ->
            {error, invalid_request}
    end;
submit_operation_to(_OwnerNs, _Target, _TargetNode, _Request, _TimeoutMs) ->
    {error, invalid_request}.

submit_operation_exact_target(
  OwnerNs, {TargetNs, _} = Target, Anchor, TargetNode, Request, Deadline) ->
    case {TargetNode =:= node_key(), quod_reg:where({quod_simplex, TargetNs})} of
        {true, Pid} when is_pid(Pid) ->
            case quod_simplex:genesis_hash(TargetNs) of
                Anchor ->
                    operation_response(
                      Request,
                      quod_simplex:dtx_endpoint_local(
                        TargetNs, Request, [], remaining_positive(Deadline)));
                _ ->
                    submit_operation_exact_routes(
                      OwnerNs, Target, TargetNode, Request, Deadline)
            end;
        _ ->
            submit_operation_exact_routes(
              OwnerNs, Target, TargetNode, Request, Deadline)
    end.

submit_operation_exact_routes(
  OwnerNs, {TargetNs, _} = Target, TargetNode, Request, Deadline) ->
    case quod_foreign_log:route_hints(Target, []) of
        {ok, Routes} ->
            case lists:keyfind(TargetNode, 1, Routes) of
                {TargetNode, Endpoints} ->
                    submit_operation_candidates(
                      OwnerNs, TargetNs,
                      [{TargetNode, Endpoint} || Endpoint <- Endpoints],
                      Request, Deadline, not_ready);
                false ->
                    {error, not_ready}
            end;
        {error, _} ->
            {error, not_ready}
    end.

submit_operation_target(OwnerNs, {TargetNs, _} = Target, Anchor,
                        Request, Deadline) ->
    case quod_reg:where({quod_simplex, TargetNs}) of
        Pid when is_pid(Pid) ->
            case quod_simplex:genesis_hash(TargetNs) of
                Anchor ->
                    operation_response(
                      Request,
                      quod_simplex:dtx_endpoint_local(
                        TargetNs, Request, [], remaining_positive(Deadline)));
                _ ->
                    submit_operation_routes(
                      OwnerNs, Target, Request, Deadline)
            end;
        undefined ->
            submit_operation_routes(OwnerNs, Target, Request, Deadline)
    end.

submit_operation_routes(OwnerNs, {TargetNs, _} = Target,
                        Request, Deadline) ->
    case quod_foreign_log:route_hints(Target, []) of
        {ok, Routes} ->
            submit_operation_candidates(
              OwnerNs, TargetNs,
              [{PeerKey, Endpoint}
               || {PeerKey, Endpoints} <- Routes,
                  Endpoint <- Endpoints],
              Request, Deadline, not_ready);
        {error, _} ->
            {error, not_ready}
    end.

submit_operation_candidates(_OwnerNs, _TargetNs, [], _Request,
                            _Deadline, Last) ->
    {error, Last};
submit_operation_candidates(OwnerNs, TargetNs, Candidates, Request,
                            Deadline, Last) ->
    submit_operation_candidates(
      OwnerNs, TargetNs, Candidates, Request, Deadline, Last,
      fun(Key, Endpoint, Remaining) ->
              quod_simplex:dtx_endpoint_request(
                OwnerNs, TargetNs, Key, Endpoint, Request, [], Remaining)
      end).

submit_operation_candidates(_OwnerNs, _TargetNs, [], _Request,
                            _Deadline, Last, _Attempt) ->
    {error, Last};
submit_operation_candidates(OwnerNs, TargetNs,
                            [{PeerKey, Endpoint} | Rest], Request,
                            Deadline, Last, Attempt) ->
    case remaining(Deadline) of
        0 -> {error, Last};
        Remaining ->
            Result = Attempt(PeerKey, Endpoint, Remaining),
            case operation_response(Request, Result) of
                {error, Reason} ->
                    case endpoint_failure_disposition(Request, Reason) of
                        stop -> {error, Reason};
                        next ->
                            submit_operation_candidates(
                              OwnerNs, TargetNs, Rest, Request,
                              Deadline, Reason, Attempt)
                    end;
                Ok -> Ok
            end
    end.

%% Cancellation mutates a node-private idempotent journal row. Once any exact
%% endpoint attempt fails, its sole custody owner parks until the directory
%% publishes a real route edge; walking stale alternatives here would turn a
%% transport failure into an immediate semantic retry. A timeout or authenticated
%% link loss is likewise uncertain for every write/read request and must return
%% to its existing history/recovery owner instead of resubmitting automatically.
endpoint_failure_disposition({cancel_operation_effect, _, _, _}, _Reason) -> stop;
endpoint_failure_disposition(_Request, timeout) -> stop;
endpoint_failure_disposition(_Request, connection_lost) -> stop;
endpoint_failure_disposition(_Request, _Reason) -> next.

operation_response({apply_claim, _, _, _} = Request,
                   {ok, Response, ValidationSidecar}) ->
    case quod_dtx_endpoint:correlates(Request, Response) of
        true -> {ok, Response, ValidationSidecar};
        false -> {error, invalid_request}
    end;
operation_response(Request, {ok, Response, _ValidationSidecar}) ->
    case quod_dtx_endpoint:correlates(Request, Response) of
        true -> {ok, Response};
        false -> {error, invalid_request}
    end;
operation_response(_Request, {error, Reason}) ->
    {error, Reason}.

remaining_positive(Deadline) ->
    max(1, remaining(Deadline)).

-doc """
Build participant-applied certificates under the original absolute deadline.

Each request carries the exact Resolve evidence already verified by the
coordinator. For valid input the returned list is aligned with `Requests`. An
exact certificate is retained as `{verified, Certificate}` even when another
participant is temporarily unavailable; only that participant's row is
`retry`. A caller authorizing Complete must still require every row.
""".
-spec certify_applied_many(binary(), [{source(), claim(), map()}], integer()) ->
          {ok, [many_result()]} | {error, invalid_request | retry}.
certify_applied_many(OwnerNs, Requests, Deadline) ->
    certify_applied_many_with(
      OwnerNs, Requests, Deadline, production_dependencies()).

certify_operation_with(OwnerNs, Ref,
  Evidence = #{identity := Target, phase := transaction, slot := Slot,
               block_hash := Hash, record_digest := Digest}, SeedVotes,
  Deadline, Dependencies)
  when is_binary(OwnerNs), is_integer(Deadline) ->
    case {quod_dtx:certified_ref_claim(Ref), historical_committee_view(Target, Evidence),
          dependency_network_identity(Dependencies)} of
        {{ok, {Target, Slot, Hash, Digest}}, {ok, Committee, _CommitteeId, Routes}, {ok, Network}} ->
            %% This local hint is transport selection only. The exact historical
            %% evidence was already resolved against its exact reference;
            %% do not capture a new view.
            %% Local endpoint admission still checks this reference's anchor.
            Probe = fun(Key, Source) ->
                Request = {operation_applied, request_id(), Ref},
                Verify = fun(Result) ->
                    operation_response_vote(Network, Evidence, Key, Result)
                end,
                case probe_source(Source, OwnerNs, element(1, Target), Key,
                                  Request, Deadline, Dependencies, Verify) of
                    {ok, Statement, Vote} -> {signed, {operation, Statement}, Vote, none};
                    ignore -> ignore
                end
            end,
            Seeds = operation_seed_votes(
                      Ref, Network, Evidence, Committee, SeedVotes),
            Seeded = maps:from_list(
                       [{Signer, true}
                        || {signed, _, {Signer, _}, _} <- Seeds]),
            with_probe_sources(
              {local, Target}, Committee, Routes, Seeded,
              Deadline, Dependencies,
                fun(Sources, Needed) ->
                    case collect_quorum(
                           operation_applied_probe, Sources,
                           Needed, Deadline, Probe, Seeds) of
                        {ok, {signed, {operation, Statement}, Rows}} ->
                            {ok, Certificate} = quod_applied_certificate:operation_certificate(
                                                  Statement, signed_rows(Rows)),
                            %% Each collected row was authenticated against this
                            %% exact statement and historical member at receipt.
                            case remaining(Deadline) > 0 of
                                true -> {ok, Certificate};
                                false -> {error, retry}
                            end;
                        _ -> {error, retry}
                    end
                end);
        {_, _, {error, _}} -> {error, retry};
        _ -> {error, invalid_request}
    end;
certify_operation_with(_, _, _, _, _, _) -> {error, invalid_request}.

%% The same finite verify/certify work serves live delivery, restarted owners
%% and read-only receipt lookup. Known is either an already-verified capture
%% or just discovery bytes. Never recapture a sufficient verified entry.
-doc "Verify or certify exact application evidence within the original absolute deadline.".
-spec certify_operation_evidence(binary(), identity(), quod_dtx:certified_ref(), map(),
                                  none | quod_applied_certificate:operation_certificate(), integer()) ->
          {ok, quod_dtx:certified_ref(), map(), none | quod_applied_certificate:operation_certificate()} |
          {error, term()}.
certify_operation_evidence(OwnerNs, Target, Ref,
                           #{transaction := Transaction} = Known, Certificate, Deadline) ->
    EntryHint = maps:get(entry_hint, Known, none),
    SeedVotes = maps:get(operation_votes, Known, []),
    Exact = quod_trace:with_optional_span(
      quod_trace:context(), <<"quod.operation.exact_evidence">>, internal,
      #{'quod.owner.namespace' => OwnerNs},
      fun() ->
          case Known of
              #{phase := transaction, committee := _} -> {ok, Known};
              _ -> quod_foreign_log:resolve_reference(
                     Target, Ref, transaction, none, EntryHint, Deadline)
          end
      end),
    case Exact of
        {ok, #{transaction := ExactTransaction} = Evidence} ->
            certify_matching_operation_evidence(
              quod_transaction:same_ledger_transaction(Transaction, ExactTransaction),
              OwnerNs, Ref, Evidence, Certificate, SeedVotes, Deadline);
        {ok, _} -> {error, invalid_target_evidence};
        {error, _} -> {error, retry}
    end.

certify_matching_operation_evidence(false, _, _, _, _, _, _) ->
    {error, invalid_target_evidence};
certify_matching_operation_evidence(
  true, OwnerNs, Ref, Evidence, Certificate, SeedVotes, Deadline) ->
    Result = case Certificate of
        none -> certify_operation_with(
                  OwnerNs, Ref, Evidence, SeedVotes,
                  Deadline, production_dependencies());
        _ ->
            case quod_ontology:network_identity() of
                {ok, Network} ->
                    case quod_trace:with_optional_span(
                           quod_trace:context(), <<"quod.operation.certificate_verify">>,
                           internal, #{},
                           fun() -> quod_applied_certificate:verify_operation_certificate(
                                      Certificate, Network, Evidence) end) of
                        true -> {ok, Certificate};
                        false -> {error, invalid_operation_result_certificate}
                    end;
                {error, _} -> {error, retry}
            end
    end,
    case {remaining(Deadline), Result} of
        {0, _} -> {error, retry};
        {_, {ok, Verified}} -> {ok, Ref, Evidence, Verified};
        {_, {error, invalid_operation_result_certificate} = Error} -> Error;
        _ -> {ok, Ref, Evidence, none}
    end.

%% A current-view operation projection supplies only a discovery height.
%% Owned operations use the existing recovery owner. An unowned completed
%% operation is a bounded read: exact source receipt -> exact applications ->
%% AM3. Current-view labels never become target verdicts. Before its async
%% receipt exists, a remote reconnect remains uncertain; it submits nothing.
-doc "Resolve one complete certified operation vector under an absolute observation deadline.".
-spec operation_result(binary(), term(), binary(), map(), integer()) ->
          {ok, list()} | {error, term()}.
operation_result(OwnerNs, {operation, Ns, Anchor, _, _} = Op, Digest,
  #{ref := Op, request_digest := Digest, height := ClaimHeight} = Projection, Deadline) ->
    case quod_simplex:history_view_at({Ns, Anchor}, ClaimHeight, Deadline) of
        {ok, _View} ->
            case remaining(Deadline) of
                0 -> {error, retry};
                Remaining ->
                    case quod_simplex:await_operation_result(Ns, Op, Remaining) of
                        {operation_results, Rows} -> {ok, Rows};
                        {error, _} -> {error, retry}
                    end
            end;
        {error, NonHosted} when NonHosted =:= not_hosted; NonHosted =:= invalid_identity ->
            remote_operation_receipt(OwnerNs, Op, Digest, Projection, Deadline);
        {error, _} -> {error, retry}
    end;
operation_result(_, _, _, _, _) -> {error, invalid_request}.

remote_operation_receipt(OwnerNs, {operation, Ns, Anchor, _, _} = Op, Digest,
  #{operation_state := terminal, receipt_height := Slot}, Deadline)
  when is_integer(Slot), Slot > 0 ->
    Request = {operation_receipt, request_id(), Op, Slot},
    case submit_operation_routes(OwnerNs, {Ns, Anchor}, Request, Deadline) of
        {ok, {operation_receipt, _, Op, Slot, Blob}} ->
            case quod_transaction:decode_evidence(Blob) of
                {ok, Ref, Complete} ->
                    case quod_foreign_log:resolve_reference(
                           {Ns, Anchor}, Ref, transaction, none, none, Deadline) of
                        {ok, #{transaction := ExactComplete}} ->
                            case quod_transaction:same_ledger_transaction(Complete, ExactComplete) of
                                true -> resolve_receipt_results(OwnerNs, Op, Digest, ExactComplete, Deadline);
                                false -> {error, invalid_completion}
                            end;
                        _ -> {error, retry}
                    end;
                {error, _} -> {error, retry}
            end;
        _ -> {error, retry}
    end;
remote_operation_receipt(_, _, _, _, _) -> {error, retry}.

resolve_receipt_results(OwnerNs, {operation, Ns, _, _, _} = Op, Digest,
  #transaction{role = {remote_complete, Op, Digest, Rows},
    evidence = {applications, [{_, #transaction{evidence = {ClaimRef, Claim}}} | _]}}
    = Receipt,
  Deadline) ->
    case quod_operation:new(Ns, Op, ClaimRef, Claim) of
        {ok, Model} ->
            case quod_operation:request_digest(Model) =:= Digest andalso
                 quod_operation_vector:receipt_references(Rows) =:=
                   {ok, quod_operation:references(Model)} of
                true ->
                    %% Validates canonical completeness and pair/claim binding;
                    %% the restored model is NOT used as verdict authority.
                    case quod_operation:restore_receipt(Receipt, Model) of
                        {ok, Restored} -> certify_receipt_rows(
                            OwnerNs, quod_operation:observations(Restored), Model, Deadline);
                        {error, _} = Error -> Error
                    end;
                false -> {error, invalid_completion}
            end;
        {error, _} = Error -> Error
    end;
resolve_receipt_results(_, _, _, _, _) -> {error, invalid_completion}.

certify_receipt_rows(_OwnerNs, [], Model, Deadline) ->
    case {remaining(Deadline), quod_operation:results(Model)} of
        {0, _} -> {error, retry};
        {_, {ok, Rows}} -> {ok, Rows};
        _ -> {error, retry}
    end;
certify_receipt_rows(OwnerNs, [{Target, #{reference := Ref, evidence := Discovery} = Row} | Rows],
                     Model, Deadline) ->
    Certificate = maps:get(certificate, Row, none),
    case certify_operation_evidence(OwnerNs, Target, Ref, Discovery, Certificate, Deadline) of
        {ok, Ref, Evidence, Verified} when Verified =/= none ->
            case quod_operation:accept(Target, Ref, Evidence, Verified, Model) of
                {ok, Updated} -> certify_receipt_rows(OwnerNs, Rows, Updated, Deadline);
                {error, _} = Error -> Error
            end;
        _ -> {error, retry}
    end.

operation_response_vote(Network, Evidence, Key,
  {ok, {operation_applied, _RequestId, _Ref, Statement, Key, Signature}}) ->
    case operation_vote_valid(Network, Evidence, Key, Statement, Signature) of
        true -> {ok, Statement, {Key, Signature}};
        false -> ignore
    end;
operation_response_vote(_, _, _, _) -> ignore.

operation_seed_votes(Ref, Network, Evidence, Committee, Votes) ->
    lists:filtermap(
      fun({{operation_vote, VoteRef, Signer}, {Statement, Signature}})
            when is_binary(Signer), is_binary(Signature) ->
              case VoteRef =:= Ref andalso lists:member(Signer, Committee) andalso
                   operation_vote_valid(
                     Network, Evidence, Signer, Statement, Signature) of
                  true ->
                      {true,
                       {signed, {operation, Statement},
                        {Signer, Signature}, none}};
                  false -> false
              end;
         (_) -> false
      end, quod_dtx_endpoint:normalize_sidecar(Votes)).

operation_vote_valid(Network, Evidence, Signer, Statement, Signature) ->
    case quod_applied_certificate:operation_statement_binding(Statement) of
        {ok, #{result := Result}} ->
            quod_applied_certificate:operation_statement(
              Network, Evidence, Result) =:= {ok, Statement} andalso
                quod_applied_certificate:verify_operation_vote(
                  Statement, Signer, Signature);
        error -> false
    end.

-doc "Build one `f + 1` certificate within the original absolute monotonic deadline.".
-spec certify_reads(binary(), {source(), binary()}, integer()) ->
          {ok, quod_read_certificate:certificate()} |
          {error, invalid_request | conflict_retry | retry}.
certify_reads(OwnerNs, Request, Deadline) ->
    certify_reads_with(
      OwnerNs, Request, Deadline, production_dependencies()).

-doc """
Resolve one anchored public outcome through a frozen certified current view.

Terminal and ledger-derived pending statuses require `f + 1` identical
current-validator replies. Absence remains `retry` for every lane: a snapshot
cannot exclude a later vote or a participant's recovery presentation. The
absolute monotonic deadline includes the caller's initial history capture.
""".
-spec lookup_outcome(binary(), source(), term(), integer()) ->
          outcome_result().
lookup_outcome(OwnerNs, Source, OutcomeRef, Deadline) ->
    lookup_outcome_with(
      OwnerNs, Source, OutcomeRef, Deadline, production_dependencies()).

lookup_outcome_with(OwnerNs, Source, OutcomeRef, Deadline, Dependencies)
  when is_integer(Deadline) ->
    case remaining(Deadline) of
        0 -> {error, retry};
        TimeoutMs -> lookup_outcome_before_deadline(
                       OwnerNs, Source, OutcomeRef, TimeoutMs, Deadline, Dependencies)
    end;
lookup_outcome_with(_OwnerNs, _Source, _OutcomeRef, _Deadline, _Dependencies) ->
    {error, invalid_request}.

lookup_outcome_before_deadline(
  OwnerNs, Source, OutcomeRef, TimeoutMs, Deadline, Dependencies) ->
    case valid_outcome_request(OwnerNs, Source, OutcomeRef, TimeoutMs) of
        {ok, Target} ->
            case call_current_view(
                   Source, {identity, Target}, Deadline, Dependencies) of
                {ok, View} ->
                    lookup_outcome_view(
                      OwnerNs, Source, OutcomeRef, Target, View,
                      Deadline, Dependencies);
                {error, _} ->
                    {error, retry}
            end;
        error ->
            {error, invalid_request}
    end.

production_dependencies() ->
    #{view =>
          fun({local, LocalSource}, {identity, Identity}, _Timeout) ->
                  local_current_view(LocalSource, Identity);
             ({remote, Routes}, {identity, Identity}, Timeout) ->
                  quod_foreign_log:current(Routes, Identity, Timeout)
          end,
      local =>
          fun(TargetNs, Request, Timeout) ->
                  quod_simplex:dtx_endpoint_local(
                    TargetNs, Request, [], Timeout)
          end,
      remote =>
          fun(Owner, TargetNs, PeerKey, Endpoint, Request, Timeout) ->
                  quod_simplex:dtx_endpoint_request(
                    Owner, TargetNs, PeerKey, Endpoint, Request, [], Timeout)
          end,
      exact_entry =>
          fun({local, LocalSource}, Ref, Timeout) ->
                  quod_foreign_log:verify_local(
                    LocalSource, Ref, entry, Timeout);
             ({remote, _Routes}, Ref, Timeout) ->
                  quod_foreign_log:verify_reference(Ref, entry, Timeout)
          end,
      resolve => fun quod_quic:resolve/1,
      node_key => fun node_key/0,
      network_identity => fun quod_ontology:network_identity/0}.

%% Current-view admission uses the same owner turn as its byte source. The
%% apply-sent frontier is deliberately distinct from the committed ledger tip;
%% this map does not introduce a Prolog MVCC snapshot or acknowledgement.
local_current_view(
  #{identity := Identity, applied := Applied,
    projection := #{committee := Committee, committee_id := CommitteeId,
                    validator_routes := Routes}} = Source,
  Identity) when Applied > 0, Committee =/= [] ->
    case quod_simplex:history_view_live(Source) of
        true ->
            {ok, #{identity => Identity, slot => Applied,
                   committee => Committee, committee_id => CommitteeId,
                   route_candidates => lists:keysort(
                     1, [{Peer, [Endpoint]}
                         || Peer <- Committee,
                            {ok, Endpoint} <- [maps:find(Peer, Routes)],
                            quod_quic:valid_endpoint(Endpoint)])}};
        false -> {error, not_ready}
    end;
local_current_view(_Source, _Identity) ->
    {error, not_ready}.

%% Validators may attest a newer anchor while the initial source is pinned.
%% Borrow that exact reference's bytes once from the original owner, without
%% changing the admitted committee, sealed plan, or proof snapshot. A later
%% retirement cannot invalidate an already-admitted read certificate, so this
%% byte-only capture requires committed history, not current validator role.
read_anchor_source(
  {local, #{identity := Identity, slot := Height}} = Source,
  Identity, {Slot, _BlockHash, _RecordDigest}, _Deadline) when Slot =< Height ->
    {ok, Source};
read_anchor_source(
  {local, #{owner := Owner, identity := Identity} = View},
  Identity, {Slot, _BlockHash, _RecordDigest}, Deadline) ->
    case quod_simplex:history_view_live(View) of
        true ->
            case quod_simplex:history_view({Owner, Identity}, committed, Deadline) of
                {ok, #{owner := Owner, identity := Identity,
                       slot := CurrentHeight} = Current}
                  when Slot =< CurrentHeight ->
                    {ok, {local, Current}};
                _ -> {error, not_ready}
            end;
        false -> {error, not_ready}
    end;
read_anchor_source({remote, _Routes} = Source, _Identity, _Claim, _Deadline) ->
    {ok, Source};
read_anchor_source(_Source, _Identity, _Claim, _Deadline) ->
    {error, invalid_request}.

prepare_applied(OwnerNs, {Source, Claim, Evidence}, TimeoutMs) ->
    case valid_request(OwnerNs, Source, Claim, TimeoutMs) of
        {ok, Target, GroupId, ResolveRef, Generation, Verdict} ->
            case valid_resolve_evidence(
                   Target, GroupId, ResolveRef, Generation, Verdict, Evidence) of
                {ok, Committee, CommitteeId, Routes} ->
                    {ok, {Source, Committee, Routes,
                          {Target, CommitteeId, GroupId, ResolveRef, Generation, Verdict}}};
                error -> {error, retry}
            end;
        error -> {error, invalid_request}
    end.

certify_reads_with(OwnerNs, {Source, PlanBlob}, Deadline, Dependencies)
  when is_integer(Deadline) ->
    case remaining(Deadline) of
        0 -> {error, retry};
        TimeoutMs -> certify_reads_before_deadline(
                       OwnerNs, Source, PlanBlob, TimeoutMs, Deadline, Dependencies)
    end;
certify_reads_with(_OwnerNs, _Request, _Deadline, _Dependencies) ->
    {error, invalid_request}.

certify_reads_before_deadline(
  OwnerNs, Source, PlanBlob, TimeoutMs, Deadline, Dependencies) ->
    case valid_read_request(OwnerNs, Source, PlanBlob, TimeoutMs) of
        {ok, Plan, Target} ->
            case call_current_view(
                   Source, {identity, Target}, Deadline, Dependencies) of
                {ok, View} ->
                    certify_reads_view(
                      OwnerNs, Source, Plan, PlanBlob, Target, View,
                      Deadline, Dependencies);
                {error, _} ->
                    {error, retry}
            end;
        error ->
            {error, invalid_request}
    end.

valid_read_request(OwnerNs, Source, PlanBlob, TimeoutMs)
  when is_binary(OwnerNs), byte_size(OwnerNs) > 0,
       is_integer(TimeoutMs), TimeoutMs > 0,
       TimeoutMs =< ?QUOD_DTX_ENDPOINT_WORKER_TIMEOUT_MS ->
    case {valid_source(Source), quod_dtx:decode(PlanBlob)} of
        {true, {ok, Plan}} ->
            case quod_dtx:verify(Plan) andalso
                 quod_dtx:diff_ops(Plan) =:= 0 andalso
                 quod_dtx:effects_count(Plan) =:= 0 andalso
                 maps:get(read_functors, quod_dtx:core(Plan), 0) > 0 of
                true -> {ok, Plan, quod_dtx:target(Plan)};
                false -> error
            end;
        _ -> error
    end;
valid_read_request(_OwnerNs, _Source, _PlanBlob, _TimeoutMs) ->
    error.

certify_reads_view(
  OwnerNs, Source, Plan, PlanBlob, Target, View, Deadline, Dependencies) ->
    case valid_identity_current_view(Target, View) of
        {ok, Committee, CommitteeId, MinimumSlot, Routes} ->
            case MinimumSlot >= quod_dtx:base_height(Plan) of
                true ->
                    with_probe_sources(Source, Committee, Routes, Deadline, Dependencies,
                        fun(Sources, Needed) ->
                            collect_read_votes(
                              OwnerNs, Source, Sources, Plan, PlanBlob,
                              CommitteeId, Needed,
                              Deadline, Dependencies)
                        end);
                false ->
                    {error, retry}
            end;
        _ ->
            {error, retry}
    end.

collect_read_votes(
  OwnerNs, Source, Sources, Plan, PlanBlob, CommitteeId, Needed, Deadline,
  Dependencies) ->
    Probe =
        fun(Key, ProbeSource) ->
                case probe_read_attest(
                       OwnerNs, Key, ProbeSource, Plan, PlanBlob,
                       CommitteeId, Deadline, Dependencies) of
                    {ok, Binding, SignedRow, AnchorRef} ->
                        {signed, {read, Binding}, SignedRow, AnchorRef};
                    conflict_retry ->
                        {ok, conflict_retry};
                    ignore -> ignore
                end
        end,
    case collect_quorum(
           read_certificate_probe, Sources, Needed, Deadline, Probe) of
        {ok, {signed, {read, {Target, ProofId, PlanDigest, AnchorClaim,
                              CommitteeId}}, Rows}} ->
            case verified_read_anchor(
                   Source, Target, AnchorClaim, Rows, Deadline,
                   Dependencies) of
                {ok, AnchorRef, Signatures} ->
                    case quod_read_certificate:new(
                           Target, ProofId, PlanDigest, AnchorRef,
                           CommitteeId, Signatures) of
                        {ok, Certificate} -> {ok, Certificate};
                        error -> {error, retry}
                    end;
                error ->
                    {error, retry}
            end;
        {ok, conflict_retry} ->
            {error, conflict_retry};
        _ ->
            {error, retry}
    end.

certify_applied_many_with(OwnerNs, Requests, Deadline, Dependencies)
  when is_integer(Deadline) ->
    case remaining(Deadline) of
        0 -> {error, retry};
        TimeoutMs -> certify_applied_many_before_deadline(
                       OwnerNs, Requests, TimeoutMs, Deadline, Dependencies)
    end;
certify_applied_many_with(_OwnerNs, _Requests, _Deadline, _Dependencies) ->
    {error, invalid_request}.

certify_applied_many_before_deadline(
  OwnerNs, Requests, TimeoutMs, Deadline, Dependencies)
  when is_list(Requests), Requests =/= [],
       length(Requests) =< ?QUOD_MAX_DTX_PARTICIPANTS,
       is_integer(TimeoutMs), TimeoutMs > 0,
       TimeoutMs =< ?QUOD_DTX_ENDPOINT_WORKER_TIMEOUT_MS ->
    case prepare_applied_many(OwnerNs, Requests, TimeoutMs, []) of
        {ok, Prepared} ->
            certify_applied_many_requests(
              OwnerNs, Prepared, Deadline, Dependencies);
        error -> {error, invalid_request}
    end;
certify_applied_many_before_deadline(
  _OwnerNs, _Requests, _TimeoutMs, _Deadline, _Dependencies) ->
    {error, invalid_request}.

%% Validate the complete batch before spawning any child. Workers carry only
%% authenticated statement fields and committee/routes, never re-decode input.
prepare_applied_many(_OwnerNs, [], _TimeoutMs, Acc) ->
    {ok, lists:reverse(Acc)};
prepare_applied_many(OwnerNs, [{_, _, Evidence} = Request | Rest], TimeoutMs, Acc)
  when is_map(Evidence) ->
    case prepare_applied(OwnerNs, Request, TimeoutMs) of
        {ok, Prepared} -> prepare_applied_many(OwnerNs, Rest, TimeoutMs, [Prepared | Acc]);
        {error, _} -> error
    end;
prepare_applied_many(_OwnerNs, _Requests, _TimeoutMs, _Acc) -> error.

certify_applied_many_requests(OwnerNs, Requests, Deadline, Dependencies) ->
    Parent = self(),
    TraceCtx = quod_trace:context(),
    VerifyRef = make_ref(),
    Pending =
        lists:foldl(
          fun({Index, Prepared}, Acc) ->
                  {Pid, Monitor} = spawn_opt(
                    fun() ->
                        Result = quod_trace:with_optional_span(
                                   TraceCtx, <<"quod.dtx.applied.verify">>, internal, #{},
                                   fun() -> certify_applied_prepared(
                                              OwnerNs, Prepared,
                                              Deadline, Dependencies) end),
                        Parent ! {dtx_current_view_many, VerifyRef, self(),
                                  Index, Result}
                    end, [link, monitor]),
                  Acc#{Pid => {Monitor, Index}}
          end, #{}, lists:enumerate(Requests)),
    collect_many_results(VerifyRef, Pending, #{}, Deadline).

collect_many_results(VerifyRef, Pending, Results, _Deadline)
  when map_size(Pending) =:= 0 ->
    flush_worker_results(dtx_current_view_many, VerifyRef),
    {ok, aligned_many_results(Results)};
collect_many_results(VerifyRef, Pending, Results, Deadline) ->
    case remaining(Deadline) of
        0 ->
            stop_workers(dtx_current_view_many, VerifyRef, Pending),
            {ok, aligned_many_results(mark_pending_retry(Pending, Results))};
        Wait ->
            receive
                {dtx_current_view_many, VerifyRef, Pid, Index, {ok, View}}
                  when is_map_key(Pid, Pending) ->
                    case maps:take(Pid, Pending) of
                        {{Monitor, Index}, Rest} ->
                            _ = erlang:demonitor(Monitor, [flush]),
                            %% A result can already be queued when its caller
                            %% resumes after the deadline. Consumption, not the
                            %% worker's send time, admits this certificate.
                            Result = case remaining(Deadline) of
                                         0 -> retry;
                                         _ -> {verified, View}
                                     end,
                            collect_many_results(
                              VerifyRef, Rest,
                              Results#{Index => Result},
                              Deadline);
                        {{Monitor, ExpectedIndex}, Rest} ->
                            _ = erlang:demonitor(Monitor, [flush]),
                            collect_many_results(
                              VerifyRef, Rest,
                              Results#{ExpectedIndex => retry}, Deadline)
                    end;
                {dtx_current_view_many, VerifyRef, Pid, _Index, {error, retry}}
                  when is_map_key(Pid, Pending) ->
                    {{Monitor, ExpectedIndex}, Rest} = maps:take(Pid, Pending),
                    _ = erlang:demonitor(Monitor, [flush]),
                    collect_many_results(
                      VerifyRef, Rest, Results#{ExpectedIndex => retry},
                      Deadline);
                {'DOWN', Monitor, process, Pid, _Reason}
                  when is_map_key(Pid, Pending) ->
                    case maps:get(Pid, Pending) of
                        {Monitor, Index} ->
                            Rest = maps:remove(Pid, Pending),
                            collect_many_results(
                              VerifyRef, Rest, Results#{Index => retry},
                              Deadline);
                        _ ->
                            collect_many_results(
                              VerifyRef, Pending, Results, Deadline)
                    end
            after Wait ->
                stop_workers(dtx_current_view_many, VerifyRef, Pending),
                {ok,
                 aligned_many_results(mark_pending_retry(Pending, Results))}
            end
    end.

mark_pending_retry(Pending, Results) ->
    maps:fold(
      fun(_Pid, {_Monitor, Index}, Acc) -> Acc#{Index => retry} end,
      Results, Pending).

aligned_many_results(Results) ->
    [Result || {_Index, Result} <-
                   lists:keysort(1, maps:to_list(Results))].

valid_request(OwnerNs, Source,
              #{target := {TargetNs, <<_:256>> = Anchor} = Target,
                group_id := <<_:256>> = GroupId,
                resolve_ref := ResolveRef,
                generation := Generation,
                verdict := Verdict} = Claim,
              TimeoutMs)
  when is_binary(OwnerNs), byte_size(OwnerNs) > 0,
       is_binary(TargetNs), byte_size(TargetNs) > 0,
       map_size(Claim) =:= 5,
       is_integer(Generation), Generation >= 0, Generation =< ?MAX_UINT64,
       (Verdict =:= commit orelse Verdict =:= abort),
       is_integer(TimeoutMs), TimeoutMs > 0,
       TimeoutMs =< ?QUOD_DTX_ENDPOINT_WORKER_TIMEOUT_MS ->
    case {valid_source(Source),
          quod_dtx:certified_ref_binding(ResolveRef)} of
        {true, {ok, {TargetNs, Anchor}, _Slot, <<_:256>>}} ->
            {ok, Target, GroupId, ResolveRef, Generation, Verdict};
        _ ->
            error
    end;
valid_request(_OwnerNs, _Source, _Claim, _TimeoutMs) ->
    error.

valid_outcome_request(OwnerNs, Source, OutcomeRef, TimeoutMs)
  when is_binary(OwnerNs), byte_size(OwnerNs) > 0,
       is_integer(TimeoutMs), TimeoutMs > 0,
       TimeoutMs =< ?QUOD_DTX_ENDPOINT_WORKER_TIMEOUT_MS ->
    case {valid_source(Source), quod_outcome:ref_identity(OutcomeRef)} of
        {true, {ok, Target}} -> {ok, Target};
        _ -> error
    end;
valid_outcome_request(_OwnerNs, _Source, _OutcomeRef, _TimeoutMs) ->
    error.

lookup_outcome_view(OwnerNs, Source, OutcomeRef, Target, View,
                    Deadline, Dependencies) ->
    case valid_identity_current_view(Target, View) of
        {ok, Committee, CommitteeId, MinimumSlot, Routes} ->
            with_probe_sources(Source, Committee, Routes, Deadline, Dependencies,
                fun(Sources, Needed) ->
                    Claim = {Target, CommitteeId, MinimumSlot, OutcomeRef},
                    case collect_outcomes(
                           OwnerNs, Sources, Claim, Needed, Deadline,
                           Dependencies) of
                        {ok, not_found} ->
                            %% Applied-snapshot absence never excludes a
                            %% later vote, submission or participant recovery.
                            {error, retry};
                        {ok, Status} ->
                            {ok, Status};
                        retry ->
                            {error, retry}
                    end
                end);
        error ->
            {error, retry}
    end.

valid_source(
  {local, #{owner := Owner, identity := {Ns, <<_:256>>},
            slot := Slot, applied := Applied,
            snapshot := _Snapshot, projection := Projection}}) ->
    is_pid(Owner) andalso is_binary(Ns) andalso byte_size(Ns) > 0 andalso
        is_integer(Slot) andalso Slot > 0 andalso
        is_integer(Applied) andalso Applied >= 0 andalso Applied =< Slot andalso
        is_map(Projection);
valid_source({remote, Routes}) when is_list(Routes), Routes =/= [],
                                    length(Routes) =< ?MAX_VALIDATORS ->
    quod_foreign_log:valid_route_candidates(Routes);
valid_source(_) ->
    false.

call_current_view(Source, Basis, Deadline, Dependencies) ->
    case remaining(Deadline) of
        0 -> {error, retry};
        Remaining ->
            %% Freezing the committee and asking that committee are one
            %% operation. Do not let a cold history fetch consume the caller's
            %% entire deadline and make the mandatory corroboration probe
            %% impossible. A retry can reuse the shared history cache.
            Timeout = erlang:max(1, Remaining - erlang:max(1, Remaining div 4)),
            View = maps:get(view, Dependencies),
            try View(Source, Basis, Timeout)
            catch exit:_ -> {error, retry}
            end
    end.

certify_applied_prepared(OwnerNs,
  {Source, Committee, Routes, {Target, CommitteeId, GroupId, ResolveRef, Generation, Verdict}},
  Deadline, Dependencies) ->
    case remaining(Deadline) of
        0 -> {error, retry};
        _ ->
            case dependency_network_identity(Dependencies) of
                {ok, NetworkIdentity} ->
                    Claim = {NetworkIdentity, Target, CommitteeId, GroupId,
                             ResolveRef, Generation, Verdict},
                    with_probe_sources(Source, Committee, Routes, Deadline, Dependencies,
                      fun(Sources, Needed) ->
                          case collect_applied(OwnerNs, Sources, Claim, Needed, Deadline, Dependencies) of
                              {ok, Certificate} -> {ok, Certificate};
                              retry -> {error, retry}
                          end
                      end);
                {error, _} -> {error, retry}
            end
    end.

valid_resolve_evidence(Target, GroupId, ResolveRef, Generation, Verdict,
                        Evidence) ->
    case {quod_applied_certificate:exact_resolve_binding(Evidence, ResolveRef),
          historical_committee_view(Target, Evidence)} of
        {{ok, GroupId, ResolveRef, Generation, Verdict},
         {ok, Committee, CommitteeId, Routes}} ->
            {ok, Committee, CommitteeId, Routes};
        _ -> error
    end.

historical_committee_view(
  Target,
  #{identity := Target, committee := Committee,
    committee_id := <<_:256>> = CommitteeId, routes := RouteMap})
  when is_list(Committee), Committee =/= [],
       length(Committee) =< ?MAX_VALIDATORS,
       is_map(RouteMap), map_size(RouteMap) =< ?MAX_VALIDATORS ->
    Routes = lists:keysort(
               1,
               [{Key, [Endpoint]}
                || {Key, Endpoint} <- maps:to_list(RouteMap)]),
    case Committee =:= lists:usort(Committee) andalso
         lists:all(fun valid_key/1, Committee) andalso
         valid_historical_routes(Routes, Committee) of
        true -> {ok, Committee, CommitteeId, Routes};
        false -> error
    end;
historical_committee_view(_Target, _Evidence) ->
    error.

%% A co-hosted validator needs no transport route to attest. Historical
%% routes are therefore an optional, authenticated reachability aid rather
%% than a precondition for a valid Resolve-era committee.
valid_historical_routes(Routes, Committee) ->
    lists:all(
      fun({Key, [Endpoint]}) ->
              lists:member(Key, Committee) andalso
                  quod_quic:valid_endpoint(Endpoint);
         (_) ->
              false
      end, Routes).

valid_identity_current_view(
  Target,
  #{identity := Target, slot := Slot,
    committee := Committee, committee_id := <<_:256>> = CommitteeId,
    route_candidates := Routes} = View)
  when map_size(View) =:= 5,
       is_integer(Slot), Slot > 0, Slot =< ?MAX_UINT64,
       is_list(Committee), Committee =/= [],
       length(Committee) =< ?MAX_VALIDATORS,
       is_list(Routes), length(Routes) =< ?MAX_VALIDATORS ->
    case Committee =:= lists:usort(Committee) andalso
         lists:all(fun valid_key/1, Committee) andalso
         valid_routes(Routes, Committee) of
        true -> {ok, Committee, CommitteeId, Slot, Routes};
        false -> error
    end;
valid_identity_current_view(_Target, _View) ->
    error.

valid_key(<<_:256>>) -> true;
valid_key(_) -> false.

valid_routes(Routes, Committee) ->
    quod_foreign_log:valid_route_candidates(Routes) andalso
        lists:all(
          fun({Key, _Endpoints}) -> lists:member(Key, Committee) end,
          Routes).

with_probe_sources(Source, Committee, Routes, Deadline, Dependencies, Collect) ->
    with_probe_sources(
      Source, Committee, Routes, #{}, Deadline, Dependencies, Collect).

with_probe_sources(Source, Committee, Routes, Seeded,
                   Deadline, Dependencies, Collect) ->
    Sources = [{Key, Endpoint}
               || {Key, Endpoint} <-
                      probe_sources(Source, Committee, Routes, Dependencies),
                  not maps:is_key(Key, Seeded)],
    Needed = quod_quorum:honest_threshold(length(Committee)),
    case length(Sources) + map_size(Seeded) >= Needed andalso
         remaining(Deadline) > 0 of
        true -> Collect(Sources, Needed);
        false -> {error, retry}
    end.

probe_sources(Source, Committee, Routes, Dependencies) ->
    LocalKey = case Source of
                   {local, _} -> dependency_node_key(Dependencies);
                   {remote, _} -> none
               end,
    SourceRoutes = case Source of
                       {remote, Candidates} -> Candidates;
                       {local, _} -> []
                   end,
    lists:filtermap(
      fun(Key) when Key =:= LocalKey, LocalKey =/= none ->
              {true, {Key, local}};
         (Key) ->
              case probe_endpoints(
                     Key, dependency_resolved_endpoint(Key, Dependencies),
                     SourceRoutes, Routes) of
                  [_ | _] = Endpoints ->
                      {true, {Key, {remote, Endpoints}}};
                  [] -> false
              end
      end, Committee).

%% The certified view fixes who may attest; endpoints remain reachability
%% only. Merge the shared key resolver's current endpoint before the caller's
%% identity-pinned candidates and the certified historical fallback, so a retired
%% holder remains reachable after moving. Transport still authenticates Key, and
%% no route can add a signer outside Committee.
probe_endpoints(
  Key, ResolvedEndpoint, SourceRoutes, HistoricalRoutes) ->
    Resolved = case ResolvedEndpoint of
                   {ok, Endpoint} -> [Endpoint];
                   error -> []
               end,
    Live = case lists:keyfind(Key, 1, SourceRoutes) of
               {Key, Endpoints0} -> Endpoints0;
               false -> []
           end,
    Historical = case lists:keyfind(Key, 1, HistoricalRoutes) of
                     {Key, Endpoints1} -> Endpoints1;
                     false -> []
                 end,
    unique_endpoints(Resolved ++ Live ++ Historical, #{}, []).

dependency_resolved_endpoint(Key, Dependencies) ->
    Resolve = maps:get(resolve, Dependencies),
    case Resolve(Key) of
        {ok, Endpoint} ->
            case quod_quic:valid_endpoint(Endpoint) of
                true -> {ok, Endpoint};
                false -> error
            end;
        _ ->
            error
    end.

unique_endpoints([], _Seen, Acc) ->
    lists:reverse(Acc);
unique_endpoints([Endpoint | Rest], Seen, Acc) ->
    case maps:is_key(Endpoint, Seen) of
        true -> unique_endpoints(Rest, Seen, Acc);
        false -> unique_endpoints(
                   Rest, Seen#{Endpoint => true}, [Endpoint | Acc])
    end.

dependency_node_key(Dependencies) ->
    NodeKey = maps:get(node_key, Dependencies),
    case NodeKey() of
        <<_:256>> = Key -> Key;
        _ -> none
    end.

dependency_network_identity(Dependencies) ->
    case maps:find(network_identity, Dependencies) of
        {ok, NetworkIdentity} ->
            try NetworkIdentity() of
                {ok, <<_:256>> = Identity} -> {ok, Identity};
                _ -> {error, unavailable}
            catch _:_ -> {error, unavailable}
            end;
        error ->
            {error, unavailable}
    end.

node_key() ->
    case application:get_env(quod, node_pubkey) of
        {ok, <<_:256>> = Key} -> Key;
        _ -> none
    end.

collect_applied(OwnerNs, Sources, Claim, Needed, Deadline, Dependencies) ->
    Probe = fun(Key, Source) ->
                    case probe_applied(
                           OwnerNs, Key, Source, Claim, Deadline,
                           Dependencies) of
                        {ok, SignedRow} ->
                            {signed, applied, SignedRow, none};
                        ignore -> ignore
                    end
            end,
    case collect_quorum(
           dtx_applied_probe, Sources, Needed, Deadline, Probe) of
        {ok, {signed, applied, Rows}} ->
            quod_applied_certificate:applied_certificate(Claim, signed_rows(Rows));
        _ ->
            retry
    end.

collect_outcomes(OwnerNs, Sources, Claim, Needed, Deadline, Dependencies) ->
    Probe = fun(Key, Source) ->
                    probe_outcome(
                      OwnerNs, Key, Source, Claim, Deadline, Dependencies)
            end,
    collect_quorum(dtx_outcome_probe, Sources, Needed, Deadline, Probe).

collect_quorum(Tag, Sources, Needed, Deadline, Probe) ->
    collect_quorum(Tag, Sources, Needed, Deadline, Probe, []).

collect_quorum(Tag, Sources, Needed, Deadline, Probe, Seeds) ->
    quod_trace:with_optional_span(
      quod_trace:context(), <<"quod.dtx.quorum.collect">>, internal,
      #{'quod.probe.family' => atom_to_binary(Tag, utf8),
        'quod.quorum.required' => Needed,
        'quod.quorum.seeded' => length(Seeds),
        'quod.quorum.sources' => length(Sources)},
      fun() ->
          case seed_quorum(Seeds, Needed, #{}) of
              {reached, Value} -> {ok, Value};
              {continue, Counts} ->
                  Parent = self(),
                  TraceCtx = quod_trace:context(),
                  ProbeRef = make_ref(),
                  Pending = lists:foldl(
                        fun({Key, Source}, Acc) ->
                            {Pid, Monitor} = spawn_opt(
                              fun() ->
                                  Result = quod_trace:with_optional_span(
                                             TraceCtx, <<"quod.dtx.quorum.probe">>, client,
                                             #{'quod.probe.family' => atom_to_binary(Tag, utf8)},
                                             fun() -> Probe(Key, Source) end),
                                  Parent ! {Tag, ProbeRef, self(), Key, Result}
                              end, [link, monitor]),
                            Acc#{Pid => {Monitor, Key}}
                        end, #{}, Sources),
                  collect_quorum_results(
                    Tag, ProbeRef, Pending, Needed, Counts, Deadline)
          end
      end).

seed_quorum([], _Needed, Counts) -> {continue, Counts};
seed_quorum([Seed | Rest], Needed, Counts) ->
    case count_match(Seed, Needed, Counts) of
        {reached, _} = Reached -> Reached;
        {continue, Next} -> seed_quorum(Rest, Needed, Next)
    end.

collect_quorum_results(Tag, ProbeRef, Pending, _Needed, _Counts, _Deadline)
  when map_size(Pending) =:= 0 ->
    flush_worker_results(Tag, ProbeRef),
    retry;
collect_quorum_results(Tag, ProbeRef, Pending, Needed, Counts, Deadline) ->
    case remaining(Deadline) of
        0 ->
            stop_workers(Tag, ProbeRef, Pending),
            retry;
        Wait ->
            receive
                {Tag, ProbeRef, Pid, Key, Result}
                  when is_map_key(Pid, Pending) ->
                    case maps:take(Pid, Pending) of
                        {{Monitor, Key}, Rest} ->
                            _ = erlang:demonitor(Monitor, [flush]),
                            case count_match(Result, Needed, Counts) of
                                {reached, Value} ->
                                    stop_workers(Tag, ProbeRef, Rest),
                                    {ok, Value};
                                {continue, Counts1} ->
                                    collect_quorum_results(
                                      Tag, ProbeRef, Rest, Needed,
                                      Counts1, Deadline)
                            end;
                        {{Monitor, _OtherKey}, Rest} ->
                            _ = erlang:demonitor(Monitor, [flush]),
                            collect_quorum_results(
                              Tag, ProbeRef, Rest, Needed, Counts, Deadline)
                    end;
                {'DOWN', Monitor, process, Pid, _Reason}
                  when is_map_key(Pid, Pending) ->
                    case maps:get(Pid, Pending) of
                        {Monitor, _Key} ->
                            collect_quorum_results(
                              Tag, ProbeRef, maps:remove(Pid, Pending),
                              Needed, Counts, Deadline);
                        _ ->
                            collect_quorum_results(
                              Tag, ProbeRef, Pending, Needed,
                              Counts, Deadline)
                    end
            after Wait ->
                stop_workers(Tag, ProbeRef, Pending),
                retry
            end
    end.

count_match({ok, Value}, Needed, Counts) ->
    Count = maps:get(Value, Counts, 0) + 1,
    case Count >= Needed of
        true -> {reached, Value};
        false -> {continue, Counts#{Value => Count}}
    end;
count_match(
  {signed, Value, {<<_:256>> = Signer, <<_:512>> = Signature}, Witness},
  Needed, Counts) ->
    Key = {signed, Value},
    Rows0 = maps:get(Key, Counts, #{}),
    Rows = Rows0#{Signer => {Signature, Witness}},
    case map_size(Rows) >= Needed of
        true ->
            {reached,
             {signed, Value,
              [{RowSigner, RowSignature, RowWitness}
               || {RowSigner, {RowSignature, RowWitness}} <-
                      lists:keysort(1, maps:to_list(Rows))]}};
        false ->
            {continue, Counts#{Key => Rows}}
    end;
count_match(_Ignored, _Needed, Counts) ->
    {continue, Counts}.

signed_rows(Rows) ->
    [{Signer, Signature} || {Signer, Signature, _Witness} <- Rows].

verified_read_anchor(Source, Target, Claim, Rows, Deadline, Dependencies) ->
    %% Votes establish the immutable entry claim. The certified-history owner
    %% separately validates one carried finality proof at the entry's actual
    %% committee era; proof-subset bytes are neither identity nor authority by
    %% themselves. This is the same exact-reference verifier used downstream.
    Candidates = lists:uniq([Ref || {_Signer, _Signature, Ref} <- Rows]),
    %% Equivalent finality proofs all witness the same claim. Capture newer
    %% local bytes once, before trying those proofs, rather than once per
    %% candidate or after any invalid proof.
    ExactSourceResult = case remaining(Deadline) of
                            0 -> {error, retry};
                            _ -> read_anchor_source(Source, Target, Claim, Deadline)
                        end,
    case ExactSourceResult of
        {ok, ExactSource} ->
            case verify_read_anchor_candidates(
                   ExactSource, Target, Claim, Candidates, Deadline,
                   Dependencies) of
                {ok, AnchorRef} -> {ok, AnchorRef, signed_rows(Rows)};
                error -> error
            end;
        {error, _} -> error
    end.

verify_read_anchor_candidates(
  _Source, _Target, _Claim, [], _Deadline, _Dependencies) ->
    error;
verify_read_anchor_candidates(
  Source, Target, {Slot, BlockHash, RecordDigest} = Claim,
  [Ref | Rest], Deadline, Dependencies) ->
    case remaining(Deadline) of
        0 ->
            error;
        Wait ->
            Verify = maps:get(exact_entry, Dependencies),
            case Verify(Source, Ref, Wait) of
                {ok, #{identity := Target, slot := Slot,
                       block_hash := BlockHash,
                       record_digest := RecordDigest}} ->
                    {ok, Ref};
                _ ->
                    verify_read_anchor_candidates(
                      Source, Target, Claim, Rest, Deadline, Dependencies)
            end
    end.

stop_workers(Tag, Ref, Pending) ->
    maps:foreach(
      fun(Pid, _MonitorAndKey) ->
              _ = unlink(Pid),
              exit(Pid, kill)
      end, Pending),
    CleanupDeadline = quod_time:mono_ms() + ?PROBE_CLEANUP_MS,
    await_worker_downs(Tag, Ref, Pending, CleanupDeadline),
    flush_worker_results(Tag, Ref).

await_worker_downs(_Tag, _Ref, Pending, _Deadline)
  when map_size(Pending) =:= 0 ->
    ok;
await_worker_downs(Tag, Ref, Pending, Deadline) ->
    case remaining(Deadline) of
        0 ->
            maps:foreach(
              fun(_Pid, {Monitor, _Key}) ->
                      _ = erlang:demonitor(Monitor, [flush])
              end, Pending);
        Wait ->
            receive
                {'DOWN', Monitor, process, Pid, _Reason}
                  when is_map_key(Pid, Pending) ->
                    case maps:get(Pid, Pending) of
                        {Monitor, _Key} ->
                            await_worker_downs(
                              Tag, Ref, maps:remove(Pid, Pending), Deadline);
                        _ ->
                            await_worker_downs(Tag, Ref, Pending, Deadline)
                    end;
                {Tag, Ref, _Pid, _Key, _Result} ->
                    await_worker_downs(Tag, Ref, Pending, Deadline)
            after Wait ->
                maps:foreach(
                  fun(_Pid, {Monitor, _Key}) ->
                          _ = erlang:demonitor(Monitor, [flush])
                  end, Pending)
            end
    end.

flush_worker_results(Tag, Ref) ->
    receive
        {Tag, Ref, _Pid, _Key, _Result} ->
            flush_worker_results(Tag, Ref)
    after 0 ->
        ok
    end.

probe_outcome(OwnerNs, PeerKey, Source,
              {{TargetNs, _Anchor} = Target, CommitteeId, MinimumSlot,
               OutcomeRef},
              Deadline, Dependencies) ->
    Request = {outcome, request_id(), OutcomeRef,
               CommitteeId, MinimumSlot},
    probe_source(
      Source, OwnerNs, TargetNs, PeerKey, Request, Deadline, Dependencies,
      fun(Result) -> outcome_response(Target, CommitteeId, Result) end).

outcome_response(
  Target, CommitteeId,
  {ok, {outcome, _RequestId, Target, CommitteeId, _AppliedFloor,
        Outcome}}) ->
    case quorum_outcome_allowed(Outcome) of
        true -> {ok, Outcome};
        false -> ignore
    end;
outcome_response(_Target, _CommitteeId, _Result) ->
    ignore.

%% `pending_vote` is local journal/handoff state, not committed snapshot
%% evidence. Do not turn independent local observations into an outcome.
quorum_outcome_allowed(
  #{status := pending, phase := pending_vote}) -> false;
quorum_outcome_allowed(not_found) -> true;
quorum_outcome_allowed(#{status := _}) -> true;
quorum_outcome_allowed(_) -> false.

call_endpoint(OwnerNs, TargetNs, PeerKey, Source, Request,
              Deadline, Dependencies) ->
    case remaining(Deadline) of
        0 -> {error, timeout};
        Timeout ->
            try
                Result = case Source of
                             local ->
                                 Local = maps:get(local, Dependencies),
                                 Local(TargetNs, Request, Timeout);
                             {remote, Endpoint} ->
                                 Remote = maps:get(remote, Dependencies),
                                 Remote(OwnerNs, TargetNs, PeerKey, Endpoint,
                                        Request, Timeout)
                         end,
                case Result of
                    {ok, Response, _ValidationSidecar} -> {ok, Response};
                    Other -> Other
                end
            catch exit:_ -> {error, not_ready}
            end
    end.

probe_read_attest(
  OwnerNs, PeerKey, Source, Plan, PlanBlob, CommitteeId, Deadline,
  Dependencies) ->
    {TargetNs, _Anchor} = Target = quod_dtx:target(Plan),
    Request = {read_attest, request_id(), PlanBlob},
    ProofId = quod_dtx:proof_id(Plan),
    PlanDigest = quod_dtx:digest(Plan),
    probe_source(
      Source, OwnerNs, TargetNs, PeerKey, Request, Deadline, Dependencies,
      fun(Result) -> read_attest_response_vote(
                       Target, ProofId, PlanDigest, CommitteeId, PeerKey, Result)
      end).

read_attest_response_vote(
  Target, ProofId, PlanDigest, CommitteeId, ExpectedSigner,
  {ok, {read_attest, _RequestId, Target, ProofId, PlanDigest, AnchorRef,
        CommitteeId,
        ExpectedSigner, Signature}}) ->
    case {quod_read_certificate:verify_vote(
            Target, ProofId, PlanDigest, AnchorRef,
            CommitteeId, ExpectedSigner, Signature),
          quod_dtx:certified_ref_claim(AnchorRef)} of
        {true,
         {ok, {Target, Slot, BlockHash, RecordDigest}}} ->
            {ok,
             {Target, ProofId, PlanDigest,
              {Slot, BlockHash, RecordDigest}, CommitteeId},
             {ExpectedSigner, Signature}, AnchorRef};
        _ ->
            ignore
    end;
read_attest_response_vote(
  _Target, _ProofId, _PlanDigest, _CommitteeId,
  _ExpectedSigner,
  {ok, {error, _RequestId, conflict_retry}}) -> conflict_retry;
read_attest_response_vote(
  _Target, _ProofId, _PlanDigest, _CommitteeId,
  _ExpectedSigner, _Result) ->
    ignore.

probe_applied(OwnerNs, PeerKey, Source,
              {NetworkIdentity, {TargetNs, _Anchor} = Target, CommitteeId,
               GroupId, ResolveRef, Generation, Verdict},
              Deadline, Dependencies) ->
    Request = {applied, request_id(), GroupId, ResolveRef,
               Generation, Verdict},
    probe_source(
      Source, OwnerNs, TargetNs, PeerKey, Request, Deadline, Dependencies,
      fun(Result) -> applied_response_vote(
                       NetworkIdentity, Target, CommitteeId, PeerKey, Result)
      end).

%% A correlated reply ends address selection, not evidence verification.
%% Unready or invalid evidence contributes nothing to the committee collector;
%% another address for that same peer is not another possible witness. Local
%% and remote replies cross this same correlation boundary exactly once.
probe_source(Source, OwnerNs, TargetNs, PeerKey, Request,
  Deadline, Dependencies, Verify) ->
    Select = fun({ok, Response} = Reply, Last) ->
              case quod_dtx_endpoint:correlates(Request, Response) of
                  true -> {done, Verify(Reply)};
                  false -> {next, Last}
              end;
         (_, Last) -> {next, Last}
      end,
    case Source of
        local ->
            {_, Result} = Select(call_endpoint(
              OwnerNs, TargetNs, PeerKey, local, Request, Deadline, Dependencies), ignore),
            Result;
        {remote, Endpoints} ->
            quod_peer_route:walk(Endpoints, Deadline,
              fun(Endpoint, Timeout) ->
                  call_endpoint(OwnerNs, TargetNs, PeerKey, {remote, Endpoint}, Request,
                                min(Deadline, quod_time:mono_ms() + Timeout), Dependencies)
              end, Select, ignore)
    end.

applied_response_vote(
  NetworkIdentity, Target, CommitteeId, ExpectedSigner,
  {ok, {applied, _RequestId, Target, CommitteeId, GroupId,
         ResolveRef, Generation, Verdict, ExpectedSigner, Signature}}) ->
    case quod_applied_certificate:applied_vote_valid(
           NetworkIdentity, Target, CommitteeId, GroupId, ResolveRef,
           Generation, Verdict, ExpectedSigner, Signature) of
        true -> {ok, {ExpectedSigner, Signature}};
        false -> ignore
    end;
applied_response_vote(_NetworkIdentity, _Target, _CommitteeId,
                      _ExpectedSigner, _Result) ->
    ignore.

request_id() ->
    crypto:strong_rand_bytes(?QUOD_DTX_ENDPOINT_REQUEST_ID_BITS div 8).

remaining(Deadline) ->
    max(0, Deadline - quod_time:mono_ms()).

-ifdef(TEST).
test_certify_operation(OwnerNs, Ref, Evidence, Deadline, Dependencies) ->
    certify_operation_with(
      OwnerNs, Ref, Evidence, maps:get(operation_votes, Evidence, []),
      Deadline, Dependencies).

test_certify_applied(
  OwnerNs, Source, Claim, Evidence, TimeoutMs, Dependencies) ->
    Deadline = quod_time:mono_ms() + TimeoutMs,
    case remaining(Deadline) of
        0 -> {error, retry};
        Remaining ->
            case prepare_applied(OwnerNs, {Source, Claim, Evidence}, Remaining) of
                {ok, Prepared} -> certify_applied_prepared(OwnerNs, Prepared, Deadline, Dependencies);
                {error, _} = Error -> Error
            end
    end.

test_certify_applied_many(OwnerNs, Requests, Deadline, Dependencies) ->
    certify_applied_many_with(
      OwnerNs, Requests, Deadline, Dependencies).

test_certify_reads(OwnerNs, Request, Deadline, Dependencies) ->
    certify_reads_with(OwnerNs, Request, Deadline, Dependencies).

test_lookup_outcome(OwnerNs, Source, OutcomeRef, Deadline, Dependencies) ->
    lookup_outcome_with(
      OwnerNs, Source, OutcomeRef, Deadline, Dependencies).

test_production_dependencies() -> production_dependencies().

test_read_anchor_source(Source, Target, Claim, Deadline) ->
    read_anchor_source(Source, Target, Claim, Deadline).

test_endpoint_failure_disposition(Request, Reason) ->
    endpoint_failure_disposition(Request, Reason).

test_submit_operation_candidates(Request, Results) when is_list(Results) ->
    Counter = atomics:new(1, []),
    ResultTuple = list_to_tuple(Results),
    Candidates =
        [{<<N:256>>, {"127.0.0.1", 10000 + N}}
         || N <- lists:seq(1, length(Results))],
    Attempt =
        fun(_PeerKey, _Endpoint, _Remaining) ->
                Index = atomics:add_get(Counter, 1, 1),
                element(Index, ResultTuple)
        end,
    Result = submit_operation_candidates(
               <<"quod:test-owner">>, <<"quod:test-target">>, Candidates,
               Request, quod_time:mono_ms() + 1000, not_ready, Attempt),
    {Result, atomics:get(Counter, 1)}.

-endif.
