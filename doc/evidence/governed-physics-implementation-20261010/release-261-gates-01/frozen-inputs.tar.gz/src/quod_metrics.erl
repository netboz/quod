-module(quod_metrics).
-moduledoc """
Prometheus metrics for quod, served at `GET /metrics` on `metrics_port` (default 14568).

Every series carries a constant **`node_id`** label — this node's identity (`kp_<hex>`, from
`m:quod_identity`) — so a fleet-wide Prometheus tells nodes apart by their stable pubkey rather than a
volatile host:port. Per-namespace series add a **`namespace`** label.

Two collection paths:

  * **Poll (5s).** Scalar gauges are refreshed from each subsystem's `stats/1`
    (`m:quod_brahms`, `m:quod_simplex`, `m:quod_prolog`, `m:quod_runtime`, `m:quod_feed`). Cumulative counts are exposed
    as gauges set to the running total (use `rate()`/`increase()` in Grafana).
  * **Event.** The LIVE `{committed, Ns, Slot, Entry}` shape on the shared
    `{committed, Ns}` property carries its target namespace and drives finalized-transaction size and
    author metrics (never replay — see `quod_simplex:publish_feed/3`). Height-only
    certified-head wakes on that property are ignored here. The submitting
    Prolog process records end-to-end latency and authoritative retry outcomes; the
    proposer records one batching sample per proposed block; completion of an
    origin-owned submission records how many internal retargets it needed.

| metric | type | extra labels | what it means (plain) |
| ------ | ---- | ------------ | --------------------- |
| `quod_up` | gauge | | 1 while the node is running |
| `quod_brahms_*{namespace}` | gauge | | peer discovery plus each node's bounded, signed estimate of total live population |
| `quod_consensus_slot/committed/approved/last_applied/committee_size{namespace}` | gauge | | block numbers (newest / final / votable / applied) and how many nodes may vote |
| `quod_consensus_pipeline_gap{namespace}` | gauge | | blocks with enough votes but not yet final (stays 0-2 by design) |
| `quod_consensus_appends/proposals/batched_txs/commits/submitted/skips{namespace}` | gauge | | running totals of change and block activity |
| `quod_consensus_batch_window_ms{namespace}` | gauge | | configured time a proposer waits for more transactions before sealing a block |
| `quod_consensus_batch_size/batch_wait_ms{namespace}` | histogram | | transactions per proposed block and actual collection time |
| `quod_consensus_pending{namespace}` | gauge | | change requests waiting to be made final right now |
| `quod_consensus_append_busy/redirect/bad{namespace}` | gauge | | running totals of turned-away change requests, by reason |
| `quod_consensus_custody_depth/custody_ready/custody_bytes{namespace}` | gauge | | origin-owned signed submissions retained until local durable resolution, the subset ready for placement, and their encoded byte budget |
| `quod_consensus_ingress_retargets{namespace}` | gauge | | running total of retained submissions placed again after authoritative exclusion from an earlier slot |
| `quod_consensus_ingress_retarget_hops{namespace}` | histogram | | internal retarget count per completed origin-owned submission; zero means its first placement resolved |
| `quod_consensus_is_validator{namespace}` | gauge | | 1 if this node may vote (it actually votes only when `syncing` is 0) |
| `quod_consensus_syncing{namespace}` | gauge | | 1 while catching up / confirming the latest block, 0 once up to date |
| `quod_consensus_progress_slot/progress_phase{namespace}` | gauge | | current protocol view, its phase (0 idle, 1 proposal, 2 notarization) |
| `quod_consensus_progress_timeouts{namespace}` | gauge | | protocol watchdog expirations |
| `quod_consensus_head_*_votes/head_complaint_signed{namespace}` | gauge | | verified finality evidence for the oldest unfinished block and this node's own skip decision |
| `quod_consensus_missing_certified_blocks{namespace}` | gauge | | quorum-approved in-flight blocks whose content this node is retrieving from another validator |
| `quod_consensus_signing_journal_vote_sync_seconds{namespace}` | histogram | | time to make one local vote decision crash-durable before its signature is sent |
| `quod_consensus_redrives{namespace}` | gauge | | proposals re-sent while waiting |
| `quod_consensus_ahead_gap{namespace}` | gauge | | how many final blocks the network is ahead of this node (0 = up to date) |
| `quod_runtime_healthy/subscriptions_active/reactions_active/source_targets_active/source_interests_active/source_views_active/source_views_ready/source_views_building/source_views_unreachable/p_height/e_frontier/queue_len{namespace}` | gauge | | runtime: live flag, local subscription/reaction catalogue and certified source-view states, rebuilt-through height, effect-release frontier, queued events |
| `quod_runtime_reconciles/collapses/dropped_events/rejected_subscriptions{namespace}` | gauge | | running totals: full P rebuilds, work collapsed into a rebuild, dropped events and malformed subscription clauses |
| `quod_runtime_reaction_candidates/matches/reactions_executed/reaction_failures{namespace}` | gauge | | running totals for local and subscribed reaction selection, Erlog matches, queued goals and matching or queue failures |
| `quod_runtime_reaction_seconds{namespace,result}` | histogram | | local and subscribed reaction matching, owner resolution, and queue admission time by bounded result |
| `quod_foreign_follow_*` / `quod_foreign_projection_*` | gauge | | node-wide certified-follow targets, consumers, work, memory, health, traffic and rebuild totals; no target namespace label is exposed |
| `quod_foreign_history_custody_losses/corruptions/index_losses` | gauge | | separate owner-lifetime integrity-loss totals; worker loss never counts as corruption unless corruption is independently diagnosed |
| `quod_foreign_feed_registrations` | gauge | | live target-validator height-wake registrations owned by the node-wide certified follower |
| `quod_directory_desired_hosts{visibility}` / `quod_directory_advertisement_generation` / `quod_directory_route_*` | gauge | | fact-derived local hosting, the current signed generation, and exact route demand/wake activity; only fixed visibility labels are used |
| `quod_directory_rebuild_seconds{result}` | histogram | | exact route demand to directory-availability wake time, using only fixed result labels |
| `quod_effect_custody_*` | gauge | | node-wide direct-effect rows (including the group-active subset), reservations, and the committed capacity policy projected from root |
| `quod_prolog_applied/applies/rejects/proves/conflicts{namespace}` | gauge | | this node's stored-data activity (written / rejected / queried) |
| `quod_prolog_parked{namespace}` | gauge | | writes waiting here for their change to be made final |
| `quod_prolog_park_timeouts{namespace}` | gauge | | running total of writes whose final outcome was still unknown when their caller deadline elapsed |
| `quod_prolog_proof_workers/scope_workers{namespace}` | gauge | | origin proofs and selected proof scopes currently using a frozen data snapshot |
| `quod_prolog_kb_memory_words{namespace}` | gauge | | Erlang VM words used by the committed knowledge-base ETS table |
| `quod_prolog_kb_history_predicates{namespace}` | gauge | | predicates retaining an older version because a query still needs it |
| `quod_feed_pushed/ingested/pulled{namespace}` | gauge | | running totals of blocks spread / received / pulled to fill gaps |
| `quod_feed_dropped{namespace}` | gauge | `reason` | blocks thrown away, by reason (duplicate / gap / unverified / ...) |
| `quod_feed_digests/fresh_digests{namespace}` | gauge | | nodes sending 'alive' heartbeats / of those, still fresh |
| `quod_feed_recipients{namespace}` | gauge | | authenticated remote nodes currently registered for correlated height wakes from this hosted ontology |
| `quod_tx_commit_latency_ms{namespace}` | histogram | | submit → committed-and-applied, measured on the SUBMITTING node with one monotonic clock (one sample per change, at its author) |
| `quod_tx_diff_ops{namespace}` | histogram | | pieces of data added or removed per finished change, attributed to the target ontology |
| `quod_tx_committed_total{namespace}` | counter | `author` | finished changes in the target ontology, by its submitting node |
| `quod_dtx_committed_total{namespace}` | counter | `phase` | committed distributed-control barriers, by protocol phase |
| `quod_dtx_validation_events_total{namespace}` | counter | `event` | DTX validation attempts that reached their final abstention safeguard |
| `quod_dtx_submit_fanout_total{namespace}` | counter | `result` | bounded target-validator DTX delivery attempts and outcomes |
| `quod_dtx_admission_waiting/dormant{namespace}` | gauge | | active Vote selections and proof-reserved source groups in the single admission FIFO |
| `quod_dtx_admission_wait_ms{namespace}` | histogram | | time a sealed distributed write waited for durable source reservation |
| `quod_ontology_owner_current/peak{namespace,component,state}` | gauge | | current and owner-lifetime peak rows in the existing ontology-local DTX and catch-up owners |
| `quod_ontology_owner_bytes_current/peak{namespace,component}` | gauge | | current and owner-lifetime peak encoded bytes retained by ontology-local owners that retain encoded data |
| `quod_node_owner_current/peak{component,state}` | gauge | | current and owner-lifetime peak rows in the existing node-wide foreign-history, signed-goal, and scope routers |
| `quod_node_owner_bytes_current{component}` | gauge | | current bytes retained by node-wide owners that report byte totals |
| `quod_ontology_owner_duration_seconds` / `quod_node_owner_duration_seconds` | histogram | `component`, `phase`, `result` | lifetime of rows explicitly retired by a live owner, using only fixed labels |
| `quod_ontology_owner_terminal_total` / `quod_node_owner_terminal_total` | counter | `component`, `phase`, `result` | rows explicitly retired by a live owner, using only fixed labels |
| `quod_client_outcome_unknown_total` | counter | `producer` | client-visible uncertain write outcomes, split by the exact target or gateway boundary that produced them |
| `quod_tx_signature_validation_seconds{namespace}` | histogram | | time spent checking one transaction author's signature |
| `quod_tx_invalid_signatures_total{namespace}` | counter | | transaction signatures that failed cryptographic verification |
| `quod_remote_operation_stage_seconds{namespace,stage,result}` | histogram | | fixed stages of a signed one-target foreign operation; values never become labels |
| `quod_dtx_group_stage_seconds{namespace,stage,result}` | histogram | | fixed stages of one durable multi-ontology transaction; group ids and participant identities never become labels |
| `quod_foreign_history_stage_seconds{stage,result}` | histogram | | node-wide certified-history queue, resident decision, verification, cache, persistence, caller handoff, and serving timing; remote identities never become labels |
| `quod_tx_retries_total{namespace}` | counter | `reason` | operations explicitly told to prove and submit again |
| `quod_link_send_drops_total` | counter | `peer`, `channel`, `reason` | frames discarded at the QUIC send gate instead of transmitted; channel is the bounded `log`, `ingress`, or `other` class |
| `quod_consensus_round_approve_ms{namespace}` | histogram | | own proposal: broadcast to support-quorum approval, this node's clock |
| `quod_consensus_round_commit_ms{namespace}` | histogram | | own proposal: approval to final-and-durable here, this node's clock |
| `quod_consensus_event_ms{namespace}` | histogram | `class` | opt-in wall time handling one consensus event, by event class |
| `quod_consensus_event_qlen{namespace}` | histogram | `class` | opt-in mailbox depth found at consensus event entry |
| `quod_consensus_share_lag_ms{namespace}` | histogram | `kind` | own proposal: broadcast to each peer vote share arriving back |
| `quod_consensus_step_ms{namespace}` | histogram | `step` | named sub-steps inside consensus handlers (the slow-handler decomposition) |
| `quod_quic_srtt_ms/min_rtt_ms/cwnd_bytes/bytes_in_flight/send_queue_bytes/congested/in_recovery` | gauge | `peer` | per-peer QUIC transport health: RTT estimate vs wire floor, congestion window, unacked bytes, data queued behind pacing/cwnd, throttle flags |
""".

-behaviour(gen_server).

-export([start_link/0, observe_transaction_signature/3,
         observe_signing_journal_vote_sync/2,
         observe_tx_latency/2, count_link_send_drop/3, observe_round_phase/3,
         observe_consensus_event/4, observe_share_lag/3, observe_consensus_step/3,
         observe_batch/3, observe_ingress_retarget_hops/2, count_tx_retry/2,
         count_dtx_validation/2, count_dtx_submit_fanout/3,
         observe_dtx_admission_wait/2,
         observe_remote_operation_stage/4,
         observe_dtx_group_stage/4,
         observe_foreign_history_stage/3,
         observe_directory_rebuild/2,
         observe_runtime_reaction/3,
         observe_ontology_owner_terminal/5,
         observe_node_owner_terminal/4,
         count_client_outcome_unknown/1]).
-export([init/1, handle_call/3, handle_cast/2, handle_info/2, terminate/2]).

-ifdef(TEST).
-export([consensus_stat_keys/0, declare/1, test_observe_commit/2,
         test_refresh_foreign_log/0,
         test_remove_stale_consensus_metrics/1]).
-endif.

-include("quod_ledger.hrl").

-define(REFRESH_MS, 5000).
-define(LAT_BUCKETS,  [1, 5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000]).  %% ms: submit→commit
-define(ROUND_BUCKETS, [1, 2, 5, 10, 25, 50, 100, 150, 200, 300, 400, 500, 750,
                        1000, 2000, 5000]).   %% ms: one consensus round phase — fine-grained around the
                                              %% suspicious 100-750ms range so the probe can localize it
-define(EVENT_BUCKETS, [0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 25, 50, 100,
                        250, 500, 1000]).  %% ms per statem event; sub-ms resolution to
                                           %% split "fast handler" from "slow handler"
-define(QLEN_BUCKETS, [0, 1, 2, 5, 10, 25, 50, 100, 500, 1000]).  %% mailbox depth at entry
-define(DIFF_BUCKETS, [1, 2, 4, 8, 16, 32, 64, 128]).                               %% asserts+retracts per tx
-define(BATCH_SIZE_BUCKETS, [1, 2, 4, 8, 16, 32, 64, 128, 256]).
-define(BATCH_WAIT_BUCKETS, [0, 1, 2, 5, 10, 15, 25, 40, 75, 100, 250, 500, 1000]).
-define(RETARGET_HOPS_BUCKETS, [0, 1, 2, 3, 5, 8, 13, 21, 34]).
-define(DTX_ADMISSION_WAIT_BUCKETS,
        [0, 1, 2, 5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000,
         10000, 30000, 60000]).
-define(SIG_BUCKETS,  [0.00005, 0.0001, 0.00025, 0.0005, 0.001,
                       0.0025, 0.005, 0.01, 0.025, 0.05]).                            %% seconds per verify
-define(VOTE_SYNC_BUCKETS, [0.0001, 0.00025, 0.0005, 0.001, 0.0025,
                            0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5]).               %% seconds per datasync
-define(REACTION_BUCKETS, [0.00005, 0.0001, 0.00025, 0.0005, 0.001,
                           0.0025, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25,
                           0.5, 1.0]).
-define(OWNER_DURATION_BUCKETS,
        [0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5,
         5, 10, 30, 60, 300, 600]).
-define(REMOTE_OPERATION_STAGE_BUCKETS,
        [0.0001, 0.00025, 0.0005, 0.001, 0.0025, 0.005, 0.01,
         0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 30]).

start_link() ->
    gen_server:start_link({local, ?MODULE}, ?MODULE, [], []).

init([]) ->
    Port = application:get_env(quod, metrics_port, 14568),
    application:set_env(prometheus, prometheus_http, [{path, "/metrics"}, {port, Port}]),
    case prometheus_httpd:start() of
        {ok, _}                        -> ok;
        {error, {already_started, _}}  -> ok;
        Other -> logger:warning("quod: prometheus_httpd start: ~p", [Other])
    end,
    declare(local_node_id()),
    prometheus_gauge:set(quod_up, 1),
    self() ! refresh,
    logger:info("quod: prometheus metrics on :~p/metrics", [Port]),
    {ok, #{subs => #{}}}.

handle_call(_Req, _From, State) -> {reply, ok, State}.
handle_cast(_Msg, State)        -> {noreply, State}.

handle_info(refresh, State) ->
    SimplexNamespaces = quod_simplex:namespaces(),
    _ = remove_stale_consensus_metrics(SimplexNamespaces),
    _ = [refresh_ns(Ns)        || Ns <- quod_brahms:namespaces()],
    _ = [refresh_log_ns(Ns)    || Ns <- SimplexNamespaces],
    _ = [refresh_catchup_ns(Ns) || Ns <- SimplexNamespaces],
    _ = [refresh_runtime_ns(Ns) || Ns <- quod_prolog:namespaces()],  %% runtime runs beside each kb
    _ = refresh_foreign_log(),                                      %% one shared owner per node
    _ = refresh_directory(),                                        %% one fact-derived route projection per node
    _ = refresh_client_goal_router(),
    _ = refresh_scope_router(),
    _ = refresh_effect_custody(),                                   %% one shared owner per node
    _ = [refresh_prolog_ns(Ns) || Ns <- quod_prolog:namespaces()],
    _ = [refresh_feed_ns(Ns)   || Ns <- SimplexNamespaces],   %% feed runs per-ns alongside consensus
    _ = refresh_transport(),                                          %% per-peer QUIC srtt/cwnd/in-flight
    State1 = subscribe_commits(State),
    erlang:send_after(?REFRESH_MS, self(), refresh),
    {noreply, State1};
handle_info({committed, Ns, _Slot, Entry}, State) ->
    _ = observe_commit(Ns, Entry),
    {noreply, State};
handle_info(_Info, State) ->
    {noreply, State}.

terminate(_Reason, _State) -> ok.

%% --- declare -------------------------------------------------------------

%% `NodeId` becomes a constant label on EVERY series (this whole endpoint is one node), so it is attached
%% at declare time rather than threaded through every set/observe/inc. `declare` is idempotent.
declare(NodeId) ->
    CL = #{node_id => NodeId},
    _ = prometheus_gauge:declare([{name, quod_up}, {help, "1 while this node is running (0 or missing means it is down)."},
                                  {constant_labels, CL}]),
    G = fun(Name, Help) ->
            prometheus_gauge:declare([{name, Name}, {help, Help}, {labels, [namespace]},
                                      {constant_labels, CL}])
        end,
    H = fun(Name, Help, Buckets) ->
            prometheus_histogram:declare([{name, Name}, {help, Help}, {labels, [namespace]},
                                          {buckets, Buckets}, {constant_labels, CL}])
        end,
    RH = fun(Name, Help, Buckets) ->
             prometheus_histogram:declare(
               [{name, Name}, {help, Help}, {labels, [namespace, result]},
                {buckets, Buckets}, {constant_labels, CL}])
         end,
    N = fun(Name, Help) ->
            prometheus_gauge:declare([{name, Name}, {help, Help},
                                      {constant_labels, CL}])
        end,
    OG = fun(Name, Help) ->
             prometheus_gauge:declare(
               [{name, Name}, {help, Help},
                {labels, [namespace, component, state]},
                {constant_labels, CL}])
         end,
    OBG = fun(Name, Help) ->
              prometheus_gauge:declare(
                [{name, Name}, {help, Help},
                 {labels, [namespace, component]},
                 {constant_labels, CL}])
          end,
    NG = fun(Name, Help) ->
             prometheus_gauge:declare(
               [{name, Name}, {help, Help},
                {labels, [component, state]}, {constant_labels, CL}])
         end,
    NBG = fun(Name, Help) ->
              prometheus_gauge:declare(
                [{name, Name}, {help, Help},
                 {labels, [component]}, {constant_labels, CL}])
          end,
    %% Peer discovery: how this node finds and keeps track of the other nodes.
    _ = G(quod_brahms_view_size,   "How many other nodes this node currently knows about."),
    _ = G(quod_brahms_sample_size, "How many of those known nodes are in the small random set this node shares updates with, so gossip stays even."),
    _ = G(quod_brahms_links,       "How many other nodes this node has an open connection to right now."),
    _ = G(quod_brahms_rounds,      "Total number of update-sharing rounds this node has run (only ever goes up)."),
    _ = G(quod_brahms_evictions,   "Total number of nodes this node has dropped after they stopped responding (only ever goes up)."),
    _ = G(quod_brahms_tombstones,  "Nodes just marked dead and remembered for a short while so they are not added straight back (temporary; returns to 0)."),
    _ = G(quod_brahms_estimated_n, "Estimated total number of live nodes in this Brahms overlay. Nodes gossip a bounded sketch of signed, expiring stable identities, so a departed node ages out and a port change does not count as a new node."),
    %% Consensus: how the nodes agree on one shared, ordered history of changes.
    _ = G(quod_consensus_slot,            "The number of the newest block this node has. Higher means more history; all healthy nodes should track close together."),
    _ = G(quod_consensus_committed,       "The number of the newest block that is final and can never change."),
    _ = G(quod_consensus_protocol_view,        "Current consensus view within the installed committee era; independent of material ledger height."),
    _ = G(quod_consensus_pipeline_gap,    "Notarized material blocks beyond the durable ledger head; excludes empty recovery carriers."),
    _ = G(quod_consensus_last_applied,    "The number of the newest block whose changes this node has written into its own copy of the data."),
    _ = G(quod_consensus_committee_size,  "How many nodes are currently allowed to vote on changes."),
    _ = G(quod_consensus_appends,         "Total change requests this node accepted (while it was the leader) to put into blocks (only ever goes up)."),
    _ = G(quod_consensus_proposals,       "Total blocks this node has proposed while it was the leader (only ever goes up)."),
    _ = G(quod_consensus_batched_txs,     "Total changes packed into the blocks this node proposed. Divide its rate by the proposal rate to get the average number of changes per block."),
    _ = G(quod_consensus_batch_window_ms, "How many milliseconds this ontology's proposer is configured to wait after the first transaction before sealing a block. A larger value usually packs more transactions together but adds up to that much delay to a quiet write."),
    _ = G(quod_consensus_commits,         "Total blocks that have been made final and applied (only ever goes up)."),
    _ = G(quod_consensus_submitted,       "Total change requests handed to this node (only ever goes up)."),
    _ = G(quod_consensus_pending,         "Change requests waiting to be made final right now."),
    _ = G(quod_consensus_append_busy,     "Total change requests turned away as overloaded: the bounded waiting line was full, or a request waited past its cutoff during a stall. Requests that merely arrive at a busy moment now wait in line instead of being turned away, so any sustained increase here is an overload or a stalled cluster and deserves an alert (only ever goes up)."),
    _ = G(quod_consensus_ingress_queued,  "Change requests this node is holding right now. Relayed requests wait only for their explicitly named target slot; local requests may wait behind an unresolved author lane. Membership changes also wait for the current pipeline to become final. A value that stays high means consensus is not making room as fast as requests arrive."),
    _ = G(quod_consensus_ingress_overflow, "Total requests refused because the bounded ingress line (or one author's fair share of it) was full (only ever goes up)."),
    _ = G(quod_consensus_ingress_expired, "Total waiting requests cut loose because the cluster made no room for them within the ingress cutoff - a visible sign of a stall (only ever goes up)."),
    _ = G(quod_consensus_ingress_forwarded, "Total locally queued requests sent to the proposer of their exact target slot when the queue became dispatchable (only ever goes up)."),
    _ = G(quod_consensus_custody_depth, "Origin-owned signed content submissions this node is retaining until its local durable log proves inclusion or exclusion."),
    _ = G(quod_consensus_custody_ready, "Retained origin-owned submissions eligible for placement in the next usable consensus slot."),
    _ = G(quod_consensus_custody_bytes, "Encoded bytes held by this node's origin-owned submission custody."),
    _ = G(quod_consensus_ingress_retargets, "Total times this node placed the same retained signed submission again after its local durable log excluded an earlier placement (only ever goes up)."),
    _ = G(quod_consensus_relay_accepted, "Total relayed requests whose destination acknowledged that it was holding or processing them (only ever goes up)."),
    _ = G(quod_consensus_relay_duplicates, "Total exact duplicate relay submissions received while the original request was already being processed. This should stay low; a high rate means reconnect replay or duplicate callers are adding avoidable consensus-mailbox work (only ever goes up)."),
    _ = G(quod_consensus_append_redirect, "Total change requests refused because the local consensus process was unavailable, the receiver did not own the declared target slot, or that slot had already closed. This should stay near zero (only ever goes up)."),
    _ = G(quod_consensus_append_bad,      "Total change requests rejected because they were malformed or not allowed (only ever goes up)."),
    _ = G(quod_consensus_append_stale,    "Total otherwise-valid requests whose author sequence had already been superseded by newer approved history. This is a locally confirmed rejection, so the caller can safely re-prove with a fresh sequence (only ever goes up)."),
    _ = G(quod_consensus_membership_rejects, "Total requests to add or remove a voting node that this node judged invalid and refused (only ever goes up)."),
    _ = G(quod_consensus_redrives,        "Total times this node re-sent a proposal it was still waiting on instead of giving up. Climbing steadily means one of the voting nodes is not responding."),
    _ = G(quod_consensus_progress_slot,   "The current protocol view watched by this node; 0 means no pending consensus demand."),
    _ = G(quod_consensus_progress_phase,  "Current protocol wait: 0 idle, 1 a proposal, 2 notarization."),
    _ = G(quod_consensus_progress_timeouts, "Total protocol-view watchdog expirations. Occasional increases recover packet loss; sustained increases mean consensus is not advancing."),
    _ = G(quod_consensus_head_support_votes, "Verified support votes this node currently holds for the strongest block at the current protocol view. Reaching the certificate quorum approves that block."),
    _ = G(quod_consensus_head_commit_votes, "Verified commit votes this node currently holds for the strongest block at the current protocol view. Reaching the certificate quorum makes that block final."),
    _ = G(quod_consensus_head_complaint_votes, "Verified complaint votes this node currently holds for the current protocol view. A complaint quorum advances the protocol view without appending a material entry."),
    _ = G(quod_consensus_head_complaint_signed, "1 when this validator has itself durably complained in the current protocol view, 0 otherwise. Commit and complaint votes exclude one another only within that same view."),
    _ = G(quod_consensus_missing_certified_blocks, "Quorum-approved in-flight blocks whose vote certificate this node has but whose transaction content it is still retrieving. A value that stays above 0 means block recovery is not reaching any holder."),
    _ = G(quod_consensus_is_validator,    "1 if this node is allowed to vote on changes, 0 if it only reads and follows along. It actually casts votes only when 'syncing' is also 0."),
    _ = G(quod_consensus_syncing,         "1 while this node is still catching up or confirming it is on the latest block; 0 once it is up to date. A voting node cannot vote until this is 0."),
    _ = G(quod_consensus_ahead_gap,       "How many final blocks the rest of the network is ahead of this node (0 means up to date). A value that stays above 0 means this node has fallen behind and is fetching the blocks it is missing."),
    _ = G(quod_dtx_admission_waiting, "Atomic roles awaiting Vote selection in the existing owner admission FIFO."),
    _ = G(quod_dtx_admission_dormant, "Source groups durably reserved before the proof activates their own material."),
    _ = OG(quod_ontology_owner_current,
           "Current rows in internal work owners attached to one locally hosted ontology. Component and state are fixed labels; no remote identity or payload is exposed."),
    _ = OG(quod_ontology_owner_peak,
           "Highest simultaneous row count observed by that owner process since it started. The value resets when the owning process restarts."),
    _ = OBG(quod_ontology_owner_bytes_current,
            "Current encoded bytes retained by an internal owner attached to one locally hosted ontology."),
    _ = OBG(quod_ontology_owner_bytes_peak,
            "Highest encoded-byte total observed by that owner process since it started. The value resets when the owning process restarts."),
    _ = NG(quod_node_owner_current,
           "Current rows in one node-wide internal work owner. Component and state are fixed labels; peer, agent, target ontology, request, and payload identities are never labels."),
    _ = NG(quod_node_owner_peak,
           "Highest simultaneous row count observed by that node-wide owner process since it started. The value resets when the owning process restarts."),
    _ = NBG(quod_node_owner_bytes_current,
            "Current encoded bytes retained by one node-wide internal owner."),
    %% Runtime: live ordered input and actual resource owners.
    _ = G(quod_runtime_healthy,         "1 while the runtime is live and processing; 0 while booting, replaying, reconciling, or unhealthy. Missing means the runtime process is absent. A persistent 0 means it cannot currently release effects; check runtime logs and the failure metrics."),
    _ = G(quod_runtime_subscriptions_active, "How many distinct valid anchored subscribes/2 facts are active in this namespace's local runtime catalogue."),
    _ = G(quod_runtime_reactions_active, "How many currently committed react_on/2 clauses are active."),
    _ = G(quod_runtime_reaction_candidates, "Total react_on/2 clauses considered for canonical applied fact events (only ever goes up)."),
    _ = G(quod_runtime_reaction_matches, "Total react_on/2 event matches produced by Erlog unification (only ever goes up)."),
    _ = G(quod_runtime_reactions_executed, "Total reaction goals accepted by their current actor queue (only ever goes up)."),
    _ = G(quod_runtime_reaction_failures, "Total eligibility or queue admission failures (only ever goes up)."),
    _ = RH(quod_runtime_reaction_seconds, "Time spent matching and queueing one reaction candidate, split by its bounded result.", ?REACTION_BUCKETS),
    _ = G(quod_runtime_source_targets_active, "How many distinct anchored remote ontologies have at least one active source-qualified reaction interest."),
    _ = G(quod_runtime_source_interests_active, "How many active source-qualified react_on/2 interests are compiled across all targets."),
    _ = G(quod_runtime_source_views_active, "How many durable subscription targets this namespace runtime currently tracks; unavailable targets remain parked until an owner or route/feed wake."),
    _ = G(quod_runtime_source_views_ready, "How many subscribed foreign projections are currently certified and materialized for this namespace."),
    _ = G(quod_runtime_source_views_building, "How many subscribed foreign projections are currently rebuilding from certified history."),
    _ = G(quod_runtime_source_views_unreachable, "How many durable subscription targets this runtime cannot currently certify or reach."),
    _ = G(quod_runtime_p_height,        "The newest local block whose canonical input has been processed."),
    _ = G(quod_runtime_e_frontier,      "The processed local canonical input frontier used by the existing direct effect owner. Resource consumers use actual installation readiness."),
    _ = G(quod_runtime_queue_len,       "Local and certified subscribed publications waiting for ordered reaction matching and resource selection."),
    _ = G(quod_runtime_reconciles,      "Total committed snapshot attachments and catalog reconciliations (only ever goes up). One per boot or recovery is normal."),
    _ = G(quod_runtime_collapses,       "Total event batches collapsed into current-state recovery after overload or a reader failure (only ever goes up)."),
    _ = G(quod_runtime_dropped_events,  "Total change events dropped because a rebuild made them redundant or the queue overflowed (only ever goes up)."),
    _ = G(quod_runtime_rejected_subscriptions,"Total malformed subscribes/2 clauses ignored by local runtime reconciliation (only ever goes up)."),
    %% One node-wide certified foreign-history/fact owner. Target namespaces
    %% are deliberately absent from labels so hostile or high-cardinality
    %% durable subscription catalogues cannot grow Prometheus series.
    _ = N(quod_foreign_follow_targets, "Distinct foreign ontology histories actively followed on this node."),
    _ = N(quod_foreign_follow_consumers, "Local progress and projection consumer references sharing the node-wide certified follows."),
    _ = N(quod_foreign_projection_workers, "Foreign fact-projection workers currently materializing or holding certified state."),
    _ = N(quod_foreign_projection_bytes, "MVCC memory bytes held by foreign fact projections currently active on this node."),
    _ = N(quod_foreign_follow_building, "Followed targets whose certified fact projection is rebuilding."),
    _ = N(quod_foreign_follow_unreachable, "Followed targets currently unreachable or not certifiable."),
    _ = N(quod_foreign_follow_wakes, "Total coalesced message-driven certified-follow wake jobs started (only ever goes up)."),
    _ = N(quod_foreign_follow_pages, "Total certified history pages added by continuous follows (only ever goes up)."),
    _ = N(quod_foreign_follow_entries, "Total certified ledger entries added by continuous follows (only ever goes up)."),
    _ = N(quod_foreign_follow_bytes, "Total certified cache bytes added by continuous follows (only ever goes up)."),
    _ = N(quod_foreign_follow_coalesced, "Total source-view notices collapsed behind an unacknowledged notice (only ever goes up)."),
    _ = N(quod_foreign_follow_resnapshots, "Total state-only follow resnapshots delivered for initial attachment, rebuild, or lost occurrence continuity (only ever goes up)."),
    _ = N(quod_foreign_projection_rebuilds, "Total foreign fact-projection generations started (only ever goes up)."),
    _ = N(quod_foreign_history_custody_losses, "Total foreign mutable cursors lost on actual writer death since owner startup."),
    _ = N(quod_foreign_history_corruptions, "Total diagnosed foreign history integrity corruptions since owner startup; excludes mere writer loss."),
    _ = N(quod_foreign_history_index_losses, "Total foreign phase-index handoff losses since owner startup; excludes writer death and diagnosed corruption."),
    _ = N(quod_foreign_follow_max_lag, "Largest certified source height lag observed since this owner started."),
    _ = N(quod_foreign_feed_registrations, "Live target-validator height-wake registrations owned by the node-wide certified follower."),
    _ = N(quod_foreign_bootstrap_candidates, "TLS-authenticated foreign route candidates retained separately from dormant verified histories."),
    _ = N(quod_foreign_bootstrap_accepted, "Total authenticated foreign route candidate observations accepted into the lazy history owner (only ever goes up)."),
    _ = N(quod_foreign_bootstrap_rejected, "Total authenticated foreign route candidate observations refused by validation (only ever goes up)."),
    _ = N(quod_foreign_bootstrap_evicted, "Total older candidate endpoints evicted by the per-identity source bound (only ever goes up)."),
    _ = prometheus_gauge:declare(
          [{name, quod_directory_desired_hosts},
           {help, "Ontology identities in the node manager's fact-derived desired-host projection, split only by the fixed discoverable/private visibility classes."},
           {labels, [visibility]}, {constant_labels, CL}]),
    _ = N(quod_directory_advertisement_generation, "Newest local signed directory generation number. It advances when the committed ready-host projection changes or its lease is renewed."),
    _ = N(quod_directory_route_demands, "Exact missing-route demands currently retained by the existing directory-control owner."),
    _ = N(quod_directory_route_demanded, "Total distinct exact missing-route demands accepted since the directory-control owner started."),
    _ = N(quod_directory_route_wakes, "Total retained exact route demands completed by a directory availability edge since the directory-control owner started."),
    _ = prometheus_histogram:declare(
          [{name, quod_directory_rebuild_seconds},
           {help, "Time from retaining one exact missing-route demand until the ordinary directory availability edge completes it. Result uses a closed vocabulary; identities and endpoints are never labels."},
           {labels, [result]}, {buckets, ?REMOTE_OPERATION_STAGE_BUCKETS},
           {constant_labels, CL}]),
    %% One node-wide direct-effect journal. Capacity comes from committed
    %% root policy; the two flags distinguish a real zero capacity from
    %% unlimited or a node that has not received its projection yet.
    _ = N(quod_effect_custody_active, "Direct effects in crash-durable custody that have not reached a terminal result."),
    _ = N(quod_effect_custody_group_active, "Direct effects in active DTX group custody. This is a subset of active custody, not an additional row count."),
    _ = N(quod_effect_custody_reservations, "Direct-effect custody places reserved by proofs that have not yet bound their transaction."),
    _ = N(quod_effect_custody_terminal, "Completed direct-effect rows retained for local outcome lookup or later compaction."),
    _ = N(quod_effect_custody_capacity, "Committed bounded direct-effect custody capacity. Zero is also used when the separate unlimited or configured flag explains that no numeric bound applies yet."),
    _ = N(quod_effect_custody_capacity_configured, "1 after committed root policy has configured direct-effect custody; 0 while startup projection is unavailable."),
    _ = N(quod_effect_custody_capacity_unlimited, "1 when committed root policy explicitly makes direct-effect custody unlimited; 0 for a numeric capacity or before configuration."),
    %% Stored data: this node's own copy of the shared data.
    _ = G(quod_prolog_applied,       "The number of the newest block this node has written into its stored data."),
    _ = G(quod_prolog_applies,       "Total finished changes this node has written into its stored data (only ever goes up)."),
    _ = G(quod_prolog_rejects,       "Total finished changes not written because the data they depended on had already changed (only ever goes up)."),
    _ = G(quod_prolog_proves,        "Total read queries this node has answered (only ever goes up)."),
    _ = G(quod_prolog_conflicts,     "Total finished changes skipped because they clashed with newer data (only ever goes up)."),
    _ = G(quod_prolog_parked,        "Write requests waiting here for their change to be made final right now."),
    _ = G(quod_prolog_park_timeouts, "Total write callers whose transaction still had no final result at the local waiting deadline. The transaction may finalize later, so inspect the returned target-anchored outcome reference instead of retrying the same non-idempotent operation (only ever goes up)."),
    _ = G(quod_prolog_proof_workers, "How many local queries are running right now. Each uses a frozen view of the data, so a value at the configured limit means new queries are being turned away until one finishes."),
    _ = G(quod_prolog_scope_workers, "How many selected proof scopes this node is serving right now. Each keeps one reusable frozen-base session until the origin proof closes it."),
    _ = G(quod_prolog_kb_memory_words, "How much Erlang VM memory, in words, this ontology's shared knowledge-base table is using. Multiply by the VM word size (normally 8 bytes on a 64-bit node) for an approximate byte count."),
    _ = G(quod_prolog_kb_history_predicates, "How many predicates are temporarily keeping an older data version because a running origin proof or selected scope still needs it. It should return to 0 after those proof scopes finish."),
    %% Spreading finished blocks to the rest of the network.
    _ = G(quod_feed_pushed,   "Total final blocks this node produced and started sending out to the rest of the network (only ever goes up)."),
    _ = G(quod_feed_ingested, "Total blocks this node received from others, checked, applied, and passed along (only ever goes up)."),
    _ = G(quod_feed_pulled,   "Total times this node asked others to send it blocks it was missing (only ever goes up)."),
    _ = G(quod_feed_digests,       "How many other nodes this node is currently getting 'still alive' heartbeats from (used to judge whether a candidate is alive enough to add as a voting node)."),
    _ = G(quod_feed_fresh_digests, "How many of those nodes sent a heartbeat recently enough to still count as alive."),
    _ = G(quod_feed_recipients, "How many authenticated remote nodes are currently registered for correlated height wakes from this hosted ontology."),
    _ = prometheus_gauge:declare([{name, quod_feed_dropped},
                                  {help, "Total blocks received from other nodes that this node threw away, grouped by why (only ever goes up). "
                                         "duplicate = already had it (harmless); gap = arrived out of order and fetched again later; "
                                         "unverified = failed its vote check, possibly a faulty or dishonest node (the one to watch); "
                                         "the other reasons are minor."},
                                  {labels, [namespace, reason]}, {constant_labels, CL}]),
    %% Per-change timing and size.
    _ = H(quod_tx_commit_latency_ms, "How long each change took from being handed in to being made final and applied, in milliseconds. Measured on the node that submitted the change, with a single clock - so it is honest end-to-end time, never a comparison of two machines' clocks - and each change is counted exactly once.", ?LAT_BUCKETS),
    _ = H(quod_tx_diff_ops,          "How many individual pieces of data each finished change added or removed.", ?DIFF_BUCKETS),
    _ = H(quod_consensus_batch_size,
          "How many transactions this node packed into each block it proposed. Values near 1 under a busy workload mean transactions are missing the same collection window and causing extra blocks.",
          ?BATCH_SIZE_BUCKETS),
    _ = H(quod_consensus_batch_wait_ms,
          "How long, in milliseconds, this node kept each new block open to collect more transactions before proposing it. Full or membership blocks can seal early; ordinary quiet blocks should be close to the configured batch window.",
          ?BATCH_WAIT_BUCKETS),
    _ = H(quod_consensus_ingress_retarget_hops,
          "How many internal retargets each completed origin-owned submission needed. Zero means its first placement resolved; values above zero expose slot-boundary churn without turning it into a client retry.",
          ?RETARGET_HOPS_BUCKETS),
    _ = H(quod_dtx_admission_wait_ms,
          "How long a sealed distributed write waited, in milliseconds, for durable source reservation.",
          ?DTX_ADMISSION_WAIT_BUCKETS),
    _ = H(quod_tx_signature_validation_seconds,
          "How long this node spent checking one transaction author's Ed25519 signature before accepting it. Higher values mean transaction authentication is consuming more consensus time.",
          ?SIG_BUCKETS),
    _ = prometheus_histogram:declare(
          [{name, quod_remote_operation_stage_seconds},
           {help, "Time spent in one fixed stage of a signed one-target foreign operation. Stage and result use a closed vocabulary; ontology identities, operation ids, goals, and failure payloads are never labels."},
           {labels, [namespace, stage, result]},
           {buckets, ?REMOTE_OPERATION_STAGE_BUCKETS},
           {constant_labels, CL}]),
    _ = prometheus_histogram:declare(
          [{name, quod_dtx_group_stage_seconds},
           {help, "Time spent in one fixed stage of a durable multi-ontology transaction. Group ids, participant identities, goals, and failure payloads are never labels."},
           {labels, [namespace, stage, result]},
           {buckets, ?REMOTE_OPERATION_STAGE_BUCKETS},
           {constant_labels, CL}]),
    _ = prometheus_histogram:declare(
          [{name, quod_foreign_history_stage_seconds},
           {help, "Node-wide time spent queueing, deciding, verifying, persisting, serving, and handing off certified foreign history. Remote ontology identities and request values are never labels."},
           {labels, [stage, result]},
           {buckets, ?REMOTE_OPERATION_STAGE_BUCKETS},
           {constant_labels, CL}]),
    _ = H(quod_consensus_signing_journal_vote_sync_seconds,
          "How long this node took to make one support, commit, or skip vote crash-durable before sending its signature. Every new vote waits for this small disk sync; sustained high values directly delay block finality.",
          ?VOTE_SYNC_BUCKETS),
    _ = H(quod_consensus_round_approve_ms,
          "When it was this node's turn to build a block: how long, in milliseconds, from sending the new block out to the other nodes until enough of them agreed to accept it. This is the first half of agreeing on a block; on a fast local network it should be a few tens of milliseconds, and rising values mean agreement is getting slower.",
          ?ROUND_BUCKETS),
    _ = prometheus_histogram:declare(
          [{name, quod_consensus_event_ms},
           {help, "How long, in milliseconds, this node spent dealing with one incoming message, grouped by the kind of message. If these stay small while blocks are still slow, the delay is somewhere other than this node's own work."},
           {labels, [namespace, class]}, {buckets, ?EVENT_BUCKETS}, {constant_labels, CL}]),
    _ = prometheus_histogram:declare(
          [{name, quod_consensus_event_qlen},
           {help, "How many messages were already waiting in line when this node picked up the next one to handle, grouped by kind. A number that climbs means messages are arriving faster than the node can handle them, so work backs up and everything slows down."},
           {labels, [namespace, class]}, {buckets, ?QLEN_BUCKETS}, {constant_labels, CL}]),
    _ = prometheus_histogram:declare(
          [{name, quod_consensus_step_ms},
           {help, "How long, in milliseconds, each individual step of handling a block took (saving a vote to disk, saving the block, sending it on, and so on), grouped by step name. When a block is slow, the step with the biggest number here is the cause."},
           {labels, [namespace, step]}, {buckets, ?EVENT_BUCKETS}, {constant_labels, CL}]),
    _ = prometheus_histogram:declare(
          [{name, quod_consensus_share_lag_ms},
           {help, "When it was this node's turn to build a block: how long, in milliseconds, from sending the block out until each other node's vote came back. The plain measure of how long it takes to collect votes from the others."},
           {labels, [namespace, kind]}, {buckets, ?ROUND_BUCKETS}, {constant_labels, CL}]),
    _ = H(quod_consensus_round_commit_ms,
          "When it was this node's turn to build a block: how long, in milliseconds, from the block being accepted until it is made final and saved to disk here. This is the second half of agreeing on a block; add it to the first half for the full time a block takes.",
          ?ROUND_BUCKETS),
    _ = prometheus_histogram:declare(
          [{name, quod_ontology_owner_duration_seconds},
           {help, "Lifetime of one internal owner row explicitly retired while its locally hosted ontology owner is alive. Component, phase, result, and histogram buckets are fixed; identities and failure payloads are never labels."},
           {labels, [namespace, component, phase, result]},
           {buckets, ?OWNER_DURATION_BUCKETS}, {constant_labels, CL}]),
    _ = prometheus_histogram:declare(
          [{name, quod_node_owner_duration_seconds},
           {help, "Lifetime of one node-wide internal owner row explicitly retired while its owner is alive. Component, phase, result, and histogram buckets are fixed; identities and failure payloads are never labels."},
           {labels, [component, phase, result]},
           {buckets, ?OWNER_DURATION_BUCKETS}, {constant_labels, CL}]),
    _ = prometheus_counter:declare([{name, quod_tx_committed_total},
                                    {help, "Total finished changes, grouped by the node that submitted them (only ever goes up)."},
                                    {labels, [namespace, author]}, {constant_labels, CL}]),
    _ = prometheus_counter:declare([{name, quod_dtx_committed_total},
                                    {help, "Committed distributed-transaction control barriers, grouped by protocol phase."},
                                    {labels, [namespace, phase]}, {constant_labels, CL}]),
    _ = prometheus_counter:declare(
          [{name, quod_dtx_validation_events_total},
           {help, "Distributed-control validation attempts that reached their final abstention safeguard."},
           {labels, [namespace, event]}, {constant_labels, CL}]),
    _ = prometheus_counter:declare(
          [{name, quod_dtx_submit_fanout_total},
           {help, "Bounded target-validator delivery attempts and their correlated results for distributed controls."},
           {labels, [namespace, result]}, {constant_labels, CL}]),
    _ = prometheus_counter:declare(
          [{name, quod_ontology_owner_terminal_total},
           {help, "Internal owner rows explicitly retired by live locally hosted ontology owners, using only fixed component, phase, and result labels."},
           {labels, [namespace, component, phase, result]},
           {constant_labels, CL}]),
    _ = prometheus_counter:declare(
          [{name, quod_node_owner_terminal_total},
           {help, "Node-wide internal owner rows explicitly retired by live owners, using only fixed component, phase, and result labels."},
           {labels, [component, phase, result]}, {constant_labels, CL}]),
    _ = prometheus_counter:declare(
          [{name, quod_client_outcome_unknown_total},
           {help, "Client-visible uncertain write outcomes, split by the fixed target or gateway boundary that produced them. Operation, ontology, peer, and failure values are never labels."},
           {labels, [producer]}, {constant_labels, CL}]),
    _ = prometheus_counter:declare(
          [{name, quod_tx_invalid_signatures_total},
           {help, "Total transaction author signatures that failed cryptographic verification. Any increase means malformed, corrupted, or dishonest transaction input was rejected before this node voted for its block."},
           {labels, [namespace]}, {constant_labels, CL}]),
    _ = prometheus_counter:declare(
          [{name, quod_tx_retries_total},
           {help, "Total operations explicitly told to prove and submit again, grouped by cause. stale_sequence means newer approved history overtook the signed author sequence. Ordinary retained content is internally retargeted after slot exclusion and does not increment this counter."},
           {labels, [namespace, reason]}, {constant_labels, CL}]),
    P = fun(Name, Help) ->
            prometheus_gauge:declare([{name, Name}, {help, Help}, {labels, [peer]},
                                      {constant_labels, CL}])
        end,
    _ = P(quod_quic_srtt_ms,
          "The typical time, in milliseconds, for a message to reach each other node and a reply to come back, as the network connection estimates it. On a local network this should be a few milliseconds; if it is much larger than quod_quic_min_rtt_ms, something (a busy machine or slow replies) is adding delay on top of the network, and that slows every block."),
    _ = P(quod_quic_min_rtt_ms,
          "The fastest round trip ever seen to each other node, in milliseconds - the raw speed of the network with nothing slowing it down. Compare it against quod_quic_srtt_ms: a big gap between them means delay is being added on top of the network."),
    _ = P(quod_quic_cwnd_bytes,
          "How many bytes the connection to each other node is currently willing to have traveling at once. Anything beyond this waits its turn quietly instead of going out immediately, so a small number here can slow sending down without showing any error."),
    _ = P(quod_quic_bytes_in_flight,
          "How many bytes have been sent to each other node but not yet confirmed as arrived. If this sits right at the limit above (quod_quic_cwnd_bytes), the connection itself is what is holding sending back."),
    _ = P(quod_quic_send_queue_bytes,
          "How many bytes have been handed to the connection for sending to each other node but are still waiting inside it to actually go out. The node believes it already sent them, so this is hidden delay; a value that stays above zero means the connection is holding messages back."),
    _ = P(quod_quic_congested,
          "1 when the connection to this other node is deliberately slowing sending because the link looks full, 0 otherwise."),
    _ = P(quod_quic_in_recovery,
          "1 when the connection to this other node is recovering from data lost on the network, 0 otherwise."),
    _ = prometheus_counter:declare(
          [{name, quod_link_send_drops_total},
           {help, "Total messages this node threw away instead of sending, grouped by destination, bounded channel class, and reason. channel='log' is consensus, channel='ingress' is retained relay traffic, and channel='other' covers every non-Simplex or malformed channel without creating arbitrary labels. 'flow_control' means that node was reading too slowly to accept more; 'queue_full' means this node's own outbound buffer was full. Consensus watchdog recovery and retained-relay reconnect replay recover their own lost work; a steady climb still slows progress (only ever goes up)."},
           {labels, [peer, channel, reason]}, {constant_labels, CL}]),
    ok.

%% Signature checks happen in the consensus and history-validation paths. Metrics
%% must never become a dependency of either path, including during supervisor
%% startup or a metrics-process restart.
-spec observe_transaction_signature(binary(), boolean(), non_neg_integer()) -> ok.
observe_transaction_signature(Ns, Valid, DurationNative)
  when is_binary(Ns), is_boolean(Valid), is_integer(DurationNative), DurationNative >= 0 ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            try
                Seconds = erlang:convert_time_unit(DurationNative, native, nanosecond) / 1000000000,
                _ = prometheus_histogram:observe(
                      quod_tx_signature_validation_seconds, [label(Ns)], Seconds),
                _ = case Valid of
                        true  -> ok;
                        false -> prometheus_counter:inc(
                                   quod_tx_invalid_signatures_total, [label(Ns)])
                    end,
                ok
            catch
                _:_ -> ok
            end
    end.

%% Vote persistence is on the consensus hot path, but observability must remain optional during
%% supervisor startup and metrics-process restarts.
-spec observe_signing_journal_vote_sync(binary(), non_neg_integer()) -> ok.
observe_signing_journal_vote_sync(Ns, DurationNative)
  when is_binary(Ns), is_integer(DurationNative), DurationNative >= 0 ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            try
                %% The seconds-suffixed histogram converts native durations on
                %% export, including its finite bucket bounds.
                _ = prometheus_histogram:observe(
                      quod_consensus_signing_journal_vote_sync_seconds,
                      [label(Ns)], DurationNative),
                ok
            catch
                _:_ -> ok
            end
    end.

%% --- poll refresh --------------------------------------------------------

refresh_ns(Ns) ->
    case quod_brahms:stats(Ns) of
        #{view := V, sample := S, conns := C, rounds := R, evictions := E,
          tombstones := T, estimated_n := EN} ->
            _ = prometheus_gauge:set(quod_brahms_view_size,   [label(Ns)], V),
            _ = prometheus_gauge:set(quod_brahms_sample_size, [label(Ns)], S),
            _ = prometheus_gauge:set(quod_brahms_links,       [label(Ns)], C),
            _ = prometheus_gauge:set(quod_brahms_rounds,      [label(Ns)], R),
            _ = prometheus_gauge:set(quod_brahms_evictions,   [label(Ns)], E),
            _ = prometheus_gauge:set(quod_brahms_tombstones,  [label(Ns)], T),
            _ = prometheus_gauge:set(quod_brahms_estimated_n, [label(Ns)], EN),
            ok;
        _ -> ok
    end.

refresh_runtime_ns(Ns) ->
    case quod_runtime:stats(Ns) of
        #{mode := Mode, subscriptions_active := SA,
          reactions_active := RA, source_targets_active := STA,
          source_interests_active := SIA, p_height := PH, e_frontier := EF,
          source_views_active := SVA, source_views_ready := SVR,
          source_views_building := SVB, source_views_unreachable := SVU,
          queue_len := QL, reconciles := RC, collapses := CO, dropped_events := DE,
          rejected_subscriptions := RS,
          reaction_candidates := RCa, reaction_matches := RM,
          reactions_executed := RE,
          reaction_failures := RF} ->
            S = fun(Name, V) -> prometheus_gauge:set(Name, [label(Ns)], V) end,
            _ = S(quod_runtime_healthy, case Mode of live -> 1; _ -> 0 end),
            _ = S(quod_runtime_subscriptions_active, SA),
            _ = S(quod_runtime_reactions_active, RA),
            _ = S(quod_runtime_reaction_candidates, RCa),
            _ = S(quod_runtime_reaction_matches, RM),
            _ = S(quod_runtime_reactions_executed, RE),
            _ = S(quod_runtime_reaction_failures, RF),
            _ = S(quod_runtime_source_targets_active, STA),
            _ = S(quod_runtime_source_interests_active, SIA),
            _ = S(quod_runtime_source_views_active, SVA),
            _ = S(quod_runtime_source_views_ready, SVR),
            _ = S(quod_runtime_source_views_building, SVB),
            _ = S(quod_runtime_source_views_unreachable, SVU),
            _ = S(quod_runtime_p_height, PH),
            _ = S(quod_runtime_e_frontier, EF),
            _ = S(quod_runtime_queue_len, QL),
            _ = S(quod_runtime_reconciles, RC),
            _ = S(quod_runtime_collapses, CO),
            _ = S(quod_runtime_dropped_events, DE),
            _ = S(quod_runtime_rejected_subscriptions, RS),
            ok;
        _ -> remove_runtime_metrics(Ns)
    end.

remove_runtime_metrics(Ns) ->
    Labels = [label(Ns)],
    Names = [quod_runtime_healthy,
             quod_runtime_subscriptions_active, quod_runtime_reactions_active,
             quod_runtime_reaction_candidates, quod_runtime_reaction_matches,
             quod_runtime_reactions_executed,
             quod_runtime_reaction_failures,
             quod_runtime_source_targets_active, quod_runtime_source_interests_active,
             quod_runtime_source_views_active, quod_runtime_source_views_ready,
             quod_runtime_source_views_building,
             quod_runtime_source_views_unreachable,
             quod_runtime_p_height, quod_runtime_e_frontier, quod_runtime_queue_len,
             quod_runtime_reconciles, quod_runtime_collapses, quod_runtime_dropped_events,
             quod_runtime_rejected_subscriptions],
    _ = [prometheus_gauge:remove(Name, Labels) || Name <- Names],
    ok.

-ifdef(TEST).
test_refresh_foreign_log() -> refresh_foreign_log().
-endif.

refresh_foreign_log() ->
    Stats = quod_foreign_log:stats(),
    Set = fun(Name, Key) ->
                  prometheus_gauge:set(Name, maps:get(Key, Stats, 0))
          end,
    _ = Set(quod_foreign_follow_targets, followed_histories),
    _ = Set(quod_foreign_follow_consumers, follow_consumers),
    _ = Set(quod_foreign_projection_workers, projection_workers),
    _ = Set(quod_foreign_projection_bytes, projection_bytes),
    _ = Set(quod_foreign_follow_building, follow_building),
    _ = Set(quod_foreign_follow_unreachable, follow_unreachable),
    _ = Set(quod_foreign_follow_wakes, follow_wakes),
    _ = Set(quod_foreign_follow_pages, follow_pages),
    _ = Set(quod_foreign_follow_entries, follow_entries),
    _ = Set(quod_foreign_follow_bytes, follow_bytes),
    _ = Set(quod_foreign_follow_coalesced, follow_coalesced),
    _ = Set(quod_foreign_follow_resnapshots, follow_resnapshots),
    _ = Set(quod_foreign_projection_rebuilds, projection_rebuilds),
    _ = Set(quod_foreign_history_custody_losses, history_custody_losses),
    _ = Set(quod_foreign_history_corruptions, history_corruptions),
    _ = Set(quod_foreign_history_index_losses, history_index_losses),
    _ = Set(quod_foreign_follow_max_lag, max_follow_lag),
    _ = Set(quod_foreign_feed_registrations, feed_registrations),
    _ = Set(quod_foreign_bootstrap_candidates, bootstrap_candidates),
    _ = Set(quod_foreign_bootstrap_accepted, bootstrap_accepted),
    _ = Set(quod_foreign_bootstrap_rejected, bootstrap_rejected),
    _ = Set(quod_foreign_bootstrap_evicted, bootstrap_evicted),
    _ = set_node_owner_rows(
          foreign_history,
          #{verifying => maps:get(pending, Stats, 0),
            page_pulls => maps:get(pulls, Stats, 0),
            cached_histories => maps:get(histories, Stats, 0)},
          #{}),
    _ = set_node_owner_bytes(
          foreign_history, maps:get(cache_bytes, Stats, 0)),
    ok.

refresh_directory() ->
    Manager = quod_namespace_manager:stats(),
    Desired = case Manager of
                  #{desired_hosts := Counts} -> Counts;
                  _ -> #{}
              end,
    _ = prometheus_gauge:set(
          quod_directory_desired_hosts, [<<"discoverable">>],
          maps:get(discoverable, Desired, 0)),
    _ = prometheus_gauge:set(
          quod_directory_desired_hosts, [<<"private">>],
          maps:get(private, Desired, 0)),
    Control = quod_directory_control:stats(),
    _ = set_directory_control_gauge(
          quod_directory_advertisement_generation, sequence, Control),
    _ = set_directory_control_gauge(
          quod_directory_route_demands, route_demands, Control),
    _ = set_directory_control_gauge(
          quod_directory_route_demanded, route_demanded, Control),
    _ = set_directory_control_gauge(
          quod_directory_route_wakes, route_wakes, Control),
    ok.

set_directory_control_gauge(Name, Key, Stats) when is_map(Stats) ->
    prometheus_gauge:set(Name, maps:get(Key, Stats, 0));
set_directory_control_gauge(Name, _Key, _Stats) ->
    prometheus_gauge:set(Name, 0).

refresh_client_goal_router() ->
    Stats = quod_client_goal_router:stats(),
    set_node_owner_rows(
      client_goal_router, maps:get(owner_current, Stats, #{}),
      maps:get(owner_peak, Stats, #{})).

refresh_scope_router() ->
    Stats = quod_ask_router:stats(),
    set_node_owner_rows(
      scope_router, maps:get(owner_current, Stats, #{}),
      maps:get(owner_peak, Stats, #{})).

refresh_catchup_ns(Ns) ->
    Stats = quod_catchup:stats(Ns),
    set_ontology_owner_rows(
      Ns, catchup_read,
      #{client_pending => maps:get(client_pending, Stats, 0),
        server_inflight => maps:get(server_inflight, Stats, 0)},
      #{client_pending => maps:get(client_pending_peak, Stats, 0),
        server_inflight => maps:get(server_inflight_peak, Stats, 0)}).

refresh_effect_custody() ->
    case quod_effect_journal:stats() of
        #{limits := Limits, active := Active, group_active := GroupActive,
          reservations := Reservations, terminal := Terminal} ->
            _ = prometheus_gauge:set(quod_effect_custody_active, Active),
            _ = prometheus_gauge:set(
                  quod_effect_custody_group_active, GroupActive),
            _ = prometheus_gauge:set(
                  quod_effect_custody_reservations, Reservations),
            _ = prometheus_gauge:set(quod_effect_custody_terminal, Terminal),
            {Value, Configured, Unlimited} =
                effect_capacity_metrics(Limits),
            _ = prometheus_gauge:set(quod_effect_custody_capacity, Value),
            _ = prometheus_gauge:set(
                  quod_effect_custody_capacity_configured, Configured),
            _ = prometheus_gauge:set(
                  quod_effect_custody_capacity_unlimited, Unlimited),
            ok;
        _ ->
            _ = prometheus_gauge:set(quod_effect_custody_active, 0),
            _ = prometheus_gauge:set(quod_effect_custody_group_active, 0),
            _ = prometheus_gauge:set(
                  quod_effect_custody_reservations, 0),
            _ = prometheus_gauge:set(quod_effect_custody_terminal, 0),
            _ = prometheus_gauge:set(quod_effect_custody_capacity, 0),
            _ = prometheus_gauge:set(
                  quod_effect_custody_capacity_configured, 0),
            _ = prometheus_gauge:set(
                  quod_effect_custody_capacity_unlimited, 0),
            ok
    end.

effect_capacity_metrics(unconfigured) -> {0, 0, 0};
effect_capacity_metrics({unlimited, _}) -> {0, 1, 1};
effect_capacity_metrics({Capacity, _})
  when is_integer(Capacity), Capacity >= 0 ->
    {Capacity, 1, 0}.

refresh_log_ns(Ns) ->
    case quod_simplex:stats(Ns) of
        %% This pattern MUST stay a subset of quod_simplex:stats_map/1 — a key listed
        %% here but absent there silently skips EVERY consensus gauge (falls through to
        %% the `_ -> ok` arm). consensus_stat_keys/0 mirrors this list; the lockstep
        %% eunit in quod_simplex_tests pins the two together.
        #{slot := Sl, committed := CI, protocol_view := PV, pipeline_gap := PG,
          last_applied := LA, committee_size := CS,
          appends := AP, proposals := PR, batched_txs := BT,
          batch_window_ms := BW,
          commits := CM, submitted := SU, pending := PE,
          r_busy := RB, r_redirect := RR, r_bad := RD, r_stale := RS,
          membership_rejects := MR,
          ingress_queued := IQ, ingress_overflow := IO,
          ingress_expired := IE, ingress_forwarded := IF,
          custody_depth := CD, custody_ready := CR, custody_bytes := CB,
          dtx_admission_waiting := DAW, dtx_admission_dormant := DAD,
          owner_current := OwnerCurrent, owner_peak := OwnerPeak,
          owner_bytes_current := OwnerBytesCurrent,
          owner_bytes_peak := OwnerBytesPeak,
          ingress_retargets := IRT,
          relay_accepted := RA,
          relay_duplicates := RDU,
          redrives := RV, progress_slot := PS, progress_phase_code := PP,
          progress_timeouts := PT, head_support_votes := HSV, head_commit_votes := HCV,
          head_complaint_votes := HXV, head_complaint_signed := HXS,
          missing_certified_blocks := MCB,
          is_validator := IV, syncing := SY,
          ahead_gap := AG} ->
            S = fun(Name, V) -> prometheus_gauge:set(Name, [label(Ns)], V) end,
            _ = S(quod_consensus_slot,            Sl),
            _ = S(quod_consensus_committed,       CI),
            _ = S(quod_consensus_protocol_view,        PV),
            _ = S(quod_consensus_pipeline_gap,    PG),
            _ = S(quod_consensus_last_applied,    LA),
            _ = S(quod_consensus_committee_size,  CS),
            _ = S(quod_consensus_appends,         AP),
            _ = S(quod_consensus_proposals,       PR),
            _ = S(quod_consensus_batched_txs,     BT),
            _ = S(quod_consensus_batch_window_ms, BW),
            _ = S(quod_consensus_commits,         CM),
            _ = S(quod_consensus_submitted,       SU),
            _ = S(quod_consensus_pending,         PE),
            _ = S(quod_consensus_append_busy,     RB),
            _ = S(quod_consensus_ingress_queued,  IQ),
            _ = S(quod_consensus_ingress_overflow, IO),
            _ = S(quod_consensus_ingress_expired, IE),
            _ = S(quod_consensus_ingress_forwarded, IF),
            _ = S(quod_consensus_custody_depth, CD),
            _ = S(quod_consensus_custody_ready, CR),
            _ = S(quod_consensus_custody_bytes, CB),
            _ = S(quod_dtx_admission_waiting, DAW),
            _ = S(quod_dtx_admission_dormant, DAD),
            _ = maps:foreach(
                  fun(Component, Current) ->
                          set_ontology_owner_rows(
                            Ns, Component, Current,
                            maps:get(Component, OwnerPeak, #{}))
                  end, OwnerCurrent),
            _ = maps:foreach(
                  fun(Component, CurrentBytes) ->
                          set_ontology_owner_bytes(
                            Ns, Component, CurrentBytes,
                            maps:get(Component, OwnerBytesPeak, undefined))
                  end, OwnerBytesCurrent),
            _ = S(quod_consensus_ingress_retargets, IRT),
            _ = S(quod_consensus_relay_accepted, RA),
            _ = S(quod_consensus_relay_duplicates, RDU),
            _ = S(quod_consensus_append_redirect, RR),
            _ = S(quod_consensus_append_bad,      RD),
            _ = S(quod_consensus_append_stale,    RS),
            _ = S(quod_consensus_membership_rejects, MR),
            _ = S(quod_consensus_redrives,        RV),
            _ = S(quod_consensus_progress_slot,   PS),
            _ = S(quod_consensus_progress_phase,  PP),
            _ = S(quod_consensus_progress_timeouts, PT),
            _ = S(quod_consensus_head_support_votes, HSV),
            _ = S(quod_consensus_head_commit_votes, HCV),
            _ = S(quod_consensus_head_complaint_votes, HXV),
            _ = S(quod_consensus_head_complaint_signed, HXS),
            _ = S(quod_consensus_missing_certified_blocks, MCB),
            _ = S(quod_consensus_is_validator,    IV),
            _ = S(quod_consensus_syncing,         SY),
            _ = S(quod_consensus_ahead_gap,       AG),
            ok;
        _ -> ok
    end.

%% Consensus gauges describe live per-ontology processes, not retained history.
%% Prometheus keeps a label row after its producer disappears, so reconcile those
%% rows against the simplex registry before each refresh.  Reading the registry
%% instead of remembering a previous process-local set also repairs stale rows
%% after the metrics process itself restarts.
remove_stale_consensus_metrics(Namespaces) ->
    Live = maps:from_keys([label(Ns) || Ns <- Namespaces], true),
    Rows = prometheus_gauge:values(default, quod_consensus_syncing),
    lists:foreach(
      fun({[{_NamespaceLabel, NsLabel}], _Value}) ->
              case maps:is_key(NsLabel, Live) of
                  true -> ok;
                  false -> remove_consensus_metrics(NsLabel)
              end
      end, Rows),
    ok.

remove_consensus_metrics(NsLabel) ->
    _ = [prometheus_gauge:remove(Name, [NsLabel])
         || Name <- consensus_gauge_names()],
    ok.

consensus_gauge_names() ->
    [quod_consensus_slot,
     quod_consensus_committed,
     quod_consensus_protocol_view,
     quod_consensus_pipeline_gap,
     quod_consensus_last_applied,
     quod_consensus_committee_size,
     quod_consensus_appends,
     quod_consensus_proposals,
     quod_consensus_batched_txs,
     quod_consensus_batch_window_ms,
     quod_consensus_commits,
     quod_consensus_submitted,
     quod_consensus_pending,
     quod_consensus_append_busy,
     quod_consensus_ingress_queued,
     quod_consensus_ingress_overflow,
     quod_consensus_ingress_expired,
     quod_consensus_ingress_forwarded,
     quod_consensus_custody_depth,
     quod_consensus_custody_ready,
     quod_consensus_custody_bytes,
     quod_dtx_admission_waiting,
     quod_dtx_admission_dormant,
     quod_consensus_ingress_retargets,
     quod_consensus_relay_accepted,
     quod_consensus_relay_duplicates,
     quod_consensus_append_redirect,
     quod_consensus_append_bad,
     quod_consensus_append_stale,
     quod_consensus_membership_rejects,
     quod_consensus_redrives,
     quod_consensus_progress_slot,
     quod_consensus_progress_phase,
     quod_consensus_progress_timeouts,
     quod_consensus_head_support_votes,
     quod_consensus_head_commit_votes,
     quod_consensus_head_complaint_votes,
     quod_consensus_head_complaint_signed,
     quod_consensus_missing_certified_blocks,
     quod_consensus_is_validator,
     quod_consensus_syncing,
     quod_consensus_ahead_gap].

-ifdef(TEST).
test_remove_stale_consensus_metrics(Namespaces) ->
    remove_stale_consensus_metrics(Namespaces).
-endif.

%% Ask every live connection process for its QUIC transport stats and surface them
%% per peer. The conn processes register on the `{connections, local}` property; a
%% bounded selective receive per conn keeps a wedged connection from stalling the
%% refresh. Stats RTTs arrive in MICROseconds (the lib's public contract) — convert.
refresh_transport() ->
    Pids = try gproc:lookup_pids(quod_reg:prop({connections, local}))
           catch _:_ -> []
           end,
    lists:foreach(
      fun(Pid) ->
              Ref = make_ref(),
              Pid ! {transport_stats, self(), Ref},
              receive
                  {Ref, {Peer, {ok, Stats}}} when is_binary(Peer) ->
                      set_transport_gauges(author_label(Peer), Stats);
                  {Ref, _} ->
                      ok   %% peer not yet learned, or stats unavailable
              after 50 -> ok
              end
      end, Pids).

set_transport_gauges(Peer, Stats) ->
    Num = fun(Name, Key, Scale) ->
                  case maps:get(Key, Stats, undefined) of
                      V when is_number(V) ->
                          prometheus_gauge:set(Name, [Peer], V / Scale);
                      _ -> ok
                  end
          end,
    Bool = fun(Name, Key) ->
                   case maps:get(Key, Stats, undefined) of
                       true  -> prometheus_gauge:set(Name, [Peer], 1);
                       false -> prometheus_gauge:set(Name, [Peer], 0);
                       _     -> ok
                   end
           end,
    _ = Num(quod_quic_srtt_ms, srtt, 1000),            %% us -> ms
    _ = Num(quod_quic_min_rtt_ms, min_rtt, 1000),      %% us -> ms
    _ = Num(quod_quic_cwnd_bytes, cwnd, 1),
    _ = Num(quod_quic_bytes_in_flight, bytes_in_flight, 1),
    _ = Num(quod_quic_send_queue_bytes, send_queue_bytes, 1),
    _ = Bool(quod_quic_congested, congested),
    _ = Bool(quod_quic_in_recovery, in_recovery),
    ok.

refresh_prolog_ns(Ns) ->
    case quod_prolog:stats(Ns) of
        #{applied := A, applies := AP, rejects := RJ, proves := PR, conflicts := CF,
          parked := PK, park_timeouts := PT, proof_workers := PW, scope_workers := SW,
          kb_memory_words := MW, kb_history_predicates := HP} ->
            S = fun(Name, V) -> prometheus_gauge:set(Name, [label(Ns)], V) end,
            _ = S(quod_prolog_applied,       A),
            _ = S(quod_prolog_applies,       AP),
            _ = S(quod_prolog_rejects,       RJ),
            _ = S(quod_prolog_proves,        PR),
            _ = S(quod_prolog_conflicts,     CF),
            _ = S(quod_prolog_parked,        PK),
            _ = S(quod_prolog_park_timeouts, PT),
            _ = S(quod_prolog_proof_workers, PW),
            _ = S(quod_prolog_scope_workers, SW),
            _ = S(quod_prolog_kb_memory_words, MW),
            _ = S(quod_prolog_kb_history_predicates, HP),
            ok;
        _ -> ok
    end.

refresh_feed_ns(Ns) ->
    case quod_feed:stats(Ns) of
        #{pushed := PU, ingested := IN, pulled := PL, dropped := DR,
          digests := DG, fresh_digests := FR, recipients := RC} ->
            S = fun(Name, V) -> prometheus_gauge:set(Name, [label(Ns)], V) end,
            _ = S(quod_feed_pushed,   PU),
            _ = S(quod_feed_ingested, IN),
            _ = S(quod_feed_pulled,   PL),
            _ = S(quod_feed_digests,       DG),
            _ = S(quod_feed_fresh_digests, FR),
            _ = S(quod_feed_recipients, RC),
            _ = maps:foreach(fun(Reason, C) ->
                                 prometheus_gauge:set(quod_feed_dropped, [label(Ns), atom_to_binary(Reason, utf8)], C)
                             end, DR),
            ok;
        _ -> ok
    end.

%% --- live commit event ---------------------------------------------------

%% Subscribe once per namespace to the shared `{committed, Ns}` property.  The
%% full-entry clause above observes each live finalized transaction; height-only
%% certified-head wakes deliberately fall through.  The subscription lives on
%% this process, so it survives a quod_simplex restart.
subscribe_commits(State = #{subs := Subs}) ->
    Subs1 = lists:foldl(fun(Ns, Acc) ->
                            case maps:is_key(Ns, Acc) of
                                true  -> Acc;
                                false -> _ = quod_reg:subscribe({committed, Ns}), Acc#{Ns => true}
                            end
                        end, Subs, quod_simplex:namespaces()),
    State#{subs => Subs1}.

%% A live-committed entry: observe content per transaction and DTX controls per
%% phase. Protocol carriers never reach this seam. Commit latency is not observed here: the block timestamp is the
%% proposer's wall clock (ratcheted to the fleet maximum) and `submitted_at` is the author's, so their
%% difference measures clock skew as much as processing time. Latency is observed at the SUBMITTING
%% node instead (`observe_tx_latency/2`, called by quod_prolog when the parked write resolves).
observe_commit(Ns, Entry) ->
    #entry{data = Data} = quod_ledger:entry_view(Entry),
    case quod_ledger:classify(Data) of
        {content, Transactions} ->
            lists:foreach(fun(T) -> observe_transaction(Ns, T) end,
                          Transactions);
        {controls, Controls} ->
            lists:foreach(
              fun({Phase, _Control}) -> observe_dtx(Ns, Phase) end,
              Controls);
        invalid -> ok
    end.

-ifdef(TEST).
test_observe_commit(Ns, Entry) -> observe_commit(Ns, Entry).
-endif.

observe_transaction(Ns, #transaction{author = Author, diff = Diff}) ->
    L = label(Ns),
    _ = prometheus_histogram:observe(quod_tx_diff_ops, [L], length(Diff)),
    _ = prometheus_counter:inc(quod_tx_committed_total, [L, author_label(Author)]),
    ok.

observe_dtx(Ns, Phase) ->
    _ = prometheus_counter:inc(
          quod_dtx_committed_total,
          [label(Ns), atom_to_binary(Phase, utf8)]),
    ok.

-doc "Observe one local or subscribed reaction candidate without making metrics a runtime dependency.".
-spec observe_runtime_reaction(binary(),
                               executed | unmatched |
                               {failed, term()},
                               non_neg_integer()) -> ok.
observe_runtime_reaction(Ns, Result, ElapsedUs)
  when is_binary(Ns), is_integer(ElapsedUs), ElapsedUs >= 0 ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            Label =
                case Result of
                    executed -> <<"executed">>;
                    unmatched -> <<"unmatched">>;
                    {failed, _} -> <<"failed">>
                end,
            try
                _ = prometheus_histogram:observe(
                      quod_runtime_reaction_seconds,
                      [label(Ns), Label],
                      erlang:convert_time_unit(
                        ElapsedUs, microsecond, native)),
                ok
            catch _:_ -> ok
            end
    end.

-doc "Observe one fixed stage of a signed one-target foreign operation.".
-spec observe_remote_operation_stage(
        binary(), atom(), atom(), non_neg_integer()) -> ok.
observe_remote_operation_stage(Ns, Stage, Result, DurationNative)
  when is_binary(Ns), is_integer(DurationNative), DurationNative >= 0 ->
    case {remote_operation_stage(Stage), remote_operation_result(Result),
          whereis(?MODULE)} of
        {{ok, StageLabel}, {ok, ResultLabel}, Pid} when is_pid(Pid) ->
            try
                _ = prometheus_histogram:observe(
                      quod_remote_operation_stage_seconds,
                      [label(Ns), StageLabel, ResultLabel], DurationNative),
                ok
            catch _:_ -> ok
            end;
        _ -> ok
    end;
observe_remote_operation_stage(_Ns, _Stage, _Result, _DurationNative) ->
    ok.

remote_operation_stage(gateway_verification) ->
    {ok, <<"gateway_verification">>};
remote_operation_stage(identity_certificate) ->
    {ok, <<"identity_certificate">>};
remote_operation_stage(proof_seal) -> {ok, <<"proof_seal">>};
remote_operation_stage(read_certification) ->
    {ok, <<"read_certification">>};
remote_operation_stage(source_claim) -> {ok, <<"source_claim">>};
remote_operation_stage(claim_verification) ->
    {ok, <<"claim_verification">>};
remote_operation_stage(target_application) ->
    {ok, <<"target_application">>};
remote_operation_stage(response_flush) -> {ok, <<"response_flush">>};
remote_operation_stage(completion) -> {ok, <<"completion">>};
remote_operation_stage(_) -> error.

remote_operation_result(ok) -> {ok, <<"ok">>};
remote_operation_result(rejected) -> {ok, <<"rejected">>};
remote_operation_result(uncertain) -> {ok, <<"uncertain">>};
remote_operation_result(failed) -> {ok, <<"failed">>};
remote_operation_result(_) -> error.

-doc "Observe one fixed stage of a durable multi-ontology transaction.".
-spec observe_dtx_group_stage(
        binary(), atom(), atom(), non_neg_integer()) -> ok.
observe_dtx_group_stage(Ns, Stage, Result, DurationNative)
  when is_binary(Ns), is_integer(DurationNative), DurationNative >= 0 ->
    case {dtx_group_stage(Stage), remote_operation_result(Result),
          whereis(?MODULE)} of
        {{ok, StageLabel}, {ok, ResultLabel}, Pid} when is_pid(Pid) ->
            try
                _ = prometheus_histogram:observe(
                      quod_dtx_group_stage_seconds,
                      [label(Ns), StageLabel, ResultLabel], DurationNative),
                ok
            catch _:_ -> ok
            end;
        _ -> ok
    end;
observe_dtx_group_stage(_Ns, _Stage, _Result, _DurationNative) ->
    ok.

dtx_group_stage(proof_seal) -> {ok, <<"proof_seal">>};
dtx_group_stage(admission) -> {ok, <<"admission">>};
dtx_group_stage(coordinator_total) -> {ok, <<"coordinator_total">>};
dtx_group_stage(vote_wave) -> {ok, <<"vote_wave">>};
dtx_group_stage(resolve_wave) -> {ok, <<"resolve_wave">>};
dtx_group_stage(applied_wave) -> {ok, <<"applied_wave">>};
dtx_group_stage(complete) -> {ok, <<"complete">>};
dtx_group_stage(endpoint_wait) -> {ok, <<"endpoint_wait">>};
dtx_group_stage(phase_verification) -> {ok, <<"phase_verification">>};
dtx_group_stage(coordinator_mailbox) -> {ok, <<"coordinator_mailbox">>};
dtx_group_stage(result_handoff) -> {ok, <<"result_handoff">>};
dtx_group_stage(end_to_end) -> {ok, <<"end_to_end">>};
dtx_group_stage(_) -> error.

-doc "Observe one fixed node-wide certified foreign-history stage.".
-spec observe_foreign_history_stage(atom(), atom(), non_neg_integer()) -> ok.
observe_foreign_history_stage(Stage, Result, DurationNative)
  when is_integer(DurationNative), DurationNative >= 0 ->
    case {foreign_history_stage(Stage), remote_operation_result(Result),
          whereis(?MODULE)} of
        {{ok, StageLabel}, {ok, ResultLabel}, Pid} when is_pid(Pid) ->
            try
                _ = prometheus_histogram:observe(
                      quod_foreign_history_stage_seconds,
                      [StageLabel, ResultLabel], DurationNative),
                ok
            catch _:_ -> ok
            end;
        _ -> ok
    end;
observe_foreign_history_stage(_Stage, _Result, _DurationNative) ->
    ok.

foreign_history_stage(queue_wait) -> {ok, <<"queue_wait">>};
foreign_history_stage(request_exact) -> {ok, <<"request_exact">>};
foreign_history_stage(request_current) -> {ok, <<"request_current">>};
foreign_history_stage(request_follow) -> {ok, <<"request_follow">>};
foreign_history_stage(current_total) -> {ok, <<"current_total">>};
foreign_history_stage(current_setup) -> {ok, <<"current_setup">>};
foreign_history_stage(owner_mailbox) -> {ok, <<"owner_mailbox">>};
foreign_history_stage(owner_admission) -> {ok, <<"owner_admission">>};
foreign_history_stage(resident_current_hit) ->
    {ok, <<"resident_current_hit">>};
foreign_history_stage(resident_current_miss) ->
    {ok, <<"resident_current_miss">>};
foreign_history_stage(cache_open) -> {ok, <<"cache_open">>};
foreign_history_stage(cache_replay) -> {ok, <<"cache_replay">>};
foreign_history_stage(ledger_resume) -> {ok, <<"ledger_resume">>};
foreign_history_stage(ledger_open) -> {ok, <<"ledger_open">>};
foreign_history_stage(ledger_suspend) -> {ok, <<"ledger_suspend">>};
foreign_history_stage(checkpoint_read) -> {ok, <<"checkpoint_read">>};
foreign_history_stage(projection_validate) ->
    {ok, <<"projection_validate">>};
foreign_history_stage(phase_resume) -> {ok, <<"phase_resume">>};
foreign_history_stage(phase_open) -> {ok, <<"phase_open">>};
foreign_history_stage(phase_suspend) -> {ok, <<"phase_suspend">>};
foreign_history_stage(page_fetch) -> {ok, <<"page_fetch">>};
foreign_history_stage(page_verify) -> {ok, <<"page_verify">>};
foreign_history_stage(ledger_append) -> {ok, <<"ledger_append">>};
foreign_history_stage(ledger_sync) -> {ok, <<"ledger_sync">>};
foreign_history_stage(phase_commit) -> {ok, <<"phase_commit">>};
foreign_history_stage(checkpoint_write) -> {ok, <<"checkpoint_write">>};
foreign_history_stage(cache_accounting) -> {ok, <<"cache_accounting">>};
foreign_history_stage(result_install) -> {ok, <<"result_install">>};
foreign_history_stage(caller_wake) -> {ok, <<"caller_wake">>};
foreign_history_stage(serve_read_total) -> {ok, <<"serve_read_total">>};
foreign_history_stage(serve_snapshot_lookup) ->
    {ok, <<"serve_snapshot_lookup">>};
foreign_history_stage(serve_snapshot_resume) ->
    {ok, <<"serve_snapshot_resume">>};
foreign_history_stage(serve_range_read) ->
    {ok, <<"serve_range_read">>};
foreign_history_stage(_) -> error.

-doc "Observe one exact route demand completed by the ordinary directory availability edge.".
-spec observe_directory_rebuild(ok, non_neg_integer()) -> ok.
observe_directory_rebuild(Result, DurationNative)
  when is_integer(DurationNative), DurationNative >= 0 ->
    case {directory_rebuild_result(Result), whereis(?MODULE)} of
        {{ok, ResultLabel}, Pid} when is_pid(Pid) ->
            try
                %% prometheus duration histograms accept native time; the
                %% `_seconds` suffix converts bounds and exported sums.
                _ = prometheus_histogram:observe(
                      quod_directory_rebuild_seconds,
                      [ResultLabel], DurationNative),
                ok
            catch _:_ -> ok
            end;
        _ -> ok
    end;
observe_directory_rebuild(_Result, _DurationNative) ->
    ok.

directory_rebuild_result(ok) -> {ok, <<"ok">>};
directory_rebuild_result(_) -> error.

-doc "Record one row explicitly retired by a live hosted-ontology owner.".
-spec observe_ontology_owner_terminal(binary(), atom(), atom(), atom(),
                                      non_neg_integer()) -> ok.
observe_ontology_owner_terminal(Ns, Component, Phase, Result, DurationMs)
  when is_binary(Ns), is_integer(DurationMs), DurationMs >= 0 ->
    case {ontology_owner_component(Component), owner_phase(Phase),
          owner_result(Result), whereis(?MODULE)} of
        {{ok, ComponentLabel}, {ok, PhaseLabel}, {ok, ResultLabel}, Pid}
          when is_pid(Pid) ->
            try
                Labels = [label(Ns), ComponentLabel, PhaseLabel, ResultLabel],
                _ = prometheus_histogram:observe(
                      quod_ontology_owner_duration_seconds, Labels,
                      erlang:convert_time_unit(
                        DurationMs, millisecond, native)),
                _ = prometheus_counter:inc(
                      quod_ontology_owner_terminal_total, Labels),
                ok
            catch _:_ -> ok
            end;
        _ ->
            ok
    end;
observe_ontology_owner_terminal(_Ns, _Component, _Phase, _Result,
                                _DurationMs) ->
    ok.

-doc "Record one row explicitly retired by a live node-wide owner.".
-spec observe_node_owner_terminal(atom(), atom(), atom(), non_neg_integer()) -> ok.
observe_node_owner_terminal(Component, Phase, Result, DurationMs)
  when is_integer(DurationMs), DurationMs >= 0 ->
    case {node_owner_component(Component), owner_phase(Phase),
          owner_result(Result), whereis(?MODULE)} of
        {{ok, ComponentLabel}, {ok, PhaseLabel}, {ok, ResultLabel}, Pid}
          when is_pid(Pid) ->
            try
                Labels = [ComponentLabel, PhaseLabel, ResultLabel],
                _ = prometheus_histogram:observe(
                      quod_node_owner_duration_seconds, Labels,
                      erlang:convert_time_unit(
                        DurationMs, millisecond, native)),
                _ = prometheus_counter:inc(
                      quod_node_owner_terminal_total, Labels),
                ok
            catch _:_ -> ok
            end;
        _ ->
            ok
    end;
observe_node_owner_terminal(_Component, _Phase, _Result, _DurationMs) ->
    ok.

-doc "Count one client-visible uncertain write result at its exact producing boundary.".
-spec count_client_outcome_unknown(
        target_execute | target_cursor |
        gateway_execute_transport | gateway_cursor_transport) -> ok.
count_client_outcome_unknown(Producer) ->
    case {client_outcome_unknown_producer(Producer), whereis(?MODULE)} of
        {{ok, ProducerLabel}, Pid} when is_pid(Pid) ->
            try
                _ = prometheus_counter:inc(
                      quod_client_outcome_unknown_total, [ProducerLabel]),
                ok
            catch _:_ -> ok
            end;
        _ ->
            ok
    end.

-doc """
One frame discarded at the QUIC send gate (`m:quod_link` ignores backpressure by design;
this makes the ignored return VISIBLE). The transport channel is reduced to the fixed
`log`, `ingress`, or `other` label set: only an exact deterministic `{log, Namespace}`
or `{ingress, Namespace}` identity receives its named label. Called from bare link
processes on the send path, so — like every observe helper here — an absent metrics
process makes it a no-op.
""".
-spec count_link_send_drop(binary() | term(), binary() | term(), term()) -> ok.
count_link_send_drop(Peer, Channel, Reason) ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            try
                _ = prometheus_counter:inc(
                      quod_link_send_drops_total,
                      [author_label(Peer), link_channel_label(Channel),
                       drop_reason(Reason)]),
                ok
            catch _:_ -> ok
            end
    end.

%% Channels are opaque bytes at the transport boundary. Decode with `safe` so a
%% peer-supplied identity can never intern atoms, then require byte-for-byte equality
%% with quod's deterministic encoding. Labels themselves are fixed literals; unrelated,
%% malformed, and non-canonical channels all share one bounded `other` value.
link_channel_label(Channel) when is_binary(Channel) ->
    try binary_to_term(Channel, [safe]) of
        {log, Ns} when is_binary(Ns) ->
            exact_channel_label(Channel, {log, Ns}, <<"log">>);
        {ingress, Ns} when is_binary(Ns) ->
            exact_channel_label(Channel, {ingress, Ns}, <<"ingress">>);
        _ ->
            <<"other">>
    catch _:_ ->
        <<"other">>
    end;
link_channel_label(_) ->
    <<"other">>.

exact_channel_label(Channel, Identity, Label) ->
    case term_to_binary(Identity, [deterministic]) of
        Channel -> Label;
        _       -> <<"other">>
    end.

drop_reason({flow_control_blocked, connection})  -> <<"flow_control_conn">>;
drop_reason({flow_control_blocked, {stream, _}}) -> <<"flow_control_stream">>;
drop_reason(send_queue_full)                     -> <<"queue_full">>;
drop_reason(_)                                   -> <<"other">>.

-doc """
One consensus-round phase sample for a block THIS node proposed, `Ms` on this node's
monotonic clock: `approve` = proposal broadcast → support quorum held; `commit` =
approval → final and durable here. Called from the consensus statem's hot path, so an
absent metrics process makes it a no-op (same contract as every observe helper here).
""".
-spec observe_round_phase(binary(), approve | commit, integer()) -> ok.
observe_round_phase(Ns, Phase, Ms)
  when is_binary(Ns), (Phase =:= approve orelse Phase =:= commit),
       is_integer(Ms), Ms >= 0 ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            try
                Name = case Phase of
                           approve -> quod_consensus_round_approve_ms;
                           commit  -> quod_consensus_round_commit_ms
                       end,
                _ = prometheus_histogram:observe(Name, [label(Ns)], Ms),
                ok
            catch _:_ -> ok
            end
    end;
observe_round_phase(_Ns, _Phase, _Ms) ->
    ok.

-doc """
One consensus statem event handled: wall `Us` (microseconds) and the mailbox depth found
at entry, by event class. The consensus state machine calls this only when
`detailed_consensus_metrics` is enabled; an absent metrics process makes it a no-op.
""".
-spec observe_consensus_event(binary(), atom(), integer(), non_neg_integer()) -> ok.
observe_consensus_event(Ns, Class, Us, QLen)
  when is_binary(Ns), is_atom(Class), is_integer(Us), Us >= 0, is_integer(QLen) ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            try
                L = [label(Ns), atom_to_binary(Class, utf8)],
                _ = prometheus_histogram:observe(quod_consensus_event_ms, L, Us / 1000),
                _ = prometheus_histogram:observe(quod_consensus_event_qlen, L, QLen),
                ok
            catch _:_ -> ok
            end
    end;
observe_consensus_event(_Ns, _Class, _Us, _QLen) ->
    ok.

-doc "One named sub-step inside a consensus handler took `Us` microseconds (guarded no-op without a metrics process).".
-spec observe_consensus_step(binary(), atom(), integer()) -> ok.
observe_consensus_step(Ns, Step, Us)
  when is_binary(Ns), is_atom(Step), is_integer(Us), Us >= 0 ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            try
                _ = prometheus_histogram:observe(
                      quod_consensus_step_ms,
                      [label(Ns), atom_to_binary(Step, utf8)], Us / 1000),
                ok
            catch _:_ -> ok
            end
    end;
observe_consensus_step(_Ns, _Step, _Us) ->
    ok.

-doc "A peer's vote share arrived for a slot this node proposed, `Ms` after the proposal broadcast (one clock).".
-spec observe_share_lag(binary(), atom(), integer()) -> ok.
observe_share_lag(Ns, Kind, Ms)
  when is_binary(Ns), is_atom(Kind), is_integer(Ms), Ms >= 0 ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            try
                _ = prometheus_histogram:observe(
                      quod_consensus_share_lag_ms,
                      [label(Ns), atom_to_binary(Kind, utf8)], Ms),
                ok
            catch _:_ -> ok
            end
    end;
observe_share_lag(_Ns, _Kind, _Ms) ->
    ok.

-doc """
One end-to-end latency sample: a write submitted on THIS node resolved as committed and applied,
`Ms` measured by the caller on one monotonic clock. The submitting node is the only place that
latency is real — any cross-node timestamp difference embeds wall-clock skew. Like every observe
helper here, metrics must never become a dependency of the observed path (write resolution), so
an absent/mid-restart metrics process makes this a no-op.
""".
-spec observe_tx_latency(binary(), integer()) -> ok.
observe_tx_latency(Ns, Ms) when is_binary(Ns), is_integer(Ms), Ms >= 0 ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            try
                _ = prometheus_histogram:observe(quod_tx_commit_latency_ms, [label(Ns)], Ms),
                ok
            catch _:_ -> ok
            end
    end;
observe_tx_latency(_Ns, _Ms) ->
    ok.

-doc """
Record one proposed block's transaction count and collection wait. This is called
once per local proposal, not once per consensus message, so it remains cheap enough
to keep enabled during performance runs.
""".
-spec observe_batch(binary(), pos_integer(), non_neg_integer()) -> ok.
observe_batch(Ns, Size, WaitMs)
  when is_binary(Ns), is_integer(Size), Size > 0,
       is_integer(WaitMs), WaitMs >= 0 ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            try
                _ = prometheus_histogram:observe(
                      quod_consensus_batch_size, [label(Ns)], Size),
                _ = prometheus_histogram:observe(
                      quod_consensus_batch_wait_ms, [label(Ns)], WaitMs),
                ok
            catch _:_ -> ok
            end
    end;
observe_batch(_Ns, _Size, _WaitMs) ->
    ok.

-doc """
Record how many internal retargets an origin-owned submission needed before it
resolved. Zero is a first-placement completion. Observability is never a
dependency of caller resolution, including while the metrics process is absent
or restarting.
""".
-spec observe_ingress_retarget_hops(binary(), non_neg_integer()) -> ok.
observe_ingress_retarget_hops(Ns, Hops)
  when is_binary(Ns), is_integer(Hops), Hops >= 0 ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            try
                _ = prometheus_histogram:observe(
                      quod_consensus_ingress_retarget_hops,
                      [label(Ns)], Hops),
                ok
            catch _:_ -> ok
            end
    end;
observe_ingress_retarget_hops(_Ns, _Hops) ->
    ok.

-doc "Count one locally authoritative re-proof response returned to a caller.".
-spec count_tx_retry(binary(), stale_sequence) -> ok.
count_tx_retry(Ns, Reason)
  when is_binary(Ns), Reason =:= stale_sequence ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            try
                _ = prometheus_counter:inc(
                      quod_tx_retries_total,
                      [label(Ns), atom_to_binary(Reason, utf8)]),
                ok
            catch _:_ -> ok
            end
    end;
count_tx_retry(_Ns, _Reason) ->
    ok.

-doc "Count one DTX validation attempt that reached final abstention.".
-spec count_dtx_validation(binary(), abstain) -> ok.
count_dtx_validation(Ns, abstain)
  when is_binary(Ns) ->
    count_fixed_event(
      quod_dtx_validation_events_total, Ns, abstain, 1);
count_dtx_validation(_Ns, _Event) ->
    ok.

-doc "Count bounded DTX target-delivery attempts and correlated outcomes.".
-spec count_dtx_submit_fanout(
        binary(), attempted | accepted | refused | uncertain | unavailable,
        non_neg_integer()) -> ok.
count_dtx_submit_fanout(Ns, Result, Count)
  when is_binary(Ns), is_integer(Count), Count >= 0,
       (Result =:= attempted orelse Result =:= accepted orelse
        Result =:= refused orelse Result =:= uncertain orelse
        Result =:= unavailable) ->
    count_fixed_event(quod_dtx_submit_fanout_total, Ns, Result, Count);
count_dtx_submit_fanout(_Ns, _Result, _Count) ->
    ok.

-doc "Record one sealed distributed write's wait for durable source reservation.".
-spec observe_dtx_admission_wait(binary(), non_neg_integer()) -> ok.
observe_dtx_admission_wait(Ns, WaitMs)
  when is_binary(Ns), is_integer(WaitMs), WaitMs >= 0 ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            try
                _ = prometheus_histogram:observe(
                      quod_dtx_admission_wait_ms, [label(Ns)], WaitMs),
                ok
            catch _:_ -> ok
            end
    end;
observe_dtx_admission_wait(_Ns, _WaitMs) ->
    ok.

count_fixed_event(_Name, _Ns, _Event, 0) ->
    ok;
count_fixed_event(Name, Ns, Event, Count) ->
    case whereis(?MODULE) of
        undefined ->
            ok;
        _Pid ->
            try
                _ = prometheus_counter:inc(
                      Name, [label(Ns), atom_to_binary(Event, utf8)], Count),
                ok
            catch _:_ -> ok
            end
    end.

set_ontology_owner_rows(Ns, Component, Current, Peak) ->
    case ontology_owner_component(Component) of
        {ok, ComponentLabel} ->
            maps:foreach(
              fun(State, Value) ->
                      case owner_state(Component, State) of
                          {ok, StateLabel} ->
                              prometheus_gauge:set(
                                quod_ontology_owner_current,
                                [label(Ns), ComponentLabel, StateLabel], Value);
                          error -> ok
                      end
              end, Current),
            maps:foreach(
              fun(State, Value) ->
                      case owner_state(Component, State) of
                          {ok, StateLabel} ->
                              prometheus_gauge:set(
                                quod_ontology_owner_peak,
                                [label(Ns), ComponentLabel, StateLabel], Value);
                          error -> ok
                      end
              end, Peak),
            ok;
        error -> ok
    end.

set_ontology_owner_bytes(Ns, Component, Current, Peak) ->
    case ontology_owner_component(Component) of
        {ok, ComponentLabel} ->
            _ = prometheus_gauge:set(
                  quod_ontology_owner_bytes_current,
                  [label(Ns), ComponentLabel], Current),
            case Peak of
                Value when is_number(Value) ->
                    prometheus_gauge:set(
                      quod_ontology_owner_bytes_peak,
                      [label(Ns), ComponentLabel], Value);
                undefined -> ok
            end;
        error -> ok
    end.

set_node_owner_rows(Component, Current, Peak) ->
    case node_owner_component(Component) of
        {ok, ComponentLabel} ->
            maps:foreach(
              fun(State, Value) ->
                      case owner_state(Component, State) of
                          {ok, StateLabel} ->
                              prometheus_gauge:set(
                                quod_node_owner_current,
                                [ComponentLabel, StateLabel], Value);
                          error -> ok
                      end
              end, Current),
            maps:foreach(
              fun(State, Value) ->
                      case owner_state(Component, State) of
                          {ok, StateLabel} ->
                              prometheus_gauge:set(
                                quod_node_owner_peak,
                                [ComponentLabel, StateLabel], Value);
                          error -> ok
                      end
              end, Peak),
            ok;
        error -> ok
    end.

set_node_owner_bytes(Component, Current) ->
    case node_owner_component(Component) of
        {ok, ComponentLabel} ->
            prometheus_gauge:set(
              quod_node_owner_bytes_current, [ComponentLabel], Current);
        error -> ok
    end.

%% --- labels --------------------------------------------------------------

%% This node's stable identity for the constant `node_id` label. `node_pubkey` is set by
%% quod_app:apply_identity before the supervisor (hence this process) starts;
%% the `local` fallback covers configuration-free tests.
local_node_id() ->
    case application:get_env(quod, node_pubkey) of
        {ok, Pub} when is_binary(Pub) -> quod_identity:short(Pub);
        _                             -> <<"local">>
    end.

author_label(A) when is_binary(A) -> quod_identity:short(A);
author_label(A)                   -> iolist_to_binary(io_lib:format("~0p", [A])).

%% A prometheus label value must be printable UTF-8. A well-formed namespace passes through unchanged; a
%% pathological one is base64'd so it can never produce a malformed /metrics exposition line.
label(Ns) when is_binary(Ns) ->
    case unicode:characters_to_binary(Ns) of
        B when is_binary(B) -> B;
        _                   -> base64:encode(Ns)
    end.

%% Every value below is a closed vocabulary.  Never derive these labels from
%% requests, identities, target namespaces or failure terms.
ontology_owner_component(dtx_control) -> {ok, <<"dtx_control">>};
ontology_owner_component(dtx_endpoint) -> {ok, <<"dtx_endpoint">>};
ontology_owner_component(catchup_read) -> {ok, <<"catchup_read">>};
ontology_owner_component(_) -> error.

node_owner_component(foreign_history) -> {ok, <<"foreign_history">>};
node_owner_component(client_goal_router) -> {ok, <<"client_goal_router">>};
node_owner_component(scope_router) -> {ok, <<"scope_router">>};
node_owner_component(_) -> error.

client_outcome_unknown_producer(target_execute) ->
    {ok, <<"target_execute">>};
client_outcome_unknown_producer(target_cursor) ->
    {ok, <<"target_cursor">>};
client_outcome_unknown_producer(gateway_execute_transport) ->
    {ok, <<"gateway_execute_transport">>};
client_outcome_unknown_producer(gateway_cursor_transport) ->
    {ok, <<"gateway_cursor_transport">>};
client_outcome_unknown_producer(_) -> error.

owner_phase(vote) -> {ok, <<"vote">>};
owner_phase(resolve) -> {ok, <<"resolve">>};
owner_phase(complete) -> {ok, <<"complete">>};
owner_phase(outbound) -> {ok, <<"outbound">>};
owner_phase(inbound) -> {ok, <<"inbound">>};
owner_phase(client) -> {ok, <<"client">>};
owner_phase(server) -> {ok, <<"server">>};
owner_phase(scope) -> {ok, <<"scope">>};
owner_phase(identity) -> {ok, <<"identity">>};
owner_phase(probe) -> {ok, <<"probe">>};
owner_phase(route) -> {ok, <<"route">>};
owner_phase(_) -> error.

owner_result(completed) -> {ok, <<"completed">>};
owner_result(timeout) -> {ok, <<"timeout">>};
owner_result(caller_down) -> {ok, <<"caller_down">>};
owner_result(link_down) -> {ok, <<"link_down">>};
owner_result(worker_down) -> {ok, <<"worker_down">>};
owner_result(expired) -> {ok, <<"expired">>};
owner_result(rejected) -> {ok, <<"rejected">>};
owner_result(unavailable) -> {ok, <<"unavailable">>};
owner_result(not_found) -> {ok, <<"not_found">>};
owner_result(busy) -> {ok, <<"busy">>};
owner_result(error) -> {ok, <<"error">>};
owner_result(shutdown) -> {ok, <<"shutdown">>};
owner_result(_) -> error.

owner_state(dtx_control, retained) -> {ok, <<"retained">>};
owner_state(dtx_control, ready) -> {ok, <<"ready">>};
owner_state(dtx_control, blocked) -> {ok, <<"blocked">>};
owner_state(dtx_control, waiters) -> {ok, <<"waiters">>};
owner_state(dtx_endpoint, outbound) -> {ok, <<"outbound">>};
owner_state(dtx_endpoint, inbound) -> {ok, <<"inbound">>};
owner_state(catchup_read, client_pending) -> {ok, <<"client_pending">>};
owner_state(catchup_read, server_inflight) -> {ok, <<"server_inflight">>};
owner_state(foreign_history, verifying) -> {ok, <<"verifying">>};
owner_state(foreign_history, page_pulls) -> {ok, <<"page_pulls">>};
owner_state(foreign_history, cached_histories) -> {ok, <<"cached_histories">>};
owner_state(client_goal_router, outbound) -> {ok, <<"outbound">>};
owner_state(client_goal_router, inbound) -> {ok, <<"inbound">>};
owner_state(client_goal_router, cursor_routes) -> {ok, <<"cursor_routes">>};
owner_state(scope_router, scopes) -> {ok, <<"scopes">>};
owner_state(scope_router, owners) -> {ok, <<"owners">>};
owner_state(scope_router, retained_owners) -> {ok, <<"retained_owners">>};
owner_state(scope_router, openings) -> {ok, <<"openings">>};
owner_state(scope_router, identity_probes) -> {ok, <<"identity_probes">>};
owner_state(scope_router, identity_collections) ->
    {ok, <<"identity_collections">>};
owner_state(scope_router, identity_attestations) ->
    {ok, <<"identity_attestations">>};
owner_state(_, _) -> error.

-ifdef(TEST).
%% EXACTLY the keys refresh_log_ns/1's map pattern requires of quod_simplex:stats_map/1.
%% The lockstep eunit (quod_simplex_tests) asserts every one exists in stats_map — a key
%% added to the pattern without the stat would otherwise silently zero ALL consensus gauges.
consensus_stat_keys() ->
    [slot, committed, protocol_view, pipeline_gap, last_applied, committee_size,
     appends, proposals, batched_txs, batch_window_ms,
     commits, submitted, pending,
     r_busy, r_redirect, r_bad, r_stale, membership_rejects,
     ingress_queued, ingress_overflow, ingress_expired, ingress_forwarded,
     custody_depth, custody_ready, custody_bytes, ingress_retargets,
     dtx_admission_waiting, dtx_admission_dormant,
     owner_current, owner_peak, owner_bytes_current, owner_bytes_peak,
     relay_accepted, relay_duplicates,
     redrives, progress_slot, progress_phase_code,
     progress_timeouts, head_support_votes, head_commit_votes,
     head_complaint_votes, head_complaint_signed, missing_certified_blocks,
     is_validator, syncing, ahead_gap].
-endif.
