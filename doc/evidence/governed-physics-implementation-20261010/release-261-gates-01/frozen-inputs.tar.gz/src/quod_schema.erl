-module(quod_schema).
-moduledoc """
HOCON config **schema** for quod.

The config **file** (`config/quod.conf`, overridable by `$QUOD_CONF`) is the primary
source of configuration. OS environment variables prefixed `QUOD_` override individual
scalar keys, using `__` to descend the path — e.g. `QUOD_NODE__PORT=15000` overrides
`node.port` (the `content` LIST is not env-overridable; deploys render the file). Env
override is applied during `m:hocon_tconf` check (see `quod_app:load_config/0`).

String values are `binary()` (HOCON's native string), converted to lists in the boot
code where the rest of the system expects `{Host, Port}` / file paths.
""".

-include_lib("typerefl/include/types.hrl").

-behaviour(hocon_schema).
-export([namespace/0, roots/0, fields/1]).

namespace() -> quod.

%% Each root defaults to `#{}` so an absent block falls back to its field defaults
%% (a config with no `node {}` still yields node.ip/port defaults).
roots() ->
    [ {node,     hoconsc:mk(hoconsc:ref(?MODULE, node),     #{default => #{}})}
    , {metrics,  hoconsc:mk(hoconsc:ref(?MODULE, metrics),  #{default => #{}})}
    , {explorer, hoconsc:mk(hoconsc:ref(?MODULE, explorer), #{default => #{}})}
    , {client,   hoconsc:mk(hoconsc:ref(?MODULE, client),   #{default => #{}})}
    , {agent_vault, hoconsc:mk(hoconsc:ref(?MODULE, agent_vault), #{default => #{}})}
    , {identity, hoconsc:mk(hoconsc:ref(?MODULE, identity), #{default => #{}})}
    %% Kept as an empty schema solely so retired directory authority fields
    %% fail configuration validation instead of being silently ignored.
    , {directory, hoconsc:mk(hoconsc:ref(?MODULE, directory), #{default => #{}})}
      %% A LIST: a node may host several ontologies side by side (each entry founds or
      %% joins one namespace, with its own mode/genesis/anchor). One entry is the common case.
    , {content,  hoconsc:mk(hoconsc:array(hoconsc:ref(?MODULE, content)), #{default => [#{}]})}
    ].

fields(node) ->
    %% `port` is the ADVERTISED p2p endpoint (what peers dial + the link-header hint).
    %% `bind_port` is where QUIC actually LISTENS locally; 0 ⇒ same as `port`. They differ
    %% only under bridge networking + portmap, where the container binds a fixed internal
    %% port while advertising the dynamic HOST port Nomad mapped to it (see deploy/quod.nomad).
    [ {ip,        hoconsc:mk(binary(),  #{default => <<"127.0.0.1">>})}
    , {port,      hoconsc:mk(integer(), #{default => 14567})}
    , {bind_port, hoconsc:mk(integer(), #{default => 0})}
    %% QUIC liveness: a peer we haven't heard from for `idle_timeout_ms` is dropped, while
    %% `keepalive_ms` PINGs probe an otherwise-quiet-but-alive link. Detection ≈ the two summed
    %% (~2.5s at the defaults). Tuned for a trusted low-RTT LAN; raise both for a lossier/WAN
    %% path. Keep `keepalive_ms` well below `idle_timeout_ms` (else a healthy link false-closes).
    , {idle_timeout_ms, hoconsc:mk(integer(), #{default => 2000})}
    , {keepalive_ms,    hoconsc:mk(integer(), #{default => 500})}
      %% Local diagnostic policy applies to every hosted ontology, including
      %% dynamically-created and recovered ones absent from the content list.
    , {consensus_owner_tracing, hoconsc:mk(boolean(), #{default => false})}
      %% Local admission policy applies to dynamically hosted ontologies too.
      %% Runtime limits are per ontology; the peer limit is shared by the node.
      %% Zero hosted agents leaves the node executor and observations available.
    , {runtime_max_hosted_agents,
       hoconsc:mk(integer(), #{default => 1024,
                             validator => fun(N) -> N >= 0 andalso N =< 1024 end})}
    , {runtime_max_agent_observations,
       hoconsc:mk(integer(), #{default => 4096, validator => fun(N) -> N > 0 end})}
    , {runtime_max_agent_observation_bytes,
       hoconsc:mk(integer(), #{default => 1048576, validator => fun(N) -> N > 0 end})}
    , {peer_observation_limit,
       hoconsc:mk(integer(), #{default => 4096, validator => fun(N) -> N > 0 end})}
    ];
fields(metrics) ->
    [ {port, hoconsc:mk(integer(), #{default => 14568})}
    ];
fields(explorer) ->
    %% The optional standalone Explorer (`quod_explorer`). OFF by default: it is an
    %% unauthenticated read-only ledger viewer, so widening `ip` past loopback remains a
    %% deliberate operator choice. Its signed console is served only through the TLS client
    %% listener, where it uses the ordinary authenticated signed-goal API.
    [ {enabled, hoconsc:mk(boolean(), #{default => false})}
    , {ip,      hoconsc:mk(binary(),  #{default => <<"127.0.0.1">>})}
    , {port,    hoconsc:mk(integer(), #{default => 14569})}
    , {read_budget_ms,
       hoconsc:mk(integer(), #{default => 30000, validator => fun(N) -> N > 0 end})}
    ];
fields(client) ->
    %% Static bootstrap, fixed challenge-response authentication, and bounded
    %% signed-goal ingress. Predicate authorization remains exclusively in the
    %% target ontology's ordinary can_invoke/4 path.
    %%
    %% Always TLS: a browser withholds Web Crypto outside a secure context, so
    %% plaintext would leave the client unable to hold a key at all. Both PEM
    %% paths empty ⇒ the node's own self-signed browser cert (`quod_client_tls`).
    [ {enabled,  hoconsc:mk(boolean(), #{default => false})}
    , {ip,       hoconsc:mk(binary(),  #{default => <<"127.0.0.1">>})}
    , {port,     hoconsc:mk(integer(), #{default => 14570})}
    , {certfile, hoconsc:mk(binary(),  #{default => <<>>})}
    , {keyfile,  hoconsc:mk(binary(),  #{default => <<>>})}
    ];
fields(agent_vault) ->
    [ {enabled, hoconsc:mk(boolean(), #{default => false})}
    , {provider_enabled, hoconsc:mk(boolean(), #{default => false})}
    , {directory, hoconsc:mk(binary(), #{default => <<>>})}
    , {unlock_file, hoconsc:mk(binary(), #{default => <<>>})}
    , {ip, hoconsc:mk(binary(), #{default => <<"127.0.0.1">>})}
    , {port, hoconsc:mk(integer(), #{default => 14571})}
    , {certfile, hoconsc:mk(binary(), #{default => <<>>})}
    , {keyfile, hoconsc:mk(binary(), #{default => <<>>})}
    , {client_ca_file, hoconsc:mk(binary(), #{default => <<>>})}
    , {peer_keys, hoconsc:mk(hoconsc:array(binary()), #{default => []})}
    ];
fields(identity) ->
    %% The node's Ed25519 keypair (its `node_id` is the pubkey) is generated on first
    %% boot and persisted under `dir`. `dir = ""` ⇒ `<content.data_dir>/identity` (or the
    %% quod_simplex user_cache default), so identity shares the ledger's durability domain.
    [ {dir, hoconsc:mk(binary(), #{default => <<"">>})}
    ];
fields(directory) ->
    [];
fields(content) ->
    %% One ontology this node founds (create) or joins at boot — `content` is a LIST of
    %% these. `genesis_file` is read once by the founder at create; `data_dir = ""` ⇒
    %% quod_simplex's default. Ontologies may share one data_dir: the ledger store keeps
    %% each namespace in its own subdirectory (quod_ledger_store:ns_dir/2).
    [ {namespace,    hoconsc:mk(binary(), #{default => <<"quod:root">>})}
    , {mode,         hoconsc:mk(hoconsc:enum([create, join]), #{default => create})}
    , {role,         hoconsc:mk(hoconsc:enum([member, replica]), #{default => member})}
    , {genesis_file, hoconsc:mk(binary(), #{default => <<"ontologies/quod_root.pl">>})}
    , {data_dir,     hoconsc:mk(binary(), #{default => <<"">>})}
      %% Optional FAST-LOCAL home for the block ledger only. The chain is replicated by
      %% consensus (a node that loses its ledger re-syncs trustlessly from peers), so it
      %% does not need the durable volume; identity + signing journal REMAIN under data_dir.
      %% "" => the ledger shares data_dir (the previous behaviour).
    , {ledger_dir,   hoconsc:mk(binary(), #{default => <<"">>})}
    , {seeds,        hoconsc:mk(hoconsc:array(binary()), #{default => []})}
    , {max_proof_workers,
       hoconsc:mk(integer(), #{default => 64, validator => fun(N) -> N > 0 end})}
    , {max_scope_workers,
       hoconsc:mk(integer(), #{default => 64, validator => fun(N) -> N > 0 end})}
    , {proof_timeout_ms,
       hoconsc:mk(integer(), #{default => 60000, validator => fun(N) -> N > 0 end})}
    , {transaction_ttl_ms,
       hoconsc:mk(integer(), #{default => 30000, validator => fun(N) -> N > 0 end})}
      %% Time the proposer keeps a newly-opened block available for more ordinary
      %% transactions. 0 seals immediately; 25 ms is the measured fleet default.
    , {batch_window_ms,
       hoconsc:mk(integer(),
                  #{default => 25,
                    validator => fun(N) -> N >= 0 andalso N =< 1000 end})}
    , {scope_timeout_ms,
       hoconsc:mk(integer(), #{default => 60000, validator => fun(N) -> N > 0 end})}
    , {scope_step_timeout_ms,
       hoconsc:mk(integer(), #{default => 30000, validator => fun(N) -> N > 0 end})}
      %% Expensive per-event/per-substep Prometheus probes for short diagnostic runs.
      %% Disabled by default because they execute inside the serial consensus process.
    , {detailed_consensus_metrics, hoconsc:mk(boolean(), #{default => false})}
      %% `mode=join` REQUIRES this: the out-of-band trust anchor — the founder's genesis
      %% block hash as a 64-char hex string, copied from the founder's boot log (see
      %% `quod_app`). Empty for a `create` node. It is what makes catch-up trustless: a
      %% joiner verifies the whole downloaded history against this one pinned fingerprint.
    , {genesis_hash, hoconsc:mk(binary(), #{default => <<"">>})}
    ].
