-module(quod_transaction).
-moduledoc """
Canonical transaction identity and author signatures.

The signature format is a protocol contract with one fixed domain/schema tag,
bound to the target's `{Ns, GenesisAnchor, AuthorAdmission}` supplied by the
validating committee from its own state — never by the author. The anchor
is the slot-1 block hash and cryptographically covers the per-founding random
`consensus_incarnation` fact committed inside that block, so a transaction
signed under any earlier founding of the same namespace is unverifiable after
a re-found: exact mutation-version read tokens (unlike the old content hashes)
could validate by coincidence across a wipe, and this binding is what closes
that. Every committed field except `sig` is covered; no alternate tag is
accepted.
""".

-include("quod_ledger.hrl").
-include("quod_proof_limits.hrl").

-export([from_plan/5, remote_claim/5, remote_application/3,
         remote_application_material/3,
         remote_complete/4, attach_evidence/3, attach_receipt_evidence/2,
         remote_claim_references/1, validate_independent_claim/1,
         encode_foreign_reads/1, decode_foreign_reads/1,
         encode_evidence/2, decode_evidence/1, same_ledger_transaction/2,
         stable_ref/1,
         role/1, evidence/1, required_references/1,
         bind_id/2, valid_id/2,
         plan_outcome_ref/4, encode_durable_submission/2,
         bytes/2, sign/3, sign_submission/3, verify/2,
         submission/2, submission_id/1, verify_submission/1,
         encode_ledger_transaction/1, decode_ledger_transaction/2,
         decode_context/0, decode_ledger_transaction/3,
         encoded_ledger_transaction_size/1,
         decode_canonical_transaction/2,
         relay_attempt_id/5, decode_verified_submission/2,
         decode_submission_metadata/1, matches_selection/2,
         encode_operation_submission/1, decode_operation_submission/2,
         operation_submission_context/1,
         validate_request/4, request_claim/1, remote_claim_route/2,
         requires_network_identity/1]).

-export_type([target_binding/0, decode_context/0]).

-define(DOMAIN, quod_transaction).
-define(ID_DOMAIN, quod_semantic_transaction).
-define(ID_VERSION, 7).
%% V15 admits only certified receipt vectors and atomic Vote/Resolve/Complete.
%% Earlier versions are deliberately not decoded. Material and referenced
%% transactions remain canonical byte blobs, preserving the binding of an
%% author's continuous admission generation, transaction role,
%% role evidence, certified foreign reads, signed-agent request, authorization
%% transcript, and the atom-bearing diff/read set through the bounded Prolog wire alphabet,
%% including explicit event occurrences. The fixed envelope can therefore be
%% decoded safely before a small, explicit vocabulary allocation is permitted
%% for an authenticated committee author.
%% Unrelated committee changes do not invalidate retained custody, while
%% remove/re-admit makes every signature from the earlier admission
%% unverifiable. DTX controls use their own admission-scoped sequence lane, and
%% each committed control's certified reference binds the exact committee that
%% finalized its ledger position.
-define(VERSION, 15). %% one atomic Vote/Resolve/Complete format break
-define(RELAY_ATTEMPT_DOMAIN, quod_relay_attempt).
-define(RELAY_ATTEMPT_VERSION, 2).
-define(PUBKEY_BYTES, 32).
-define(SIGNATURE_BYTES, 64).
-define(SUBMISSION_ID_BYTES, 16).
-define(ERA_BYTES, 32).
-define(MAX_SLOT, 16#FFFFFFFFFFFFFFFF).
-define(OPERATION_CANCEL_DOMAIN, <<"quod.operation.cancel.v1">>).

-type target_binding() :: {binary(), binary(), binary()}.

%% Call-local derivation shared by every target in one claim. Only the private
%% constructor below can produce it; no runtime owner or retained trust cache.
-record(operation_identity, {claim_ref, binding, operation_ref, goal, result}).

%% Trusted native carrier, like a signing receipt: only this module constructs
%% it, and no wire grammar accepts it. It belongs to one bounded decode call,
%% never an owner, ETS table or request's freshness/finality decision.
-record(decoded_transactions, {completed = #{} :: map()}).
-opaque decode_context() :: #decoded_transactions{}.

-doc "Start one call-local record decoder; only this constructor and decoder returns may supply contexts.".
-spec decode_context() -> decode_context().
decode_context() -> #decoded_transactions{}.

-doc """
Build the unsigned semantic transaction carried by one sealed plan.

`Material` is the canonical result returned by `quod_dtx:material/1`, optionally
augmented with the already-certified `foreign_reads` list. This keeps the
origin's opaque-byte id and validators' decoded-term id identical while the
replaceable certificates remain outside that semantic id.
""".
-spec from_plan(quod_dtx:plan(), map(), binary(), binary(),
                none | quod_client_goal:request_auth()) -> #transaction{}.
from_plan(Plan, #{diff := Diff, read_check := ReadCheck,
                  effects := Effects} = Material,
          GoalBlob, ResultBlob, RequestAuth)
  when is_list(Diff), is_map(ReadCheck),
       is_binary(GoalBlob), is_binary(ResultBlob) ->
    Target = quod_dtx:target(Plan),
    {StoredAuth, AuthTranscript} =
        request_fields(Plan, Material, GoalBlob, RequestAuth),
    ForeignReads = foreign_reads_from_material(Material),
    Transaction =
        #transaction{tx_id = <<>>,
                     role = application,
                     evidence = none,
                     foreign_reads = ForeignReads,
                     origin = quod_dtx:origin(Plan),
                     proof_id = quod_dtx:proof_id(Plan),
                     plan_digest = quod_dtx:digest(Plan),
                     goal = GoalBlob,
                     result = ResultBlob,
                     diff = Diff,
                     read_check = ReadCheck,
                     effects = Effects,
                     request_auth = StoredAuth,
                     auth_transcript = AuthTranscript,
                     author = none,
                     sig = none},
    Transaction#transaction{
      tx_id = semantic_plan_id(
                Target, Plan, GoalBlob, ResultBlob,
                StoredAuth, AuthTranscript, application)}.

-doc "Build one metadata-only source claim for the exact sealed writer set.".
-spec remote_claim({binary(), <<_:256>>}, quod_dtx:manifest(), [tuple()],
                   quod_client_goal:request_auth(), [term()]) ->
          #transaction{}.
remote_claim({OriginNs, <<_:256>> = OriginAnchor} = Origin, Manifest,
             Bundles0,
             {agent_goal_v1, <<_:256>>, _Bytes, _Signature} = RequestAuth,
             ForeignReads0)
  when is_binary(OriginNs), is_list(Bundles0) ->
    ForeignReads = canonical_foreign_reads_or_error(ForeignReads0),
    Bundles = lists:sort(Bundles0),
    {ok, Plans} = claim_plans(Origin, Manifest, Bundles),
    [{Plan, #{goal := GoalBlob, result := ResultBlob}} | _] = Plans,
    {ok, RequestEvidence} =
        quod_client_goal:verify_durable_request(RequestAuth, GoalBlob),
    Claim0 =
        #transaction{tx_id = <<>>,
                     role = {remote_claim, Manifest, Bundles, []},
                     evidence = none,
                     foreign_reads = ForeignReads,
                     origin = Origin,
                     proof_id = quod_dtx:proof_id(Plan),
                     plan_digest = quod_dtx:manifest_digest(Manifest),
                     goal = GoalBlob,
                     result = ResultBlob,
                     diff = [], read_check = #{}, effects = [],
                     request_auth = RequestAuth,
                     auth_transcript = none,
                     author = none, sig = none,
                     claim_view = {Origin, Manifest, Bundles, Plans,
                                   RequestAuth, GoalBlob, RequestEvidence}},
    Identity = #operation_identity{
                  claim_ref = {transaction, OriginNs, OriginAnchor, ClaimId}} =
        operation_identity(Claim0),
    Predicted = predicted_applications(Identity, Plans),
    Claim0#transaction{
      tx_id = ClaimId,
      role = {remote_claim, Manifest, Bundles, Predicted}}.

-doc "Build the ordinary target application bound to one durable source claim.".
-spec remote_application(term(), #transaction{}, {binary(), <<_:256>>}) -> #transaction{}.
remote_application(
  ClaimRef, Claim, Target) ->
    {Application, _Plan, _Context, _Material} =
        remote_application_material(ClaimRef, Claim, Target),
    Application.

-doc "Build a target application and carry its authenticated plan, context and material.".
-spec remote_application_material(term(), #transaction{}, {binary(), <<_:256>>}) ->
          {#transaction{}, quod_dtx:plan(), map(), map()}.
remote_application_material(
  {transaction, OriginNs, <<_:256>> = OriginAnchor, <<_:256>>} = ClaimRef,
  #transaction{origin = {OriginNs, OriginAnchor} = Origin,
               role = {remote_claim, _Manifest, _Bundles, _Predicted},
               foreign_reads = ForeignReads,
               goal = GoalBlob,
               result = ResultBlob} = Claim,
  Target)
  when is_binary(OriginNs),
       is_binary(GoalBlob), is_binary(ResultBlob) ->
    %% Only the selected target materializes vocabulary. Other authenticated
    %% claim plans remain opaque, including on the source cancellation path.
    {ok, {Plan, Context}} = claim_plan(Claim, Target),
    Identity = #operation_identity{claim_ref = ClaimRef} =
        operation_identity(Claim),
    {ApplicationId, OperationRef, RequestDigest} =
        application_identity(Identity, Target, Plan),
    true = declared_application_matches(Claim, Target, ApplicationId),
    {ok, Material} = quod_dtx:material(Plan),
    Application0 =
        #transaction{tx_id = <<>>,
                     role = {remote_application, ClaimRef,
                             OperationRef, RequestDigest},
                     evidence = none,
                     foreign_reads = ForeignReads,
                     origin = Origin,
                     proof_id = quod_dtx:proof_id(Plan),
                     plan_digest = quod_dtx:digest(Plan),
                     goal = GoalBlob, result = ResultBlob,
                     diff = maps:get(diff, Material),
                     read_check = maps:get(read_check, Material),
                     effects = maps:get(effects, Material),
                     request_auth = none, auth_transcript = none,
                     author = none, sig = none},
    {Application0#transaction{tx_id = ApplicationId}, Plan, Context, Material};
remote_application_material(_ClaimRef, _Claim, _Target) ->
    error(bad_remote_claim).

operation_identity(
    Claim = #transaction{origin = {Ns, Anchor}, goal = Goal, result = Result,
                         request_auth = RequestAuth}) ->
    ClaimId = semantic_id_or_error({Ns, Anchor}, Claim),
    true = Claim#transaction.tx_id =:= <<>> orelse Claim#transaction.tx_id =:= ClaimId,
    {agent_goal_v1, _Digest} = Binding = quod_client_goal:request_binding(RequestAuth),
    {ok, #{operation_ref := OperationRef}} = request_claim(Claim),
    #operation_identity{claim_ref = {transaction, Ns, Anchor, ClaimId},
                        binding = Binding, operation_ref = OperationRef,
                        goal = Goal, result = Result}.

application_identity(
    #operation_identity{claim_ref = ClaimRef,
                        binding = {agent_goal_v1, Digest} = Binding,
                        operation_ref = OperationRef, goal = Goal,
                        result = Result}, Target, Plan) ->
    %% The signed request is invariant across this vector; EACH target still
    %% has to bind its independently authenticated plan to that exact request.
    Binding = quod_dtx:request_binding(Plan),
    Role = {remote_application, ClaimRef, OperationRef, Digest},
    {semantic_plan_id(Target, Plan, Goal, Result, none, none, Role), OperationRef, Digest}.

declared_application_matches(#transaction{tx_id = <<>>}, _Target, _Id) ->
    %% Only the constructor's unsigned, unbound tentative value has no
    %% prediction vector yet; no canonical signed transaction permits this ID.
    true;
declared_application_matches(Claim, Target, Id) ->
    case remote_claim_references(Claim) of
        {ok, Refs} ->
            {Ns, Anchor} = Target,
            quod_operation_vector:lookup(Target, Refs) =:=
                {ok, {transaction, Ns, Anchor, Id}};
        error -> false
    end.

-doc "Build a canonical complete receipt of certified application outcomes.".
-spec remote_complete({binary(), <<_:256>>}, term(), binary(), term()) ->
          #transaction{}.
remote_complete({Ns, <<_:256>> = Anchor} = Origin, OperationRef,
                <<_:256>> = RequestDigest,
                Receipt0)
  when is_binary(Ns) ->
    {ok, Receipt} = quod_operation_vector:receipt(Receipt0),
    {ok, GoalBlob} = quod_durable_term:encode_goal(true),
    {ok, ResultBlob} = quod_durable_term:encode_result(#{}),
    Complete0 =
        #transaction{tx_id = <<>>,
                     role = {remote_complete, OperationRef,
                             RequestDigest, Receipt},
                     evidence = none,
                     foreign_reads = [],
                     origin = Origin, proof_id = RequestDigest,
                     plan_digest = RequestDigest,
                     goal = GoalBlob, result = ResultBlob,
                     diff = [], read_check = #{}, effects = [],
                     request_auth = none, auth_transcript = none,
                     author = none, sig = none},
    Complete0#transaction{tx_id = semantic_id_or_error(
                                    {Ns, Anchor}, Complete0)};
remote_complete(_Origin, _OperationRef, _RequestDigest, _TargetRef) ->
    error(bad_remote_completion).

-doc "Attach independently verified acceleration evidence without changing tx_id.".
-spec attach_evidence(#transaction{}, term(), #transaction{}) -> #transaction{}.
attach_evidence(
  Transaction = #transaction{role = {remote_application, ClaimRef, _, _},
                             evidence = none},
  CertifiedRef, Claim = #transaction{}) ->
    case stable_ref(CertifiedRef) =:= ClaimRef andalso
         certified_transaction_matches(CertifiedRef, Claim) of
        true -> Transaction#transaction{evidence = {CertifiedRef, Claim}};
        false -> error(bad_remote_evidence)
    end;
attach_evidence(_Transaction, _CertifiedRef, _Referenced) ->
    error(bad_remote_evidence).

-doc "Attach the exact complete certificate vector without changing semantic identity.".
-spec attach_receipt_evidence(#transaction{}, [{term(), #transaction{}}]) -> #transaction{}.
attach_receipt_evidence(
  Transaction = #transaction{role = {remote_complete, _, _, Receipt}, evidence = none},
  Pairs) when is_list(Pairs) ->
    Sorted = lists:sort(fun({A, _}, {B, _}) -> stable_ref(A) < stable_ref(B) end, Pairs),
    case receipt_evidence_references(Receipt, Sorted) of
        {ok, _Refs} -> Transaction#transaction{evidence = {applications, Sorted}};
        error -> error(bad_remote_evidence)
    end;
attach_receipt_evidence(_, _) -> error(bad_remote_evidence).

-doc "Encode one exact certified transaction evidence pair.".
-spec encode_evidence(term(), #transaction{}) ->
          {ok, binary()} | {error, bad_remote_evidence | too_large}.
encode_evidence(CertifiedRef, #transaction{} = Transaction) ->
    case certified_transaction_matches(CertifiedRef, Transaction) of
        true ->
            case encode_ledger_transaction(Transaction) of
                {ok, TransactionBytes} ->
                    %% Evidence is one transport frame, not a new semantic
                    %% quota.  Reuse the existing durable-operation envelope
                    %% bound so this codec and its only carrier cannot disagree.
                    case quod_safe_term:encode_canonical(
                           {quod_transaction_evidence, 2,
                            CertifiedRef, TransactionBytes},
                           ?QUOD_DTX_ENDPOINT_MAX_ENVELOPE_BYTES) of
                        {ok, Blob} -> {ok, Blob};
                        {error, too_large} -> {error, too_large};
                        {error, bad_term} -> {error, bad_remote_evidence}
                    end;
                {error, too_large} -> {error, too_large};
                {error, bad_term} -> {error, bad_remote_evidence}
            end;
        false -> {error, bad_remote_evidence}
    end.

-doc "Decode one bounded canonical certified transaction evidence pair.".
-spec decode_evidence(binary()) ->
          {ok, term(), #transaction{}} | {error, bad_remote_evidence}.
decode_evidence(Blob)
  when is_binary(Blob),
       byte_size(Blob) =< ?QUOD_DTX_ENDPOINT_MAX_ENVELOPE_BYTES ->
    case {quod_safe_term:validate_canonical(
            Blob, ?QUOD_DTX_ENDPOINT_MAX_ENVELOPE_BYTES),
          quod_safe_term:decode(
            Blob, ?QUOD_DTX_ENDPOINT_MAX_ENVELOPE_BYTES)} of
        {ok, {ok, {quod_transaction_evidence, 2, CertifiedRef,
                   TransactionBytes}}}
          when is_binary(TransactionBytes) ->
            case decode_ledger_transaction(TransactionBytes, wrapped) of
                {ok, Transaction} ->
                    case certified_transaction_matches(
                           CertifiedRef, Transaction) of
                        true -> {ok, CertifiedRef, Transaction};
                        false -> {error, bad_remote_evidence}
                    end;
                {error, _} -> {error, bad_remote_evidence}
            end;
        _ -> {error, bad_remote_evidence}
    end;
decode_evidence(_) -> {error, bad_remote_evidence}.

-doc "Compare complete canonical envelopes, independent of local symbol representation.".
-spec same_ledger_transaction(term(), term()) -> boolean().
same_ledger_transaction(#transaction{} = A, #transaction{} = B) ->
    %% Exact signed bytes, not semantic IDs: an opaque foreign symbol and an
    %% owner's atom may denote the same bytes. Malformed inputs never compare
    %% equal, and another author/signature/evidence envelope is not substituted.
    case {encode_ledger_transaction(A), encode_ledger_transaction(B)} of
        {{ok, Bytes}, {ok, Bytes}} -> true;
        _ -> false
    end;
same_ledger_transaction(_, _) -> false.

-spec role(#transaction{}) -> term().
role(#transaction{role = Role}) -> Role.

-spec evidence(#transaction{}) -> term().
evidence(#transaction{evidence = Evidence}) -> Evidence.

-doc "Return typed exact ledger references required to validate content.".
-spec required_references(#transaction{}) -> [{transaction | entry, term()}] | error.
required_references(
  #transaction{role = {remote_application, ClaimRef, _, _},
               evidence = {CertifiedRef, _},
               foreign_reads = ForeignReads}) ->
    case {stable_ref(CertifiedRef), read_reference_requirements(ForeignReads)} of
        {ClaimRef, {ok, ReadRefs}} -> [{transaction, CertifiedRef} | ReadRefs];
        _ -> error
    end;
required_references(
  #transaction{role = {remote_complete, _, _, Receipt},
               evidence = {applications, Pairs}, foreign_reads = []}) ->
    case receipt_evidence_references(Receipt, Pairs) of
        {ok, _} -> [{transaction, Ref} || {Ref, _Tx} <- Pairs];
        _ -> error
    end;
required_references(#transaction{role = application, evidence = none,
                                 foreign_reads = ForeignReads}) ->
    read_reference_requirements_or_error(ForeignReads);
required_references(#transaction{role = {remote_claim, _, _, _},
                                 evidence = none,
                                 foreign_reads = ForeignReads}) ->
    read_reference_requirements_or_error(ForeignReads);
required_references(#transaction{}) -> error.

read_reference_requirements_or_error(ForeignReads) ->
    case read_reference_requirements(ForeignReads) of
        {ok, Requirements} -> Requirements;
        error -> error
    end.

read_reference_requirements(ForeignReads) ->
    case canonical_foreign_reads(ForeignReads) of
        {ok, Certificates} ->
            read_reference_requirements(Certificates, []);
        error -> error
    end.

read_reference_requirements([], Acc) ->
    {ok, lists:reverse(Acc)};
read_reference_requirements([Certificate | Rest], Acc) ->
    case quod_read_certificate:binding(Certificate) of
        {ok, #{anchor_ref := AnchorRef}} ->
            read_reference_requirements(Rest, [{entry, AnchorRef} | Acc]);
        error -> error
    end.

-doc "Project one certified ledger reference to its stable transaction identity.".
-spec stable_ref(term()) ->
          {transaction, binary(), <<_:256>>, <<_:256>>} | invalid.
stable_ref(Ref) ->
    case quod_dtx:certified_ref_binding(Ref) of
        {ok, {Ns, Anchor}, _Slot, TxId} ->
            {transaction, Ns, Anchor, TxId};
        error -> invalid
    end.

certified_transaction_matches(CertifiedRef,
                              #transaction{tx_id = TxId}) ->
    case quod_dtx:certified_ref_binding(CertifiedRef) of
        {ok, _Identity, _Slot, TxId} -> true;
        _ -> false
    end.

semantic_id_or_error(Target, Transaction) ->
    case semantic_id(Target, Transaction) of
        {ok, Id} -> Id;
        error -> error(bad_transaction_material)
    end.

-doc "Bind a transaction's stable id to its target and complete semantic write.".
-spec bind_id({binary(), binary()}, #transaction{}) -> #transaction{}.
bind_id(Target, Transaction = #transaction{}) ->
    Transaction#transaction{tx_id = semantic_id_or_error(Target, Transaction)}.

-doc "Whether `tx_id` is the canonical id of this target-bound semantic write.".
-spec valid_id({binary(), binary()}, #transaction{}) -> boolean().
valid_id({Ns, <<_:256>>} = Target,
         #transaction{tx_id = <<_:256>> = TxId} = Transaction)
  when is_binary(Ns) ->
    semantic_id(Target, Transaction) =:= {ok, TxId};
valid_id(_Target, _Transaction) ->
    false.

-doc "Build the expected anchored outcome without decoding a foreign plan's payloads.".
-spec plan_outcome_ref(quod_dtx:plan(), binary(), binary(),
                       none | quod_client_goal:request_auth()) ->
          {transaction, binary(), binary(), binary()}.
plan_outcome_ref(Plan, GoalBlob, ResultBlob, RequestAuth)
  when is_binary(GoalBlob), is_binary(ResultBlob) ->
    {Ns, <<_:256>> = Anchor} = Target = quod_dtx:target(Plan),
    {StoredAuth, AuthTranscript} =
        request_outcome_fields(Plan, GoalBlob, RequestAuth),
    {transaction, Ns, Anchor,
     semantic_plan_id(
       Target, Plan, GoalBlob, ResultBlob, StoredAuth, AuthTranscript,
       application)}.

request_outcome_fields(Plan, _GoalBlob, none) ->
    case quod_dtx:request_binding(Plan) of
        none -> {none, none};
        _ -> error(bad_request_binding)
    end;
request_outcome_fields(Plan, GoalBlob, RequestAuth) ->
    case quod_dtx:material(Plan) of
        {ok, Material} -> request_fields(Plan, Material, GoalBlob, RequestAuth);
        {error, _} -> error(bad_plan)
    end.

-doc "Encode one durable goal/result pair through the shared persistence codec.".
-spec encode_durable_submission(term(), map()) ->
          {ok, binary(), binary()} | {error, term()}.
encode_durable_submission(Goal, Bindings) when is_map(Bindings) ->
    case quod_durable_term:encode_goal(Goal) of
        {ok, GoalBlob} ->
            case quod_durable_term:encode_result(Bindings) of
                {ok, ResultBlob} -> {ok, GoalBlob, ResultBlob};
                {error, _} = Error -> Error
            end;
        {error, _} = Error -> Error
    end;
encode_durable_submission(_Goal, _Bindings) ->
    {error, invalid_result}.

request_fields(Plan, _Material, _GoalBlob, none) ->
    case quod_dtx:request_binding(Plan) of
        none -> {none, none};
        _ -> error(bad_request_binding)
    end;
request_fields(Plan, #{transcript := Transcript}, GoalBlob,
               {agent_goal_v1, <<_:256>> = Digest, _Bytes, _Signature} = Auth) ->
    case quod_dtx:request_binding(Plan) of
        {agent_goal_v1, Digest} ->
            Target = quod_dtx:target(Plan),
            case quod_client_goal:authorization_transcript(
                   Transcript, Target, GoalBlob) of
                {ok, Authorization} ->
                    case request_evidence(
                           Target, GoalBlob, Auth, Authorization, verify) of
                        {ok, _Evidence} -> {Auth, Authorization};
                        {error, _} -> error(bad_request_binding)
                    end;
                _ -> error(bad_request_binding)
            end;
        _ ->
            error(bad_request_binding)
    end;
request_fields(_Plan, _Material, _GoalBlob, _RequestAuth) ->
    error(bad_request_binding).

-doc "Validate and expose one transaction's durable signed-agent claim.".
-spec validate_request(binary(), {binary(), <<_:256>>}, non_neg_integer(),
                       #transaction{}) ->
          {ok, none | map()} | {error, term()}.
validate_request(_Network, _Target, _AdmissionMs,
                 #transaction{role = Role, request_auth = none,
                              auth_transcript = none}) ->
    case Role of
        application -> {ok, none};
        {remote_application, _, _, _} -> {ok, none};
        {remote_complete, _, _, _} -> {ok, none};
        _ -> {error, invalid_request_binding}
    end;
validate_request(
  <<_:256>> = Network, {Ns, <<_:256>>} = Target, AdmissionMs,
  #transaction{role = application, origin = Target, goal = GoalBlob,
               request_auth = Auth,
               auth_transcript = {agent_goal_v1, TranscriptBlob}})
  when is_binary(Ns), is_integer(AdmissionMs), AdmissionMs >= 0,
       is_binary(GoalBlob), is_binary(TranscriptBlob) ->
    request_evidence(
      Target, GoalBlob, Auth, {agent_goal_v1, TranscriptBlob},
      {admission, Network, AdmissionMs});
validate_request(
  <<_:256>> = Network, {Ns, <<_:256>>} = Target, AdmissionMs,
  #transaction{role = {remote_claim, _, _, _}, origin = Target,
               goal = GoalBlob,
               auth_transcript = none} = Transaction)
  when is_binary(Ns), is_integer(AdmissionMs), AdmissionMs >= 0,
       is_binary(GoalBlob) ->
    case claim_view(Transaction) of
        {ok, _Plans, Evidence} ->
            quod_client_goal:validate_evidence(Evidence, Network, Target, AdmissionMs);
        error -> {error, invalid_request_binding}
    end;
validate_request(_Network, _Target, _AdmissionMs, #transaction{}) ->
    {error, invalid_request_binding}.

-doc "Return the bounded operation claim without consulting runtime state.".
-spec request_claim(#transaction{}) -> none | {ok, map()} | error.
request_claim(#transaction{role = application,
                           request_auth = none, auth_transcript = none}) ->
    none;
request_claim(#transaction{role = application, origin = Target,
                           goal = GoalBlob, request_auth = Auth,
                           auth_transcript = {agent_goal_v1, TranscriptBlob}})
  when is_binary(GoalBlob), is_binary(TranscriptBlob) ->
    case request_evidence(
           Target, GoalBlob, Auth, {agent_goal_v1, TranscriptBlob}, verify) of
        {ok, #{claim := Claim}} -> {ok, Claim};
        {error, _} -> error
    end;
request_claim(#transaction{role = {remote_claim, _, _, _},
                           auth_transcript = none} = Transaction) ->
    case claim_view(Transaction) of
        {ok, _Plans, #{claim := Claim}} -> {ok, Claim};
        error -> error
    end;
request_claim(#transaction{role = {remote_application, _, _, _},
                           request_auth = none, auth_transcript = none}) -> none;
request_claim(#transaction{role = {remote_complete, _, _, _},
                           request_auth = none, auth_transcript = none}) -> none;
request_claim(#transaction{}) ->
    error.

-doc "Classify whether a remote claim may use any host or its private effect owner.".
-spec remote_claim_route(#transaction{}, {binary(), <<_:256>>}) ->
          shared | {private, <<_:256>>} | error.
remote_claim_route(Claim = #transaction{}, Target) ->
    case claim_plan(Claim, Target) of
        {ok, {Plan, _Context}} ->
            case {quod_dtx:signer(Plan), quod_dtx:effects_count(Plan)} of
                {_Signer, 0} -> shared;
                {<<_:256>> = Signer, 1} ->
                    {private, Signer};
                _ -> error
            end;
        error -> error
    end.

claim_plan(Claim, Target) ->
    case claim_plans(Claim) of
        {ok, Plans} ->
            case [P || {Plan, _} = P <- Plans, quod_dtx:target(Plan) =:= Target] of
                [Pair] -> {ok, Pair};
                [] -> error
            end;
        error -> error
    end.

-doc "Return the canonical predicted application set, never a preferred target.".
-spec remote_claim_references(#transaction{}) -> {ok, [term()]} | error.
remote_claim_references(#transaction{role = {remote_claim, Manifest, Bundles, Refs}}) ->
    try
        true = valid_bundle_set(Manifest, Bundles),
        {ok, Refs} = quod_operation_vector:references(Refs),
        true = [Target || {Target, _, _, _} <- Bundles] =:=
                   [quod_operation_vector:target(R) || R <- Refs],
        {ok, Refs}
    catch _:_ -> error
    end;
remote_claim_references(_) -> error.

valid_bundle_set(Manifest, Bundles)
  when is_list(Bundles), length(Bundles) > 0,
       length(Bundles) =< ?QUOD_MAX_DTX_PARTICIPANTS ->
    %% manifest_digest validates its canonical participant set. Checking exact
    %% headers before decoding any selected blob prevents extra/duplicate or
    %% missing bundles from hiding behind list-comprehension filtering.
    _ = quod_dtx:manifest_digest(Manifest),
    lists:all(fun({{Ns, <<_:256>>}, <<_:256>>, Blob, _Attestation}) ->
                      is_binary(Ns) andalso byte_size(Ns) > 0 andalso is_binary(Blob);
                 (_) -> false
              end, Bundles) andalso
        [{Target, Digest} || {Target, Digest, _, _} <- Bundles] =:=
            quod_dtx:manifest_participants(Manifest);
valid_bundle_set(_, _) -> false.

%% The view is built only by construction/canonical decode, never read from
%% the wire. Its exact input binding prevents record edits from reusing a
%% different bundle's authentication. The request claim is bound to its exact
%% auth and goal too; role checks reuse it without owning any vocabulary.
claim_plans(Transaction) ->
    case claim_view(Transaction) of
        {ok, Plans, _Request} -> {ok, Plans};
        error -> error
    end.

claim_view(#transaction{origin = Origin,
                       role = {remote_claim, Manifest, Bundles, _},
                       request_auth = Auth, goal = Goal,
                       claim_view = {Origin, Manifest, Bundles, Plans,
                                     Auth, Goal, Request}}) ->
    {ok, Plans, Request};
claim_view(_) -> error.

authenticate_claim(Tx = #transaction{origin = Origin, request_auth = Auth, goal = Goal,
                                    role = {remote_claim, Manifest, Bundles, _}}) ->
    case {claim_plans(Origin, Manifest, Bundles),
          quod_client_goal:verify_durable_request(Auth, Goal)} of
        {{ok, Plans}, {ok, Request}} ->
            {ok, Tx#transaction{claim_view = {Origin, Manifest, Bundles, Plans,
                                             Auth, Goal, Request}}};
        _ -> error
    end;
authenticate_claim(Tx) -> {ok, Tx}.

claim_plans(Origin, Manifest, Bundles) ->
    try
        %% Independent claims have caller deadlines, not atomic vote expiry.
        none = quod_dtx:manifest_deadline(Manifest),
        true = valid_bundle_set(Manifest, Bundles),
        {ok, [begin
                  {ok, BoundPlan} = authenticated_claim_plan(
                    Origin, Manifest, Target, Digest, Blob, Attestation),
                  BoundPlan
              end || {Target, Digest, Blob, Attestation} <- Bundles]}
    catch _:_ -> error
    end.

%% The eligibility grant is the executing target's existing signed manifest
%% attestation, derived from its own sealed session. No source Boolean or
%% surviving live session is an authority input to validator/recovery reads.
-doc "Require each writer's already-authenticated independent attestation for N > 1.".
-spec validate_independent_claim(#transaction{}) -> ok | {error, atom()}.
validate_independent_claim(Claim = #transaction{
    role = {remote_claim, _, [_ | _] = Bundles, _}}) ->
    case claim_plans(Claim) of
        {ok, _Plans} ->
            case length(Bundles) =:= 1 orelse
                 lists:all(fun({_Target, _Digest, _Blob, Attestation}) ->
                               quod_dtx:attestation_mode(Attestation) =:= independent
                           end, Bundles) of
                true -> ok;
                false -> {error, independent_scope_required}
            end;
        error -> {error, invalid_plan_attestation}
    end;
validate_independent_claim(_) -> {error, invalid_operation_claim}.

authenticated_claim_plan(Origin, Manifest, Target, Digest, Blob, Attestation) ->
    case quod_dtx:decode(Blob) of
        {ok, Plan} ->
            case quod_dtx:origin(Plan) =:= Origin andalso
                 quod_dtx:target(Plan) =:= Target andalso
                 quod_dtx:digest(Plan) =:= Digest andalso
                 quod_dtx:writes(Plan) of
                true ->
                    case quod_dtx:attested_context(Target, Plan, Manifest, Attestation) of
                        {ok, Context} -> {ok, {Plan, Context}};
                        error -> error
                    end;
                false -> error
            end;
        _ -> error
    end.

predicted_applications(Identity, Plans) ->
    [begin
         {Ns, Anchor} = Target = quod_dtx:target(Plan),
         {Id, _, _} = application_identity(Identity, Target, Plan),
         {transaction, Ns, Anchor, Id}
     end || {Plan, _Context} <- Plans].

receipt_evidence_references(Receipt, Pairs) when is_list(Pairs) ->
    case quod_operation_vector:receipt_references(Receipt) of
        {ok, Refs} when length(Refs) =:= length(Pairs) ->
            case lists:all(fun({Ref, #transaction{} = Tx}) ->
                                  certified_transaction_matches(Ref, Tx);
                             (_) -> false
                          end, Pairs) andalso
                 [stable_ref(Ref) || {Ref, _} <- Pairs] =:= Refs of
                true -> {ok, Refs};
                false -> error
            end;
        _ -> error
    end;
receipt_evidence_references(_, _) -> error.

-doc "Whether a content value must be checked against the network identity.".
-spec requires_network_identity(term()) -> boolean().
requires_network_identity([]) -> false;
requires_network_identity(
  [#transaction{request_auth = none, auth_transcript = none} | Rest]) ->
    requires_network_identity(Rest);
requires_network_identity([#transaction{} | _Rest]) -> true;
requires_network_identity([_Malformed | _Rest]) -> true;
requires_network_identity(_ImproperOrMalformed) -> true.

valid_request_fields(_Target, _GoalBlob, none, none) ->
    true;
valid_request_fields(Target, GoalBlob, Auth, Authorization) ->
    case request_evidence(
           Target, GoalBlob, Auth, Authorization, verify) of
        {ok, _Evidence} -> true;
        {error, _} -> false
    end.

%% One structural verifier feeds transaction construction, signed bytes,
%% claim extraction, and admission-time validation. Callers project the shape
%% they need; none of them reimplements request or transcript checks.
request_evidence(Target, GoalBlob, Auth, Authorization, verify) ->
    checked_request_target(
      Target,
      quod_client_goal:verify_durable_authorization(
        Auth, Authorization, GoalBlob));
request_evidence(Target, GoalBlob, Auth, Authorization,
                 {admission, Network, AdmissionMs}) ->
    checked_request_target(
      Target,
      quod_client_goal:validate_durable_authorization(
        Auth, Authorization, Network, Target, AdmissionMs, GoalBlob)).

checked_request_target(
  {Ns, Anchor},
  {ok, #{evidence :=
             #{request := #{agent_namespace := Ns,
                            agent_genesis_anchor := Anchor}}}} = Result)
  when is_binary(Ns), is_binary(Anchor) ->
    Result;
checked_request_target(_Target, {ok, _OtherEvidence}) ->
    {error, invalid_request_binding};
checked_request_target(_Target, {error, _} = Error) ->
    Error.

semantic_id({Ns, <<_:256>> = Anchor},
            #transaction{role = Role, origin = Origin, proof_id = ProofId,
                         plan_digest = PlanDigest, goal = Goal,
                         result = Result, diff = Diff,
                         read_check = ReadCheck, effects = Effects,
                         request_auth = RequestAuth,
                         auth_transcript = AuthTranscript})
  when is_binary(Ns) ->
    case semantic_material_bytes(Diff, ReadCheck, Effects) of
        {ok, DiffBytes, ReadCheckBytes, EffectsBytes} ->
            semantic_id_parts(
              Ns, Anchor, Origin, ProofId, PlanDigest, Goal, Result,
              DiffBytes, ReadCheckBytes, EffectsBytes,
              RequestAuth, AuthTranscript, semantic_role(Role));
        error ->
            error
    end.

semantic_material_bytes(Diff, ReadCheck, Effects)
  when is_list(Diff), is_map(ReadCheck), is_list(Effects) ->
    case {quod_wire_term:encode_canonical(Diff),
          quod_read_set:encode(ReadCheck),
          quod_wire_term:encode_canonical(Effects)} of
        {{ok, DiffBytes}, {ok, ReadCheckBytes}, {ok, EffectsBytes}} ->
            {ok, DiffBytes, ReadCheckBytes, EffectsBytes};
        _ ->
            error
    end;
semantic_material_bytes(_Diff, _ReadCheck, _Effects) ->
    error.

semantic_plan_id(
  {Ns, <<_:256>> = Anchor}, Plan, GoalBlob, ResultBlob,
  RequestAuth, AuthTranscript, Role) ->
    case semantic_id_parts(
           Ns, Anchor, quod_dtx:origin(Plan), quod_dtx:proof_id(Plan),
           quod_dtx:digest(Plan), GoalBlob, ResultBlob,
           quod_dtx:diff_bytes(Plan), quod_dtx:read_check_bytes(Plan),
           quod_dtx:effects_bytes(Plan), RequestAuth, AuthTranscript, Role) of
        {ok, Id} -> Id;
        error -> error(bad_transaction_material)
    end.

semantic_id_parts(Ns, Anchor, Origin, ProofId, PlanDigest, Goal, Result,
                  DiffBytes, ReadCheckBytes, EffectsBytes,
                  RequestAuth, AuthTranscript, Role) ->
    case quod_safe_term:encode_canonical(
           {?ID_DOMAIN, ?ID_VERSION, Ns, Anchor, Origin, ProofId,
            PlanDigest, Goal, Result, DiffBytes, ReadCheckBytes, EffectsBytes,
            RequestAuth, AuthTranscript, Role},
           ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES) of
        {ok, Canonical} -> {ok, crypto:hash(sha256, Canonical)};
        {error, _} -> error
    end.

%% The predicted target id is checked but excluded from C, breaking the C/T
%% construction cycle. Every other role field participates in its semantic id.
semantic_role({remote_claim, Manifest, Bundles, Predicted}) when is_list(Predicted) ->
    {remote_claim, Manifest, Bundles};
semantic_role({remote_complete, OperationRef, RequestDigest, Receipt}) ->
    {ok, Identity} = quod_operation_vector:receipt_identity(Receipt),
    {remote_complete, OperationRef, RequestDigest, Identity};
semantic_role(Role) -> Role.

-doc "Canonical bytes signed by a transaction author, bound to the target identity.".
-spec bytes(target_binding(), #transaction{}) ->
          {ok, binary()} | {error, bad_term}.
bytes(Binding, #transaction{evidence = Evidence} = Transaction) ->
    transaction_bytes(Binding, Transaction, encode_signed_evidence(Evidence));
bytes(_Binding, _Transaction) -> {error, bad_term}.

%% EvidenceBytes is either produced by the checked encoder above or retained
%% by this module's decoder immediately after authenticating that exact wire.
%% Native callers cannot substitute carried signed_bytes for view validation.
transaction_bytes({TargetNs, TargetAnchor, AuthorAdmission},
      Transaction = #transaction{tx_id = TxId, role = Role,
                   foreign_reads = ForeignReads,
                   origin = Origin, proof_id = ProofId,
                   plan_digest = PlanDigest, goal = Goal,
                   result = Result, diff = Diff, read_check = ReadCheck,
                   effects = Effects,
                   request_auth = RequestAuth,
                   auth_transcript = AuthTranscript,
                   author = Author, author_seq = AuthorSeq,
                   submitted_at = SubmittedAt}, EvidenceBytes)
  when is_binary(TargetNs), is_binary(TargetAnchor),
       is_binary(AuthorAdmission), byte_size(TargetAnchor) =:= 32,
       byte_size(AuthorAdmission) =:= 32 ->
    case {encode_material(Diff, ReadCheck, Effects),
          EvidenceBytes,
          canonical_foreign_reads(ForeignReads),
          valid_role_fields({TargetNs, TargetAnchor}, Transaction)} of
        {{ok, MaterialWire, EffectsWire}, {ok, EvidenceWire},
         {ok, ForeignReads}, true}
          when byte_size(EffectsWire) =< ?QUOD_MAX_DIRECT_EFFECT_BYTES ->
            case quod_effect:validate_transaction(
                   TargetNs, TargetAnchor, Author, Effects) of
                true ->
                    canonical_bytes(
                      TargetNs, TargetAnchor, AuthorAdmission, TxId, Origin,
                      ProofId, PlanDigest, Goal, Result, MaterialWire,
                      EffectsWire, Role, EvidenceWire, ForeignReads,
                      RequestAuth, AuthTranscript,
                      Author, AuthorSeq, SubmittedAt);
                false ->
                    {error, bad_term}
            end;
        {{ok, _MaterialWire, _EffectsWire}, _Evidence,
         _ForeignReads, _} ->
            {error, bad_term};
        {{error, bad_term} = Error, _Evidence, _ForeignReads, _} ->
            Error
    end;
transaction_bytes(_Binding, _Transaction, _EvidenceBytes) ->
    {error, bad_term}.

canonical_bytes(TargetNs, TargetAnchor, AuthorAdmission, TxId, Origin,
                ProofId, PlanDigest, Goal, Result, MaterialWire, EffectsWire,
                Role, Evidence, ForeignReads, RequestAuth, AuthTranscript, Author,
                AuthorSeq, SubmittedAt) ->
    quod_safe_term:encode_canonical(
      {?DOMAIN, ?VERSION, TargetNs, TargetAnchor, AuthorAdmission,
       TxId, Origin, ProofId, PlanDigest, Goal, Result, MaterialWire,
       EffectsWire, Role, Evidence, ForeignReads, RequestAuth, AuthTranscript,
       Author, AuthorSeq, SubmittedAt},
      ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES).

encode_material(Diff, ReadCheck, Effects)
  when is_list(Diff), is_map(ReadCheck), is_list(Effects) ->
    case quod_read_set:pairs(ReadCheck) of
        {ok, ReadPairs} -> encode_material_pairs(Diff, ReadPairs, Effects);
        error -> {error, bad_term}
    end;
encode_material(_Diff, _ReadCheck, _Effects) ->
    {error, bad_term}.

encode_material_pairs(Diff, ReadPairs, Effects) ->
    case {quod_wire_term:encode_canonical(
            {Diff, ReadPairs}),
          quod_wire_term:encode_canonical(Effects)} of
        {{ok, MaterialWire}, {ok, EffectsWire}} ->
            {ok, MaterialWire, EffectsWire};
        _ ->
            {error, bad_term}
    end.

encode_signed_evidence(none) ->
    {ok, none};
encode_signed_evidence({applications, Pairs}) when is_list(Pairs) ->
    try
        {ok, {certified_applications,
              [begin {ok, Wire} = encode_signed_evidence(Pair), Wire end || Pair <- Pairs]}}
    catch _:_ -> {error, bad_term}
    end;
encode_signed_evidence({CertifiedRef, #transaction{} = Transaction}) ->
    case encode_ledger_transaction(Transaction) of
        {ok, TransactionBytes} ->
            {ok, {certified_transaction, CertifiedRef, TransactionBytes}};
        {error, _} ->
            {error, bad_term}
    end;
encode_signed_evidence(_Evidence) ->
    {error, bad_term}.

decode_signed_evidence(none, Context) ->
    {ok, none, Context};
decode_signed_evidence({certified_applications, Wires}, Context) when is_list(Wires) ->
    try
        {Pairs, Next} = lists:mapfoldl(fun(Wire, Acc) ->
            {certified_transaction, _, _} = Wire,
            {ok, Pair, Decoded} = decode_signed_evidence(Wire, Acc),
            {Pair, Decoded}
        end, Context, Wires),
        {ok, {applications, Pairs}, Next}
    catch _:_ -> {error, malformed_material}
    end;
decode_signed_evidence(
  {certified_transaction, CertifiedRef, TransactionBytes}, Context)
  when is_binary(TransactionBytes) ->
    %% Certified evidence describes another ontology.  It is never an
    %% authority to allocate that ontology's vocabulary in this VM.
    case decode_ledger_transaction(TransactionBytes, wrapped, Context) of
        {ok, Transaction, Next} -> {ok, {CertifiedRef, Transaction}, Next};
        {error, _} -> {error, malformed_material}
    end;
decode_signed_evidence(_EvidenceWire, _Context) ->
    {error, malformed_material}.

-doc """
Sign an unsigned transaction for the target identity. The supplied identity
must own the same public key named by `author`; callers cannot use a node key
to sign for a different author.
""".
-spec sign(target_binding(), #transaction{}, quod_identity:signer()) ->
        {ok, #transaction{}} | {error, term()}.
sign(Binding, Transaction, Identity) ->
    case signing_material(Binding, Transaction, Identity) of
        {ok, Signed, _Author, _Signature, _Canonical} -> {ok, Signed};
        {error, _} = Error -> Error
    end.

-doc "Sign and build a relay submission without encoding the transaction twice.".
-spec sign_submission(target_binding(), #transaction{}, quod_identity:signer()) ->
          {ok, #transaction{}, {submit, binary(), binary(), binary()}} |
          {error, term()}.
sign_submission(Binding, Transaction, Identity) ->
    case signing_material(Binding, Transaction, Identity) of
        {ok, Signed, Author, Signature, Canonical}
          when byte_size(Canonical) =< ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES ->
            {ok, Signed, {submit, Author, Signature, Canonical}};
        {ok, _Signed, _Author, _Signature, _Canonical} ->
            {error, too_large};
        {error, _} = Error ->
            Error
    end.

signing_material(
  {TargetNs, TargetAnchor, AuthorAdmission} = Binding,
  #transaction{author = Author, sig = none,
               signed_bytes = none} = Transaction,
  #{pubkey := Author} = Identity)
  when is_binary(TargetNs), is_binary(TargetAnchor), is_binary(AuthorAdmission),
       byte_size(TargetAnchor) =:= 32, byte_size(AuthorAdmission) =:= 32,
       byte_size(Author) =:= ?PUBKEY_BYTES ->
    case bytes(Binding, Transaction) of
        {ok, Canonical} ->
            case quod_safe_term:validate_canonical(
                   Canonical, ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES) of
                ok ->
                    Signature = quod_identity:sign(Canonical, Identity),
                    {ok,
                     Transaction#transaction{sig = Signature,
                                             signed_bytes = Canonical,
                                             authentication = {Author, Signature, Canonical}},
                     Author, Signature, Canonical};
                {error, _} ->
                    {error, bad_term}
            end;
        {error, _} = Error ->
            Error
    end;
signing_material(_Binding, #transaction{sig = Sig}, _Identity)
  when Sig =/= none ->
    {error, already_signed};
signing_material(_Binding, #transaction{}, _Identity) ->
    {error, author_mismatch};
signing_material(_Binding, _Transaction, _Identity) ->
    {error, malformed_transaction}.

-doc "Verify a transaction signature against the validator's own target identity.".
-spec verify(target_binding(), #transaction{}) -> boolean().
verify({TargetNs, TargetAnchor, AuthorAdmission} = Binding,
       #transaction{author = Author, sig = Signature,
                    signed_bytes = SignedBytes} = Transaction)
  when is_binary(TargetNs), is_binary(TargetAnchor), is_binary(AuthorAdmission),
       byte_size(TargetAnchor) =:= 32, byte_size(AuthorAdmission) =:= 32,
       is_binary(Author), byte_size(Author) =:= ?PUBKEY_BYTES,
       is_binary(Signature), byte_size(Signature) =:= ?SIGNATURE_BYTES ->
    is_binary(SignedBytes)
        andalso byte_size(SignedBytes) =< ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES
        andalso authenticated_signature(Transaction)
        andalso case bytes(Binding, Transaction) of
                    {ok, SignedBytes} -> true;
                    _ -> false
                end;
verify(_Binding, _Transaction) ->
    false.

%% The codec/signing boundary owns this receipt, not the wire. It attests only
%% the exact author/signature/bytes triple: view reconstruction and the caller's
%% historical target/admission binding still run at every verification seam.
authenticated_signature(#transaction{author = Author, sig = Signature,
                                     signed_bytes = Canonical,
                                     authentication = {Author, Signature, Canonical}}) ->
    true;
authenticated_signature(#transaction{author = Author, sig = Signature,
                                     signed_bytes = Canonical}) ->
    verify_submission({submit, Author, Signature, Canonical}).

-doc """
Build the relay payload whose canonical transaction bytes remain opaque until
the receiving validator has verified their signature.
""".
-spec submission(target_binding(), #transaction{}) ->
        {ok, {submit, binary(), binary(), binary()}} | {error, term()}.
submission(Binding, #transaction{author = Author, sig = Signature} = Transaction)
  when is_binary(Author), byte_size(Author) =:= ?PUBKEY_BYTES,
       is_binary(Signature), byte_size(Signature) =:= ?SIGNATURE_BYTES ->
    case Transaction#transaction.signed_bytes of
        Canonical when is_binary(Canonical),
                       byte_size(Canonical) =<
                           ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES ->
            case bytes(Binding, Transaction) of
                {ok, Canonical} ->
                    {ok, {submit, Author, Signature, Canonical}};
                {ok, _Different} ->
                    {error, noncanonical};
                {error, _} = Error ->
                    Error
            end;
        Canonical when is_binary(Canonical) ->
            {error, too_large};
        _ ->
            {error, unsigned_or_malformed}
    end;
submission(_Binding, _Transaction) ->
    {error, unsigned_or_malformed}.

-doc "Stable 16-byte correlation id for one authenticated author/signature pair.".
-spec submission_id({submit, binary(), binary(), binary()}) -> binary().
submission_id({submit, Author, Signature, _Canonical}) ->
    <<Id:16/binary, _/binary>> =
        crypto:hash(
          sha256,
          term_to_binary(
            {quod_submission, 2, Author, Signature}, [deterministic])),
    Id.

-doc """
Return the stable 16-byte identity of one exact relay placement.

The domain-separated digest binds an exact signed submission to its namespace,
consensus era, target view, and target validator. Retargeting the unchanged
submission therefore keeps its `submission_id/1` but receives a distinct attempt
id. Malformed inputs return `error`; this helper is total at the relay boundary.
""".
-spec relay_attempt_id(binary(), binary(), binary(), pos_integer(), binary()) ->
        binary() | error.
relay_attempt_id(Ns, SubmissionId, Era, TargetSlot, Target)
  when is_binary(Ns),
       is_binary(SubmissionId),
       byte_size(SubmissionId) =:= ?SUBMISSION_ID_BYTES,
       is_binary(Era),
       byte_size(Era) =:= ?ERA_BYTES,
       is_integer(TargetSlot),
       TargetSlot >= 1,
       TargetSlot =< ?MAX_SLOT,
       is_binary(Target),
       byte_size(Target) =:= ?PUBKEY_BYTES ->
    Canonical =
        term_to_binary(
          {?RELAY_ATTEMPT_DOMAIN, ?RELAY_ATTEMPT_VERSION,
           Ns, SubmissionId, Era, TargetSlot, Target},
          [deterministic]),
    <<Id:?SUBMISSION_ID_BYTES/binary, _/binary>> =
        crypto:hash(sha256, Canonical),
    Id;
relay_attempt_id(_Ns, _SubmissionId, _Era, _TargetSlot, _Target) ->
    error.

-doc """
Verify the author signature over the still-opaque canonical bytes. This is the
only operation permitted before the inner transaction is decoded.
""".
-spec verify_submission(term()) -> boolean().
verify_submission({submit, Author, Signature, Canonical})
  when is_binary(Author), byte_size(Author) =:= ?PUBKEY_BYTES,
       is_binary(Signature), byte_size(Signature) =:= ?SIGNATURE_BYTES,
       is_binary(Canonical),
       byte_size(Canonical) =< ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES ->
    quod_identity:verify(Signature, Canonical, Author);
verify_submission(_Submission) ->
    false.

-doc "Encode the exact transaction artifact carried inside a canonical block.".
-spec encode_ledger_transaction(#transaction{}) ->
          {ok, binary()} | {error, bad_term | too_large}.
encode_ledger_transaction(
  Transaction = #transaction{author = Author, sig = Signature,
                             signed_bytes = Canonical})
  when is_binary(Author), byte_size(Author) =:= ?PUBKEY_BYTES,
       is_binary(Signature), byte_size(Signature) =:= ?SIGNATURE_BYTES,
       is_binary(Canonical) ->
    Submission = {submit, Author, Signature, Canonical},
    case {authenticated_signature(Transaction),
          decode_submission_metadata(Canonical)} of
        {true, {ok, #{target := {Ns, Anchor}, admission := Admission,
                      author := Author}}} ->
            case bytes({Ns, Anchor, Admission}, Transaction) of
                {ok, Canonical} -> encode_ledger_transaction_term(Submission);
                _ -> {error, bad_term}
            end;
        _ ->
            {error, bad_term}
    end;
encode_ledger_transaction(Genesis = #transaction{sig = none,
                                                 signed_bytes = none}) ->
    encode_genesis_transaction(Genesis);
encode_ledger_transaction(#transaction{}) ->
    {error, bad_term}.

-doc "The exact ledger-envelope size, reserving fixed-width signing fields for an unsigned local transaction.".
-spec encoded_ledger_transaction_size(#transaction{}) ->
          {ok, non_neg_integer()} | {error, bad_term | too_large}.
encoded_ledger_transaction_size(Transaction = #transaction{sig = Signature})
  when is_binary(Signature) ->
    case encode_ledger_transaction(Transaction) of
        {ok, Blob} -> {ok, byte_size(Blob)};
        {error, _} = Error -> Error
    end;
encoded_ledger_transaction_size(
  Transaction = #transaction{origin = {Ns, Anchor}, author = Author,
                             sig = none, signed_bytes = none})
  when is_binary(Ns), is_binary(Anchor), byte_size(Anchor) =:= 32,
       is_binary(Author), byte_size(Author) =:= ?PUBKEY_BYTES ->
    %% Admission and signature are fixed-width bytes. Use the largest legal
    %% sequence representation so pre-signing admission cannot undercount the
    %% final canonical envelope.
    Reserved = Transaction#transaction{author_seq = ?MAX_SLOT},
    case bytes({Ns, Anchor, <<0:256>>}, Reserved) of
        {ok, Canonical} ->
            encode_ledger_transaction_size_term(
              {submit, Author, <<0:512>>, Canonical});
        {error, _} ->
            {error, bad_term}
    end;
encoded_ledger_transaction_size(#transaction{}) ->
    {error, bad_term}.

encode_ledger_transaction_size_term(Term) ->
    case encode_ledger_transaction_term(Term) of
        {ok, Blob} -> {ok, byte_size(Blob)};
        {error, _} = Error -> Error
    end.

encode_ledger_transaction_term(Term) ->
    case quod_safe_term:encode_canonical(
           Term, ?QUOD_MAX_OPERATION_SUBMISSION_BYTES) of
        {ok, Blob} -> {ok, Blob};
        {error, too_large} -> {error, too_large};
        {error, bad_term} -> {error, bad_term}
    end.

encode_genesis_transaction(
  #transaction{tx_id = TxId, role = application, evidence = none,
               foreign_reads = [], origin = Origin,
               proof_id = none, plan_digest = none,
               goal = undefined, result = undefined,
               diff = Diff, read_check = ReadCheck, effects = [],
               request_auth = none, auth_transcript = none,
               author = Author, author_seq = 0, submitted_at = 0,
               sig = none, signed_bytes = none})
  when is_binary(TxId), is_map(ReadCheck), map_size(ReadCheck) =:= 0,
       is_binary(Author) ->
    case quod_wire_term:encode_canonical(Diff) of
        {ok, DiffBytes} ->
            encode_ledger_transaction_term(
              {quod_genesis_transaction, 1, TxId, Origin,
               DiffBytes, Author});
        {error, _} -> {error, bad_term}
    end;
encode_genesis_transaction(_Genesis) ->
    {error, bad_term}.

-doc "Decode a ledger transaction with target-owned or opaque foreign symbols.".
-spec decode_ledger_transaction(binary(), materialized | wrapped) ->
          {ok, #transaction{}} | {error, term()}.
decode_ledger_transaction(Blob, SymbolMode) ->
    decoded_result(decode_ledger_transaction(Blob, SymbolMode, decode_context())).

-doc """
Decode within the caller's bounded page, sharing only complete authenticated
records under exact envelope bytes and symbol mode. Contexts are trusted native
values minted here, not caller-seeded maps or wire data. Discard on page return
or failure; never retain across pages. Enclosing reference, committee, finality,
admission and freshness checks remain the consuming verifier's responsibility.
""".
-spec decode_ledger_transaction(binary(), materialized | wrapped, decode_context()) ->
          {ok, #transaction{}, decode_context()} | {error, term()}.
decode_ledger_transaction(Blob, SymbolMode,
                          #decoded_transactions{completed = Completed} = Context)
  when is_binary(Blob),
       byte_size(Blob) =< ?QUOD_MAX_OPERATION_SUBMISSION_BYTES,
       (SymbolMode =:= materialized orelse SymbolMode =:= wrapped) ->
    Key = {Blob, SymbolMode},
    case maps:find(Key, Completed) of
        {ok, Transaction} -> {ok, Transaction, Context};
        error ->
            case decode_ledger_record(Blob, SymbolMode, Context) of
                {ok, Transaction, #decoded_transactions{completed = Nested} = Next} ->
                    {ok, Transaction,
                     Next#decoded_transactions{completed = Nested#{Key => Transaction}}};
                {error, _} = Error -> Error
            end
    end;
decode_ledger_transaction(_Blob, _SymbolMode, _Context) ->
    {error, malformed_ledger_transaction}.

decode_ledger_record(Blob, SymbolMode, Context) ->
    case decode_canonical_term(
           Blob, ?QUOD_MAX_OPERATION_SUBMISSION_BYTES, SymbolMode) of
        {ok, {quod_genesis_transaction, 1, TxId, Origin,
              DiffBytes, Author}}
          when is_binary(TxId), is_binary(DiffBytes), is_binary(Author) ->
            case decode_genesis_transaction(TxId, Origin, DiffBytes, Author, SymbolMode) of
                {ok, Transaction} -> {ok, Transaction, Context};
                {error, _} = Error -> Error
            end;
        {ok, Submission = {submit, _, _, _}} ->
            decode_self_bound_submission(Submission, SymbolMode, Context);
        _ ->
            {error, malformed_ledger_transaction}
    end.

decode_genesis_transaction(TxId, Origin, DiffBytes, Author, SymbolMode) ->
    case quod_wire_term:decode_canonical(
           DiffBytes, ?QUOD_MAX_OPERATION_SUBMISSION_BYTES) of
        {ok, Diff0} when is_list(Diff0) ->
            case materialize_decoded(Diff0, SymbolMode) of
                {ok, Diff} ->
                    {ok, #transaction{tx_id = TxId, origin = Origin,
                                      diff = Diff, read_check = #{},
                                      author = Author, sig = none,
                                      signed_bytes = none}};
                {error, _} -> {error, malformed_ledger_transaction}
            end;
        _ ->
            {error, malformed_ledger_transaction}
    end.

decode_self_bound_submission(
  Submission = {submit, Author, _Signature, Canonical}, SymbolMode, Context) ->
    case {verify_submission(Submission),
          decode_submission_metadata(Canonical)} of
        {true,
         {ok, #{target := {Ns, Anchor}, admission := Admission,
                author := Author}}} ->
            decode_verified_submission(
              {Ns, Anchor, Admission}, Submission, SymbolMode, Context);
        _ ->
            {error, malformed_ledger_transaction}
    end.

-doc """
Decode a submission after `verify_submission/1` succeeded. Canonical reconstruction
rejects non-canonical ETF and binds the opaque bytes to the target identity
and `Author`.
""".
-spec decode_verified_submission(target_binding(), term()) ->
        {ok, #transaction{}} | {error, term()}.
decode_verified_submission(
  {TargetNs, TargetAnchor, AuthorAdmission} = Binding,
  {submit, Author, Signature, Canonical})
  when is_binary(TargetNs), is_binary(TargetAnchor),
       is_binary(AuthorAdmission),
       is_binary(Author), is_binary(Signature),
       is_binary(Canonical),
       byte_size(Canonical) =< ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES ->
    decoded_result(decode_verified_submission(
      Binding, {submit, Author, Signature, Canonical}, materialized, decode_context()));
decode_verified_submission(_Binding, _Submission) ->
    {error, malformed_submission}.

decode_verified_submission(
  {TargetNs, TargetAnchor, AuthorAdmission} = Binding,
  {submit, Author, Signature, Canonical}, SymbolMode, Context)
  when is_binary(TargetNs), is_binary(TargetAnchor),
       is_binary(AuthorAdmission),
       is_binary(Author), is_binary(Signature),
       is_binary(Canonical),
       byte_size(Canonical) =< ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES,
       (SymbolMode =:= materialized orelse SymbolMode =:= wrapped) ->
    case decode_canonical_transaction(Binding, Canonical, SymbolMode, Context) of
        {ok, Transaction = #transaction{author = Author}, Next} ->
            {ok, Transaction#transaction{sig = Signature,
                                         signed_bytes = Canonical,
                                         authentication = {Author, Signature, Canonical}}, Next};
        {ok, #transaction{}, _Next} ->
            {error, namespace_or_author_mismatch};
        {error, _} = Error ->
            Error
    end;
decode_verified_submission(_Binding, _Submission, _SymbolMode, _Context) ->
    {error, malformed_submission}.

-doc """
Decode the one current canonical transaction body into its unsigned in-memory
view. This is the shared parser used by signed submissions and by the direct
effect journal while Simplex still owns the pending transaction's only signing
step. Reconstruction shares the native encoder, retaining evidence bytes only
within the call that just authenticated them. A term view never replaces or
reinterprets the carried bytes; public encoders still validate native views.
""".
-spec decode_canonical_transaction(target_binding(), binary()) ->
          {ok, #transaction{}} | {error, term()}.
decode_canonical_transaction(
  {TargetNs, TargetAnchor, AuthorAdmission} = Binding, Canonical)
  when is_binary(TargetNs), is_binary(TargetAnchor),
       is_binary(AuthorAdmission), is_binary(Canonical),
       byte_size(Canonical) =< ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES ->
    decoded_result(decode_canonical_transaction(Binding, Canonical, materialized, decode_context()));
decode_canonical_transaction(_Binding, _Canonical) ->
    {error, malformed_submission}.

decode_canonical_transaction(
  {TargetNs, TargetAnchor, AuthorAdmission} = Binding, Canonical, SymbolMode, Context)
  when is_binary(TargetNs), is_binary(TargetAnchor),
       is_binary(AuthorAdmission), is_binary(Canonical),
       byte_size(Canonical) =< ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES,
       (SymbolMode =:= materialized orelse SymbolMode =:= wrapped) ->
    case decode_canonical_term(
           Canonical, ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES, SymbolMode) of
        {ok,
         {?DOMAIN, ?VERSION, TargetNs, TargetAnchor, AuthorAdmission,
          TxId, Origin, ProofId,
          PlanDigest, Goal, Result, MaterialWire, EffectsWire, Role,
          EvidenceWire, ForeignReads, RequestAuth, AuthTranscript,
          Author, AuthorSeq, SubmittedAt}} ->
            case {decode_material(MaterialWire, EffectsWire, SymbolMode),
                  decode_signed_evidence(EvidenceWire, Context)} of
                {{ok, Diff, ReadCheck, Effects}, {ok, Evidence, Next}} ->
                    Transaction0 =
                        #transaction{tx_id = TxId, role = Role,
                                     evidence = Evidence, origin = Origin,
                                     foreign_reads = ForeignReads,
                                     proof_id = ProofId,
                                     plan_digest = PlanDigest,
                                     goal = Goal, result = Result,
                                     diff = Diff, read_check = ReadCheck,
                                     effects = Effects,
                                     request_auth = RequestAuth,
                                     auth_transcript = AuthTranscript,
                                     author = Author,
                                     author_seq = AuthorSeq,
                                     submitted_at = SubmittedAt,
                                     sig = none, signed_bytes = none},
                    case authenticate_claim(Transaction0) of
                        {ok, Transaction} ->
                            case transaction_bytes(Binding, Transaction,
                                                   {ok, EvidenceWire}) of
                                {ok, Canonical} -> {ok, Transaction, Next};
                                {ok, _OtherCanonical} -> {error, noncanonical};
                                {error, _} -> {error, malformed_material}
                            end;
                        error -> {error, malformed_material}
                    end;
                {{error, _} = Error, _Evidence} -> Error;
                {_Material, {error, _} = Error} -> Error
            end;
        {ok, Other}
          when is_tuple(Other), tuple_size(Other) >= 2,
               element(1, Other) =:= ?DOMAIN,
               element(2, Other) =/= ?VERSION ->
            {error, unsupported_version};
        {ok, _Other} ->
            {error, namespace_or_author_mismatch};
        _ ->
            {error, malformed_canonical_bytes}
    end;
decode_canonical_transaction(_Binding, _Canonical, _SymbolMode, _Context) ->
    {error, malformed_submission}.

decoded_result({ok, Transaction, _Context}) -> {ok, Transaction};
decoded_result({error, _} = Error) -> Error.

-doc "Decode bounded metadata from the one current V15 transaction envelope.".
-spec decode_submission_metadata(term()) ->
          {ok, #{target := {binary(), binary()},
                 admission := binary(), tx_id := binary(),
                 effects := [quod_effect:effect()], author := binary(),
                 sequence := non_neg_integer(),
                 role := term(), request_auth := term()}} |
          {error, malformed_submission}.
decode_submission_metadata(Canonical)
  when is_binary(Canonical),
       byte_size(Canonical) =< ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES ->
    case {quod_safe_term:validate_canonical(
            Canonical, ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES),
          quod_safe_term:decode(
            Canonical, ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES)} of
        {ok, {ok,
         {?DOMAIN, ?VERSION, Ns, <<_:256>> = Anchor,
          <<_:256>> = Admission, <<_:256>> = TxId,
          _Origin, _ProofId, _PlanDigest, _Goal, _Result,
          _MaterialWire, EffectsWire, Role, _Evidence,
          _ForeignReads,
          RequestAuth, _AuthTranscript,
          <<_:256>> = Author, Sequence, _SubmittedAt} = Decoded}}
          when is_binary(Ns), is_integer(Sequence), Sequence >= 0 ->
            case {term_to_binary(Decoded, [deterministic]) =:= Canonical,
                  quod_wire_term:decode_canonical(
                    EffectsWire, ?QUOD_MAX_DIRECT_EFFECT_BYTES)} of
                {true, {ok, Effects}} when is_list(Effects) ->
                    {ok, #{target => {Ns, Anchor}, admission => Admission,
                           tx_id => TxId, effects => Effects,
                           author => Author, sequence => Sequence,
                           role => Role, request_auth => RequestAuth}};
                _ ->
                    {error, malformed_submission}
            end;
        _ ->
            {error, malformed_submission}
    end;
decode_submission_metadata(_Canonical) ->
    {error, malformed_submission}.

-doc """
Select a ledger item by bounded, atom-safe metadata. This is NOT authentication:
the selected bytes must still pass decode_ledger_transaction/2 and finality.
Native values have already crossed that decoder. No material or goal is decoded
just to decide whether an unrelated item is wanted.
""".
-spec matches_selection(term(), binary() | #transaction{}) -> boolean().
matches_selection(Selection, Blob) when is_binary(Blob) ->
    case decode_canonical_term(Blob, ?QUOD_MAX_OPERATION_SUBMISSION_BYTES, wrapped) of
        {ok, {submit, _, _, Canonical}} ->
            case decode_submission_metadata(Canonical) of
                {ok, #{tx_id := Id, role := Role, request_auth := Auth}} ->
                    selection_matches(Selection, Id, Role, Auth);
                _ -> false
            end;
        {ok, {quod_genesis_transaction, 1, Id, _, _, _}} ->
            selection_matches(Selection, Id, application, none);
        _ -> false
    end;
matches_selection(Selection, #transaction{tx_id = Id, role = Role, request_auth = Auth}) ->
    selection_matches(Selection, Id, Role, Auth).

selection_matches({application, Id}, Id, _, _) -> true;
selection_matches({digest, 1, Digest}, Id, _, _) when is_binary(Id) ->
    crypto:hash(sha256, Id) =:= Digest;
selection_matches({digest, _, Id}, Id, _, _) -> true;
selection_matches({completion, Ref}, _, {remote_complete, Ref, _, _}, _) -> true;
selection_matches({claim, {operation, Ns, Anchor, Agent, OpId}}, _,
                  {remote_claim, _, _, _}, {agent_goal_v1, _, Bytes, _}) ->
    case quod_client_goal:decode(Bytes) of
        {ok, #{agent_namespace := Ns, agent_genesis_anchor := Anchor,
               operation_id := OpId, agent_instance_text := Text,
               parser_version := Version}} ->
            case quod_agent_ref:from_text(Ns, Anchor, Text, Version) of
                {ok, #{blob := Agent}} -> true;
                _ -> false
            end;
        _ -> false
    end;
selection_matches(_, _, _, _) -> false.

-doc "Encode one exact signed source claim for target operation custody.".
-spec encode_operation_submission(term()) ->
          {ok, binary()} | {error, invalid_operation_submission}.
encode_operation_submission(Submission) ->
    case operation_submission_context(Submission) of
        {ok, Blob, _Claim, _Plans} -> {ok, Blob};
        {error, _} = Error -> Error
    end.

%% Source custody encodes the whole claim. It does not choose a target or
%% materialize any target's effect; target custody later uses the exact
%% reservation/row identity with decode_operation_submission/2.
operation_claim_submission(Submission = {submit, Author, _Signature, Bytes}) ->
    try
        true = verify_submission(Submission),
        {ok, #{target := {Ns, Anchor}, admission := Admission, author := Author}} =
            decode_submission_metadata(Bytes),
        {ok, #transaction{role = {remote_claim, Manifest, _Bundles, _}} = Claim} =
            decode_verified_submission({Ns, Anchor, Admission}, Submission),
        {Ns, Anchor, Author, Admission} = quod_dtx:manifest_coordinator(Manifest),
        {ok, Plans} = claim_plans(Claim),
        true = lists:any(fun({Plan, _Context}) -> quod_dtx:effects_count(Plan) =:= 1 end, Plans),
        {ok, Claim}
    catch _:_ -> {error, invalid_operation_submission}
    end;
operation_claim_submission(_) -> {error, invalid_operation_submission}.

-doc "Authenticate source custody once, returning its exact bytes and opaque effect plans.".
-spec operation_submission_context(term()) ->
          {ok, binary(), #transaction{}, [quod_dtx:plan()]} |
          {error, invalid_operation_submission}.
operation_submission_context(Submission) ->
    case operation_claim_submission(Submission) of
        {ok, Claim} ->
            Blob = term_to_binary(Submission, [deterministic]),
            {ok, Plans} = claim_plans(Claim),
            case byte_size(Blob) =< ?QUOD_MAX_OPERATION_SUBMISSION_BYTES of
                true -> {ok, Blob, Claim,
                         [P || {P, _} <- Plans, quod_dtx:effects_count(P) =:= 1]};
                false -> {error, invalid_operation_submission}
            end;
        {error, _} = Error -> Error
    end.

-doc "Verify and decode one exact signed source claim used for operation custody.".
-spec decode_operation_submission(binary(), {binary(), <<_:256>>}) ->
          {ok,
           #{submission := term(), claim := #transaction{},
             claim_ref := term(), target := {binary(), <<_:256>>},
             target_ref := term(), plan := quod_dtx:plan(),
             plan_digest := <<_:256>>, manifest_digest := <<_:256>>,
             effect := quod_effect:effect(),
             author := <<_:256>>, admission := <<_:256>>,
             cancel_digest := <<_:256>>}} |
          {error, invalid_operation_submission}.
decode_operation_submission(Blob, Target)
  when is_binary(Blob),
       byte_size(Blob) =< ?QUOD_MAX_OPERATION_SUBMISSION_BYTES ->
    case quod_safe_term:decode(
           Blob, ?QUOD_MAX_OPERATION_SUBMISSION_BYTES) of
        {ok, Submission = {submit, _, _, _}} ->
            case term_to_binary(Submission, [deterministic]) =:= Blob of
                true -> operation_submission(Submission, Target);
                false -> {error, invalid_operation_submission}
            end;
        _ ->
            {error, invalid_operation_submission}
    end;
decode_operation_submission(_Blob, _Target) ->
    {error, invalid_operation_submission}.

%% The outer signature is checked while the transaction bytes are still
%% opaque. Only then may the fixed metadata reveal the exact source binding
%% needed by the existing canonical transaction decoder.
operation_submission(
  Submission = {submit, Author, Signature, Canonical}, Target) ->
    case verify_submission(Submission) of
        true ->
            operation_submission_metadata(
              Submission, Author, Signature,
              decode_submission_metadata(Canonical), Target);
        false ->
            {error, invalid_operation_submission}
    end.

operation_submission_metadata(
  Submission, Author, Signature,
  {ok, #{target := {OriginNs, OriginAnchor} = Origin,
         admission := Admission, author := Author}}, Target)
  when is_binary(OriginNs), byte_size(OriginNs) > 0 ->
    case decode_verified_submission(
           {OriginNs, OriginAnchor, Admission}, Submission) of
        {ok,
         Claim = #transaction{
                   tx_id = <<_:256>> = ClaimTxId,
                   origin = Origin,
                   role = {remote_claim, Manifest, _Bundles, _Predicted}}} ->
            case {quod_dtx:manifest_coordinator(Manifest), claim_plan(Claim, Target)} of
                {{OriginNs, OriginAnchor, Author, Admission}, {ok, {Plan, _Context}}} ->
                    operation_submission_plan(
                      Submission, Author, Signature, Admission, Claim,
                      {transaction, OriginNs, OriginAnchor, ClaimTxId}, Target,
                      quod_dtx:digest(Plan), quod_dtx:manifest_digest(Manifest), Plan);
                _ -> {error, invalid_operation_submission}
            end;
        _ ->
            {error, invalid_operation_submission}
    end;
operation_submission_metadata(
  _Submission, _Author, _Signature, _Metadata, _Target) ->
    {error, invalid_operation_submission}.

operation_submission_plan(
  Submission, Author, Signature, Admission, Claim, ClaimRef,
  Target, PlanDigest, ManifestDigest, Plan) ->
    case {quod_dtx:target(Plan) =:= Target,
          quod_dtx:digest(Plan) =:= PlanDigest,
          quod_dtx:material(Plan)} of
        {true, true, {ok, #{effects := [Effect]} = Material}} ->
            case quod_effect:validate_plan(Plan, Material) of
                true ->
                    operation_submission_application(
                      Submission, Author, Signature, Admission, Claim,
                      ClaimRef, Target, PlanDigest, ManifestDigest,
                      Plan, Effect);
                false ->
                    {error, invalid_operation_submission}
            end;
        _ ->
            {error, invalid_operation_submission}
    end.

operation_submission_application(
  Submission, Author, Signature, Admission, Claim, ClaimRef,
  {TargetNs, TargetAnchor} = Target, PlanDigest, ManifestDigest,
  Plan, Effect) ->
    try application_identity(operation_identity(Claim), Target, Plan) of
        {<<_:256>> = TargetTxId, _OperationRef, _RequestDigest} ->
            true = declared_application_matches(Claim, Target, TargetTxId),
            {ok,
             #{submission => Submission, claim => Claim,
               claim_ref => ClaimRef, target => Target,
               target_ref =>
                   {transaction, TargetNs, TargetAnchor, TargetTxId},
               plan => Plan, plan_digest => PlanDigest,
               manifest_digest => ManifestDigest, effect => Effect,
               author => Author, admission => Admission,
               cancel_digest =>
                   crypto:hash(
                     sha256,
                     <<?OPERATION_CANCEL_DOMAIN/binary, Signature/binary>>) }};
        _ ->
            {error, invalid_operation_submission}
    catch
        _:_ -> {error, invalid_operation_submission}
    end.

valid_role_fields(
  Target, #transaction{role = application, evidence = none,
                       goal = Goal, request_auth = RequestAuth,
                       auth_transcript = AuthTranscript}) ->
    valid_request_fields(Target, Goal, RequestAuth, AuthTranscript);
valid_role_fields(
  Target,
  Claim = #transaction{
            origin = Target,
            role = {remote_claim, Manifest, Bundles, Predicted},
            evidence = none, goal = Goal,
            diff = [], read_check = #{}, effects = [],
            request_auth =
              {agent_goal_v1, <<_:256>>, _Bytes, <<_:512>>},
            auth_transcript = none})
  when is_list(Bundles), is_list(Predicted), is_binary(Goal) ->
    case claim_plans(Claim) of
        {ok, Plans} ->
            quod_dtx:manifest_digest(Manifest) =:= Claim#transaction.plan_digest andalso
                lists:all(fun({Plan, Context}) -> Context =:=
                    #{proof_id => Claim#transaction.proof_id,
                           origin => Target,
                           principal => quod_dtx:principal(Plan),
                           goal => Claim#transaction.goal,
                           result => Claim#transaction.result,
                           plan_digest => quod_dtx:digest(Plan)} end, Plans) andalso
                predicted_remote_refs(Claim, Plans, Predicted);
        _ -> false
    end;
valid_role_fields(
  _Target,
  #transaction{role = {remote_application, ClaimRef, OperationRef,
                       <<_:256>> = RequestDigest},
               evidence = {CertifiedRef, #transaction{} = Claim},
               foreign_reads = ForeignReads,
               request_auth = none, auth_transcript = none}) ->
    ForeignReads =:= Claim#transaction.foreign_reads andalso
        stable_ref(CertifiedRef) =:= ClaimRef andalso
        certified_transaction_matches(CertifiedRef, Claim) andalso
        remote_claim_binding(Claim, OperationRef, RequestDigest);
valid_role_fields(
  Target,
  #transaction{role = {remote_complete, OperationRef,
                       <<_:256>> = RequestDigest, Receipt},
               evidence = {applications, Pairs},
               foreign_reads = [],
               diff = [], read_check = #{}, effects = [],
               request_auth = none, auth_transcript = none}) ->
    operation_origin(OperationRef) =:= Target andalso
        receipt_evidence_references(Receipt, Pairs) =/= error andalso
        lists:all(fun({_Ref, TargetTx}) ->
                      remote_application_binding(TargetTx, OperationRef, RequestDigest)
                  end, Pairs);
valid_role_fields(_Target, _Transaction) ->
    false.

foreign_reads_from_material(Material) ->
    canonical_foreign_reads_or_error(maps:get(foreign_reads, Material, [])).

-doc "Encode the canonical certificate list carried by a scope submission.".
-spec encode_foreign_reads([term()]) ->
          {ok, binary()} | {error, bad_foreign_reads | too_large}.
encode_foreign_reads(ForeignReads) ->
    case canonical_foreign_reads(ForeignReads) of
        {ok, Canonical} ->
            case encode_read_certificates(Canonical, []) of
                {ok, RevBlobs} ->
                    Blob = term_to_binary(
                             {quod_foreign_reads, 1,
                              lists:reverse(RevBlobs)}, [deterministic]),
                    case byte_size(Blob) =< ?QUOD_MAX_DTX_BODY_BYTES of
                        true -> {ok, Blob};
                        false -> {error, too_large}
                    end;
                error ->
                    {error, bad_foreign_reads}
            end;
        error ->
            {error, bad_foreign_reads}
    end.

-doc "Decode the canonical certificate list carried by a scope submission.".
-spec decode_foreign_reads(binary()) ->
          {ok, [term()]} | {error, bad_foreign_reads | too_large}.
decode_foreign_reads(Blob)
  when is_binary(Blob), byte_size(Blob) =< ?QUOD_MAX_DTX_BODY_BYTES ->
    case quod_safe_term:decode(Blob, ?QUOD_MAX_DTX_BODY_BYTES) of
        {ok, {quod_foreign_reads, 1, CertificateBlobs}}
          when is_list(CertificateBlobs) ->
            case decode_read_certificates(CertificateBlobs, []) of
                {ok, RevCertificates} ->
                    Certificates = lists:reverse(RevCertificates),
                    case canonical_foreign_reads(Certificates) of
                        {ok, Certificates} ->
                            case encode_foreign_reads(Certificates) of
                                {ok, Blob} -> {ok, Certificates};
                                _ -> {error, bad_foreign_reads}
                            end;
                        error -> {error, bad_foreign_reads}
                    end;
                error -> {error, bad_foreign_reads}
            end;
        _ -> {error, bad_foreign_reads}
    end;
decode_foreign_reads(Blob) when is_binary(Blob) ->
    {error, too_large};
decode_foreign_reads(_) ->
    {error, bad_foreign_reads}.

encode_read_certificates([], RevBlobs) ->
    {ok, RevBlobs};
encode_read_certificates([Certificate | Rest], RevBlobs) ->
    case quod_read_certificate:encode(Certificate) of
        {ok, Blob} -> encode_read_certificates(Rest, [Blob | RevBlobs]);
        {error, _} -> error
    end.

decode_read_certificates([], RevCertificates) ->
    {ok, RevCertificates};
decode_read_certificates([Blob | Rest], RevCertificates) when is_binary(Blob) ->
    case quod_read_certificate:decode(Blob) of
        {ok, Certificate} ->
            decode_read_certificates(Rest, [Certificate | RevCertificates]);
        {error, _} -> error
    end;
decode_read_certificates(_Malformed, _RevCertificates) ->
    error.

canonical_foreign_reads_or_error(ForeignReads) ->
    case canonical_foreign_reads(ForeignReads) of
        {ok, Canonical} -> Canonical;
        error -> error(bad_foreign_reads)
    end.

canonical_foreign_reads(ForeignReads) when is_list(ForeignReads) ->
    case lists:all(fun quod_read_certificate:valid_shape/1, ForeignReads) of
        true ->
            Canonical = lists:usort(ForeignReads),
            case Canonical =:= ForeignReads of
                true -> {ok, Canonical};
                false -> error
            end;
        false -> error
    end;
canonical_foreign_reads(_ForeignReads) ->
    error.

predicted_remote_refs(Claim, Plans, Predicted) ->
    %% The bound request claim and one source semantic-ID derivation feed the
    %% whole vector, including N=1. No target repeats the request authentication.
    try predicted_applications(operation_identity(Claim), Plans) of
        Predicted -> true;
        _ -> false
    catch _:_ -> false
    end.

remote_claim_binding(
  #transaction{role = {remote_claim, _Manifest, _Bundle, _Predicted}} = Claim,
  OperationRef, RequestDigest) ->
    case request_claim(Claim) of
        {ok, #{operation_ref := OperationRef, digest := RequestDigest}} -> true;
        _ -> false
    end;
remote_claim_binding(_, _, _) -> false.

remote_application_binding(
  #transaction{role = {remote_application, _ClaimRef,
                       OperationRef, RequestDigest}},
  OperationRef, RequestDigest) -> true;
remote_application_binding(_, _, _) -> false.

operation_origin({operation, Ns, <<_:256>> = Anchor, _Agent, <<_:256>>})
  when is_binary(Ns) -> {Ns, Anchor};
operation_origin(_) -> invalid.

decode_material(MaterialWire, EffectsWire, SymbolMode) ->
    case {quod_wire_term:decode_canonical(
            MaterialWire, ?QUOD_MAX_CANONICAL_TRANSACTION_BYTES),
          quod_wire_term:decode_canonical(
            EffectsWire, ?QUOD_MAX_DIRECT_EFFECT_BYTES)} of
        {{ok, {Diff0, ReadPairs0}}, {ok, Effects0}}
          when is_list(Diff0), is_list(ReadPairs0), is_list(Effects0) ->
            case quod_read_set:valid_pairs(ReadPairs0) of
                true -> decode_material_pairs(Diff0, ReadPairs0, Effects0, SymbolMode);
                false -> {error, malformed_material}
            end;
        _ ->
            {error, malformed_material}
    end.

decode_material_pairs(Diff0, ReadPairs0, Effects0, SymbolMode) ->
    case materialize_decoded({Diff0, ReadPairs0, Effects0}, SymbolMode) of
        {ok, {Diff, ReadPairs, Effects}} ->
            %% The wire list was checked before materialization;
            %% a map cannot establish canonicality or uniqueness.
            ReadCheck = maps:from_list(ReadPairs),
            case quod_effect:validate_list(Effects) of
                true -> {ok, Diff, ReadCheck, Effects};
                false -> {error, malformed_material}
            end;
        {error, _} = Error ->
            Error
    end.

materialize_decoded(Term, wrapped) -> {ok, Term};
materialize_decoded(Term, materialized) ->
    quod_wire_term:materialize_symbols(Term).

decode_canonical_term(Blob, MaxBytes, wrapped) ->
    quod_safe_term:decode_wrapped(Blob, MaxBytes);
decode_canonical_term(Blob, MaxBytes, materialized) ->
    case {quod_safe_term:validate_canonical(Blob, MaxBytes),
          quod_safe_term:decode(Blob, MaxBytes)} of
        {ok, {ok, Term}} -> {ok, Term};
        {{error, Reason}, _} -> {error, Reason};
        {_, {error, Reason}} -> {error, Reason}
    end.
