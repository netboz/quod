-module(quod_client_http_tests).
-moduledoc """
Handler tests that go through a real listener.

The routes are exercised over HTTPS rather than by calling `init/2` directly,
because the defect worth catching here lives in the seam between the handler and
cowboy. A handler that replies correctly but returns the wrong shape still
delivers its response — cowboy has already sent the bytes — and then crashes its
request process, so **every status assertion passes while every request logs a
crash**. That is exactly the state this module was written against, so the
assertions include the absence of crash reports, not only the responses.
""".

-include_lib("eunit/include/eunit.hrl").
-include("quod_client_goal_limits.hrl").
-include_lib("opentelemetry/include/otel_span.hrl").

%% The logger handler used by collect_crashes/1.
-export([log/2]).

-define(PEER, {127, 0, 0, 1}).

outcome_unknown_is_pending_test() ->
    Ns = <<"quod:target">>,
    Anchor = <<7:256>>,
    TxId = <<8:256>>,
    ?assertEqual(
       {202, #{result => pending, ns => Ns,
               anchor => binary:encode_hex(Anchor, lowercase),
               tx_id => binary:encode_hex(TxId, lowercase)}},
       signed_proof_reply(
         {error, {outcome_unknown,
                  {transaction, Ns, Anchor, TxId}}})).

group_commit_and_unknown_are_json_safe_test() ->
    Ns = <<"quod:origin">>,
    Anchor = <<31:256>>,
    Coordinator = <<32:256>>,
    Admission = <<33:256>>,
    GroupId = <<34:256>>,
    Ref = {group, Ns, Anchor, Coordinator, Admission, GroupId},
    Target = {<<"quod:target">>, <<35:256>>},
    {200, Committed} = signed_proof_reply(
                         {ok, [#{0 => linked}],
                          #{ref => Ref, height => 9,
                            participant_slots =>
                              [{{Ns, Anchor}, 8, 1},
                               {Target, 7, 2}]}}),
    ?assertEqual(ok, maps:get(result, Committed)),
    ?assertEqual(binary:encode_hex(GroupId, lowercase),
                 maps:get(group_id, Committed)),
    ?assertEqual(2, length(maps:get(participant_slots, Committed))),
    ?assert(is_binary(iolist_to_binary(json:encode(Committed)))),
    {202, Pending} = signed_proof_reply(
                       {error, {outcome_unknown, Ref}}),
    ?assertEqual(pending, maps:get(result, Pending)),
    ?assertEqual(binary:encode_hex(Coordinator, lowercase),
                 maps:get(coordinator, Pending)).

invalid_action_is_a_bad_request_test() ->
    ?assertEqual(
       {400, #{error => invalid_action}},
       signed_proof_reply({error, invalid_action})).

foreign_commit_is_json_safe_test() ->
    Ns = <<"quod:target">>,
    Anchor = <<12:256>>,
    TxId = <<13:256>>,
    Reply =
        {200, #{result => ok, bindings => [#{}], ns => Ns,
                anchor => binary:encode_hex(Anchor, lowercase),
                tx_id => binary:encode_hex(TxId, lowercase)}},
    ?assertEqual(
       Reply,
       signed_proof_reply(
         {ok, [#{}], {transaction, Ns, Anchor, TxId}})),
    {200, JsonMap} = Reply,
    ?assert(is_binary(iolist_to_binary(json:encode(JsonMap)))).

failure_reasons_are_rendered_test() ->
    ?assertEqual(
       {200, #{result => fail,
               reasons => [<<"outer(bob)">>, <<"missing(bob)">>]}},
       signed_proof_reply(
         {fail, [{outer, bob}, {missing, bob}]})).

%% These payload assertions used to keep an uncalled explorer proof API alive.
%% Exercise the signed client normalizer/HTTP path instead, including its
%% request binding, before comparing the same public outcome fields.
signed_proof_reply(Raw) ->
    Evidence = #{request_digest => <<91:256>>,
                 request => #{operation_id => <<92:256>>},
                 variables => [{<<"X">>, 0}]},
    {Code, Json} = quod_client_http:signed_goal_result(
      {ok, Evidence, {normalized, quod_client_result:normalize(Evidence, Raw)}}),
    case Code of
        N when N =:= 200; N =:= 202 ->
            ?assertEqual(b64url(<<91:256>>), maps:get(request_digest, Json)),
            ?assertEqual(b64url(<<92:256>>), maps:get(operation_id, Json));
        _ -> ok
    end,
    {Code, maps:without([request_digest, operation_id], Json)}.


signed_goal_result_keeps_parser_variable_names_test() ->
    Evidence = #{request_digest => <<1:256>>,
                 request => #{operation_id => <<2:256>>},
                 variables => [{<<"Person">>, 0}]},
    ?assertEqual(
       {200, #{result => ok, height => 7,
               request_digest => b64url(<<1:256>>),
               operation_id => b64url(<<2:256>>),
               bindings => [#{<<"Person">> => <<"bob">>}]}},
       quod_client_http:signed_goal_result(
         {ok, Evidence,
          {normalized,
           quod_client_result:normalize(Evidence,
                                        {ok, [#{0 => bob}], 7})}})),
    ?assertEqual(
       {409, #{error => read_only}},
       quod_client_http:signed_goal_result(
         {ok, Evidence, {normalized, {error, read_only}}})).

signed_operation_resolution_has_one_pending_and_terminal_shape_test() ->
    Evidence = #{request_digest => <<1:256>>,
                 request => #{operation_id => <<2:256>>}},
    ?assertEqual(
       {202, #{result => operation_outcome, status => pending,
               terminal => false,
               request_digest => b64url(<<1:256>>),
               operation_id => b64url(<<2:256>>)}},
       quod_client_http:signed_goal_result(
         {ok, Evidence, {operation_pending, ignored}})),
    ?assertEqual(
       {200, #{result => operation_outcome, status => committed,
               terminal => true, claim_height => 3, height => 4,
               request_digest => b64url(<<1:256>>),
               operation_id => b64url(<<2:256>>)}},
       quod_client_http:signed_goal_result(
         {ok, Evidence,
          {operation_outcome, #{height => 3},
           #{status => committed, height => 4}}})),
    ?assertEqual(
       {409, #{error => operation_conflict}},
       quod_client_http:signed_goal_result({error, operation_conflict})).

refused_group_resolution_does_not_invent_an_operation_claim_test() ->
    Evidence = #{request_digest => <<1:256>>, request => #{operation_id => <<2:256>>}},
    Ref = {group, <<"source">>, <<3:256>>, <<4:256>>, <<5:256>>, <<6:256>>},
    {202, Pending} = quod_client_http:signed_goal_result(
        {ok, Evidence, {group_outcome, Ref, #{status => pending}}}),
    ?assertMatch(#{result := group_outcome, terminal := false}, Pending),
    {200, Terminal} = quod_client_http:signed_goal_result(
        {ok, Evidence, {group_outcome, Ref,
            #{status => aborted, height => 7, reasons => [vote_deadline]}}}),
    ?assertMatch(#{result := group_outcome, status := aborted, terminal := true}, Terminal),
    ?assertEqual(binary:encode_hex(<<6:256>>, lowercase), maps:get(group_id, Terminal)),
    ?assertNot(maps:is_key(claim_height, Terminal)),
    ?assert(is_binary(iolist_to_binary(json:encode(Terminal)))).

recovered_group_result_preserves_exact_named_bindings_test() ->
    Evidence = #{request_digest => <<1:256>>,
                 request => #{operation_id => <<2:256>>}},
    Ref = {ontology_ref, <<"a-personal-lobby">>, <<0, 255, 128, 17, 0:224>>},
    {200, Reply} = quod_client_http:signed_goal_result(
        {ok, Evidence, {operation_outcome, #{height => 3},
            #{status => committed, height => 4,
              bindings => [{<<"Lobby">>, Ref}, {<<"Label">>, <<"console">>}]}}}),
    ?assertEqual([#{<<"Lobby">> => quod_client_goal_parser:value_text(Ref),
                   <<"Label">> => quod_client_goal_parser:value_text(<<"console">>)}],
                 maps:get(bindings, Reply)),
    ?assertEqual(true, maps:get(terminal, Reply)),
    ?assert(is_binary(iolist_to_binary(json:encode(Reply)))).

signed_goal_busy_is_not_misreported_as_cursor_contention_test() ->
    ?assertEqual(
       {503, #{error => ontology_busy}},
       quod_client_http:signed_goal_result({error, busy})),
    ?assertEqual(
       {409, #{error => cursor_busy}},
       quod_client_http:signed_goal_result({error, cursor_busy})),
    ?assertEqual(
       {404, #{error => cursor_not_found}},
       quod_client_http:signed_goal_result({error, cursor_not_found})).

signed_dispatch_parent_and_cleanup_test() ->
    quod_trace_tests:with_tracer(fun() ->
        Before = quod_trace:context(),
        Req = #{headers =>
                  #{<<"traceparent">> => trace_parent(),
                    <<"baggage">> => <<"private=must-not-be-carried">>,
                    <<"authorization">> => <<"private-authentication">>}},
        Result = quod_client_http:test_trace_request(
            Req, signed_goal_execute,
            fun() ->
                Carrier = quod_trace:inject(quod_trace:context()),
                ?assertNot(lists:keymember(<<"baggage">>, 1, Carrier)),
                quod_trace:with_span(
                  quod_trace:context(), <<"http.child">>, internal, #{},
                  fun(_) -> {ok, unchanged} end)
            end),
        ?assertEqual({ok, unchanged}, Result),
        ?assertEqual(Before, quod_trace:context()),
        Span = quod_trace_tests:take_span(<<"quod.client.request">>),
        Child = quod_trace_tests:take_span(<<"http.child">>),
        ?assertEqual(16#4bf92f3577b34da6a3ce929d0e0e4736,
                     Span#span.trace_id),
        ?assertEqual(16#00f067aa0ba902b7, Span#span.parent_span_id),
        ?assertEqual(server, Span#span.kind),
        ?assertEqual(Span#span.span_id, Child#span.parent_span_id),
        ?assertEqual(
           #{'quod.client.route' => <<"signed_goal_execute">>},
           otel_attributes:map(Span#span.attributes))
    end).

signed_dispatch_exception_preserves_reply_semantics_test() ->
    quod_trace_tests:with_tracer(fun() ->
        Before = quod_trace:context(),
        Req = #{headers => #{<<"traceparent">> => trace_parent()}},
        Reason = {private_failure, <<"never-export-this-payload">>},
        ?assertThrow(Reason,
          quod_client_http:test_trace_request(
            Req, signed_goal_read, fun() -> throw(Reason) end)),
        ?assertEqual(Before, quod_trace:context()),
        Span = quod_trace_tests:take_span(<<"quod.client.request">>),
        ?assert(Span#span.end_time >= Span#span.start_time),
        ?assertEqual(
           #{'quod.client.route' => <<"signed_goal_read">>,
             'quod.outcome' => <<"http_dispatch">>},
           otel_attributes:map(Span#span.attributes)),
        ?assertEqual(opentelemetry:status(error), Span#span.status)
    end).

client_http_test_() ->
    {setup, fun setup/0, fun cleanup/1,
     fun(Port) ->
         [{"health replies and keeps the connection",
           fun() -> health_is_reusable(Port) end},
          {"an API reply does not crash its request process",
           fun() -> api_reply_is_clean(Port) end},
          {"every route honours the handler contract",
           fun() -> routes_are_crash_free(Port) end},
          {"an oversized body is refused",
           fun() -> oversized_body_is_refused(Port) end},
          {"a non-POST is refused",
           fun() -> method_is_enforced(Port) end},
          {"security headers are present",
           fun() -> security_headers_present(Port) end},
          {"group selectors are bounded and retain signed session admission",
           fun() -> group_selector_http_boundary(Port) end},
          {"sampled HTTP parent reaches the signed request span",
           fun() -> signed_http_parent_is_carried(Port) end}]
     end}.

%% Two requests on ONE connection: cowboy tears the connection down when a
%% handler breaks its contract, so a successful second request is the assertion.
health_is_reusable(Port) ->
    {ok, Connection} = connect(Port),
    ?assertMatch({200, _, <<"ok\n">>}, quod_ct:https_request(Connection, get, "/health", <<>>)),
    ?assertMatch({200, _, <<"ok\n">>}, quod_ct:https_request(Connection, get, "/health", <<>>)),
    close(Connection).

group_selector_http_boundary(Port) ->
    {ok, Connection} = connect(Port),
    Ref = #{ns => <<"source">>, anchor => binary:encode_hex(<<1:256>>, lowercase),
            coordinator => binary:encode_hex(<<2:256>>, lowercase),
            coordinator_admission => binary:encode_hex(<<3:256>>, lowercase),
            group_id => binary:encode_hex(<<4:256>>, lowercase)},
    Body = #{session_id => b64url(<<0:256>>), request => b64url(<<>>),
             signature => b64url(<<0:512>>)},
    try
        lists:foreach(fun(Invalid) ->
            Encoded = iolist_to_binary(json:encode(Body#{outcome_ref => Invalid})),
            ?assertMatch({400, _, _},
                quod_ct:https_request(Connection, post, "/api/goals/outcomes", Encoded))
        end, [#{}, Ref#{group_id := <<"invalid">>}, Ref#{extra => true}]),
        Encoded = iolist_to_binary(json:encode(Body#{outcome_ref => Ref})),
        ?assertMatch({401, _, _},
            quod_ct:https_request(Connection, post, "/api/goals/outcomes", Encoded))
    after close(Connection)
    end.

api_reply_is_clean(Port) ->
    {ok, Connection} = connect(Port),
    %% Malformed on purpose: the reply's content is not the point, surviving it
    %% is. A bad field is a bad request, never a failed authentication.
    ?assertMatch({400, _, _},
                 quod_ct:https_request(Connection, post, "/api/auth/challenge", <<"{}">>)),
    ?assertMatch({400, _, _},
                 quod_ct:https_request(Connection, post, "/api/auth/complete", <<"nonsense">>)),
    ?assertMatch({404, _, _},
                 quod_ct:https_request(Connection, post, "/api/user/register", <<"{}">>)),
    ?assertMatch({400, _, _},
                 quod_ct:https_request(Connection, post, "/api/goals/read", <<"{}">>)),
    %% Still usable, so none of those replies killed the stream.
    ?assertMatch({200, _, _}, quod_ct:https_request(Connection, get, "/health", <<>>)),
    close(Connection).

%% The real signal for a broken handler contract: cowboy sends the response and
%% *then* the request process dies, so only the crash report distinguishes a
%% healthy route from one that raises on every single call.
routes_are_crash_free(Port) ->
    Crashes = collect_crashes(
                fun() ->
                    {ok, Connection} = connect(Port),
                    _ = quod_ct:https_request(Connection, get, "/health", <<>>),
                    _ = quod_ct:https_request(Connection, post, "/api/auth/challenge", <<"{}">>),
                    _ = quod_ct:https_request(Connection, post, "/api/auth/complete", <<"{}">>),
                    _ = quod_ct:https_request(Connection, post, "/api/user/register", <<"{}">>),
                    _ = quod_ct:https_request(Connection, post, "/api/goals/read", <<"{}">>),
                    _ = quod_ct:https_request(Connection, post, "/api/goals/execute", <<"{}">>),
                    _ = quod_ct:https_request(Connection, post, "/api/goals/outcomes", <<"{}">>),
                    _ = quod_ct:https_request(Connection, post, "/api/goals/cursors", <<"{}">>),
                    _ = quod_ct:https_request(Connection, get, "/api/auth/challenge", <<>>),
                    _ = quod_ct:https_request(Connection, post, "/api/auth/challenge",
                                binary:copy(<<"A">>, 8192)),
                    close(Connection)
                end),
    ?assertEqual([], Crashes).

%% `length` in cowboy_req:read_body/2 is a chunk hint, not a limit, so a body
%% delivered in one piece arrives whole however large it is.
oversized_body_is_refused(Port) ->
    {ok, Connection} = connect(Port),
    Body = <<"{\"public_key\":\"", (binary:copy(<<"A">>, 8192))/binary, "\"}">>,
    ?assertMatch({413, _, _},
                 quod_ct:https_request(Connection, post, "/api/auth/challenge", Body)),
    %% Pin the independent, larger cap on the signed-goal route as well.  Raw
    %% junk is intentional: body admission must happen before JSON decoding.
    SignedGoalBody = binary:copy(
                       <<"A">>, ?QUOD_CLIENT_GOAL_REQUEST_BYTES * 2),
    ?assertMatch({413, _, _},
                 quod_ct:https_request(Connection, post, "/api/goals/read", SignedGoalBody)),
    close(Connection).

method_is_enforced(Port) ->
    {ok, Connection} = connect(Port),
    ?assertMatch({405, _, _},
                 quod_ct:https_request(Connection, get, "/api/auth/challenge", <<>>)),
    close(Connection).

security_headers_present(Port) ->
    {ok, Connection} = connect(Port),
    {200, Headers, _} = quod_ct:https_request(Connection, get, "/health", <<>>),
    ?assertMatch(#{<<"content-security-policy">> := _}, Headers),
    CSP = maps:get(<<"content-security-policy">>, Headers),
    ?assertNotEqual(nomatch, binary:match(CSP, <<"img-src 'self' data: blob:">>)),
    ?assertEqual(<<"nosniff">>, maps:get(<<"x-content-type-options">>, Headers)),
    Digest = <<"ad1f1cbe8c100fd774e315b629d0bb1082820c9a7abe2a2a999aef846d675064">>,
    Path = binary_to_list(<<"/assets/models/", Digest/binary, ".glb">>),
    {200, AssetHeaders, ModelBytes} = quod_ct:https_request(Connection, get, Path, <<>>),
    ?assertEqual(CSP, maps:get(<<"content-security-policy">>, AssetHeaders)),
    ?assertEqual(Digest, binary:encode_hex(crypto:hash(sha256, ModelBytes), lowercase)),
    close(Connection).

signed_http_parent_is_carried(Port) ->
    quod_trace_tests:with_tracer(fun() ->
        {ok, Connection} = connect(Port),
        try
            %% Malformed goal JSON still follows the real signed HTTP dispatch:
            %% validation refusal must finish the same incoming-parent span.
            ?assertMatch({400, _, _},
              quod_ct:https_request(Connection, post, "/api/goals/execute", <<"{}">>,
                      [[<<"traceparent: ">>, trace_parent(), <<"\r\n">>],
                       <<"baggage: private=not-a-trace-attribute\r\n">>])),
            Span = quod_trace_tests:take_span(<<"quod.client.request">>),
            ?assertEqual(16#4bf92f3577b34da6a3ce929d0e0e4736,
                         Span#span.trace_id),
            ?assertEqual(16#00f067aa0ba902b7, Span#span.parent_span_id),
            ?assertEqual(true, Span#span.parent_span_is_remote),
            ?assertEqual(server, Span#span.kind),
            ?assertNot(Span#span.is_recording),
            ?assert(Span#span.end_time >= Span#span.start_time),
            ?assertMatch({200, _, _}, quod_ct:https_request(Connection, get, "/health", <<>>))
        after close(Connection)
        end
    end).

trace_parent() ->
    <<"00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01">>.

%% ======================================================================
%% harness
%% ======================================================================

%% Run `Fun` with a logger handler attached, and report the error-level reports
%% cowboy emitted while it ran.
collect_crashes(Fun) ->
    Collector = self(),
    Id = list_to_atom("crash-collector-" ++
                          integer_to_list(erlang:unique_integer([positive]))),
    ok = logger:add_handler(
           Id, ?MODULE, #{level => error, config => #{collector => Collector}}),
    try
        Fun(),
        %% Requests are answered before their process dies, so a crash report
        %% can trail the response it belongs to.
        timer:sleep(100),
        drain()
    after logger:remove_handler(Id)
    end.

drain() ->
    receive {crash_report, Report} -> [Report | drain()]
    after 0 -> []
    end.

%% logger handler callback.
log(#{level := Level, msg := Msg}, #{config := #{collector := Collector}})
  when Level =:= error; Level =:= critical ->
    Collector ! {crash_report, Msg},
    ok;
log(_Event, _Config) ->
    ok.

setup() ->
    {ok, _} = application:ensure_all_started(ssl),
    {ok, _} = application:ensure_all_started(cowboy),
    {ok, _} = application:ensure_all_started(gproc),
    Dir = tls_dir(),
    {ok, Tls} = quod_client_tls:ensure(Dir),
    {ok, _} = quod_client_auth:start_link(
                #{network_id => <<16#10:256>>, node_key => <<16#11:256>>}),
    {ok, started} =
        quod_http_listener:start(
          #{name => ?MODULE, ip => ?PEER, port => 0, routes => routes(),
            stream_handlers => [quod_http_headers_h], tls => Tls}),
    ranch:get_port(?MODULE).

cleanup(_Port) ->
    quod_http_listener:stop(?MODULE),
    case whereis(quod_client_auth) of
        undefined -> ok;
        Pid ->
            unlink(Pid),
            MRef = monitor(process, Pid),
            exit(Pid, shutdown),
            receive {'DOWN', MRef, process, Pid, _} -> ok after 5000 -> ok end
    end.

routes() ->
    [{'_', [{"/health", quod_client_http, health},
            {"/assets/[...]", cowboy_static, {priv_dir, quod, "explorer/assets"}},
            {"/api/auth/challenge", quod_client_http, auth_challenge},
            {"/api/auth/complete", quod_client_http, auth_complete},
            {"/api/goals/read", quod_client_http, signed_goal_read},
            {"/api/goals/execute", quod_client_http, signed_goal_execute},
            {"/api/goals/outcomes", quod_client_http, signed_goal_outcome},
            {"/api/goals/cursors", quod_client_http, signed_goal_cursor},
            {"/api/goals/cursors/:id/next", quod_client_http,
             signed_cursor_next},
            {"/api/goals/cursors/:id/accept", quod_client_http,
             signed_cursor_accept},
            {"/api/goals/cursors/:id", quod_client_http,
             signed_cursor_stop}]}].

tls_dir() ->
    Dir = filename:join(["/tmp", "quod-client-http-tests",
                         integer_to_list(erlang:unique_integer([positive]))]),
    ok = filelib:ensure_path(Dir),
    Dir.

%% A hand-written HTTP/1.1 exchange rather than an HTTP client dependency: the
%% point of these tests is precisely what a client library hides — whether the
%% connection survives a response — so the socket stays visible.
connect(Port) ->
    %% Self-signed by design; these tests are about the handler, not the chain.
    ssl:connect("127.0.0.1", Port,
                [binary, {active, false}, {verify, verify_none}], 5000).

close(Socket) -> ssl:close(Socket).

b64url(Bytes) ->
    base64:encode(Bytes, #{mode => urlsafe, padding => false}).
