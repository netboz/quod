-module(quod_dtx_current_view_tests).

-include_lib("eunit/include/eunit.hrl").
-include_lib("opentelemetry/include/otel_span.hrl").
-include("quod_ledger.hrl").
-include("quod_proof_limits.hrl").

deadline(TimeoutMs) -> quod_time:mono_ms() + TimeoutMs.

peer_address_selection_is_not_committee_evidence_test_() ->
    [{atom_to_list(Family) ++ "/" ++ atom_to_list(First), fun() ->
        with_peer_observation(Family, remote, fun(Key, Deps0, Invoke, Reply) ->
            Fresh = {"127.0.0.1", 31999},
            Calls = atomics:new(1, []),
            Remote = fun(_, _, Pinned, Endpoint, Request, Timeout) ->
                ?assertEqual(Key, Pinned),
                ?assert(Timeout > 0 andalso Timeout =< 1000),
                case atomics:add_get(Calls, 1, 1) of
                    1 ->
                        ?assertEqual(Fresh, Endpoint),
                        peer_first_reply(First, Family, Request, Reply);
                    2 ->
                        ?assertNotEqual(Fresh, Endpoint),
                        Reply(Request);
                    _ -> error(repeated_peer_address)
                end
            end,
            Deps = Deps0#{resolve := fun(K) -> ?assertEqual(Key, K), {ok, Fresh} end,
                          remote := Remote},
            Result = Invoke(Deps),
            case First of
                not_ready -> ?assertEqual({error, retry}, Result);
                invalid_evidence -> ?assertEqual({error, retry}, Result);
                _ -> ?assertMatch({ok, _}, Result)
            end,
            Expected = case First of not_ready -> 1; invalid_evidence -> 1; _ -> 2 end,
            ?assertEqual(Expected, atomics:get(Calls, 1))
        end)
    end} || Family <- [applied, read_attest, outcome, operation_applied],
            First <- [not_ready, invalid_evidence, wrong_correlation, transport_failure]].

local_observations_use_the_same_correlation_gate_test_() ->
    [{atom_to_list(Family), fun() ->
        with_peer_observation(Family, local, fun(Key, Deps0, Invoke, Reply) ->
            Deps = Deps0#{node_key := fun() -> Key end,
              local := fun(_, Request, _) ->
                  peer_first_reply(wrong_correlation, Family, Request, Reply)
              end,
              remote := fun(_, _, _, _, _, _) -> error(local_observation_routed) end},
            ?assertEqual({error, retry}, Invoke(Deps))
        end)
    end} || Family <- [applied, read_attest, outcome, operation_applied]].

%% Production collectors and signature verifiers run unchanged; only I/O is
%% supplied by the fixture. These are not full consensus-node witnesses.
with_peer_observation(operation_applied, _Location, Fun) ->
    quod_operation_fixture:with(1, fun(F) ->
        #{pubkey := Key} = Signer = maps:get(node_identity, F),
        Ref = maps:get(certified_target_ref, F),
        Evidence = (maps:get(evidence, F))#{routes => #{Key => {"127.0.0.1", 34249}}},
        Network = maps:get(network, F),
        Deps = #{resolve => fun(_) -> error end, node_key => fun() -> none end,
                 network_identity => fun() -> {ok, Network} end,
                 local => fun(_, _, _) -> error(unused_local) end,
                 remote => fun(_, _, _, _, _, _) -> error(unused_remote) end},
        Invoke = fun(D) -> quod_dtx_current_view:test_certify_operation(
            maps:get(source_ns, F), Ref, Evidence, deadline(1000), D) end,
        Reply = fun({operation_applied, Id, Ref0}) ->
            ?assertEqual(Ref, Ref0),
            {ok, Statement} = quod_applied_certificate:operation_statement(Network, Evidence, applied),
            {ok, {Key, Signature}} = quod_applied_certificate:sign_operation_vote(Statement, Signer),
            {ok, {operation_applied, Id, Ref, Statement, Key, Signature}, []}
        end,
        Fun(Key, Deps, Invoke, Reply)
    end);
with_peer_observation(Family, Location, Fun) ->
    F = fixture(1), [Key] = maps:get(committee, F),
    Source = case Location of remote -> source(F); local -> {local, local_source(F)} end,
    {Invoke, Reply} = case Family of
        applied -> {fun(D) -> quod_dtx_current_view:test_certify_applied(
                        maps:get(owner_ns, F), Source, maps:get(claim, F),
                        maps:get(evidence, F), 1000, D) end,
                    fun(R) -> applied_reply(F, Key, R) end};
        read_attest ->
            Plan = read_plan_blob(F, <<"peer_walk">>),
            {fun(D) -> quod_dtx_current_view:test_certify_reads(
                maps:get(owner_ns, F), {Source, Plan}, deadline(1000), D) end,
             fun(R) -> read_attest_reply(F, Key, R) end};
        outcome ->
            Ref = outcome_group_ref(F, Key),
            {fun(D) -> quod_dtx_current_view:test_lookup_outcome(
                maps:get(owner_ns, F), Source, Ref, deadline(1000), D) end,
             fun(R) -> outcome_reply(R, maps:get(target, F), maps:get(committee_id, F),
                                     8, group_committed(Ref)) end}
    end,
    Fun(Key, dependencies(F, fun(_, _) -> error(unused_transport) end), Invoke, Reply).

peer_first_reply(not_ready, _, Request, _) ->
    {ok, {error, element(2, Request), not_ready}, []};
peer_first_reply(transport_failure, _, _, _) -> {error, closed};
peer_first_reply(wrong_correlation, _, Request, Reply) ->
    {ok, Response, Hints} = Reply(Request),
    {ok, setelement(2, Response, crypto:strong_rand_bytes(16)), Hints};
peer_first_reply(invalid_evidence, outcome, Request, Reply) ->
    {ok, Response, Hints} = Reply(Request),
    Status = element(6, Response),
    {ok, setelement(6, Response,
                     #{status => pending, phase => pending_vote, ref => maps:get(ref, Status)}), Hints};
peer_first_reply(invalid_evidence, _, Request, Reply) ->
    {ok, Response, Hints} = Reply(Request),
    {ok, setelement(tuple_size(Response), Response, <<0:512>>), Hints}.

quorum_collection_has_one_parent_and_preserves_result_test_() ->
    [{atom_to_list(Outcome), fun() ->
        quod_trace_tests:with_tracer(fun() ->
            F = fixture(1),
            Reply = case Outcome of
                committed -> fun(Key, Request) -> applied_reply(F, Key, Request) end;
                retry -> fun(_Key, _Request) -> {error, not_ready} end
            end,
            Deps = dependencies(F, Reply),
            {Ctx, Parent} = quod_trace:start_span(
              otel_ctx:new(), <<"quorum.collection.test">>, internal, #{}),
            try
                Result = quod_trace:with_context(Ctx, fun() -> certify(F, Deps) end),
                case Outcome of
                    committed -> ?assertMatch({ok, _}, Result);
                    retry -> ?assertEqual({error, retry}, Result)
                end,
                TraceId = otel_span:trace_id(Parent),
                Collection = quod_trace_tests:take_span(<<"quod.dtx.quorum.collect">>, TraceId),
                Probe = quod_trace_tests:take_span(<<"quod.dtx.quorum.probe">>, TraceId),
                ?assertEqual(otel_span:span_id(Parent), Collection#span.parent_span_id),
                ?assertEqual(Collection#span.span_id, Probe#span.parent_span_id),
                ?assert(Probe#span.start_time >= Collection#span.start_time),
                ?assert(Probe#span.end_time =< Collection#span.end_time),
                Attrs = otel_attributes:map(Collection#span.attributes),
                ?assertEqual(1, maps:get('quod.quorum.required', Attrs)),
                ?assertEqual(0, maps:get('quod.quorum.seeded', Attrs)),
                ?assertEqual(1, maps:get('quod.quorum.sources', Attrs)),
                receive
                    {quod_test_span, #span{name = <<"quod.dtx.quorum.collect">>,
                                           trace_id = TraceId}} -> error(duplicate_collection_span)
                after 0 -> ok
                end
            after quod_trace:finish_span(Parent, ok)
            end
        end)
    end} || Outcome <- [committed, retry]].

exact_evidence_and_certificate_boundaries_preserve_validation_test_() ->
    [{atom_to_list(Outcome), fun() ->
        quod_trace_tests:with_tracer(fun() ->
            quod_operation_fixture:with(1, fun(F) ->
                Evidence = maps:get(evidence, F),
                Ref = maps:get(certified_target_ref, F),
                {ok, Statement} = quod_applied_certificate:operation_statement(
                                    maps:get(network, F), Evidence, applied),
                {ok, Vote} = quod_applied_certificate:sign_operation_vote(
                               Statement, maps:get(node_identity, F)),
                {ok, Valid} = quod_applied_certificate:operation_certificate(Statement, [Vote]),
                Certificate = case Outcome of valid -> Valid; invalid -> invalid_certificate end,
                {Ctx, Parent} = quod_trace:start_span(
                  otel_ctx:new(), <<"operation.evidence.test">>, internal, #{}),
                try
                    Result = quod_trace:with_context(Ctx, fun() ->
                        quod_dtx_current_view:certify_operation_evidence(
                          maps:get(source_ns, F), maps:get(target, F), Ref,
                          Evidence, Certificate, deadline(1000))
                    end),
                    case Outcome of
                        valid -> ?assertEqual({ok, Ref, Evidence, Valid}, Result);
                        invalid -> ?assertEqual({error, invalid_operation_result_certificate}, Result)
                    end,
                    TraceId = otel_span:trace_id(Parent),
                    Exact = quod_trace_tests:take_span(<<"quod.operation.exact_evidence">>, TraceId),
                    Verify = quod_trace_tests:take_span(<<"quod.operation.certificate_verify">>, TraceId),
                    ?assertEqual(otel_span:span_id(Parent), Exact#span.parent_span_id),
                    ?assertEqual(otel_span:span_id(Parent), Verify#span.parent_span_id),
                    ?assert(Exact#span.end_time =< Verify#span.start_time)
                after quod_trace:finish_span(Parent, ok)
                end
            end)
        end)
    end} || Outcome <- [valid, invalid]].

local_current_view_uses_the_captured_projection_and_apply_sent_frontier_test() ->
    {ok, _} = application:ensure_all_started(gproc),
    Ns = <<"quod:captured-current-", (integer_to_binary(
              erlang:unique_integer([positive])))/binary>>,
    Target = {Ns, digest(252)},
    Key = digest(253),
    CommitteeId = digest(254),
    Endpoint = {"127.0.0.1", 35254},
    Source = #{owner => self(), identity => Target, slot => 8, applied => 7,
               snapshot => unused,
               projection => #{committee => [Key], committee_id => CommitteeId,
                               validator_routes => #{Key => Endpoint},
                               dtx => #{generation => 5}}},
    true = quod_reg:reg({quod_simplex, Ns}),
    try
        ReadView = maps:get(
                     view, quod_dtx_current_view:test_production_dependencies()),
        %% A second owner call here would self-call and fail; the complete
        %% semantic view must instead be derived from the supplied object.
        ?assertEqual(
           {ok, #{identity => Target, slot => 7,
                  committee => [Key], committee_id => CommitteeId,
                  route_candidates => [{Key, [Endpoint]}]}},
           ReadView({local, Source}, {identity, Target}, 1000)),
        ?assertEqual(
           {error, not_ready},
           ReadView({local, Source}, {identity, {Ns, digest(255)}}, 1000))
    after
        true = gproc:unreg({n, l, {quod_simplex, Ns}})
    end.

newer_read_anchor_borrows_once_from_the_original_committed_owner_test() ->
    {ok, _} = application:ensure_all_started(gproc),
    F0 = fixture(1),
    Ns = <<"quod:recapture-current-", (integer_to_binary(
              erlang:unique_integer([positive])))/binary>>,
    Target = {Ns, digest(252)},
    F = F0#{target := Target},
    Ref = read_anchor_ref(F, maps:values(maps:get(signers, F))),
    {ok, {Target, Slot, BlockHash, RecordDigest}} =
        quod_dtx:certified_ref_claim(Ref),
    Claim = {Slot, BlockHash, RecordDigest},
    Parent = self(),
    Owner = spawn_monitor(fun() ->
        true = quod_reg:reg({quod_simplex, Ns}),
        Parent ! {capture_owner_ready, self()},
        receive
            {'$gen_call', From, {history_view, Target, committed, _Deadline}} ->
                Parent ! captured_committed_once,
                %% The requested slot 8 is still unavailable. This must be a
                %% terminal refusal, never a polling or fresh-source loop.
                gen:reply(From, {ok, #{owner => self(), identity => Target,
                                      slot => 7, applied => 7,
                                      snapshot => unused, projection => #{}}}),
                receive stop -> ok end
        end
    end),
    {Pid, Monitor} = Owner,
    receive {capture_owner_ready, Pid} -> ok
    after 1000 -> error(capture_owner_not_ready)
    end,
    Source = #{owner => Pid, identity => Target, slot => 7, applied => 7,
               snapshot => unused, projection => #{}},
    try
        ?assertEqual(
           {error, not_ready},
           quod_dtx_current_view:test_read_anchor_source(
             {local, Source}, Target, Claim, deadline(1000))),
        receive captured_committed_once -> ok
        after 0 -> error(missing_exact_owner_capture)
        end
    after
        Pid ! stop,
        receive {'DOWN', Monitor, process, Pid, normal} -> ok
        after 1000 -> exit(Pid, kill), error(capture_owner_not_stopped)
        end
    end,
    %% Keeping the same namespace registered elsewhere must not revive the
    %% original byte capability or route the re-capture to its replacement.
    true = quod_reg:reg({quod_simplex, Ns}),
    try
        ?assertEqual(
           {error, not_ready},
           quod_dtx_current_view:test_read_anchor_source(
             {local, Source}, Target, Claim, deadline(1000)))
    after
        true = gproc:unreg({n, l, {quod_simplex, Ns}})
    end.

later_quorum_anchor_capture_spends_the_original_certification_deadline_test() ->
    {ok, _} = application:ensure_all_started(gproc),
    F0 = fixture(1),
    Ns = <<"quod:deadline-anchor-", (integer_to_binary(
              erlang:unique_integer([positive])))/binary>>,
    Target = {Ns, digest(252)},
    F = F0#{target := Target,
            view := (maps:get(view, F0))#{identity := Target}},
    PlanBlob = read_plan_blob(F, <<"deadline_anchor">>),
    Parent = self(),
    {Owner, OwnerMonitor} = spawn_monitor(fun() ->
        true = quod_reg:reg({quod_simplex, Ns}),
        Parent ! {capture_owner_ready, self()},
        receive
            {'$gen_call', From, {history_view, Target, committed, CaptureDeadline}} ->
                Parent ! {later_capture_deadline, CaptureDeadline},
                receive resume -> ok end,
                gen:reply(From, {ok, #{owner => self(), identity => Target,
                                      slot => 8, applied => 8,
                                      snapshot => unused, projection => #{}}}),
                receive stop -> ok end
        end
    end),
    receive {capture_owner_ready, Owner} -> ok
    after 1000 -> error(capture_owner_not_ready)
    end,
    Source = #{owner => Owner, identity => Target, slot => 7, applied => 7,
               snapshot => unused, projection => #{}},
    Deps0 = dependencies(F, fun(Key, Request) -> read_attest_reply(F, Key, Request) end),
    Deps = Deps0#{exact_entry => fun(_, _, _) ->
        Parent ! unexpected_exact_verification,
        {error, not_ready}
    end},
    Deadline = deadline(300),
    {Reader, ReaderMonitor} = spawn_monitor(fun() ->
        Result = quod_dtx_current_view:test_certify_reads(
                   Ns, {{local, Source}, PlanBlob}, Deadline, Deps),
        Parent ! {deadline_certificate, self(), Result}
    end),
    try
        %% This is reached only after a real, cryptographically valid f+1
        %% vote. The later byte capture receives the identical original value.
        receive {later_capture_deadline, CapturedDeadline} ->
            ?assertEqual(Deadline, CapturedDeadline)
        after 1000 -> error(missing_later_quorum_anchor_capture)
        end,
        receive {deadline_certificate, Reader, Result} ->
            ?assertEqual({error, retry}, Result)
        after 1000 -> error(anchor_capture_restarted_the_budget)
        end,
        Owner ! resume,
        receive unexpected_exact_verification -> error(verification_after_expiry)
        after 0 -> ok
        end,
        %% An already-spent deadline never starts a fresh view/probe attempt.
        NeverView = Deps#{view => fun(_, _, _) -> error(view_after_expiry) end},
        ?assertEqual({error, retry},
                     quod_dtx_current_view:test_certify_reads(
                       Ns, {{local, Source}, PlanBlob}, Deadline, NeverView))
    after
        exit(Reader, kill),
        receive {'DOWN', ReaderMonitor, process, Reader, _} -> ok
        after 1000 -> error(certificate_reader_did_not_stop)
        end,
        exit(Owner, kill),
        receive {'DOWN', OwnerMonitor, process, Owner, _} -> ok
        after 1000 -> error(capture_owner_did_not_stop)
        end
    end.

newer_untrusted_read_anchor_cannot_trigger_owner_recapture_test() ->
    {ok, _} = application:ensure_all_started(gproc),
    F0 = fixture(4),
    Ns = <<"quod:untrusted-recapture-", (integer_to_binary(
              erlang:unique_integer([positive])))/binary>>,
    Target = {Ns, digest(252)},
    F = F0#{target := Target,
            view := (maps:get(view, F0))#{identity := Target}},
    [A, B | _] = maps:get(committee, F),
    Ref = read_anchor_ref(F, maps:values(maps:get(signers, F))),
    PlanBlob = read_plan_blob(F, <<"untrusted_newer_anchor">>),
    Deps = dependencies(F,
      fun(Key, Request) when Key =:= A ->
              read_attest_reply(F, Key, Request, Ref);
         (Key, Request) when Key =:= B ->
              {ok, Response, []} = read_attest_reply(F, Key, Request, Ref),
              {ok, setelement(9, Response, <<0:512>>), []};
         (_Key, _Request) -> {error, not_ready}
      end),
    Parent = self(),
    {Pid, Monitor} = spawn_monitor(fun() ->
        true = quod_reg:reg({quod_simplex, Ns}),
        Parent ! {capture_owner_ready, self()},
        count_recapture_requests(0)
    end),
    receive {capture_owner_ready, Pid} -> ok
    after 1000 -> error(capture_owner_not_ready)
    end,
    Source = #{owner => Pid, identity => Target, slot => 7, applied => 7,
               snapshot => unused, projection => #{}},
    try
        %% One valid vote plus one forged signature is below f+1. Neither
        %% the advertised height nor its apparently matching proof may cause
        %% any access to newer local bytes before the signed quorum exists.
        ?assertEqual(
           {error, retry},
           quod_dtx_current_view:test_certify_reads(
             Ns, {{local, Source}, PlanBlob}, deadline(1000), Deps)),
        Check = make_ref(),
        Pid ! {count, self(), Check},
        receive {capture_count, Check, Count} -> ?assertEqual(0, Count)
        after 1000 -> error(missing_capture_count)
        end
    after
        Pid ! stop,
        receive {'DOWN', Monitor, process, Pid, normal} -> ok
        after 1000 -> exit(Pid, kill), error(capture_owner_not_stopped)
        end
    end.

count_recapture_requests(Count) ->
    receive
        {'$gen_call', From, {history_view, _Identity, _Requirement, _Deadline}} ->
            gen:reply(From, {error, not_ready}),
            count_recapture_requests(Count + 1);
        {count, Caller, Ref} ->
            Caller ! {capture_count, Ref, Count},
            count_recapture_requests(Count);
        stop -> ok
    end.

%% Cancellation has one event-driven retry owner: endpoint failure returns to
%% that owner instead of walking another route immediately. For every other
%% request, a silent timeout or authenticated-link loss is uncertain and must
%% likewise return to existing recovery rather than resubmit the operation.
endpoint_failure_never_immediately_resubmits_uncertain_work_test() ->
    Cancellation =
        {cancel_operation_effect, <<1:128>>, {<<"quod:a">>, <<1:256>>}, <<"signed-submission">>},
    lists:foreach(
      fun(Reason) ->
              ?assertEqual(
                 stop,
                 quod_dtx_current_view:test_endpoint_failure_disposition(
                   Cancellation, Reason))
      end, [not_ready, busy, timeout, connection_lost]),
    Write = {submit, <<2:128>>, <<"signed-control">>},
    ?assertEqual(
       stop,
       quod_dtx_current_view:test_endpoint_failure_disposition(
         Write, timeout)),
    ?assertEqual(
       stop,
       quod_dtx_current_view:test_endpoint_failure_disposition(
         Write, connection_lost)),
    ?assertEqual(
       next,
       quod_dtx_current_view:test_endpoint_failure_disposition(
         Write, not_ready)),

    %% Drive the real flattened candidate walker. A stop result must end the
    %% whole route list, not merely the current peer's endpoint sub-list.
    ?assertEqual(
       {{error, not_ready}, 1},
       quod_dtx_current_view:test_submit_operation_candidates(
         Cancellation, [{error, not_ready}, {error, timeout}])),
    ?assertEqual(
       {{error, timeout}, 1},
       quod_dtx_current_view:test_submit_operation_candidates(
         Write, [{error, timeout}, {error, not_ready}])),
    Phase = {phase, <<3:128>>, <<4:256>>, vote},
    PhaseReply = {phase, <<3:128>>, 1, pending},
    ?assertEqual(
       {{ok, PhaseReply}, 2},
       quod_dtx_current_view:test_submit_operation_candidates(
         Phase, [{error, not_ready}, {ok, PhaseReply, []}])).

application_delivery_preserves_evidence_through_the_candidate_walk_test() ->
    quod_operation_fixture:with(1, fun(F) ->
        Target = maps:get(target, F),
        Ref = maps:get(certified_target_ref, F),
        {ok, ClaimBlob} = quod_transaction:encode_evidence(
                            maps:get(certified_claim_ref, F), maps:get(claim, F)),
        {ok, AppBlob} = quod_transaction:encode_evidence(
                          Ref, maps:get(application, F)),
        Request = {apply_claim, <<91:128>>, Target, ClaimBlob},
        Response = {application, <<91:128>>, committed, AppBlob},
        Entry = maps:get(entry, F),
        Hints = [{Ref, Entry}],
        ?assertEqual({{ok, Response, Hints}, 1},
          quod_dtx_current_view:test_submit_operation_candidates(
            Request, [{ok, Response, Hints}, {error, timeout}]))
    end).

exact_f_plus_one_resolve_committee_certificate_succeeds_test() ->
    F = fixture(4),
    [A, B | _] = maps:get(committee, F),
    Certificate = certificate(F, [A, B], #{}),
    ?assert(quod_ct:valid_applied_certificate_shape(Certificate)),
    ?assert(quod_applied_certificate:verify_applied_certificate(
              Certificate, maps:get(network_identity, F),
              maps:get(evidence, F))).

applied_certificate_accepts_an_equivalent_resolve_quorum_subset_test() ->
    F0 = fixture(4),
    Target = {Ns, Anchor} = maps:get(target, F0),
    Committee = maps:get(committee, F0),
    Signers = maps:get(signers, F0),
    Evidence0 = maps:get(evidence, F0),
    Control = maps:get(control, Evidence0),
    Entry0 = maps:get(entry, Evidence0),
    #entry{index = Slot, cert = #cert{block_hash = BlockHash}} =
        quod_ledger:entry_view(Entry0),
    {ok, Block} = quod_ledger:block_from_entry(Entry0),
    Position = {Block#block.era, Block#block.slot},
    Domain = quod_simplex:consensus_domain(Ns, Anchor),
    Shares = maps:from_list(
               [{Key, quod_simplex:make_share(
                        Domain, commit, Position, BlockHash,
                        maps:get(Key, Signers))}
                || Key <- Committee]),
    [A, B, C, D] = Committee,
    Form = fun(Keys) ->
                   {ok, Cert} = quod_simplex:form_cert(
                                  Domain, commit, Position, BlockHash,
                                  [maps:get(Key, Shares) || Key <- Keys],
                                  Committee),
                   Cert
           end,
    RetainedCert = Form([A, B, C]),
    SuppliedCert = Form([B, C, D]),
    Evidence = Evidence0#{entry => quod_ledger:entry(Slot, Block, RetainedCert)},
    {ok, ResolveRef} = quod_dtx:certified_entry_ref(
                          Target, quod_ledger:entry(Slot, Block, SuppliedCert), Control),
    Claim = (maps:get(claim, F0))#{resolve_ref => ResolveRef},
    F = F0#{claim => Claim, evidence => Evidence},
    Certificate = certificate(F, [A, B], #{}),
    ?assertNotEqual(RetainedCert, SuppliedCert),
    ?assert(quod_applied_certificate:verify_applied_certificate(
              Certificate, maps:get(network_identity, F), Evidence)).

insufficient_duplicate_nonmember_and_bad_signatures_fail_test() ->
    F = fixture(4),
    [A, B | _] = maps:get(committee, F),
    One = certificate(F, [A], #{}),
    {quod_dtx_applied_certificate, 2, Network, Target, CommitteeId,
     GroupId, ResolveRef, Generation, Verdict, [{A, Signature}]} = One,
    Duplicate = {quod_dtx_applied_certificate, 2, Network, Target, CommitteeId,
                 GroupId, ResolveRef, Generation, Verdict,
                 [{A, Signature}, {A, Signature}]},
    Outsider = signer(),
    NonMember = certificate_with_signers(
                  F, [Outsider, maps:get(B, maps:get(signers, F))], #{}),
    BadSignature = {quod_dtx_applied_certificate, 2, Network, Target,
                    CommitteeId, GroupId, ResolveRef, Generation, Verdict,
                    lists:keysort(1, [{A, <<0:512>>},
                                      signed_row(F, B, #{})])},
    lists:foreach(
      fun(Certificate) ->
          ?assertNot(quod_applied_certificate:verify_applied_certificate(
                       Certificate, Network, maps:get(evidence, F)))
      end, [One, Duplicate, NonMember, BadSignature]).

every_signed_statement_field_is_bound_test() ->
    F = fixture(4),
    [A, B | _] = maps:get(committee, F),
    Keys = [A, B],
    Network = maps:get(network_identity, F),
    Claim = maps:get(claim, F),
    Target = maps:get(target, F),
    WrongTarget = {<<"quod:wrong-target">>, digest(201)},
    WrongRef = certified_ref(Target, 17, digest(202)),
    WrongTargetRef = certified_ref(WrongTarget, 18, digest(203)),
    Cases =
        [{#{network_identity => digest(204)}, Network},
         {#{target => WrongTarget, resolve_ref => WrongTargetRef}, Network},
         {#{committee_id => digest(205)}, Network},
         {#{group_id => digest(206)}, Network},
         {#{resolve_ref => WrongRef}, Network},
         {#{generation => maps:get(generation, Claim) + 1}, Network},
         {#{verdict => abort}, Network}],
    lists:foreach(
      fun({Overrides, ExpectedNetwork}) ->
          Certificate = certificate(F, Keys, Overrides),
          ?assert(quod_ct:valid_applied_certificate_shape(
                    Certificate)),
          ?assertNot(quod_applied_certificate:verify_applied_certificate(
                       Certificate, ExpectedNetwork, maps:get(evidence, F)))
      end, Cases).

certification_uses_exact_resolve_committee_without_current_view_lookup_test() ->
    F = fixture(4),
    [A, B | _] = maps:get(committee, F),
    Successes = maps:from_keys([A, B], true),
    Deps0 = dependencies(
              F,
              fun(Key, Request) ->
                  case maps:is_key(Key, Successes) of
                      true -> applied_reply(F, Key, Request);
                      false -> {error, not_ready}
                  end
              end),
    %% A later current committee is irrelevant: this function must never ask
    %% for one, because the exact certified Resolve freezes its signer set.
    Deps = Deps0#{view => fun(_, _, _) -> error(stale_current_view_path) end},
    {ok, Certificate} = certify(F, Deps),
    ?assert(quod_applied_certificate:verify_applied_certificate(
              Certificate, maps:get(network_identity, F),
              maps:get(evidence, F))).

cohosted_certification_uses_the_local_member_without_a_route_test() ->
    F0 = fixture(1),
    [Key] = maps:get(committee, F0),
    Evidence = (maps:get(evidence, F0))#{routes => #{}},
    F = F0#{evidence => Evidence},
    TestPid = self(),
    Deps0 = dependencies(F, fun(_, _) -> {error, unused} end),
    Deps = Deps0#{
      node_key => fun() -> Key end,
      local =>
          fun(TargetNs, Request, _Timeout) ->
              TestPid ! {local_applied_probe, TargetNs},
              applied_reply(F, Key, Request)
          end,
      remote =>
          fun(_, _, _, _, _, _) -> error(unexpected_remote_probe) end},
    ?assertMatch(
       {ok, {quod_dtx_applied_certificate, 2, _, _, _, _, _, _, _, _}},
       quod_dtx_current_view:test_certify_applied(
         maps:get(owner_ns, F), {local, local_source(F)},
         maps:get(claim, F), Evidence, 1000, Deps)),
    receive
        {local_applied_probe, TargetNs} ->
            ?assertEqual(element(1, maps:get(target, F)), TargetNs)
    after 1000 ->
        error(local_member_was_not_probed)
    end.

one_below_f_plus_one_is_retry_test() ->
    F = fixture(7),
    [A, B | _] = maps:get(committee, F),
    Successes = maps:from_keys([A, B], true),
    Deps = dependencies(
             F,
             fun(Key, Request) ->
                 case maps:is_key(Key, Successes) of
                     true -> applied_reply(F, Key, Request);
                     false -> {error, not_ready}
                 end
             end),
    ?assertEqual({error, retry}, certify(F, Deps)).

read_certificate_reaches_f_plus_one_without_a_consensus_block_test() ->
    F = fixture(4),
    [A, B | _] = maps:get(committee, F),
    PlanBlob = read_plan_blob(F, <<"read_certificate_known">>),
    Successes = maps:from_keys([A, B], true),
    Deps = dependencies(
             F,
             fun(Key, Request) ->
                 case maps:is_key(Key, Successes) of
                     true -> read_attest_reply(F, Key, Request);
                     false -> {error, not_ready}
                 end
             end),
    {ok, Certificate} = quod_dtx_current_view:test_certify_reads(
                          maps:get(owner_ns, F), {source(F), PlanBlob},
                          deadline(1000), Deps),
    ?assert(quod_read_certificate:verify(
              Certificate, maps:get(committee, F),
              maps:get(committee_id, F))).

read_certificate_one_below_f_plus_one_retries_test() ->
    F = fixture(7),
    [A, B | _] = maps:get(committee, F),
    PlanBlob = read_plan_blob(F, <<"read_certificate_below">>),
    Successes = maps:from_keys([A, B], true),
    Deps = dependencies(
             F,
             fun(Key, Request) ->
                 case maps:is_key(Key, Successes) of
                     true -> read_attest_reply(F, Key, Request);
                     false -> {error, not_ready}
                 end
             end),
    ?assertEqual(
       {error, retry},
       quod_dtx_current_view:test_certify_reads(
         maps:get(owner_ns, F), {source(F), PlanBlob}, deadline(1000), Deps)).

read_certificate_ignores_vote_from_another_committee_view_test() ->
    F = fixture(4),
    [WrongView, Valid | _] = maps:get(committee, F),
    PlanBlob = read_plan_blob(F, <<"read_certificate_wrong_view">>),
    Deps = dependencies(
             F,
             fun(Key, Request) when Key =:= WrongView ->
                     {ok, Reply, Hints} = read_attest_reply(F, Key, Request),
                     {read_attest, RequestId, Target, ProofId, PlanDigest,
                      AnchorRef, _CommitteeId, Signer, _Signature} = Reply,
                     WrongCommitteeId = <<0:256>>,
                     Identity = maps:get(Key, maps:get(signers, F)),
                     {ok, {Signer, WrongSignature}} =
                         quod_read_certificate:sign(
                           Target, ProofId, PlanDigest, AnchorRef,
                           WrongCommitteeId, Identity),
                     {ok, {read_attest, RequestId, Target, ProofId,
                           PlanDigest, AnchorRef, WrongCommitteeId,
                           Signer, WrongSignature}, Hints};
                (Key, Request) when Key =:= Valid ->
                     read_attest_reply(F, Key, Request);
                (_Key, _Request) ->
                     {error, not_ready}
             end),
    %% f+1 is two for a four-member committee. The mismatched vote is ignored,
    %% leaving only one valid vote and therefore no certificate.
    ?assertEqual(
       {error, retry},
       quod_dtx_current_view:test_certify_reads(
         maps:get(owner_ns, F), {source(F), PlanBlob}, deadline(1000), Deps)).

read_certificate_f_plus_one_stale_refusals_remain_typed_test() ->
    F = fixture(4),
    [A, B | _] = maps:get(committee, F),
    PlanBlob = read_plan_blob(F, <<"read_certificate_stale_quorum">>),
    Stale = maps:from_keys([A, B], true),
    Deps = dependencies(
             F,
             fun(Key, Request) ->
                 case maps:is_key(Key, Stale) of
                     true -> read_attest_conflict(Request);
                     false -> {error, not_ready}
                 end
             end),
    ?assertEqual(
       {error, conflict_retry},
       quod_dtx_current_view:test_certify_reads(
         maps:get(owner_ns, F), {source(F), PlanBlob}, deadline(1000), Deps)).

read_conflict_stops_the_shared_endpoint_walk_test() ->
    F0 = fixture(1), [Key] = maps:get(committee, F0),
    Routes = [{Key, [{"127.0.0.1", 21201}, {"127.0.0.1", 21202}]}],
    F = F0#{source_routes := Routes,
             view := (maps:get(view, F0))#{route_candidates := Routes}},
    Calls = atomics:new(1, []),
    Deps0 = dependencies(F, fun(_, _) -> error(unused_transport) end),
    Deps = Deps0#{remote := fun(_, _, Pinned, _Endpoint, Request, _) ->
        ?assertEqual(Key, Pinned),
        atomics:add(Calls, 1, 1),
        read_attest_conflict(Request)
    end},
    ?assertEqual({error, conflict_retry}, quod_dtx_current_view:test_certify_reads(
        maps:get(owner_ns, F), {source(F), read_plan_blob(F, <<"terminal_read">>)},
        deadline(1000), Deps)),
    ?assertEqual(1, atomics:get(Calls, 1)).

read_certificate_one_stale_refusal_does_not_override_quorum_test() ->
    F = fixture(4),
    [Stale, A, B | _] = maps:get(committee, F),
    PlanBlob = read_plan_blob(F, <<"read_certificate_mixed_quorum">>),
    Votes = maps:from_keys([A, B], true),
    Deps = dependencies(
             F,
             fun(Key, Request) ->
                 case Key of
                     Stale -> read_attest_conflict(Request);
                     _ ->
                         case maps:is_key(Key, Votes) of
                             true -> read_attest_reply(F, Key, Request);
                             false -> {error, not_ready}
                         end
                 end
             end),
    {ok, Certificate} = quod_dtx_current_view:test_certify_reads(
                          maps:get(owner_ns, F), {source(F), PlanBlob},
                          deadline(1000), Deps),
    ?assert(quod_read_certificate:verify(
              Certificate, maps:get(committee, F),
              maps:get(committee_id, F))).

read_certificate_combines_equivalent_finality_subsets_test() ->
    F = fixture(4),
    [A, B, C, D] = maps:get(committee, F),
    Signers = maps:get(signers, F),
    RefA = read_anchor_ref(
             F, [maps:get(Key, Signers) || Key <- [A, B, C]]),
    RefB = read_anchor_ref(
             F, [maps:get(Key, Signers) || Key <- [B, C, D]]),
    ?assertNotEqual(element(8, RefA), element(8, RefB)),
    PlanBlob = read_plan_blob(F, <<"equivalent_finality_subsets">>),
    Deps = dependencies(
             F,
             fun(Key, Request) when Key =:= A ->
                     read_attest_reply(F, Key, Request, RefA);
                (Key, Request) when Key =:= B ->
                     read_attest_reply(F, Key, Request, RefB);
                (_Key, _Request) ->
                     {error, not_ready}
             end),
    {ok, Certificate} = quod_dtx_current_view:test_certify_reads(
                          maps:get(owner_ns, F), {source(F), PlanBlob},
                          deadline(1000), Deps),
    ?assert(quod_read_certificate:verify(
              Certificate, maps:get(committee, F),
              maps:get(committee_id, F))).

read_certificate_selects_verified_proof_from_equivalent_votes_test() ->
    F = fixture(4),
    [A, B | _] = maps:get(committee, F),
    GoodRef = read_anchor_ref(
                F, maps:values(maps:get(signers, F))),
    BadRef = setelement(8, GoodRef, quod_ct:fixture_finality(99, element(6, GoodRef))),
    PlanBlob = read_plan_blob(F, <<"verified_equivalent_proof">>),
    Deps0 = dependencies(
              F,
              fun(Key, Request) when Key =:= A ->
                      read_attest_reply(F, Key, Request, BadRef);
                 (Key, Request) when Key =:= B ->
                      read_attest_reply(F, Key, Request, GoodRef);
                 (_Key, _Request) ->
                      {error, not_ready}
              end),
    TestPid = self(),
    Deps = Deps0#{
      exact_entry =>
          fun(_Source, Ref, _Timeout) when Ref =:= BadRef ->
                  TestPid ! rejected_bad_finality,
                  {error, invalid_foreign_reference};
             (_Source, Ref, _Timeout) when Ref =:= GoodRef ->
                  TestPid ! accepted_good_finality,
                  {ok, read_entry_evidence(Ref)}
          end},
    {ok, Certificate} = quod_dtx_current_view:test_certify_reads(
                          maps:get(owner_ns, F), {source(F), PlanBlob},
                          deadline(1000), Deps),
    ?assertEqual(GoodRef, element(6, Certificate)),
    receive rejected_bad_finality -> ok after 0 -> error(bad_ref_not_checked) end,
    receive accepted_good_finality -> ok after 0 -> error(good_ref_not_checked) end.

read_certificate_refuses_when_no_equivalent_proof_verifies_test() ->
    F = fixture(4),
    [A, B | _] = maps:get(committee, F),
    GoodRef = read_anchor_ref(
                F, maps:values(maps:get(signers, F))),
    BadRef = setelement(8, GoodRef, quod_ct:fixture_finality(99, element(6, GoodRef))),
    PlanBlob = read_plan_blob(F, <<"no_verified_equivalent_proof">>),
    Deps0 = dependencies(
              F,
              fun(Key, Request) when Key =:= A; Key =:= B ->
                      read_attest_reply(F, Key, Request, BadRef);
                 (_Key, _Request) ->
                      {error, not_ready}
              end),
    Deps = Deps0#{exact_entry =>
                      fun(_Source, _Ref, _Timeout) ->
                              {error, invalid_foreign_reference}
                      end},
    ?assertEqual(
       {error, retry},
       quod_dtx_current_view:test_certify_reads(
         maps:get(owner_ns, F), {source(F), PlanBlob}, deadline(1000), Deps)).

read_certificate_does_not_combine_different_record_digests_test() ->
    F = fixture(4),
    [A, B | _] = maps:get(committee, F),
    RefA = read_anchor_ref(
             F, maps:values(maps:get(signers, F))),
    RefB = setelement(7, RefA, digest(242)),
    PlanBlob = read_plan_blob(F, <<"different_record_digests">>),
    Deps = dependencies(
             F,
             fun(Key, Request) when Key =:= A ->
                     read_attest_reply(F, Key, Request, RefA);
                (Key, Request) when Key =:= B ->
                     read_attest_reply(F, Key, Request, RefB);
                (_Key, _Request) ->
                     {error, not_ready}
             end),
    ?assertEqual(
       {error, retry},
       quod_dtx_current_view:test_certify_reads(
         maps:get(owner_ns, F), {source(F), PlanBlob}, deadline(1000), Deps)).

read_certification_never_allocates_foreign_plan_symbols_test() ->
    F = fixture(1),
    Symbol = <<"quod_read_certificate_foreign_symbol_6e985f">>,
    ?assertException(error, badarg,
                     binary_to_existing_atom(Symbol, utf8)),
    PlanBlob = read_plan_blob(F, Symbol),
    Before = erlang:system_info(atom_count),
    Deps = dependencies(
             F, fun(SignerKey, Request) ->
                        read_attest_reply(F, SignerKey, Request)
                end),
    ?assertMatch(
       {ok, {quod_read_certificate, 3, _, _, _, _, _, _}},
       quod_dtx_current_view:test_certify_reads(
         maps:get(owner_ns, F), {source(F), PlanBlob}, deadline(1000), Deps)),
    ?assertEqual(Before, erlang:system_info(atom_count)),
    ?assertException(error, badarg,
                     binary_to_existing_atom(Symbol, utf8)).

retired_resolve_member_uses_shared_resolver_after_endpoint_move_test() ->
    F0 = fixture(1),
    [OldKey] = maps:get(committee, F0),
    CurrentSigner = signer(),
    CurrentKey = maps:get(pubkey, CurrentSigner),
    Stale = {"127.0.0.1", 21001},
    Fresh = {"127.0.0.1", 21002},
    CurrentEndpoint = {"127.0.0.1", 21003},
    Evidence0 = maps:get(evidence, F0),
    Evidence = Evidence0#{routes => #{OldKey => Stale}},
    %% The ordinary current-route view has advanced past OldKey. Only the
    %% shared key resolver knows where that retired holder moved; the endpoint
    %% request remains pinned to OldKey at the transport boundary.
    F = F0#{evidence => Evidence,
            source_routes => [{CurrentKey, [CurrentEndpoint]}]},
    TestPid = self(),
    Deps0 = dependencies(F, fun(_, _) -> {error, unused} end),
    Deps = Deps0#{
      resolve =>
          fun(Key) when Key =:= OldKey -> {ok, Fresh};
             (Key) when Key =:= CurrentKey -> {ok, CurrentEndpoint};
             (_) -> error
          end,
      remote =>
          fun(_OwnerNs, _TargetNs, PinnedKey, Endpoint, Request, _Timeout) ->
              TestPid ! {applied_request, PinnedKey, Endpoint,
                         element(2, Request)},
              case {PinnedKey, Endpoint} of
                  {OldKey, Fresh} -> applied_reply(F, OldKey, Request);
                  {OldKey, Stale} -> {error, not_ready};
                  {CurrentKey, CurrentEndpoint} ->
                      error(current_committee_key_was_probed)
              end
          end},
    %% Before the resolver merge the exact old key has only Stale and retries.
    %% The current committee key is reachable but must never become a signer.
    ?assertMatch({ok, _}, certify(F, Deps)),
    receive {applied_request, OldKey, Fresh, <<_:128>>} -> ok
    after 1000 -> error(missing_resolved_retired_member_route)
    end,
    receive {applied_request, _, _, _} -> error(extra_probe)
    after 0 -> ok
    end.

live_route_for_a_nonmember_is_never_probed_or_counted_test() ->
    F0 = fixture(1),
    [Member] = maps:get(committee, F0),
    Outsider = signer(),
    OutsiderKey = maps:get(pubkey, Outsider),
    MemberEndpoint = {"127.0.0.1", 21101},
    OutsiderEndpoint = {"127.0.0.1", 21102},
    Evidence0 = maps:get(evidence, F0),
    Evidence = Evidence0#{routes => #{Member => MemberEndpoint}},
    SourceRoutes = lists:keysort(
                     1, [{Member, [MemberEndpoint]},
                         {OutsiderKey, [OutsiderEndpoint]}]),
    F = F0#{evidence => Evidence, source_routes => SourceRoutes},
    TestPid = self(),
    Deps0 = dependencies(F, fun(_, _) -> {error, unused} end),
    Deps = Deps0#{
      remote =>
          fun(_OwnerNs, _TargetNs, Key, Endpoint, Request, _Timeout) ->
              case {Key, Endpoint} of
                  {Member, MemberEndpoint} -> {error, not_ready};
                  {OutsiderKey, OutsiderEndpoint} ->
                      TestPid ! outsider_was_probed,
                      applied_reply(F, Outsider, Request)
              end
          end},
    %% The outsider could produce a well-formed signed response, but exact
    %% Resolve membership—not route presence—decides who may attest.
    ?assertEqual({error, retry}, certify(F, Deps)),
    receive outsider_was_probed -> error(nonmember_route_was_used)
    after 0 -> ok
    end.

malformed_resolve_evidence_and_reply_are_retryable_test() ->
    F = fixture(1),
    BadEvidence = maps:remove(committee_id, maps:get(evidence, F)),
    ?assertEqual(
       {error, retry},
       quod_dtx_current_view:test_certify_applied(
         maps:get(owner_ns, F), source(F), maps:get(claim, F), BadEvidence,
         1000, dependencies(F, fun(_, _) -> {error, unused} end))),
    BadReplyDeps = dependencies(F, fun(_Key, _Request) -> {ok, malformed} end),
    ?assertEqual({error, retry}, certify(F, BadReplyDeps)).

wrong_signer_or_bad_signature_reply_never_counts_test() ->
    F = fixture(1),
    [Key] = maps:get(committee, F),
    Outsider = signer(),
    WrongSignerDeps = dependencies(
                        F,
                        fun(_Expected, Request) ->
                            applied_reply(F, Outsider, Request)
                        end),
    ?assertEqual({error, retry}, certify(F, WrongSignerDeps)),
    BadSignatureDeps = dependencies(
                         F,
                         fun(_Expected, Request) ->
                             {ok, Response, []} = applied_reply(F, Key, Request),
                             {ok, setelement(10, Response, <<0:512>>), []}
                         end),
    ?assertEqual({error, retry}, certify(F, BadSignatureDeps)).

programmer_fault_in_probe_terminates_monitored_certifier_test() ->
    F = fixture(1),
    Deps0 = dependencies(F, fun(_, _) -> {error, unused} end),
    Deps = Deps0#{remote =>
                   fun(_OwnerNs, _TargetNs, _Key, _Endpoint,
                       _Request, _Timeout) ->
                       error(endpoint_dependency_fault)
                   end},
    {Certifier, Monitor} = spawn_monitor(fun() -> certify(F, Deps) end),
    receive
        {'DOWN', Monitor, process, Certifier,
         {endpoint_dependency_fault, [_ | _]}} -> ok
    after 2000 ->
        error(certifier_fault_was_hidden)
    end.

successful_early_certificate_reaps_other_probe_processes_test() ->
    F = fixture(4),
    TestPid = self(),
    [A, B | _] = maps:get(committee, F),
    Fast = maps:from_keys([A, B], true),
    Reply = fun(Key, Request) ->
                    TestPid ! {probe_started, Key, self()},
                    case maps:is_key(Key, Fast) of
                        true ->
                            receive {release_probe, Key} -> ok end,
                            applied_reply(F, Key, Request);
                        false ->
                            receive never -> {error, impossible} end
                    end
            end,
    Deps = dependencies(F, Reply),
    {Certifier, CertifierMonitor} = spawn_monitor(
      fun() -> TestPid ! {certify_result, certify(F, Deps)} end),
    Started = collect_started(4, #{}),
    ProbeMonitors = maps:map(
                      fun(_Key, Pid) -> erlang:monitor(process, Pid) end,
                      Started),
    maps:foreach(
      fun(Key, Pid) ->
          case maps:is_key(Key, Fast) of
              true -> Pid ! {release_probe, Key};
              false -> ok
          end
      end, Started),
    receive {certify_result, {ok, _}} -> ok
    after 2000 -> error(certifier_did_not_finish)
    end,
    receive {'DOWN', CertifierMonitor, process, Certifier, normal} -> ok
    after 2000 -> error(certifier_process_survived)
    end,
    maps:foreach(
      fun(Key, Pid) ->
          Monitor = maps:get(Key, ProbeMonitors),
          receive {'DOWN', Monitor, process, Pid, _Reason} -> ok
          after 2000 -> error({probe_process_survived, Key})
          end
      end, Started).

many_certification_preserves_aligned_successes_and_retries_test() ->
    Good = fixture(1),
    Retry = fixture(1),
    GoodSource = source(Good),
    RetrySource = source(Retry),
    GoodRoute = hd(maps:get(source_routes, Good)),
    RetryRoute = hd(maps:get(source_routes, Retry)),
    Deps0 = dependencies(Good, fun(_, _) -> {error, unused} end),
    Deps = Deps0#{
      network_identity => fun() -> {ok, maps:get(network_identity, Good)} end,
      remote =>
          fun(_OwnerNs, _TargetNs, Key, Endpoint, Request, _Timeout) ->
              case {Key, Endpoint} of
                  {GoodKey, GoodEndpoint}
                    when {GoodKey, [GoodEndpoint]} =:= GoodRoute ->
                      applied_reply(Good, Key, Request);
                  {RetryKey, RetryEndpoint}
                    when {RetryKey, [RetryEndpoint]} =:= RetryRoute ->
                      {error, not_ready}
              end
          end},
    Requests = [{GoodSource, maps:get(claim, Good), maps:get(evidence, Good)},
                {RetrySource, maps:get(claim, Retry), maps:get(evidence, Retry)}],
    ?assertMatch(
       {ok, [{verified, {quod_dtx_applied_certificate, 2, _, _, _, _, _, _, _, _}},
             retry]},
       quod_dtx_current_view:test_certify_applied_many(
         maps:get(owner_ns, Good), Requests, deadline(1000), Deps)).

many_certification_expired_deadline_starts_no_observation_test() ->
    F = fixture(1),
    Never = fun() -> error(observation_after_deadline) end,
    Deps = (dependencies(F, fun(_, _) -> error(endpoint_after_deadline) end))#{
             network_identity => Never,
             view => fun(_, _, _) -> error(view_after_deadline) end},
    ?assertEqual({error, retry},
                 quod_dtx_current_view:test_certify_applied_many(
                   maps:get(owner_ns, F), many_requests(F, 2),
                   deadline(-1), Deps)).

many_certification_refuses_non_deadline_input_test() ->
    F = fixture(1),
    ?assertEqual({error, invalid_request},
                 quod_dtx_current_view:test_certify_applied_many(
                   maps:get(owner_ns, F), many_requests(F, 1),
                   infinity, #{})).

many_certification_validates_each_input_once_before_workers_test() ->
    F = fixture(1),
    Deps = dependencies(F, fun(Key, Request) -> applied_reply(F, Key, Request) end),
    {module, quod_dtx_current_view} = code:ensure_loaded(quod_dtx_current_view),
    {ok, {call_count, Counts}} = tprof:profile(fun() ->
        ?assertMatch({ok, [{verified, _}, {verified, _}]},
          quod_dtx_current_view:test_certify_applied_many(
            maps:get(owner_ns, F), many_requests(F, 2), deadline(1000), Deps)),
        ok
    end, #{type => call_count, report => return,
           pattern => [{quod_dtx_current_view, valid_request, 4},
                       {quod_dtx_current_view, valid_resolve_evidence, 6}]}),
    lists:foreach(fun({Name, Arity}) ->
        ?assertEqual(2, lists:sum([N || {quod_dtx_current_view, FName, A, Ps} <- Counts,
                                      FName =:= Name, A =:= Arity, {_, N, _} <- Ps]))
    end, [{valid_request, 4}, {valid_resolve_evidence, 6}]).

malformed_late_batch_row_starts_no_worker_test() ->
    F = fixture(1),
    Counter = atomics:new(1, []),
    Deps = (dependencies(F, fun(_, _) -> error(endpoint_before_admission) end))#{
             network_identity => fun() -> atomics:add(Counter, 1, 1),
                                          {error, unavailable} end},
    [{Source, Claim, Evidence} = Good] = many_requests(F, 1),
    lists:foreach(fun(Bad) ->
        ?assertEqual({error, invalid_request},
          quod_dtx_current_view:test_certify_applied_many(
            maps:get(owner_ns, F), [Good, Bad], deadline(1000), Deps)),
        ?assertEqual(0, atomics:get(Counter, 1))
    end, [invalid, {Source, Claim#{generation := -1}, Evidence},
          {Source, Claim, Evidence#{committee := []}}]).

many_certification_children_follow_caller_death_test() ->
    F = fixture(1),
    Requests = many_requests(F, 2),
    TestPid = self(),
    Deps0 = dependencies(F, fun(_, _) -> {error, unused} end),
    BlockedDeps = Deps0#{remote =>
                          fun(_OwnerNs, _TargetNs, _Key, _Endpoint,
                              _Request, _Timeout) ->
                              TestPid ! {many_probe_started, self()},
                              receive never -> {error, impossible} end
                          end},
    {Certifier, CertifierMonitor} = spawn_monitor(
      fun() ->
          _ = quod_dtx_current_view:test_certify_applied_many(
                maps:get(owner_ns, F), Requests, deadline(1000), BlockedDeps),
          ok
      end),
    Children = collect_many_children(2, []),
    ChildMonitors = [{Pid, erlang:monitor(process, Pid)} || Pid <- Children],
    exit(Certifier, kill),
    receive {'DOWN', CertifierMonitor, process, Certifier, killed} -> ok
    after 2000 -> error(many_certifier_survived)
    end,
    lists:foreach(
      fun({Pid, Monitor}) ->
          receive {'DOWN', Monitor, process, Pid, killed} -> ok
          after 2000 -> error({many_child_survived, Pid})
          end
      end, ChildMonitors).

outcome_needs_f_plus_one_identical_current_validator_replies_test() ->
    F = fixture(4),
    [A, B, C, _D] = maps:get(committee, F),
    Ref = outcome_group_ref(F, A),
    Good = group_committed(Ref),
    Divergent = #{status => pending, phase => begun, ref => Ref},
    Deps = outcome_dependencies(
             maps:get(view, F),
             fun(Key, Request, Target, CommitteeId, Slot) ->
                     case Key of
                         A -> outcome_reply(
                                Request, Target, CommitteeId, Slot, Good);
                         B -> outcome_reply(
                                Request, Target, CommitteeId, Slot + 1, Good);
                         C -> outcome_reply(
                                Request, Target, CommitteeId, Slot,
                                Divergent);
                         _ -> {error, not_ready}
                     end
             end),
    ?assertEqual({ok, Good}, lookup(F, Ref, Deps)).

one_byzantine_outcome_reply_never_decides_test() ->
    F = fixture(4),
    [Byzantine | _] = maps:get(committee, F),
    Ref = outcome_transaction_ref(F),
    Forged = #{status => committed, height => 99, ref => Ref},
    Deps = outcome_dependencies(
             maps:get(view, F),
             fun(Key, Request, Target, CommitteeId, Slot) ->
                     case Key =:= Byzantine of
                         true -> outcome_reply(
                                   Request, Target, CommitteeId, Slot,
                                   Forged);
                         false -> {error, not_ready}
                     end
             end),
    ?assertEqual({error, retry}, lookup(F, Ref, Deps)).

operation_outcome_requires_f_plus_one_current_validators_test() ->
    F = fixture(4),
    [A, B | _] = maps:get(committee, F),
    Ref = outcome_operation_ref(F),
    Status = #{status => claimed, operation_state => terminal,
               height => 14, receipt_height => 14, ref => Ref,
               request_digest => digest(13),
               outcome_ref => outcome_transaction_ref(F), included => []},
    Matching = maps:from_keys([A, B], true),
    Deps = outcome_dependencies(
             maps:get(view, F),
             fun(Key, Request, Target, CommitteeId, Slot) ->
                     case maps:is_key(Key, Matching) of
                         true -> outcome_reply(
                                   Request, Target, CommitteeId, Slot,
                                   Status);
                         false -> {error, not_ready}
                     end
             end),
    ?assertEqual({ok, Status}, lookup(F, Ref, Deps)).

view_mismatch_lag_and_split_valid_statuses_are_retryable_test() ->
    F = fixture(4),
    [A, B, C, D] = maps:get(committee, F),
    Ref = outcome_transaction_ref(F),
    Committed = #{status => committed, height => 9, ref => Ref},
    Pending = #{status => pending, ref => Ref},
    Deps = outcome_dependencies(
             maps:get(view, F),
             fun(Key, Request, Target, CommitteeId, Slot) ->
                     case Key of
                         A -> outcome_reply(
                                Request, Target, digest(250), Slot,
                                Committed);
                         B -> outcome_reply(
                                Request, Target, CommitteeId, Slot - 1,
                                Committed);
                         C -> outcome_reply(
                                Request, Target, CommitteeId, Slot, Pending);
                         D -> outcome_reply(
                                Request, Target, CommitteeId, Slot,
                                Committed)
                     end
             end),
    ?assertEqual({error, retry}, lookup(F, Ref, Deps)).

ordinary_quorum_absence_stays_unknown_without_a_barrier_test() ->
    F = fixture(4),
    Ref = outcome_transaction_ref(F),
    TestPid = self(),
    Deps = outcome_dependencies(
             maps:get(view, F),
             fun(_Key, Request, Target, CommitteeId, Slot) ->
                     case element(1, Request) of
                         outcome ->
                             outcome_reply(
                               Request, Target, CommitteeId, Slot, not_found);
                         outcome_barrier ->
                             TestPid ! unexpected_ordinary_barrier,
                             {error, not_ready}
                     end
             end),
    ?assertEqual({error, retry}, lookup(F, Ref, Deps)),
    receive unexpected_ordinary_barrier -> error(barrier_was_used)
    after 0 -> ok
    end.

pending_vote_is_not_a_validator_quorum_status_test() ->
    F = fixture(4),
    [Coordinator | _] = maps:get(committee, F),
    Ref = outcome_group_ref(F, Coordinator),
    PendingVote = #{status => pending, phase => pending_vote, ref => Ref},
    TestPid = self(),
    Deps = outcome_dependencies(
             maps:get(view, F),
             fun(_Key, Request, Target, CommitteeId, Slot) ->
                     case element(1, Request) of
                         outcome -> outcome_reply(
                                      Request, Target, CommitteeId, Slot,
                                      PendingVote);
                         outcome_barrier ->
                             TestPid ! unexpected_pending_barrier,
                             {error, not_ready}
                     end
             end),
    ?assertEqual({error, retry}, lookup(F, Ref, Deps)),
    receive unexpected_pending_barrier -> error(barrier_was_used)
    after 0 -> ok
    end.

certify(F, Dependencies) ->
    quod_dtx_current_view:test_certify_applied(
      maps:get(owner_ns, F), source(F), maps:get(claim, F),
      maps:get(evidence, F), 1000, Dependencies).

source(F) ->
    {remote, maps:get(source_routes, F)}.

%% Only the transport is faked in these collector tests; local sources still
%% carry the sole history-view shape. No byte read is made by these fixtures.
local_source(F) ->
    #{owner => self(), identity => maps:get(target, F),
      slot => 8, applied => 8, snapshot => unused,
      projection => #{}}.

lookup(F, OutcomeRef, Dependencies) ->
    quod_dtx_current_view:test_lookup_outcome(
      maps:get(owner_ns, F),
      {remote, maps:get(source_routes, F)},
      OutcomeRef, deadline(1000), Dependencies).

many_requests(F, Count) ->
    lists:duplicate(
      Count, {source(F), maps:get(claim, F), maps:get(evidence, F)}).

dependencies(F, Reply) ->
    View = maps:get(view, F),
    #{view => fun(_Source, _Ref, _Timeout) -> {ok, View} end,
      local =>
          fun(_Ns, Request, _Timeout) ->
                  [Key | _] = maps:get(committee, View),
                  Reply(Key, Request)
          end,
      remote =>
          fun(_OwnerNs, _TargetNs, Key, _Endpoint, Request, _Timeout) ->
                  Reply(Key, Request)
          end,
      exact_entry =>
          fun(_Source, Ref, _Timeout) ->
                  case quod_dtx:certified_ref_claim(Ref) of
                      {ok, {Identity, Slot, BlockHash, RecordDigest}} ->
                          {ok, #{identity => Identity, slot => Slot,
                                 block_hash => BlockHash,
                                 record_digest => RecordDigest}};
                      error ->
                          {error, invalid_foreign_reference}
                  end
          end,
      resolve => fun(_Key) -> error end,
      node_key => fun() -> none end,
      network_identity =>
          fun() -> {ok, maps:get(network_identity, F)} end}.

outcome_dependencies(View, Reply) ->
    #{view => fun(_Source, _Basis, _Timeout) -> {ok, View} end,
      local =>
          fun(_Ns, Request, _Timeout) ->
                  [Key | _] = maps:get(committee, View),
                  Reply(Key, Request, maps:get(identity, View),
                        maps:get(committee_id, View), maps:get(slot, View))
          end,
      remote =>
          fun(_OwnerNs, _TargetNs, Key, _Endpoint, Request, _Timeout) ->
                  Reply(Key, Request, maps:get(identity, View),
                        maps:get(committee_id, View), maps:get(slot, View))
          end,
      resolve => fun(_Key) -> error end,
      node_key => fun() -> none end}.

outcome_reply(
  {outcome, RequestId, _OutcomeRef, _CommitteeId, _MinimumSlot},
  Target, CommitteeId, AppliedFloor, Outcome) ->
    {ok, {outcome, RequestId, Target, CommitteeId, AppliedFloor, Outcome}, []}.

outcome_transaction_ref(F) ->
    {TargetNs, Anchor} = maps:get(identity, maps:get(view, F)),
    {transaction, TargetNs, Anchor, digest(220)}.

outcome_group_ref(F, Coordinator) ->
    {TargetNs, Anchor} = maps:get(identity, maps:get(view, F)),
    {group, TargetNs, Anchor, Coordinator, digest(221), digest(222)}.

outcome_operation_ref(F) ->
    {TargetNs, Anchor} = maps:get(identity, maps:get(view, F)),
    {operation, TargetNs, Anchor,
     agent_ref(<<"quod:agent">>, digest(223), 223), digest(13)}.

group_committed(Ref) ->
    #{status => committed, height => 9, ref => Ref,
      bindings => [{<<"X">>, linked}],
      participant_slots =>
          [{{<<"quod:a">>, digest(230)}, 7, 1},
           {{<<"quod:b">>, digest(231)}, 8, 2}]}.

applied_reply(F, Key, Request) when is_binary(Key) ->
    applied_reply(F, maps:get(Key, maps:get(signers, F)), Request);
applied_reply(
  F, #{pubkey := Signer} = Identity,
  {applied, RequestId, GroupId, ResolveRef, Generation, Verdict}) ->
    Target = maps:get(target, F),
    CommitteeId = maps:get(committee_id, F),
    {ok, {Signer, Signature}} = quod_applied_certificate:sign_applied_vote(
                                 maps:get(network_identity, F), Target,
                                 CommitteeId, GroupId, ResolveRef,
                                 Generation, Verdict, Identity),
    {ok, {applied, RequestId, Target, CommitteeId, GroupId, ResolveRef,
          Generation, Verdict, Signer, Signature}, []}.

read_attest_reply(F, Key, Request) when is_binary(Key) ->
    read_attest_reply(F, maps:get(Key, maps:get(signers, F)), Request);
read_attest_reply(
  F, #{pubkey := _} = Identity,
  {read_attest, RequestId, PlanBlob}) ->
    read_attest_reply(
      F, Identity, {read_attest, RequestId, PlanBlob},
      read_anchor_ref(F, maps:values(maps:get(signers, F)))).

read_attest_reply(F, Key, Request, AnchorRef) when is_binary(Key) ->
    read_attest_reply(
      F, maps:get(Key, maps:get(signers, F)), Request, AnchorRef);
read_attest_reply(
  F, #{pubkey := Signer} = Identity,
  {read_attest, RequestId, PlanBlob}, AnchorRef) ->
    {ok, Plan} = quod_dtx:decode(PlanBlob),
    Target = quod_dtx:target(Plan),
    ProofId = quod_dtx:proof_id(Plan),
    PlanDigest = quod_dtx:digest(Plan),
    CommitteeId = maps:get(committee_id, F),
    {ok, {Signer, Signature}} = quod_read_certificate:sign(
                                 Target, ProofId, PlanDigest, AnchorRef,
                                 CommitteeId, Identity),
    {ok, {read_attest, RequestId, Target, ProofId, PlanDigest, AnchorRef,
          CommitteeId, Signer, Signature}, []}.

read_anchor_ref(F, Signers) ->
    {Ns, Anchor} = maps:get(target, F),
    Slot = 8,
    BlockHash = digest(20 + Slot),
    Position = {quod_ledger:initial_era({Ns, Anchor}), Slot - 1},
    Domain = quod_simplex:consensus_domain(Ns, Anchor),
    Shares = [quod_simplex:make_share(
                Domain, commit, Position, BlockHash, Signer)
              || Signer <- Signers],
    {ok, Cert} = quod_simplex:form_cert(
                   Domain, commit, Position, BlockHash, Shares,
                   maps:get(committee, F)),
    {ok, Finality} = quod_ledger:encode_finality_head(Cert),
    {ok, Ref} = quod_dtx:certified_ref(
                  Ns, Anchor, Slot, BlockHash, digest(241),
                  Finality),
    Ref.

read_entry_evidence(Ref) ->
    {ok, {Identity, Slot, BlockHash, RecordDigest}} =
        quod_dtx:certified_ref_claim(Ref),
    #{identity => Identity, slot => Slot, block_hash => BlockHash,
      record_digest => RecordDigest}.

read_attest_conflict({read_attest, RequestId, _PlanBlob}) ->
    {ok, {error, RequestId, conflict_retry}, []}.

read_plan_blob(F, Symbol) ->
    Target = maps:get(target, F),
    {ok, Empty} = quod_wire_term:encode_canonical([]),
    {ok, Reads} = quod_wire_term:encode_canonical(
                    [{{{'$quod_symbol', Symbol}, 1}, never_present}]),
    Core = #{target => Target, base_height => 1, proof_id => digest(242),
             origin => {<<"quod:read-origin">>, digest(243)},
             principal => anonymous, request_binding => none,
             overlay_generation => 0, diff_ops => 0, read_functors => 1,
             effects_count => 0,
             conflict_descriptor =>
                 #{reads => [{Symbol, 1}], writes => [], custody => []},
             diff => Empty, read_check => Reads, effects => Empty,
             live_bridges => Empty, transcript => Empty},
    {ok, Blob} = quod_dtx:encode({quod_plan, Core, none, none}),
    Blob.

fixture(N) ->
    OwnerNs = <<"quod:owner">>,
    Target = {<<"quod:target">>, digest(1)},
    SignerRows = [signer() || _ <- lists:seq(1, N)],
    Signers = maps:from_list(
                [{maps:get(pubkey, Signer), Signer} || Signer <- SignerRows]),
    Committee = lists:sort(maps:keys(Signers)),
    CommitteeId = digest(2),
    NetworkIdentity = digest(250),
    RouteMap = maps:from_list(
               [{Key, {"127.0.0.1", 20000 + I}}
                || {Key, I} <- lists:zip(Committee, lists:seq(1, N))]),
    Routes = [{Key, [Endpoint]}
              || {Key, Endpoint} <- maps:to_list(RouteMap)],
    GroupId = crypto:hash(sha256, term_to_binary(
        {<<"quod.dtx.group">>, 4, digest(10)}, [deterministic])),
    Generation = 9,
    Verdict = commit,
    {Evidence, ResolveRef} = resolve_evidence(
                                Target, GroupId, Generation, Verdict,
                                Committee, CommitteeId, RouteMap,
                                hd(SignerRows)),
    Claim = #{target => Target, group_id => GroupId,
              resolve_ref => ResolveRef, generation => Generation,
              verdict => commit},
    View = #{identity => Target, slot => 8,
             committee => Committee, committee_id => CommitteeId,
             route_candidates => Routes},
    #{owner_ns => OwnerNs, target => Target, claim => Claim,
      evidence => Evidence, view => View, committee => Committee,
      committee_id => CommitteeId, source_routes => Routes,
      signers => Signers, network_identity => NetworkIdentity}.

resolve_evidence(Target, GroupId, Generation, Verdict,
                  Committee, CommitteeId, Routes, ControlSigner) ->
    Origin = {<<"quod:origin">>, digest(6)},
    OriginVote = certified_ref(Origin, 2, digest(7)),
    OwnVote = certified_ref(Target, 3, digest(8)),
    %% Collector boundary: exact-reference verification is supplied by the
    %% dependency fixture, not an invented foreign consensus chain.
    Resolve = {quod_dtx_resolve, 4, GroupId, Target, digest(10), Verdict,
               OriginVote, {all_prepared, lists:sort([{Origin, OriginVote}, {Target, OwnVote}])},
               OwnVote, Generation, none},
    {ok, Material} = quod_atomic:admission_material(Resolve),
    {ok, Control} = quod_atomic:sign_control(
                      Target, Material, digest(9), 1, 1, ControlSigner),
    Slot = 7,
    Payload = {batch, [{dtx, Control}]},
    Era = quod_ledger:initial_era(Target),
    {ok, Block} = quod_ledger:new_block(
                    {Era, Slot - 1}, {Era, 0, element(2, Target)}, Slot, Payload, 0),
    Entry = quod_ledger:entry(Slot, Block,
        quod_ct:protocol_certificate(Block, #{identity => Target, signer => ControlSigner})),
    {ok, ResolveRef} = quod_dtx:certified_entry_ref(Target, Entry, Control),
    {#{identity => Target, phase => resolve, control => Control,
       entry => Entry, committee => Committee, committee_id => CommitteeId,
       routes => Routes},
     ResolveRef}.

certificate(F, Keys, Overrides) ->
    Signers = maps:get(signers, F),
    certificate_with_signers(
      F, [maps:get(Key, Signers) || Key <- Keys], Overrides).

certificate_with_signers(F, Signers, Overrides) ->
    Binding = certificate_binding(F, Overrides),
    Rows = lists:keysort(
             1, [signed_row_with_signer(Binding, Signer)
                 || Signer <- Signers]),
    #{network_identity := NetworkIdentity, target := Target,
      committee_id := CommitteeId, group_id := GroupId,
      resolve_ref := ResolveRef, generation := Generation,
      verdict := Verdict} = Binding,
    {quod_dtx_applied_certificate, 2, NetworkIdentity, Target, CommitteeId,
     GroupId, ResolveRef, Generation, Verdict, Rows}.

certificate_binding(F, Overrides) ->
    Claim = maps:get(claim, F),
    maps:merge(
      #{network_identity => maps:get(network_identity, F),
        target => maps:get(target, F),
        committee_id => maps:get(committee_id, F),
        group_id => maps:get(group_id, Claim),
        resolve_ref => maps:get(resolve_ref, Claim),
        generation => maps:get(generation, Claim),
        verdict => maps:get(verdict, Claim)},
      Overrides).

signed_row(F, Key, Overrides) ->
    signed_row_with_signer(
      certificate_binding(F, Overrides),
      maps:get(Key, maps:get(signers, F))).

signed_row_with_signer(
  #{network_identity := NetworkIdentity, target := Target,
    committee_id := CommitteeId, group_id := GroupId,
    resolve_ref := ResolveRef, generation := Generation,
    verdict := Verdict},
  Signer) ->
    {ok, Row} = quod_applied_certificate:sign_applied_vote(
                  NetworkIdentity, Target, CommitteeId, GroupId, ResolveRef,
                  Generation, Verdict, Signer),
    Row.

signer() ->
    {Pub, Seed} = quod_identity:generate(),
    #{pubkey => Pub, key => quod_identity:key_term({Pub, Seed})}.

certified_ref({Ns, Anchor}, Slot, Digest) ->
    {ok, Ref} = quod_dtx:certified_ref(
                  Ns, Anchor, Slot, digest(240), Digest,
                  quod_ct:fixture_finality(Slot - 1, digest(240))),
    Ref.

collect_started(0, Acc) ->
    Acc;
collect_started(Left, Acc) ->
    receive
        {probe_started, Key, Pid} ->
            collect_started(Left - 1, Acc#{Key => Pid})
    after 2000 ->
        error({missing_probe_starts, Left})
    end.

collect_many_children(0, Acc) ->
    Acc;
collect_many_children(Left, Acc) ->
    receive
        {many_probe_started, Pid} ->
            collect_many_children(Left - 1, [Pid | Acc])
    after 2000 ->
        error({missing_many_children, Left})
    end.

digest(N) ->
    crypto:hash(sha256, <<N:64/unsigned-big>>).

agent_ref(Ns, Anchor, N) ->
    {ok, #{blob := Blob}} = quod_agent_ref:from_text(
                              Ns, Anchor,
                              <<"human_user(", (integer_to_binary(N))/binary,
                                ").">>,
                              2),
    Blob.
