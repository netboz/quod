-module(quod_evidence_resolver_tests).

-include_lib("eunit/include/eunit.hrl").
-include("quod_ledger.hrl").

%% Resolver sidecar for A's evidence rules and R2's hosted-only ownership rule.
%% R2 replaces A's insufficient-local fallback, not its proof/deadline checks.
%% No coordinator dependency injection:
%% every result below comes from real signed bytes and the production verifier.
%% The registered source implements the existing private history_view protocol,
%% just as the foreign-log/current-view fixtures do; it is not a consensus node.
%% Run sequentially: these tests own the VM's foreign-log registration and
%% temporary call-trace patterns. Gates acknowledge real queue/custody edges;
%% sleeps only cross an already captured absolute deadline. They do not model
%% transport delivery, endpoint readiness, or shared-caller expiry isolation.
%% Unknown-vocabulary/atom-count gates remain in the ledger-artifact, catchup,
%% DTX-endpoint, transaction, safe-term, and current-view test modules.

current_era_hit_has_one_committed_capture_and_zero_foreign_work_test() ->
    F = fixture(),
    with_case(F, current, fun(C) ->
        D = deadline(3000),
        ?assertMatch({ok, #{phase := resolve}}, resolve(C, maps:get(ref, F), resolve, D)),
        ?assertEqual([capture_request(F, D)], captures(C)),
        T = traces(),
        ?assertEqual(1, calls(T, quod_simplex, history_view_at, 3)),
        ?assertEqual(1, calls(T, quod_foreign_log, verify_resident_snapshot, 6)),
        ?assertEqual(1, calls(T, quod_ledger_store, open_ro_snapshot, 1)),
        ?assertEqual(1, calls(T, quod_ledger_store, read_at, 3)),
        assert_no_foreign_work(T),
        assert_no_fetch()
    end).

malformed_requests_are_refused_before_owner_work_test() ->
    F = fixture(),
    Ref = maps:get(ref, F),
    with_case(F, current, fun(C) ->
        WrongTarget = {maps:get(ns, F), digest(wrong_expected_anchor)},
        Cases = [{identity(F), malformed, resolve},
                 {identity(F), setelement(8, Ref, <<"malformed-finality">>), resolve},
                 {WrongTarget, Ref, resolve},
                 {identity(F), setelement(3, Ref, <<"wrong:namespace">>), resolve},
                 {identity(F), setelement(4, Ref, digest(wrong_ref_anchor)), resolve},
                 {identity(F), Ref, unknown_phase},
                 {malformed, Ref, resolve}],
        lists:foreach(fun({Target, R, Phase}) ->
            ?assertEqual({error, bad_foreign_reference},
                         resolve(C#{target := Target}, R, Phase, deadline(3000)))
        end, Cases),
        ?assertEqual({error, bad_foreign_reference},
                     resolve(C#{contact := maps:get(pub, F)}, Ref, resolve, deadline(3000))),
        ?assertEqual([], captures(C)),
        T = traces(),
        ?assertEqual(0, calls(T, quod_simplex, history_view, 3)),
        ?assertEqual(0, calls(T, quod_simplex, history_view_at, 3)),
        ?assertEqual(0, calls(T, quod_foreign_log, verification_call, 2)),
        assert_no_foreign_work(T),
        assert_no_fetch()
    end).

wrong_target_refusal_has_a_real_routed_primitive_control_test() ->
    F = fixture(),
    Other = quod_foreign_log_tests:foreign_fixture(maps:get(ns, F)),
    Ref = maps:get(ref, F),
    ?assertNotEqual(identity(F), identity(Other)),
    with_case(F, current, fun(C) ->
        %% The old route-only primitive lacks an expected-target argument and
        %% really authenticates these bytes. Rejection below cannot pass just
        %% because the reference is forged or its source is unreachable.
        {ok, Evidence} = result(traced_async(fun() ->
            quod_foreign_log:verify_reference(Ref, resolve, maps:get(contact, C), none, 3000)
        end)),
        ?assertEqual(identity(F), maps:get(identity, Evidence)),
        Positive = traces(),
        ?assertEqual(1, calls(Positive, quod_foreign_log, start_distinct_worker, 7)),
        ?assertEqual(1, calls(Positive, quod_foreign_log, spawn_verification_worker, 3)),
        flush_fetches(),
        ?assertEqual({error, bad_foreign_reference},
                     resolve(C#{target := identity(Other)}, Ref, resolve, deadline(3000))),
        ?assertEqual([], captures(C)),
        Negative = traces(),
        ?assertEqual(0, calls(Negative, quod_simplex, history_view, 3)),
        ?assertEqual(0, calls(Negative, quod_simplex, history_view_at, 3)),
        ?assertEqual(0, calls(Negative, quod_foreign_log, verification_call, 2)),
        assert_no_foreign_work(Negative),
        assert_no_fetch()
    end).

nonhosted_identity_routes_once_test_() ->
    [{atom_to_list(Mode), fun() -> nonhosted_identity_routes_once(Mode) end}
     || Mode <- [none, replaced_incarnation]].

nonhosted_identity_routes_once(Mode) ->
    F = fixture(),
    with_case(F, Mode, fun(C) ->
        D = deadline(3000),
        Ref = maps:get(ref, F),
        Hint = lists:last(maps:get(chain, F)),
        ?assertMatch({ok, #{phase := resolve}},
                     resolve(C#{hint := Hint}, Ref, resolve, D)),
        T = traces(),
        ?assertEqual(1, calls(T, quod_simplex, history_view_at, 3)),
        ?assertEqual(0, calls(T, quod_foreign_log, verify_resident_snapshot, 6)),
        assert_one_routed(T, C, Ref, resolve, Hint, D),
        %% Point evidence uses the shared proof reader without opening a
        %% material cache. Projection replay has its own restart control below.
        ?assertEqual(0, calls(T, quod_foreign_log, open_cache, 5)),
        ?assertEqual(0, calls(T, quod_catchup, range_accept, 5)),
        ?assert(calls(T, quod_catchup, evidence_accept, 4) > 0),
        receive {resolver_fetch, _, _} -> ok
        after 0 -> error(routed_positive_control_did_not_fetch)
        end,
        case Mode of
            none -> ok;
            _ -> ?assertEqual([capture_request(F, D)], captures(C))
        end
    end).

lagging_hosted_prefix_waits_for_verified_suffix_without_foreign_work_test() ->
    F = fixture(),
    with_case(F, lagging, fun(C) ->
        D = deadline(3000),
        Caller = resolve_async(C, maps:get(ref, F), resolve, D),
        Source = source_pid(C),
        try
            wait_pending(Source, D),
            ?assertEqual([capture_request(F, D)], captures(C)),
            %% The owner verifies and appends the actual signed suffix before
            %% publishing its existing progress edge. No fabricated evidence.
            ok = gen_server:call(Source, {append, tl(maps:get(chain, F))}),
            ?assertMatch({ok, #{phase := resolve}}, result(Caller)),
            ?assertEqual(lists:duplicate(2, capture_request(F, D)), captures(C)),
            T = traces(),
            ?assertEqual(1, calls(T, quod_simplex, history_view_at, 3)),
            ?assertEqual(1, calls(T, quod_foreign_log, verify_resident_snapshot, 6)),
            ?assertEqual(1, calls(T, quod_ledger_store, open_ro_snapshot, 1)),
            assert_no_foreign_work(T),
            assert_no_fetch()
        after exit(Caller, kill)
        end
    end).

lagging_hosted_prefix_expires_without_routed_repair_test() ->
    F = fixture(),
    with_case(F, lagging, fun(C) ->
        D = deadline(400),
        Caller = resolve_async(C, maps:get(ref, F), resolve, D),
        try
            wait_pending(source_pid(C), D),
            ?assertEqual({error, retry}, result(Caller)),
            ?assertEqual([capture_request(F, D)], captures(C)),
            T = traces(),
            ?assertEqual(0, calls(T, quod_ledger_store, open_ro_snapshot, 1)),
            assert_no_foreign_work(T),
            assert_no_fetch()
        after exit(Caller, kill)
        end
    end).

unavailable_hosted_capture_does_not_route_test() ->
    F = fixture(),
    with_case(F, capture_unavailable, fun(C) ->
        D = deadline(3000),
        ?assertEqual({error, not_ready}, resolve(C, maps:get(ref, F), resolve, D)),
        ?assertEqual([capture_request(F, D)], captures(C)),
        assert_no_foreign_work(traces()),
        assert_no_fetch()
    end).

persisted_cache_replays_at_startup_not_on_later_requests_test() ->
    F = fixture(),
    with_case(F, none, fun(C) ->
        Ref = maps:get(ref, F),
        ?assertMatch({ok, _}, resolve(C, Ref, resolve, deadline(3000))),
        {Peer, Endpoint} = maps:get(contact, C),
        {ok, _} = quod_foreign_log_tests:prime_projection(
            [{Peer, [Endpoint]}], identity(F), length(maps:get(chain, F)), 3000),
        _ = traces(),
        flush_fetches(),
        quod_foreign_log_tests:stop_owner(maps:get(foreign, C)),
        Parent = self(),
        %% Trace the launcher before it starts the real owner. Inheritance
        %% covers initialization from its first instruction, not after init/1.
        Launcher = spawn(fun() ->
            receive start -> ok end,
            Owner = quod_foreign_log_tests:start_owner(maps:get(cache_dir, C), maps:get(fetch, C)),
            Parent ! {started_history_owner, self(), Owner},
            receive stop -> ok end
        end),
        start_trace(Launcher),
        Launcher ! start,
        New = receive {started_history_owner, Launcher, Pid} -> Pid
              after 2000 -> error(history_owner_not_started)
              end,
        try
            quod_foreign_log_tests:await_history_ready(identity(F), length(maps:get(chain, F))),
            Startup = traces(),
            ?assert(calls(Startup, quod_foreign_log, replay_cache, 7) > 0),
            ?assert(calls(Startup, quod_ledger_store, open, 3) > 0),
            ?assertEqual(1, calls(Startup, quod_foreign_log, spawn_verification_worker, 3)),
            assert_no_fetch(),
            ?assertMatch({ok, _}, resolve(C#{foreign := New}, Ref, resolve, deadline(3000))),
            T = traces(),
            ?assertEqual(0, calls(T, quod_foreign_log, replay_cache, 7)),
            ?assertEqual(0, calls(T, quod_ledger_store, open, 3)),
            %% The published prefix serves an exact read in its caller. It
            %% neither reacquires mutable custody nor starts a history job.
            ?assertEqual(0, calls(T, quod_foreign_log, spawn_verification_worker, 3)),
            ?assertEqual(1, calls(T, quod_ledger_store, open_ro_snapshot, 1)),
            ?assertEqual(1, calls(T, quod_ledger_store, read_at, 3)),
            assert_no_fetch()
        after
            stop_trace(Launcher),
            stop_trace(New),
            quod_foreign_log_tests:stop_owner(New),
            Launcher ! stop
        end
    end).

capture_owner_death_before_a_usable_view_stays_unavailable_test() ->
    F = fixture(),
    with_case(F, hold_capture, fun(C) ->
        D = deadline(3000),
        Ref = maps:get(ref, F),
        Caller = resolve_async(C, Ref, resolve, D),
        Source = source_pid(C),
        receive {resolver_capture_held, Source, D} -> ok
        after 1000 -> error(capture_not_held)
        end,
        try
            stop_source(maps:get(source, C)),
            ?assertEqual({error, not_ready}, result(Caller)),
            T = traces(),
            ?assertEqual(1, calls(T, quod_simplex, history_view_at, 3)),
            assert_no_foreign_work(T),
            assert_no_fetch()
        after
            exit(Caller, kill)
        end
    end).

sufficient_invalid_local_evidence_never_falls_back_test() ->
    F = fixture(),
    Ref = maps:get(ref, F),
    Cases = [{setelement(6, Ref, digest(changed_hash)), resolve, invalid_foreign_reference},
             {setelement(7, Ref, digest(changed_record)), resolve, invalid_foreign_reference},
             {Ref, vote, phase_mismatch}],
    with_case(F, current, fun(C) ->
        lists:foreach(fun({R, Phase, Error}) ->
            ?assertEqual({error, Error}, resolve(C, R, Phase, deadline(3000)))
        end, Cases),
        T = traces(),
        ?assertEqual(length(Cases), calls(T, quod_simplex, history_view_at, 3)),
        assert_no_foreign_work(T),
        assert_no_fetch()
    end).

current_era_accepts_distinct_valid_quorum_subsets_test() ->
    F = committee_fixture(false),
    Ref = maps:get(ref, F),
    Members = maps:get(members, F),
    Other = reference_with_signers(F, Ref, tl(Members)),
    ?assertNotEqual(element(8, Ref), element(8, Other)),
    ?assert(quod_dtx:same_certified_ref(Ref, Other)),
    with_case(F, current, fun(C) ->
        {ok, A} = resolve(C, Ref, transaction, deadline(3000)),
        {ok, B} = resolve(C, Other, transaction, deadline(3000)),
        ?assertEqual(A, B),
        ?assertEqual(5, length(maps:get(committee, A))),
        %% An unused preferred head cannot change the authority of the
        %% selected resident proof, even when its signers are outsiders.
        Outsiders = new_members(4),
        WrongEra = reference_with_signers(F, Ref, lists:sublist(Outsiders, 3)),
        assert_cert_valid_for(F, WrongEra, Outsiders),
        ?assertEqual({ok, A}, resolve(C, WrongEra, transaction, deadline(3000))),
        assert_no_foreign_work(traces()),
        assert_no_fetch()
    end).

historical_era_uses_verified_resident_proof_despite_unused_hints_test() ->
    F = committee_fixture(true),
    Ref = maps:get(ref, F),
    Members = maps:get(members, F),
    OldKeys = [K || {K, _} <- Members],
    NewMembers = lists:sublist(Members, 4),
    WrongEra = reference_with_signers(F, Ref, lists:sublist(NewMembers, 3)),
    assert_cert_valid_for(F, WrongEra, NewMembers),
    {ok, Cert} = quod_ledger:decode_finality_head(element(8, Ref)),
    [{Pub, _} | Rest] = Cert#cert.sigs,
    BadSig = reference_with_head(Ref, Cert#cert{sigs = [{Pub, <<0:512>>} | Rest]}),
    Alternate = reference_with_signers(F, Ref, tl(Members)),
    with_case(F, current, fun(C) ->
        {ok, A} = resolve(C, Ref, transaction, deadline(3000)),
        ?assertEqual(OldKeys, maps:get(committee, A)),
        {ok, B} = resolve(C, Alternate, transaction, deadline(3000)),
        ?assertEqual(A, B),
        lists:foreach(fun(R) ->
            ?assert(quod_dtx:same_certified_ref(Ref, R)),
            ?assertEqual({ok, A}, resolve(C, R, transaction, deadline(3000)))
        end, [WrongEra, BadSig]),
        T = traces(),
        ?assertEqual(4, calls(T, quod_simplex, history_view_at, 3)),
        ?assertEqual(0, calls(T, quod_foreign_log, spawn_verification_worker, 3)),
        ?assertEqual(0, calls(T, quod_foreign_log, start_distinct_worker, 7)),
        assert_no_fetch()
    end).

pinned_owner_loss_never_recaptures_or_routes_test_() ->
    [{atom_to_list(Stage), fun() -> pinned_owner_loss(Stage) end}
     || Stage <- [before_verification, after_verification]].

pinned_owner_loss(Stage) ->
    F = historical_fixture(),
    with_case(F, current, fun(C) ->
        Gate = case Stage of before_verification -> before_read; after_verification -> after_read end,
        {Caller, Token} = held_historical_call(C, deadline(3000), Gate),
        try
            ?assertEqual(1, length(captures(C))),
            stop_source(maps:get(source, C)),
            ReplacementDir = temp_dir("replacement"),
            Replacement = start_source(ReplacementDir, F, current),
            try
                Caller ! {release_local_read, Token},
                ?assertEqual({error, retry}, result(Caller)),
                ?assertEqual([], source_captures(Replacement)),
                T = traces(),
                ?assertEqual(1, calls(T, quod_simplex, history_view_at, 3)),
                assert_no_foreign_work(T),
                assert_no_fetch()
            after
                stop_source(Replacement),
                _ = file:del_dir_r(ReplacementDir)
            end
        after exit(Caller, kill)
        end
    end).

expired_or_invalid_deadline_never_starts_capture_test() ->
    F = fixture(),
    with_case(F, current, fun(C) ->
        ?assertEqual({error, retry}, resolve(C, maps:get(ref, F), resolve, deadline(-1))),
        lists:foreach(fun(D) ->
            ?assertEqual({error, bad_foreign_reference}, resolve(C, maps:get(ref, F), resolve, D))
        end, [infinity, 1.5, invalid]),
        ?assertEqual([], captures(C)),
        T = traces(),
        ?assertEqual(0, calls(T, quod_simplex, history_view, 3)),
        ?assertEqual(0, calls(T, quod_simplex, history_view_at, 3)),
        assert_no_foreign_work(T)
    end).

queued_capture_cannot_launch_after_expiry_test() ->
    F = fixture(),
    with_case(F, hold_capture, fun(C) ->
        D = deadline(400),
        Caller = resolve_async(C, maps:get(ref, F), resolve, D),
        Source = source_pid(C),
        receive {resolver_capture_held, Source, D} -> ok
        after 1000 -> error(capture_not_held)
        end,
        try
            wait_expired(D),
            Source ! release_capture,
            ?assertEqual({error, retry}, result(Caller)),
            ?assertEqual([capture_request(F, D)], captures(C)),
            T = traces(),
            ?assertEqual(1, calls(T, quod_simplex, history_view_at, 3)),
            ?assertEqual(0, calls(T, quod_foreign_log, verify_resident_snapshot, 6)),
            assert_no_foreign_work(T),
            assert_no_fetch()
        after
            Source ! release_capture,
            exit(Caller, kill)
        end
    end).

queued_routed_admission_preserves_capture_deadline_test() ->
    F = fixture(),
    with_case(F, held_other_incarnation, fun(C) ->
        Owner = maps:get(foreign, C),
        Source = source_pid(C),
        D = deadline(600),
        Caller = resolve_async(C, maps:get(ref, F), resolve, D),
        receive {resolver_capture_held, Source, D} -> ok
        after 1000 -> error(capture_not_held)
        end,
        try
            ok = sys:suspend(Owner),
            Source ! release_capture,
            Envelope = wait_message(Owner, fun
                ({'$gen_call', _, {verification, _, _, _, {verify_reference, _, _, _, _, _}}}) -> true;
                (_) -> false
            end),
            {'$gen_call', _, {verification, ActualDeadline, _, _, _}} = Envelope,
            ?assertEqual(D, ActualDeadline),
            ?assert(D > quod_time:mono_ms()),
            wait_expired(D),
            ok = sys:resume(Owner),
            ?assertEqual({error, retry}, result(Caller)),
            ?assertEqual([capture_request(F, D)], captures(C)),
            T = traces(),
            ?assertEqual(1, calls(T, quod_foreign_log, verification_call, 2)),
            assert_no_foreign_work(T),
            assert_no_fetch()
        after
            Source ! release_capture,
            _ = catch sys:resume(Owner),
            exit(Caller, kill)
        end
    end).

historical_local_read_never_queues_at_foreign_owner_test() ->
    F = historical_fixture(),
    with_case(F, current, fun(C) ->
        Owner = maps:get(foreign, C),
        ok = sys:suspend(Owner),
        try
            ?assertMatch({ok, #{phase := resolve}},
                         resolve(C, maps:get(ref, F), resolve, deadline(1000))),
            T = traces(),
            ?assertEqual(0, calls(T, quod_foreign_log, verification_call, 2)),
            assert_no_foreign_work(T),
            assert_no_fetch()
        after ok = sys:resume(Owner)
        end
    end).

verified_local_success_cannot_publish_after_expiry_test() ->
    F = historical_fixture(),
    with_case(F, current, fun(C) ->
        D = deadline(1000),
        {Caller, Token} = held_historical_call(C, D, after_read),
        try
            ?assert(D > quod_time:mono_ms()),
            wait_expired(D),
            Caller ! {release_local_read, Token},
            ?assertEqual({error, retry}, result(Caller)),
            ?assertEqual([capture_request(F, D)], captures(C)),
            assert_no_foreign_work(traces()),
            assert_no_fetch()
        after exit(Caller, kill)
        end
    end).

append_after_capture_preserves_the_borrowed_prefix_test() ->
    Full = historical_fixture(),
    Chain = maps:get(chain, Full),
    F = Full#{chain := lists:sublist(Chain, 2)},
    with_case(F, {append_before_reply, [lists:last(Chain)]}, fun(C) ->
        ?assertMatch({ok, #{phase := resolve, slot := 2}},
                     resolve(C, maps:get(ref, F), resolve, deadline(3000))),
        ?assertEqual(3, gen_server:call(source_pid(C), height)),
        T = traces(),
        ?assertEqual(1, calls(T, quod_simplex, history_view_at, 3)),
        ?assertEqual(1, calls(T, quod_ledger_store, open_ro_snapshot, 1)),
        assert_no_foreign_work(T),
        assert_no_fetch()
    end).

%% Serving-API adapter coverage only. The fixture below is NOT a running
%% Simplex readiness endpoint: readiness/applied-state and reference-worker
%% result handling are tested separately by their owners.
local_serving_uses_any_capture_and_unchanged_absolute_deadline_test() ->
    F = fixture(),
    Ref = maps:get(ref, F),
    with_case(F, current, fun(C) ->
        D = deadline(3000),
        ?assertMatch({ok, #{phase := resolve}},
                     local_evidence(C, maps:get(ns, F), Ref, resolve, D)),
        ?assertEqual([{identity(F), any, D}], captures(C)),
        T = traces(),
        LocalCalls = [Args || {trace, _, call, {quod_foreign_log, verify_local_deadline, Args}} <- T],
        ?assertMatch([[#{owner := _, identity := _, snapshot := _}, Ref, resolve, D]], LocalCalls),
        [[View, _, _, _]] = LocalCalls,
        ?assertEqual(identity(F), maps:get(identity, View)),
        ?assertEqual(source_pid(C), maps:get(owner, View)),
        ?assertEqual(1, calls(T, quod_simplex, history_view, 3)),
        ?assertEqual(1, calls(T, quod_ledger_store, read_at, 3)),
        assert_no_foreign_work(T),
        assert_no_fetch()
    end).

local_serving_expiry_is_not_ready_without_routed_fallback_test_() ->
    [{atom_to_list(Stage), fun() -> local_serving_expiry(Stage) end}
     || Stage <- [already_expired, queued_capture]].

local_serving_expiry(Stage) ->
    F = fixture(),
    with_case(F, hold_capture, fun(C) ->
        D = case Stage of already_expired -> deadline(-1); queued_capture -> deadline(400) end,
        Source = source_pid(C),
        Caller = local_evidence_async(maps:get(ns, F), maps:get(ref, F), resolve, D),
        try
            case Stage of
                already_expired -> ok;
                queued_capture ->
                    receive {resolver_capture_held, Source, D} -> ok
                    after 1000 -> error(capture_not_held)
                    end,
                    wait_expired(D),
                    Source ! release_capture
            end,
            ?assertEqual({error, not_ready}, result(Caller)),
            ExpectedCaptures = case Stage of
                already_expired -> [];
                queued_capture -> [{identity(F), any, D}]
            end,
            ?assertEqual(ExpectedCaptures, captures(C)),
            T = traces(),
            ?assertEqual(0, calls(T, quod_foreign_log, verify_local_deadline, 4)),
            assert_no_foreign_work(T),
            assert_no_fetch()
        after
            Source ! release_capture,
            exit(Caller, kill)
        end
    end).

local_serving_unavailable_copy_never_routes_test_() ->
    [{atom_to_list(Mode), fun() -> local_serving_unavailable_copy(Mode, Error) end}
     || {Mode, Error} <- [{lagging, not_found}, {none, not_ready},
                          {replaced_incarnation, invalid_request}]].

local_serving_unavailable_copy(Mode, Error) ->
    F = fixture(),
    with_case(F, Mode, fun(C) ->
        D = deadline(3000),
        ?assertEqual({error, Error},
                     local_evidence(C, maps:get(ns, F), maps:get(ref, F), resolve, D)),
        case Mode of
            none -> ok;
            _ -> ?assertEqual([{identity(F), any, D}], captures(C))
        end,
        T = traces(),
        ?assertEqual(0, calls(T, quod_foreign_log, verify_local_deadline, 4)),
        assert_no_foreign_work(T),
        assert_no_fetch()
    end).

local_serving_wrong_expected_namespace_is_invalid_before_capture_test() ->
    F = fixture(),
    with_case(F, current, fun(C) ->
        ?assertEqual({error, invalid_request},
                     local_evidence(C, <<"wrong:serving:namespace">>, maps:get(ref, F), resolve, deadline(3000))),
        ?assertEqual([], captures(C)),
        T = traces(),
        ?assertEqual(0, calls(T, quod_simplex, history_view, 3)),
        ?assertEqual(0, calls(T, quod_foreign_log, verify_local_deadline, 4)),
        assert_no_foreign_work(T),
        assert_no_fetch()
    end).

%% One immutable candidate can require different records from the same block.
%% Each record still crosses the ordinary signed decoder and exact checker;
%% only the completed block proof is shared within this candidate.
candidate_same_entry_reuses_one_verified_source_test_() ->
    [{atom_to_list(Mode), fun() -> candidate_same_entry_reuses_one_verified_source(Mode) end}
     || Mode <- [foreign, local, cohosted]].

candidate_same_entry_reuses_one_verified_source(Mode) ->
    F = batch_fixture(),
    SourceMode = case Mode of foreign -> none; _ -> current end,
    with_case(F, SourceMode, fun(C) ->
        [First | _] = Refs = maps:get(refs, F),
        {LocalIdentity, LocalSource} = case Mode of
            local -> {identity(F), gen_server:call(source_pid(C), view)};
            _ -> {{<<"validating:other">>, digest(validating_other)}, undefined}
        end,
        Contacts = #{First => {identity(F), maps:get(contact, C)}},
        Caller = traced_async(fun() ->
            quod_simplex:test_verify_content_requirements(
              [{transaction, Ref} || Ref <- Refs], LocalIdentity,
              LocalSource, Contacts, #{}, deadline(3000))
        end),
        {valid, Seen} = result(Caller),
        lists:foreach(fun({Ref, Transaction}) ->
            Evidence = maps:get(Ref, Seen),
            assert_selected_transaction(F, Ref, Transaction, Evidence),
            Candidate = #transaction{role = {remote_application, none, none, none},
              evidence = {Ref, Transaction}, foreign_reads = []},
            ?assertEqual(ok, quod_commit_validation:validate_evidence(Candidate, Seen)),
            [Other | _] = [Tx || Tx <- maps:get(transactions, F), Tx =/= Transaction],
            ?assertEqual({error, foreign_reference_binding},
              quod_commit_validation:validate_evidence(
                Candidate#transaction{evidence = {Ref, Other}}, Seen))
        end, lists:zip(Refs, maps:get(transactions, F))),
        T = traces(),
        ?assertEqual(2, calls(T, quod_foreign_log, reselect_verified, 4)),
        case Mode of
            foreign ->
                ?assertEqual(1, calls(T, quod_foreign_log, verification_call, 2)),
                ?assertEqual(1, calls(T, quod_foreign_log, spawn_verification_worker, 3)),
                ?assert(calls(T, quod_catchup, evidence_accept, 4) > 0),
                %% The real fixture sender runs in the first proof worker
                %% and reads its archive. Reselection stays in the caller.
                [SourcePid] = lists:usort([Pid || {trace, Pid, call,
                    {quod_catchup, evidence_accept, _}} <- T]),
                ?assertNotEqual(Caller, SourcePid),
                ReadPids = lists:usort([Pid || {trace, Pid, call,
                    {quod_ledger_store, read_at, [_, _, _]}} <- T]),
                ?assertEqual([SourcePid], ReadPids),
                receive {resolver_fetch, _, _} -> ok
                after 0 -> error(first_record_was_not_fetched)
                end;
            _ ->
                ?assertEqual(1, calls(T, quod_ledger_store, read_at, 3)),
                ?assertEqual(1, calls(T, quod_foreign_log, verify_local_deadline, 4)),
                ?assertEqual(case Mode of local -> 0; cohosted -> 1 end,
                             calls(T, quod_simplex, history_view_at, 3)),
                assert_no_foreign_work(T),
                assert_no_fetch()
        end
    end).

same_entry_reselection_preserves_claim_and_witness_rules_test_() ->
    [{atom_to_list(Mode), fun() -> same_entry_reselection_preserves_claim_and_witness_rules(Mode) end}
     || Mode <- [none, current]].

same_entry_reselection_preserves_claim_and_witness_rules(Mode) ->
    F = batch_fixture(),
    with_case(F, Mode, fun(C) ->
        [First, Second, Third] = maps:get(refs, F),
        [_, Tx2, Tx3] = maps:get(transactions, F),
        {ok, Evidence} = resolve(C, First, transaction, deadline(3000)),
        _ = traces(),
        flush_fetches(),
        Alternate = reference_with_signers(F, Second, tl(maps:get(members, F))),
        ?assertNotEqual(Second, Alternate),
        ?assert(quod_dtx:same_certified_ref(Second, Alternate)),
        {ok, Selected} = reselect(Evidence, Alternate, transaction, deadline(3000)),
        assert_selected_transaction(F, Second, Tx2, Selected),
        %% Provenance must survive successive selections, not only the first.
        {ok, Selected3} = reselect(Selected, Third, entry, deadline(3000)),
        assert_selected_transaction(F, Third, Tx3, Selected3),
        {ok, Cert} = quod_ledger:decode_finality_head(element(8, Second)),
        [{Signer, _} | Signatures] = Cert#cert.sigs,
        UnusedBadWitness = reference_with_head(Second,
            Cert#cert{sigs = [{Signer, <<0:512>>} | Signatures]}),
        ?assertEqual({ok, Selected},
          reselect(Evidence, UnusedBadWitness, transaction, deadline(3000))),
        Invalid = [setelement(3, Second, <<"wrong:namespace">>),
                   setelement(4, Second, digest(wrong_reselect_anchor)),
                   setelement(5, Second, 3),
                   setelement(6, Second, digest(wrong_reselect_block)),
                   setelement(7, Second, digest(absent_record))],
        lists:foreach(fun(Ref) ->
            ?assertEqual({error, invalid_foreign_reference},
              reselect(Evidence, Ref, transaction, deadline(3000)))
        end, Invalid),
        ?assertEqual({error, invalid_foreign_reference},
          reselect(Evidence, Second, vote, deadline(3000))),
        lists:foreach(fun(Ref) ->
            ?assertEqual({error, bad_foreign_reference},
              reselect(Evidence, Ref, transaction, deadline(3000)))
        end, [malformed, setelement(4, Second, malformed),
              setelement(8, Second, <<"malformed-finality">>)]),
        ?assertEqual({error, bad_foreign_reference},
          reselect(Evidence, Second, unknown_phase, deadline(3000))),
        ?assertEqual({error, retry},
          reselect(Evidence, Second, transaction, deadline(-1))),
        T = traces(),
        ?assertEqual(0, calls(T, quod_simplex, history_view_at, 3)),
        ?assertEqual(0, calls(T, quod_ledger_store, read_at, 3)),
        ?assert(calls(T, quod_transaction, verify_submission, 1) >= 3),
        assert_no_foreign_work(T),
        assert_no_fetch()
    end).

same_entry_new_selection_preserves_hosted_incarnation_test_() ->
    [{atom_to_list(Stage) ++ "-" ++ atom_to_list(Change),
      fun() -> same_entry_new_selection_preserves_hosted_incarnation(Stage, Change) end}
     || Stage <- [before_read, after_read], Change <- [death, replacement]].

same_entry_new_selection_preserves_hosted_incarnation(Stage, Change) ->
    F = batch_fixture(),
    with_case(F, current, fun(C) ->
        [First, Second, Third] = maps:get(refs, F),
        {ok, Evidence} = resolve(C, First, transaction, deadline(3000)),
        {ok, SecondEvidence} = reselect(Evidence, Second, transaction, deadline(3000)),
        _ = traces(),
        Token = make_ref(), Parent = self(),
        Caller = traced_async(fun() ->
            put({quod_foreign_log, local_read_gate}, {Stage, Parent, Token}),
            quod_foreign_log:reselect_verified(SecondEvidence, Third, transaction, deadline(3000))
        end),
        receive {local_read_held, Token, Caller} -> ok
        after 2000 -> exit(Caller, kill), error(reselection_not_held)
        end,
        ReplacementDir = temp_dir("reselect-replacement"),
        stop_source(maps:get(source, C)),
        Replacement = case Change of
            death -> none;
            replacement -> start_source(ReplacementDir, F, current)
        end,
        try
            Caller ! {release_local_read, Token},
            ?assertEqual({error, retry}, result(Caller)),
            case Replacement of
                none -> ok;
                _ -> ?assertEqual([], source_captures(Replacement))
            end,
            T = traces(),
            ?assertEqual(0, calls(T, quod_simplex, history_view_at, 3)),
            ?assertEqual(0, calls(T, quod_ledger_store, read_at, 3)),
            assert_no_foreign_work(T),
            assert_no_fetch()
        after
            exit(Caller, kill),
            stop_source(Replacement),
            _ = file:del_dir_r(ReplacementDir)
        end
    end).

completed_foreign_entry_reselection_needs_no_live_foreign_capture_test() ->
    F = batch_fixture(),
    with_case(F, none, fun(C) ->
        [First, Second | _] = maps:get(refs, F),
        [_, Transaction | _] = maps:get(transactions, F),
        {ok, Evidence} = resolve(C, First, transaction, deadline(3000)),
        quod_foreign_log_tests:stop_owner(maps:get(foreign, C)),
        _ = traces(),
        flush_fetches(),
        {ok, Selected} = reselect(Evidence, Second, transaction, deadline(3000)),
        assert_selected_transaction(F, Second, Transaction, Selected),
        T = traces(),
        ?assertEqual(0, calls(T, quod_simplex, history_view_at, 3)),
        ?assertEqual(0, calls(T, quod_ledger_store, read_at, 3)),
        assert_no_foreign_work(T),
        assert_no_fetch()
    end).

same_entry_reselection_cannot_publish_after_original_deadline_test() ->
    F = batch_fixture(),
    with_case(F, current, fun(C) ->
        [First, Second | _] = maps:get(refs, F),
        {ok, Evidence} = resolve(C, First, transaction, deadline(3000)),
        _ = traces(),
        Token = make_ref(), Parent = self(), D = deadline(400),
        Caller = traced_async(fun() ->
            put({quod_foreign_log, local_read_gate}, {after_read, Parent, Token}),
            quod_foreign_log:reselect_verified(Evidence, Second, transaction, D)
        end),
        receive {local_read_held, Token, Caller} -> ok
        after 2000 -> exit(Caller, kill), error(reselection_not_held)
        end,
        try
            %% Selection has completed; only the captured absolute deadline
            %% is allowed to elapse. This is expiry, not a readiness wait.
            wait_expired(D),
            Caller ! {release_local_read, Token},
            ?assertEqual({error, retry}, result(Caller)),
            T = traces(),
            ?assertEqual(0, calls(T, quod_simplex, history_view_at, 3)),
            ?assertEqual(0, calls(T, quod_ledger_store, read_at, 3)),
            ?assertEqual(1, calls(T, quod_transaction, verify_submission, 1)),
            assert_no_foreign_work(T),
            assert_no_fetch()
        after exit(Caller, kill)
        end
    end).

reselect(Evidence, Ref, Phase, Deadline) ->
    result(traced_async(fun() ->
        quod_foreign_log:reselect_verified(Evidence, Ref, Phase, Deadline)
    end)).

assert_selected_transaction(F, Ref, Transaction, Evidence) ->
    ?assertEqual(identity(F), maps:get(identity, Evidence)),
    ?assertEqual(2, maps:get(slot, Evidence)),
    ?assertEqual(element(6, Ref), maps:get(block_hash, Evidence)),
    ?assertEqual(element(7, Ref), maps:get(record_digest, Evidence)),
    ?assertEqual(transaction, maps:get(phase, Evidence)),
    ?assertEqual([Key || {Key, _} <- maps:get(members, F)], maps:get(committee, Evidence)),
    Selected = maps:get(transaction, Evidence),
    ?assert(quod_transaction:same_ledger_transaction(Transaction, Selected)),
    ?assertEqual(Selected, quod_ledger:selected_record(maps:get(entry, Evidence))).

%% Harness: reuse the foreign-log suite's signed genesis/control fixtures,
%% verified projection constructor, real fetch bytes, and real foreign owner.
fixture() -> quod_foreign_log_tests:foreign_fixture(quod_foreign_log_tests:unique_ns()).
historical_fixture() ->
    quod_foreign_log_tests:membership_after_finalize_fixture(quod_foreign_log_tests:unique_ns()).
identity(F) -> {maps:get(ns, F), maps:get(anchor, F)}.
capture_request(F, D) -> {identity(F), {committed, element(5, maps:get(ref, F))}, D}.
deadline(Ms) -> quod_time:mono_ms() + Ms.
digest(Term) -> crypto:hash(sha256, term_to_binary({resolver_test, Term})).
temp_dir(Label) -> quod_foreign_log_tests:temp_dir("resolver-" ++ Label).

with_case(F, Mode, Fun) ->
    {ok, _} = application:ensure_all_started(gproc),
    CacheDir = temp_dir("cache"),
    SourceDir = temp_dir("source"),
    Parent = self(),
    Fetch0 = quod_foreign_log_tests:chain_fetch(maps:get(ns, F), maps:get(chain, F)),
    Fetch = fun(Peer, Endpoint, Ns, Query, Deadline, Consume) ->
        Parent ! {resolver_fetch, Query, Deadline},
        Fetch0(Peer, Endpoint, Ns, Query, Deadline, Consume)
    end,
    Owner = quod_foreign_log_tests:start_owner(CacheDir, Fetch),
    Source = case Mode of
        none -> none;
        lagging -> start_source(SourceDir, F#{chain := [hd(maps:get(chain, F))]}, current);
        replaced_incarnation ->
            start_source(SourceDir, quod_foreign_log_tests:foreign_fixture(maps:get(ns, F)), current);
        held_other_incarnation ->
            start_source(SourceDir, quod_foreign_log_tests:foreign_fixture(maps:get(ns, F)), hold_capture);
        _ -> start_source(SourceDir, F, Mode)
    end,
    C = #{fixture => F, target => identity(F), foreign => Owner, source => Source,
          contact => {maps:get(pub, F), {"127.0.0.1", 19000}}, hint => none,
          cache_dir => CacheDir, fetch => Fetch},
    try
        start_trace(Owner),
        Fun(C)
    after
        stop_trace(Owner),
        stop_source(Source),
        quod_foreign_log_tests:stop_owner(Owner),
        _ = file:del_dir_r(SourceDir),
        _ = file:del_dir_r(CacheDir),
        flush_fetches()
    end.

start_source(Dir, F, Mode) ->
    Parent = self(),
    {Pid, Monitor} = spawn_monitor(fun() ->
        {ok, Store0} = quod_ledger_store:open(maps:get(ns, F), Dir),
        {Ns, _} = identity(F),
        {ok, Index} = quod_dtx_phase_index:open(Dir, Ns),
        {Store, Projection} = install_entries(Store0, identity(F),
            quod_simplex:history_projection(identity(F)), Index, maps:get(chain, F)),
        true = quod_reg:reg({quod_simplex, Ns}),
        %% Applied=0 deliberately proves this is a committed-history borrow,
        %% not an execution-readiness requirement. Keep only the real live era.
        View = indexed_source_view(Store, Projection, Index),
        Parent ! {resolver_source_ready, self()},
        source_loop(Store, View, Index, Mode, Parent, [])
    end),
    receive
        {resolver_source_ready, Pid} -> {Pid, Monitor};
        {'DOWN', Monitor, process, Pid, Reason} -> error({source_failed, Reason})
    after 3000 -> exit(Pid, kill), error(source_start_timeout)
    end.

source_loop(Store, View, Index, Mode, Parent, Captures) ->
    receive
        {'$gen_call', From, {history_view, Target, Requirement, D}} ->
            Captures1 = [{Target, Requirement, D} | Captures],
            case Mode of
                hold_capture -> hold_capture(Parent, D);
                _ -> ok
            end,
            {Store1, View1} = case Mode of
                {append_before_reply, Entries} ->
                    append_verified_suffix(Store, View, Index, Entries);
                _ -> {Store, View}
            end,
            Reply = case {Target =:= maps:get(identity, View), Requirement,
                          Mode, D > quod_time:mono_ms()} of
                {_, _, _, false} -> {error, timeout};
                {false, _, _, true} -> {error, invalid_identity};
                {true, _, capture_unavailable, true} -> {error, not_ready};
                {true, {committed, Required}, _, true} ->
                    case maps:get(slot, View) >= Required of
                        true -> {ok, View};
                        false -> {pending, maps:get(slot, View)}
                    end;
                {true, R, _, true} when R =:= committed; R =:= any -> {ok, View};
                _ -> {error, not_ready}
            end,
            gen:reply(From, Reply),
            case Reply of
                {pending, _} -> Parent ! {resolver_pending, self(), D};
                _ -> ok
            end,
            source_loop(Store1, View1, Index, current, Parent, Captures1);
        {'$gen_call', From, {append, Entries}} ->
            {Store1, View1} = append_verified_suffix(Store, View, Index, Entries),
            {Ns, _} = maps:get(identity, View1),
            _ = quod_reg:publish({committed, Ns}, {certified_head, Ns, maps:get(slot, View1)}),
            gen:reply(From, ok),
            source_loop(Store1, View1, Index, Mode, Parent, Captures);
        {'$gen_call', From, captures} ->
            gen:reply(From, lists:reverse(Captures)),
            source_loop(Store, View, Index, Mode, Parent, Captures);
        {'$gen_call', From, height} ->
            gen:reply(From, quod_ledger_store:last(Store)),
            source_loop(Store, View, Index, Mode, Parent, Captures);
        {'$gen_call', From, view} ->
            gen:reply(From, View),
            source_loop(Store, View, Index, Mode, Parent, Captures);
        stop -> quod_dtx_phase_index:close(Index), quod_ledger_store:close(Store)
    end.

%% Protocol fixture, not consensus admission: real window verification and
%% append-then-index installation, with one retained owner index throughout.
append_verified_suffix(Store, View, Index, Entries) ->
    {Store1, Projection} = install_entries(Store, maps:get(identity, View),
        maps:get(projection, View), Index, Entries),
    {Store1, indexed_source_view(Store1, Projection, Index)}.

install_entries(Store, Identity, Projection, Index, Entries) ->
    lists:foldl(fun(Entry, {S, P}) ->
        {ok, #{projection := P1, delta := Delta, proof := Proof}} =
            quod_ct:history_group(Identity, Entry, P, Index),
        {ok, S1} = quod_ledger_store:append(S, {Proof, [Entry]}),
        ok = quod_dtx_phase_index:commit_delta(Index, Delta),
        {S1, P1}
    end, {Store, Projection}, Entries).

indexed_source_view(Store, Projection, Index) ->
    H = quod_ledger_store:last(Store),
    {ok, Borrow} = quod_dtx_phase_index:capture(Index, H),
    #{owner => self(), identity => maps:get(target, maps:get(dtx, Projection)),
      slot => H, applied => 0, snapshot => quod_ledger_store:snapshot(Store),
      projection => Projection#{history_index => Borrow,
          committee_views := lists:sublist(maps:get(committee_views, Projection), 1)}}.

wait_pending(Source, D) ->
    receive {resolver_pending, Source, D} -> ok
    after 1000 -> error(local_prefix_did_not_wait)
    end.

hold_capture(Parent, D) ->
    Parent ! {resolver_capture_held, self(), D},
    receive release_capture -> ok end.

source_pid(C) -> element(1, maps:get(source, C)).
captures(C) -> source_captures(maps:get(source, C)).
source_captures({Pid, _}) -> gen_server:call(Pid, captures).

stop_source(none) -> ok;
stop_source({Pid, Monitor}) ->
    case is_process_alive(Pid) of
        true ->
            exit(Pid, kill),
            receive {'DOWN', Monitor, process, Pid, _} -> ok
            after 2000 -> error(source_stop_timeout)
            end;
        false -> erlang:demonitor(Monitor, [flush]), ok
    end.

resolve(C, Ref, Phase, D) -> result(resolve_async(C, Ref, Phase, D)).
resolve_async(C, Ref, Phase, D) ->
    traced_async(fun() ->
        quod_foreign_log:resolve_reference(maps:get(target, C), Ref, Phase,
                                           maps:get(contact, C), maps:get(hint, C), D)
    end).

local_evidence(_C, Ns, Ref, Phase, D) -> result(local_evidence_async(Ns, Ref, Phase, D)).
local_evidence_async(Ns, Ref, Phase, D) ->
    traced_async(fun() -> quod_simplex:dtx_local_evidence(Ns, Ref, Phase, D) end).

traced_async(Fun) ->
    Parent = self(),
    Caller = spawn(fun() ->
        receive go -> ok end,
        try Fun() of
            Result -> Parent ! {resolver_result, self(), Result}
        catch Class:Reason:Stack ->
            Parent ! {resolver_exception, self(), Class, Reason, Stack}
        end
    end),
    1 = erlang:trace(Caller, true, [call, set_on_spawn, {tracer, self()}]),
    Caller ! go,
    Caller.

result(Caller) ->
    receive
        {resolver_result, Caller, Result} -> Result;
        {resolver_exception, Caller, Class, Reason, Stack} -> erlang:raise(Class, Reason, Stack)
    after 4000 -> exit(Caller, kill), error(resolver_result_timeout)
    end.

held_historical_call(C, D, Stage) ->
    Token = make_ref(), Parent = self(),
    Caller = traced_async(fun() ->
        put({quod_foreign_log, local_read_gate}, {Stage, Parent, Token}),
        quod_foreign_log:resolve_reference(
            maps:get(target, C), maps:get(ref, maps:get(fixture, C)), resolve,
            maps:get(contact, C), maps:get(hint, C), D)
    end),
    receive {local_read_held, Token, Caller} -> {Caller, Token}
    after 2000 -> exit(Caller, kill), error(historical_read_not_held)
    end.

wait_message(Pid, Predicate) -> wait_message(Pid, Predicate, deadline(2000)).
wait_message(Pid, Predicate, D) ->
    {messages, Messages} = process_info(Pid, messages),
    case lists:filter(Predicate, Messages) of
        [Message | _] -> Message;
        [] ->
            case D > quod_time:mono_ms() of
                true -> receive after 2 -> ok end, wait_message(Pid, Predicate, D);
                false -> error(expected_owner_message_not_queued)
            end
    end.

wait_expired(D) -> receive after max(0, D - quod_time:mono_ms()) + 20 -> ok end.

trace_patterns() ->
    [{quod_simplex, history_view, 3},
     {quod_simplex, history_view_at, 3},
     {quod_foreign_log, verification_call, 2},
     {quod_foreign_log, verify_local_deadline, 4},
     {quod_foreign_log, reselect_verified, 4},
     {quod_foreign_log, verify_resident_snapshot, 6},
     {quod_foreign_log, start_distinct_worker, 7},
     {quod_foreign_log, spawn_verification_worker, 3},
     {quod_foreign_log, open_cache, 5},
     {quod_foreign_log, replay_cache, 7},
     {quod_catchup, range_accept, 5},
     {quod_catchup, evidence_accept, 4},
     {quod_catchup, verify_forward_group, 5},
     {quod_ledger_store, open, 3},
     {quod_ledger_store, open_ro, 3},
     {quod_ledger_store, open_ro_snapshot, 1},
     {quod_ledger_store, read_at, 3},
     {quod_transaction, verify_submission, 1}].

start_trace(Owner) ->
    lists:foreach(fun({M, _, _} = MFA) ->
        {module, M} = code:ensure_loaded(M),
        1 = erlang:trace_pattern(MFA, true, [local])
    end, trace_patterns()),
    1 = erlang:trace(Owner, true, [call, set_on_spawn, {tracer, self()}]).

stop_trace(Owner) ->
    _ = catch erlang:trace(Owner, false, [call, set_on_spawn]),
    lists:foreach(fun(MFA) -> erlang:trace_pattern(MFA, false, [local]) end, trace_patterns()),
    _ = traces(),
    ok.

traces() ->
    Barrier = erlang:trace_delivered(all),
    receive {trace_delivered, all, Barrier} -> ok
    after 2000 -> error(trace_barrier_timeout)
    end,
    collect_traces([]).
collect_traces(Acc) ->
    receive {trace, _, call, _} = T -> collect_traces([T | Acc])
    after 0 -> lists:reverse(Acc)
    end.
calls(T, M, F, A) -> length([ok || {trace, _, call, {TM, TF, Args}} <- T,
                                                TM =:= M, TF =:= F, length(Args) =:= A]).

assert_no_foreign_work(T) ->
    lists:foreach(fun({M, F, A}) -> ?assertEqual(0, calls(T, M, F, A)) end,
                  [{quod_foreign_log, start_distinct_worker, 7},
                   {quod_foreign_log, spawn_verification_worker, 3},
                   {quod_foreign_log, open_cache, 5},
                   {quod_foreign_log, replay_cache, 7},
                   {quod_catchup, range_accept, 5},
                   {quod_catchup, verify_forward_group, 5},
                   {quod_ledger_store, open, 3},
                   {quod_ledger_store, open_ro, 3}]).

assert_one_routed(T, C, Ref, Phase, Hint, D) ->
    ?assertEqual(1, calls(T, quod_foreign_log, start_distinct_worker, 7)),
    ?assertEqual(1, calls(T, quod_foreign_log, spawn_verification_worker, 3)),
    Requests = [{R, Deadline} || {trace, _, call, {quod_foreign_log, verification_call, [R, Deadline]}} <- T],
    ?assertMatch([{{verify_reference, Ref, Phase, _, Hint, _}, D}], Requests),
    [{{verify_reference, _, _, Contact, _, _}, _}] = Requests,
    ?assertEqual(maps:get(contact, C), Contact).

assert_no_fetch() -> receive {resolver_fetch, _, _} -> error(unexpected_network_fetch) after 0 -> ok end.
flush_fetches() -> receive {resolver_fetch, _, _} -> flush_fetches() after 0 -> ok end.

%% Five real members allow distinct 4-of-5 certificates. The optional signed
%% removal changes the live era to four members; a new-era 3-of-4 proof must
%% never authenticate the older slot. This follows the existing shrink fixture.
committee_fixture(RemoveMember) ->
    Ns = quod_foreign_log_tests:unique_ns(),
    Members = new_members(5),
    [{Author, Signer} | _] = Members,
    Keys = [K || {K, _} <- Members],
    GenesisTx = quod_simplex:test_genesis_tx(#{committee => tl(Keys), node_addr => {"127.0.0.1", 19000}},
                                              Ns, Author, digest(genesis_incarnation)),
    {ok, Block} = quod_ledger:new_block({genesis, 0}, none, 1, {batch, [GenesisTx]}, 0),
    Genesis = quod_ledger:entry(1, Block, none),
    Anchor = quod_simplex:block_hash(Block),
    Identity = {Ns, Anchor},
    {ok, P} = quod_simplex:history_validate_advance(Identity, Genesis,
        quod_simplex:history_projection(Identity)),
    {ok, Binding} = quod_simplex:history_binding(Identity, Author, P),
    Tx = signed_transaction(Identity, Binding, Author, Signer, 1,
                            [{assert, {{resolver_fact, true}, true}}]),
    Entry = committee_entry(Identity, Members, 2, maps:get(protocol_root, P), Tx),
    {ok, Ref} = quod_dtx:certified_entry_ref(Identity, Entry, Tx),
    Tail = case RemoveMember of
        false -> [];
        true ->
            Removed = lists:last(Keys),
            Removal = signed_transaction(Identity, Binding, Author, Signer, 2,
                                         [{retract, {{peer_admitted, Removed, undefined, undefined, Removed}, true}}]),
            {ok, EntryBlock} = quod_ledger:block_from_entry(Entry),
            [committee_entry(Identity, Members, 3, quod_ledger:block_ref(EntryBlock), Removal)]
    end,
    #{ns => Ns, anchor => Anchor, pub => Author, members => Members,
      ref => Ref, chain => [Genesis, Entry | Tail]}.

new_members(N) ->
    lists:sort([begin
        {Pub, Seed} = quod_identity:generate(),
        {Pub, #{pubkey => Pub, key => quod_identity:key_term({Pub, Seed})}}
    end || _ <- lists:seq(1, N)]).

signed_transaction(Identity, Binding, Author, Signer, Seq, Diff) ->
    {ok, Goal} = quod_durable_term:encode_goal({resolver_transaction, Seq}),
    {ok, Result} = quod_durable_term:encode_result(#{}),
    Tx0 = #transaction{origin = Identity, proof_id = digest({proof, Seq}),
                       plan_digest = digest({plan, Seq}), goal = Goal, result = Result,
                       diff = Diff, read_check = #{}, author = Author,
                       author_seq = Seq, submitted_at = Seq, sig = none},
    {ok, Tx} = quod_transaction:sign(Binding, quod_transaction:bind_id(Identity, Tx0), Signer),
    Tx.

committee_entry(Identity, Members, Height, Parent, Tx) ->
    committee_entries(Identity, Members, Height, Parent, [Tx]).

committee_entries({Ns, Anchor}, Members, Height, {Era, View, _} = Parent, Transactions) ->
    Position = {Era, View + 1},
    {ok, Block} = quod_ledger:new_block(Position, Parent, Height, {batch, Transactions}, 0),
    Hash = quod_simplex:block_hash(Block),
    Domain = quod_simplex:consensus_domain(Ns, Anchor),
    Sigs = [{Pub, (quod_simplex:make_share(Domain, commit, Position, Hash, Signer))#share.sig}
            || {Pub, Signer} <- lists:sublist(Members, 4)],
    quod_ledger:entry(Height, Block, #cert{kind = commit, era = Era, slot = View + 1,
                                          block_hash = Hash, sigs = Sigs}).

batch_fixture() ->
    F = committee_fixture(false),
    [Genesis, _] = maps:get(chain, F),
    Identity = identity(F),
    Members = maps:get(members, F),
    [{Author, Signer} | _] = Members,
    {ok, Projection} = quod_simplex:history_validate_advance(
        Identity, Genesis, quod_simplex:history_projection(Identity)),
    {ok, Binding} = quod_simplex:history_binding(Identity, Author, Projection),
    Transactions = [signed_transaction(Identity, Binding, Author, Signer, Seq,
        [{assert, {{resolver_record, Seq}, true}}]) || Seq <- [1, 2, 3]],
    Entry = committee_entries(Identity, Members, 2,
                              maps:get(protocol_root, Projection), Transactions),
    Refs = [begin {ok, Ref} = quod_dtx:certified_entry_ref(Identity, Entry, Tx), Ref end
            || Tx <- Transactions],
    F#{chain := [Genesis, Entry], ref := hd(Refs),
       refs => Refs, transactions => Transactions}.

reference_with_signers(F, Ref, Signers) ->
    {ok, #cert{era = Era, slot = View, block_hash = Hash} = Cert} =
        quod_ledger:decode_finality_head(element(8, Ref)),
    Domain = quod_simplex:consensus_domain(maps:get(ns, F), maps:get(anchor, F)),
    Sigs = [{Pub, (quod_simplex:make_share(Domain, commit, {Era, View}, Hash, Signer))#share.sig}
            || {Pub, Signer} <- Signers],
    reference_with_head(Ref, Cert#cert{sigs = Sigs}).

reference_with_head(Ref, Cert) ->
    {ok, Bytes} = quod_ledger:encode_finality_head(Cert),
    setelement(8, Ref, Bytes).

assert_cert_valid_for(F, Ref, Members) ->
    Domain = quod_simplex:consensus_domain(maps:get(ns, F), maps:get(anchor, F)),
    {ok, Cert} = quod_ledger:decode_finality_head(element(8, Ref)),
    ?assert(quod_simplex:verify_cert(Domain, Cert, [K || {K, _} <- Members])).
