-module(quod_schema_tests).
-include_lib("eunit/include/eunit.hrl").

%% A minimal valid config as a HOCON binary. `content` is a LIST of ontology blocks.
conf() ->
    <<"node { ip = \"10.0.0.1\", port = 14000 }\n"
      "metrics { port = 14001 }\n"
      "content = [{ namespace = \"quod:root\", mode = create, "
      "genesis_file = \"ontologies/quod_root.pl\", seeds = [\"1.2.3.4:14567\"] }]\n">>.

check(Bin) ->
    {ok, Raw} = hocon:binary(Bin, #{format => map}),
    hocon_tconf:check_plain(quod_schema, Raw,
                            #{atom_key => true, apply_override_envs => true}).

%% The single content block of a checked config (the common one-ontology case).
content1(C) -> [Block] = maps:get(content, C), Block.

%% --- defaults + parsing -------------------------------------------------

parse_test() ->
    C = check(conf()),
    ?assertEqual(<<"10.0.0.1">>, deep(C, [node, ip])),
    ?assertEqual(14000,          deep(C, [node, port])),
    ?assertEqual(14001,          deep(C, [metrics, port])),
    B = content1(C),
    ?assertEqual(<<"quod:root">>, maps:get(namespace, B)),
    ?assertEqual(create,          maps:get(mode, B)),
    ?assertEqual([<<"1.2.3.4:14567">>], maps:get(seeds, B)).

defaults_test() ->
    %% omit node.ip and metrics → schema defaults apply (incl. inside a content entry)
    C = check(<<"content = [{ namespace = \"quod:root\" }]\n">>),
    ?assertEqual(<<"127.0.0.1">>, deep(C, [node, ip])),
    ?assertEqual(14567,           deep(C, [node, port])),
    ?assertEqual(false,           deep(C, [node, consensus_owner_tracing])),
    ?assertEqual(1024,            deep(C, [node, runtime_max_hosted_agents])),
    ?assertEqual(4096,            deep(C, [node, runtime_max_agent_observations])),
    ?assertEqual(1048576,         deep(C, [node, runtime_max_agent_observation_bytes])),
    ?assertEqual(4096,            deep(C, [node, peer_observation_limit])),
    ?assertEqual(14568,           deep(C, [metrics, port])),
    ?assertEqual(<<"">>,          deep(C, [identity, dir])),
    ?assertEqual(#{},             maps:get(directory, C)),
    ?assertEqual(30000,           deep(C, [explorer, read_budget_ms])),
    B = content1(C),
    ?assertEqual(create,          maps:get(mode, B)),
    ?assertEqual(64,              maps:get(max_proof_workers, B)),
    ?assertEqual(64,              maps:get(max_scope_workers, B)),
    ?assertEqual(60000,           maps:get(proof_timeout_ms, B)),
    ?assertEqual(30000,           maps:get(transaction_ttl_ms, B)),
    ?assertEqual(25,              maps:get(batch_window_ms, B)),
    ?assertEqual(60000,           maps:get(scope_timeout_ms, B)),
    ?assertEqual(30000,           maps:get(scope_step_timeout_ms, B)),
    ?assertEqual(<<"ontologies/quod_root.pl">>, maps:get(genesis_file, B)),
    ?assertEqual([],              maps:get(seeds, B)).

%% Two ontologies side by side: each entry keeps its own mode/anchor.
two_ontologies_test() ->
    C = check(<<"content = [{ namespace = \"quod:root\" },\n"
                "           { namespace = \"animals\", mode = join, genesis_hash = \"ff\" }]\n">>),
    [B1, B2] = maps:get(content, C),
    ?assertEqual(<<"quod:root">>, maps:get(namespace, B1)),
    ?assertEqual(create,          maps:get(mode, B1)),
    ?assertEqual(<<"animals">>,   maps:get(namespace, B2)),
    ?assertEqual(join,            maps:get(mode, B2)),
    ?assertEqual(<<"ff">>,        maps:get(genesis_hash, B2)).

batch_window_parse_test() ->
    C = check(<<"content = [{ namespace = \"quod:root\", batch_window_ms = 40 }]\n">>),
    ?assertEqual(40, maps:get(batch_window_ms, content1(C))).

explorer_read_budget_parse_test() ->
    C = check(<<"explorer { read_budget_ms = 1234 }\n">>),
    ?assertEqual(1234, deep(C, [explorer, read_budget_ms])).

owner_tracing_node_policy_parse_test() ->
    C = check(<<"node { consensus_owner_tracing = true }\n">>),
    ?assertEqual(true, deep(C, [node, consensus_owner_tracing])),
    ?assertNot(maps:is_key(consensus_owner_tracing, content1(C))),
    ?assertEqual(false, maps:get(detailed_consensus_metrics, content1(C))).

owner_tracing_content_policy_rejected_test() ->
    ?assertException(
       throw, {quod_schema, [#{reason := unknown_fields,
                              unknown := "consensus_owner_tracing"}]},
       check(<<"content = [{ consensus_owner_tracing = true }]\n">>)).

owner_tracing_invalid_node_policy_test() ->
    ?assertException(
       throw, {quod_schema, _},
       check(<<"node { consensus_owner_tracing = \"invalid\" }\n">>)).

explorer_read_budget_invalid_test_() ->
    [?_assertException(throw, {quod_schema, _},
        check(iolist_to_binary(["explorer { read_budget_ms = ", Value, " }\n"])))
     || Value <- ["0", "-1", "false", "\"invalid\"", "1.5"]].

removed_directory_authority_fields_rejected_test_() ->
    [?_assertException(
        throw,
        {quod_schema,
         [#{reason := unknown_fields, path := "directory",
            unknown := Field}]},
        check(iolist_to_binary(
                ["directory { ", Field, " = [] }\n",
                 "content = [{ namespace = \"quod:root\" }]\n"])))
     || Field <- ["allowlist", "direct_seeds"]].

removed_directory_bootstraps_rejected_test() ->
    ?assertException(
       throw,
       {quod_schema,
        [#{reason := unknown_fields, path := "directory",
           unknown := "bootstraps"}]},
       check(
         <<"directory { bootstraps = [\"10.0.0.1:14567\"] }\n"
           "content = [{ namespace = \"quod:root\" }]\n">>)).

removed_ask_scope_config_names_rejected_test_() ->
    [?_assertException(
        throw,
        {quod_schema,
         [#{reason := unknown_fields, unknown := OldName}]},
        check(
          iolist_to_binary(
            ["content = [{ namespace = \"quod:root\", ",
             OldName, " = 1 }]\n"])))
     || OldName <- ["max_ask_workers", "ask_timeout_ms",
                    "ask_step_timeout_ms"]].

%% --- boot wiring: load_config generates + exposes the node identity ------

local_vault_boot_does_not_require_https_provider_test() ->
    _ = application:load(quod),
    {ok, _} = application:ensure_all_started(gproc),
    Dir = tmp_dir(),
    Saved = application:get_env(quod, agent_vault),
    try
        ConfigPath = write_boot_conf(Dir, ""),
        Unlock = filename:join(Dir, "unlock"),
        ok = quod_file:write_atomic(Unlock, crypto:strong_rand_bytes(32), 8#600),
        ok = file:write_file(ConfigPath,
          ["agent_vault { enabled = true, directory = \"", filename:join(Dir, "vault"),
           "\", unlock_file = \"", Unlock, "\" }\n"], [append]),
        os:putenv("QUOD_CONF", ConfigPath),
        _ = quod_app:load_config(),
        {ok, #{provider := none}} = application:get_env(quod, agent_vault),
        {ok, Vault} = quod_agent_vault:start_link(),
        ok = gen_server:stop(Vault)
    after
        reset_boot_env(),
        case Saved of
            undefined -> application:unset_env(quod, agent_vault);
            {ok, Value} -> application:set_env(quod, agent_vault, Value)
        end,
        _ = file:del_dir_r(Dir)
    end.

boot_identity_test() ->
    _ = application:load(quod),
    Dir = tmp_dir(),
    try
        ConfPath = write_boot_conf(Dir, ""),    %% no explicit identity.dir ⇒ <data_dir>/identity
        os:putenv("QUOD_CONF", ConfPath),
        clear_identity_env(),
        _ = quod_app:load_config(),
        ?assertEqual({ok, 30000}, application:get_env(quod, explorer_read_budget_ms)),
        {ok, Pub} = application:get_env(quod, node_pubkey),
        ?assertEqual(32, byte_size(Pub)),
        %% the keypair was persisted under <data_dir>/identity, and the cert carries it
        ?assert(filelib:is_regular(filename:join([Dir, "identity", "node.key"]))),
        {ok, Cert} = application:get_env(quod, identity_cert),
        ?assertEqual({ok, Pub}, quod_identity:pubkey_of_cert(Cert)),
        ?assertMatch({ok, _}, application:get_env(quod, identity_key)),
        %% load-or-create: a SECOND boot reloads the SAME identity (durability — the
        %% whole point of persisting node.key), it does NOT regenerate.
        clear_identity_env(),
        _ = quod_app:load_config(),
        ?assertEqual({ok, Pub}, application:get_env(quod, node_pubkey))
    after
        reset_boot_env(),
        _ = file:del_dir_r(Dir)
    end.

%% An explicit `identity { dir = ... }` wins over the <data_dir>/identity default.
identity_dir_override_test() ->
    _ = application:load(quod),
    Dir   = tmp_dir(),
    IdDir = filename:join(Dir, "custom_id"),
    try
        ConfPath = write_boot_conf(Dir, IdDir),
        os:putenv("QUOD_CONF", ConfPath),
        clear_identity_env(),
        _ = quod_app:load_config(),
        ?assert(filelib:is_regular(filename:join(IdDir, "node.key"))),
        ?assertNot(filelib:is_regular(filename:join([Dir, "identity", "node.key"])))
    after
        reset_boot_env(),
        _ = file:del_dir_r(Dir)
    end.

directory_boot_conversion_test() ->
    _ = application:load(quod),
    Dir = tmp_dir(),
    ConfPath = write_boot_conf(Dir, ""),
    try
        os:putenv("QUOD_CONF", ConfPath),
        clear_identity_env(),
        _ = quod_app:load_config(),
        {ok, Directory} = application:get_env(quod, directory),
        ?assertEqual(filename:join(Dir, "identity"),
                     maps:get(identity_dir, Directory)),
        ?assertEqual(false, maps:is_key(allowlist, Directory)),
        ?assertEqual(false, maps:is_key(direct_seeds, Directory))
    after
        reset_boot_env(),
        application:unset_env(quod, directory),
        _ = file:del_dir_r(Dir)
    end.

%% Boot publishes node policy for every local Simplex init, not a field in a
%% namespace's prepared/retained config. The same resume builder is used by
%% committed hosting recovery; it must not freeze this local diagnostic flag.
owner_tracing_boot_reaches_dynamic_resume_test() ->
    _ = application:load(quod),
    Dir = tmp_dir(),
    SavedEnv = application:get_all_env(quod),
    SavedConf = os:getenv("QUOD_CONF"),
    SavedPrefix = os:getenv("HOCON_ENV_OVERRIDE_PREFIX"),
    SavedOverride = os:getenv("QUOD_NODE__CONSENSUS_OWNER_TRACING"),
    try
        os:unsetenv("QUOD_NODE__CONSENSUS_OWNER_TRACING"),
        ConfPath = write_boot_conf(Dir, ""),
        {ok, DefaultConfig} = file:read_file(ConfPath),
        ok = file:write_file(
               ConfPath, [DefaultConfig, "node.consensus_owner_tracing = true\n"]),
        os:putenv("QUOD_CONF", ConfPath),
        Blocks = quod_app:load_config(),
        ?assertEqual({ok, true}, application:get_env(quod, consensus_owner_tracing)),
        ?assert(lists:all(fun(Block) ->
            not maps:is_key(consensus_owner_tracing, Block)
        end, Blocks)),
        Dynamic = <<"trace:dynamic-resume">>,
        ?assertNot(lists:any(fun(Block) ->
            maps:get(namespace, Block) =:= Dynamic
        end, Blocks)),
        Anchor = crypto:strong_rand_bytes(32),
        Resumed = quod_ontology:local_resume_config(Dynamic, Anchor, Dir),
        ?assertNot(maps:is_key(consensus_owner_tracing, Resumed)),
        ?assertEqual(false, maps:get(detailed_consensus_metrics, Resumed)),
        %% Reloading the ordinary default clears the local diagnostic policy;
        %% it never survives through an ontology fact or an old desired config.
        ok = file:write_file(ConfPath, DefaultConfig),
        _ = quod_app:load_config(),
        ?assertEqual({ok, false}, application:get_env(quod, consensus_owner_tracing)),
        FreshResume = quod_ontology:local_resume_config(Dynamic, Anchor, Dir),
        ?assertEqual(Resumed, FreshResume)
    after
        SavedKeys = [Key || {Key, _} <- SavedEnv],
        CurrentKeys = [Key || {Key, _} <- application:get_all_env(quod)],
        _ = [application:unset_env(quod, Key) || Key <- CurrentKeys -- SavedKeys],
        _ = [application:set_env(quod, Key, Value) || {Key, Value} <- SavedEnv,
              application:get_env(quod, Key) =/= {ok, Value}],
        restore_os_env("QUOD_CONF", SavedConf),
        restore_os_env("HOCON_ENV_OVERRIDE_PREFIX", SavedPrefix),
        restore_os_env("QUOD_NODE__CONSENSUS_OWNER_TRACING", SavedOverride),
        _ = file:del_dir_r(Dir)
    end.

%% --- env overrides individual keys, file stays primary -------------------

env_override_test_() ->
    %% Scalar keys are env-overridable; the `content` LIST is not (deploys render the file).
    {setup,
     fun() ->
         os:putenv("HOCON_ENV_OVERRIDE_PREFIX", "QUOD_"),
         os:putenv("QUOD_NODE__PORT", "15000")
     end,
     fun(_) ->
         os:unsetenv("HOCON_ENV_OVERRIDE_PREFIX"),
         os:unsetenv("QUOD_NODE__PORT")
     end,
     fun() ->
         C = check(conf()),
         %% env wins over the file value
         ?assertEqual(15000, deep(C, [node, port])),
         %% untouched keys keep their file value
         ?assertEqual(<<"10.0.0.1">>, deep(C, [node, ip])),
         ?assertEqual(create, maps:get(mode, content1(C)))
     end}.

%% --- genesis_hash: schema field + build_ns_config hex→binary plumbing ----

genesis_hash_default_test() ->
    C = check(<<"content = [{ namespace = \"quod:root\" }]\n">>),
    ?assertEqual(<<"">>, maps:get(genesis_hash, content1(C))).

genesis_hash_parse_test() ->
    Hex = <<"00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff">>,
    C = check(<<"content = [{ namespace = \"quod:root\", mode = join, genesis_hash = \"",
                Hex/binary, "\" }]\n">>),
    B = content1(C),
    ?assertEqual(join, maps:get(mode, B)),
    ?assertEqual(Hex,  maps:get(genesis_hash, B)).

%% A mode=join content config with a hex genesis_hash lands in the ns config as the raw 32-byte binary
%% quod_simplex pins, with mode + seeds forwarded. (genesis_file/data_dir left "" so build_ns_config
%% doesn't touch code:priv_dir in the eunit VM.)
build_ns_config_genesis_hash_test() ->
    Raw = crypto:strong_rand_bytes(32),
    Content = #{namespace => <<"quod:root">>, mode => join, role => member, seeds => [<<"1.2.3.4:14567">>],
                transaction_ttl_ms => 12345,
                genesis_file => <<"">>, data_dir => <<"">>, genesis_hash => binary:encode_hex(Raw)},
    {<<"quod:root">>, NsCfg} = quod_app:build_ns_config(Content),
    ?assertEqual(join, maps:get(mode, NsCfg)),
    ?assertEqual(Raw,  maps:get(genesis_hash, NsCfg)),
    ?assertEqual(12345, maps:get(transaction_ttl_ms, NsCfg)),
    ?assertEqual(25, maps:get(batch_window_ms, NsCfg)),
    ?assertEqual([{"1.2.3.4", 14567}], maps:get(seed_peers, NsCfg)).

%% A create node (blank genesis_hash) carries no anchor key at all — quod_simplex needs none.
build_ns_config_no_genesis_hash_test() ->
    Content = #{namespace => <<"quod:root">>, mode => create, role => member, seeds => [],
                genesis_file => <<"">>, data_dir => <<"">>, genesis_hash => <<"">>},
    {_, NsCfg} = quod_app:build_ns_config(Content),
    ?assertNot(maps:is_key(genesis_hash, NsCfg)),
    ?assertEqual(64, maps:get(max_proof_workers, NsCfg)),
    ?assertEqual(64, maps:get(max_scope_workers, NsCfg)),
    ?assertEqual(60000, maps:get(proof_timeout_ms, NsCfg)),
    ?assertEqual(30000, maps:get(transaction_ttl_ms, NsCfg)),
    ?assertEqual(25, maps:get(batch_window_ms, NsCfg)),
    ?assertEqual(60000, maps:get(scope_timeout_ms, NsCfg)),
    ?assertEqual(30000, maps:get(scope_step_timeout_ms, NsCfg)).

root_recovery_contacts_ignore_invalid_content_seed_test() ->
    Cfg =
        #{content =>
              [#{namespace => <<"quod:root">>,
                 seeds => [<<"10.0.0.1:14567">>, <<":14567">>,
                           <<"bad">>, <<"10.0.0.1:14567">>]}]},
    ?assertEqual(
       [{"10.0.0.1", 14567}],
       quod_app:root_contacts(Cfg)).

deep(Map, Path) -> lists:foldl(fun(K, M) -> maps:get(K, M) end, Map, Path).

%% --- boot-test helpers ---------------------------------------------------

tmp_dir() ->
    filename:join("/tmp", "quod_boot_id_" ++
      binary_to_list(binary:encode_hex(crypto:strong_rand_bytes(8), lowercase))).

restore_os_env(Name, false) -> os:unsetenv(Name);
restore_os_env(Name, Value) -> os:putenv(Name, Value).

%% Write a minimal HOCON config into Dir (with content.data_dir = Dir). IdDir = "" omits
%% the identity block (default resolution); a non-empty IdDir pins `identity.dir`.
write_boot_conf(Dir, IdDir) ->
    ok = filelib:ensure_dir(filename:join(Dir, "x")),
    U  = filename:basename(Dir),
    IdBlock = case IdDir of "" -> ""; _ -> ["identity { dir = \"", IdDir, "\" }\n"] end,
    Conf = ["node { ip = \"127.0.0.1\", port = 14999 }\n",
            IdBlock,
            "content = [{ namespace = \"bootid:", U, "\", data_dir = \"", Dir, "\" }]\n"],
    ConfPath = filename:join(Dir, "quod.conf"),
    ok = file:write_file(ConfPath, Conf),
    ConfPath.

clear_identity_env() ->
    _ = [application:unset_env(quod, K) || K <- [node_pubkey, identity_cert, identity_key]],
    ok.

%% load_config sets HOCON_ENV_OVERRIDE_PREFIX globally — unset it (and QUOD_CONF + the
%% identity env) so the boot tests don't leak state into the rest of the eunit VM.
reset_boot_env() ->
    os:unsetenv("QUOD_CONF"),
    os:unsetenv("HOCON_ENV_OVERRIDE_PREFIX"),
    application:unset_env(quod, consensus_owner_tracing),
    clear_identity_env().
