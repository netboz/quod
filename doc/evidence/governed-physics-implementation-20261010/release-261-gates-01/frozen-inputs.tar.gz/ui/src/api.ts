// Types mirroring quod_explorer_http's JSON, plus thin fetch helpers.

import { signedCursorCommand, signedGoal } from '../../client/src/signed-client.js'
import { scopedGoal } from '../../client/src/prolog-term.js'
import type { SignedIdentity, SignedGoalOptions } from '../../client/src/signed-client.js'
import type { AgentReference } from '../../client/src/signed-client.js'

export type PeerId = { id: string; pubkey: string | null }
export type Origin = { ns: string; anchor: string } | null

export type TransactionRef = {
  kind: 'transaction'
  ns: string
  anchor: string
  tx_id: string
  height?: number
}

export type TxRole = 'application' | 'remote_claim' | 'remote_application' | 'remote_complete'

export type OperationTarget = { target: NonNullable<Origin>; plan_digest: string }
export type ReceiptTarget =
  | { target: NonNullable<Origin>; kind: 'certified'; application_ref: TransactionRef;
      result: 'applied' | 'rejected'; reason: string | null; height: number; committee_id: string }

export type TxRoleDetails =
  | null
  | { targets: OperationTarget[]; target_transactions: TransactionRef[] }
  | { source_claim: TransactionRef; operation_ref: SignedRequest['operation_ref']; request_digest: string }
  | { operation_ref: SignedRequest['operation_ref']; request_digest: string; targets: ReceiptTarget[] }

export type TxRow = {
  row_type: 'transaction'
  row_id: string
  tx_id: string
  ns: string
  height: number
  time: number // block timestamp, ms epoch (0 = genesis/unset)
  goal: string | null // Prolog text; null = genesis
  author: PeerId | null
  author_seq: number
  submitted_at: number // ms epoch, 0 = unset
  ops: number
  fact_ops: number
  effect_count: number
  effect_operations: string[]
  role: TxRole
  role_details: TxRoleDetails
}

// A DTX phase is a committed ledger record too. It has no #transaction{} body,
// so it carries the control metadata rendered by the same block endpoint.
export type ControlRow = {
  row_type: 'control'
  row_id: string
  ns: string
  height: number
  time: number
  phase: Control['kind']
  control: Control
}

export type LedgerRow = TxRow | ControlRow

export type Op =
  | { op: 'assert' | 'asserta' | 'retract'; clause: string }
  | { op: 'event'; term: string }

export type Effect = {
  effect_id: string
  operation: string
  executor: PeerId
  actor: Actor
  actor_authority: 'author_node_claimed' | 'signed_agent_request'
  target: { ns: string; anchor: string }
  request_digest: string
  prepared_digest: string
  local_execution: 'pending' | 'applied' | 'retired' | 'operator_error' | 'unavailable' | 'not_this_node'
  local_custody_state?: 'transaction_bound' | 'transaction_ready' | 'transaction_submitted' | 'operation_pending' | 'group_pending' | 'released' | 'applied' | 'retired' | 'operator_error'
  local_execution_height?: number
  local_execution_result?: string | null
}

export type TxFull = TxRow & {
  result: Record<string, string> | Record<string, string>[] | string | null
  diff: Op[]
  root_facts_changed: boolean
  effects: Effect[]
  read_predicates: number
  origin: Origin
  proof_id: string | null
  plan_digest: string | null
  request?: SignedRequest | null
  signature: string | null
  signature_status: 'verified' | 'genesis' | 'unsigned' | 'invalid' | 'unknown'
  evidence_ref: TransactionRef | TransactionRef[] | null
}

export type SignedRequest = {
  status: 'verified' | 'invalid'
  request_digest: string | null
  agent: AgentActor | null
  operation_id: string | null
  operation_ref: {
    kind: 'operation'
    ns: string
    anchor: string
    agent: AgentActor
    operation_id: string
  } | null
  target: Origin
  mode: 'execute' | 'cursor' | null
  parser_version: number | null
  not_after_ms: number | null
  signature: string | null
  first_outcome: {
    kind: 'transaction' | 'group'
    ns: string
    anchor: string
    tx_id?: string
    coordinator?: PeerId
    coordinator_admission?: string
    group_id?: string
  } | null
}

export type AgentActor = {
  kind: 'agent'
  identity: { ns: string; anchor: string } | null
  reference: string
  reference_wire: string | null
}

export type Actor = { kind: 'node'; identity: PeerId } | AgentActor

export type Cert = {
  kind: string
  signers: PeerId[]
  head_view: number
  era: string
} | null

export type NsSummary = {
  ns: string
  height: number
  applied: number
  role: string
  syncing: boolean
  committee: PeerId[]
  protocol_view: number
  protocol_era: string | null
  notarized_view: number
  view_leader: PeerId | null
  proposal_slot: number
  next_proposer: PeerId | null
  proposal_open: boolean
  progress_phase: 'idle' | 'awaiting_proposal' | 'awaiting_notarization'
  genesis: string | null
}

export type Summary = { node: PeerId | null; namespaces: NsSummary[] }

export type TxsPage = { txs: LedgerRow[]; height: number; next_before: number | null }

export type Block = {
  slot: number
  time: number
  kind: 'content' | 'dtx_batch' | 'invalid'
  cert: Cert
  txs: TxFull[]
  controls?: Control[]
}

export type Control = {
  kind: 'vote' | 'resolve' | 'complete'
  group_id: string
  record_digest: string
  target: Origin
  author: PeerId
  author_admission: string
  sequence: number
  submitted_at: number
  participant_count?: number
  vote?: 'prepared' | 'refused'
  vote_deadline_ms?: number
  plan?: ParticipantPlan
  request?: SignedRequest | null
  verdict?: 'commit' | 'abort'
  reasons?: string[] | null
  voted?: boolean
  vote_ref?: { target: Origin; height: number; block_hash: string; record_digest: string } | null
  applied_generation?: number
  resolve_count?: number
}

export type ParticipantPlan = {
  status: 'bound' | 'invalid'
  target: Origin
  plan_digest: string
  signer: PeerId | null
  diff_ops: number | null
  diff: Op[] | null
  effect_count: number | null
  effects: Effect[]
}

export type TxOutcome = {
  status: 'pending' | 'committed' | 'rejected'
  ns: string
  anchor: string
  tx_id: string
  goal?: string
  bindings?: Record<string, string>
  height?: number
  reason?: string
}

export type FoundTx = {
  tx: TxFull
  block: { slot: number; time: number; cert: Cert }
  outcome: TxOutcome
}

export type FoundOutcome = FoundTx | { outcome: TxOutcome }

export type ProveReply =
  | { result: 'recovered'; operationId: string; status: string; evidence: Record<string, unknown> }
  | { result: 'solution'; cursor: string; height: number; bindings: Record<string, string>[] }
  | { result: 'ok'; height: number; bindings: Record<string, string>[] }
  | { result: 'ok'; ns: string; anchor: string; tx_id: string; bindings: Record<string, string>[] }
  | {
      result: 'ok'
      ns: string
      anchor: string
      coordinator: string
      coordinator_admission: string
      group_id: string
      height: number
      participant_slots: { ns: string; anchor: string; height: number; generation: number }[]
      bindings: Record<string, string>[]
    }
  | { result: 'fail'; reasons?: string[] }
  | { result: 'pending'; ns: string; anchor: string; tx_id: string; operationId?: string }
  | {
      result: 'pending'
      ns: string
      anchor: string
      coordinator: string
      coordinator_admission: string
      group_id: string
      operationId?: string
    }
  | { result: 'stopped' }
  | { error: string; detail?: string; leader?: PeerId | null }

async function get<T>(url: string): Promise<T> {
  const r = await fetch(url)
  if (!r.ok && r.headers.get('content-type')?.includes('json')) return (await r.json()) as T
  if (!r.ok) throw new Error(`${r.status} ${r.statusText}`)
  return (await r.json()) as T
}

export const fetchSummary = () => get<Summary>('api/summary')

export const fetchTxs = (ns: string, before?: number | null, limit = 50) =>
  get<TxsPage>(
    `api/txs?ns=${encodeURIComponent(ns)}&limit=${limit}` + (before ? `&before=${before}` : ''),
  )

export const fetchBlock = (ns: string, slot: number) =>
  get<Block | { error: string }>(`api/block/${encodeURIComponent(ns)}/${slot}`)

export const fetchTx = (ns: string, id: string) =>
  get<FoundOutcome | { error: string }>(`api/tx/${encodeURIComponent(ns)}/${encodeURIComponent(id)}`)

export const openProofCursor = (
  identity: SignedIdentity,
  agent: AgentReference,
  ns: string,
  _anchor: string,
  goal: string,
  options?: SignedGoalOptions,
) => signedGoal(
  identity,
  { mode: 'cursor', agent, goal: scopedGoal(agent.namespace, ns, goal) },
  options,
) as Promise<ProveReply>

export const nextProofSolution = (identity: SignedIdentity, cursor: string) =>
  signedCursorCommand(identity, cursor, 'next') as Promise<ProveReply>

export const acceptProofSolution = (identity: SignedIdentity, cursor: string) =>
  signedCursorCommand(identity, cursor, 'accept') as Promise<ProveReply>

export const stopProofCursor = (identity: SignedIdentity, cursor: string) =>
  signedCursorCommand(identity, cursor, 'stop') as Promise<ProveReply>
