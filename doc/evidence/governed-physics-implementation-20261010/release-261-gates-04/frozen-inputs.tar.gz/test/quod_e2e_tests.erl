-module(quod_e2e_tests).
-include_lib("eunit/include/eunit.hrl").
-include("quod_ledger.hrl").
-import(quod_ct, [rp/2, stop_ns/1]).

%%%===================================================================
%%% single-node end-to-end: prove(write) -> commit -> apply -> read,
%%% restart-from-disk -> replay, prolog-only restart -> rebuild, and
%%% the failure paths the review flagged (no ETS leak on failing proofs).
%%%===================================================================

setup() ->
    {ok, _} = application:ensure_all_started(gproc),
    U   = integer_to_list(erlang:unique_integer([positive])),
    Dir = filename:join("/tmp", "quod_e2e_" ++ U),
    Ns  = list_to_binary("e2e:" ++ U),
    {Pub, Seed} = quod_identity:generate(),   %% consensus signs shares now — a real keypair is required
    Key = quod_identity:key_term({Pub, Seed}),
    Id  = #{pubkey => Pub, key => Key},
    Cfg = #{node_id => Pub, identity => Id, data_dir => Dir, mode => create},
    {Dir, Ns, Cfg}.

cleanup({Dir, Ns, _Cfg}) ->
    case quod_reg:where({quod_ns, Ns}) of
        undefined -> ok;
        Pid       -> stop_ns(Pid)
    end,
    _ = file:del_dir_r(Dir),
    ok.

e2e_test_() ->
    {foreach, fun setup/0, fun cleanup/1,
     [fun t_non_parent_teardown/1,
      fun t_write_read/1,
      fun t_concurrent_writes_batch/1,
      fun t_direct_membership_revalidated/1,
      fun t_restart_reload/1,
      fun t_ordered_edit_restart_reload/1,
      fun t_prolog_restart_rebuild/1,
      fun t_failing_proofs_no_ets_leak/1]}.

%%%===================================================================
%%% helpers
%%%===================================================================

start_ns(Ns, Cfg) ->
    {ok, Pid} = quod_ns:start_link(Ns, Cfg),
    unlink(Pid),
    Pid.

wait_new_pid(Key, OldPid) -> wait_new_pid(Key, OldPid, 300).
wait_new_pid(_K, _Old, 0) -> error(timeout);
wait_new_pid(Key, OldPid, N) ->
    case quod_reg:where(Key) of
        P when is_pid(P), P =/= OldPid -> P;
        _ -> timer:sleep(10), wait_new_pid(Key, OldPid, N - 1)
    end.

%%%===================================================================
%%% tests
%%%===================================================================

%% EUnit cleanup runs outside the process that started the supervisor.
t_non_parent_teardown({_Dir, Ns, Cfg}) ->
    fun() ->
        Parent = self(), Tag = make_ref(),
        {Owner, OwnerMonitor} = spawn_monitor(fun() ->
            Pid = start_ns(Ns, Cfg), Parent ! {Tag, Pid},
            receive {Tag, done} -> ok end
        end),
        Pid = receive {Tag, Started} -> Started after 5000 -> error(start_timeout) end,
        try
            stop_ns(Pid),
            ?assertNot(is_process_alive(Pid))
        after
            case is_process_alive(Pid) of
                true -> gen_server:stop(Pid, shutdown, 5000);
                false -> ok
            end,
            Owner ! {Tag, done},
            receive {'DOWN', OwnerMonitor, process, Owner, normal} -> ok
            after 5000 -> error(owner_not_stopped) end
        end
    end.

t_write_read({Dir, Ns, Cfg}) ->
    fun() ->
        _Pid = start_ns(Ns, Cfg),
        %% a write goes prove -> stage -> append -> commit -> apply -> reply
        ?assertEqual(
           {ok, [#{}], 2},
           rp(Ns, {assertz, {parent, tom, bob}})),
        ?assertMatch({ok, [#{'X' := bob}], _}, rp(Ns, {parent, tom, {'X'}})),
        %% an unknown predicate fails (does not crash) — unknown=fail
        ?assertMatch({fail, [_ | _]}, rp(Ns, {grandparent, tom, {'Y'}})),
        %% index 1 is the durable genesis {add, self} config entry, so the first write
        %% commits at index 2 (the committee now survives restart — see quod_simplex).
        ?assertMatch(#{committed := 2, last_applied := 2, appends := 1},
                     quod_simplex:stats(Ns)),
        %% sealed-plan submission stamps the client submit time on the tx
        {ok, Store} = quod_ledger_store:open(Ns, Dir),
        try
            {ok, Entry} = quod_ledger_store:read_at(Store, 2),
            #entry{data = {batch, [#transaction{
                                              tx_id = TxId,
                                              submitted_at = Sub}]}} =
                quod_ledger:entry_view(Entry),
            ?assert(Sub > 0),
            %% The proof reply is sent only after the outcome row and MVCC
            %% snapshot are published, so an immediate lookup is terminal.
            ?assertMatch(
               {ok, #{status := committed, height := 2}},
               quod_outcome:lookup_live(
                 Ns, quod_ledger_store:data_dir(Cfg), TxId))
        after quod_ledger_store:close(Store) end
    end.

t_concurrent_writes_batch({Dir, Ns, Cfg}) ->
    fun() ->
        _Pid = start_ns(Ns, Cfg#{batch_window_ms => 75}),
        %% Wait for the rebuild gate before launching the burst.
        ?assertMatch({ok, _, 1}, rp(Ns, true)),
        Parent = self(),
        Count = 8,
        _ = [spawn(fun() -> Parent ! {write_result, N,
                                       quod_prolog:prove(Ns, {assertz, {batch_fact, N}})}
                   end) || N <- lists:seq(1, Count)],
        Results = [receive {write_result, N, R} -> {N, R} after 5000 -> timeout end
                   || N <- lists:seq(1, Count)],
        ?assert(
           lists:all(
             fun({_N, {ok, [#{}], 2}}) -> true;
                (_) -> false
             end,
             Results)),
        {ok, Store} = quod_ledger_store:open(Ns, Dir),
        try
            {ok, Entry} = quod_ledger_store:read_at(Store, 2),
            #entry{data = {batch, Transactions}} = quod_ledger:entry_view(Entry),
            ?assertEqual(Count, length(Transactions))
        after quod_ledger_store:close(Store) end,
        [ ?assertMatch({ok, [#{}], 2}, rp(Ns, {batch_fact, N}))
          || N <- lists:seq(1, Count) ]
    end.

%% Even the local leader rechecks a committee transaction against the parent KB.
%% This direct call bypasses the normal admit proof, so fail-closed can_join must
%% reject it. A complaint advances only the protocol view: it cannot certify
%% exclusion or add a ledger row. Invalid membership cannot become a public
%% retry merely because its original placement changed. Custody completion and
%% original-deadline expiry are checked in the shared owner tests.
t_direct_membership_revalidated({_Dir, Ns, Cfg}) ->
    fun() ->
        _Pid = start_ns(Ns, Cfg),
        ?assertMatch({ok, _, 1}, rp(Ns, true)),
        {NewMember, _} = quod_identity:generate(),
        {ok, Goal} = quod_durable_term:encode_goal(
                       {admit, NewMember, "127.0.0.1", 9999}),
        {ok, Result} = quod_durable_term:encode_result(#{}),
        Change0 = #transaction{
                    tx_id = <<>>, origin = {Ns, <<0:256>>},
                    proof_id = <<0:256>>, plan_digest = <<0:256>>,
                    goal = Goal, result = Result,
                    diff = [{assert, {{peer_admitted, NewMember,
                                      "127.0.0.1", 9999, NewMember}, true}}],
                    read_check = #{}, author = maps:get(node_id, Cfg),
                    sig = none},
        Change = quod_transaction:bind_id(
                   {Ns, quod_simplex:genesis_hash(Ns)}, Change0),
        Parent = self(), Tag = make_ref(),
        {Caller, Monitor} = spawn_monitor(fun() ->
            Parent ! {Tag, quod_simplex:append(Ns, Change)}
        end),
        try
            ?assert(quod_ct:eventually(fun() ->
                maps:get(protocol_view, quod_simplex:status(Ns), 0) > 1
            end, 3000)),
            ?assertEqual(1, length(quod_simplex:committee(Ns))),
            Stats = quod_simplex:stats(Ns),
            ?assertEqual(1, maps:get(slot, Stats)),
            ?assert(maps:get(membership_rejects, Stats) >= 1),
            receive {Tag, Premature} -> error({uncertified_exclusion, Premature})
            after 0 -> ok end,
            ?assertEqual(1, maps:get(custody_depth, quod_simplex:stats(Ns))),
            ?assertEqual(1, length(quod_simplex:committee(Ns)))
        after
            exit(Caller, kill), erlang:demonitor(Monitor, [flush])
        end
    end.

t_restart_reload({Dir, Ns, Cfg}) ->
    fun() ->
        Pid1 = start_ns(Ns, Cfg),
        {ok, _, _} = rp(Ns, {assertz, {parent, tom, bob}}),
        {ok, _, _} = rp(Ns, {assertz, {parent, ann, eve}}),
        {ok, Store} = quod_ledger_store:open(Ns, Dir),
        Ref = try
            {ok, Entry} = quod_ledger_store:read_at(Store, 2),
            #entry{data = {batch, [#transaction{tx_id = TxId}]}} =
                quod_ledger:entry_view(Entry),
            {transaction, Ns, quod_simplex:genesis_hash(Ns), TxId}
        after quod_ledger_store:close(Store) end,
        ExpectedOutcome =
            #{status => committed, height => 2, ref => Ref},
        ?assertEqual({ok, ExpectedOutcome}, quod_prolog:outcome(Ref)),
        stop_ns(Pid1),
        %% The index is derived data: remove it so this restart proves that
        %% ledger replay alone reconstructs both state and outcomes.
        ok = file:delete(
               filename:join(
                 quod_ledger_store:ns_dir(Dir, Ns), "outcomes.dets")),
        %% restart with the SAME data_dir: quod_simplex reloads the block list from disk,
        %% quod_prolog rebuilds both the fresh kb projection and the exact
        %% compact durable outcome from that ledger.
        _Pid2 = start_ns(Ns, Cfg),
        ?assertMatch({ok, [#{'X' := bob}], _}, rp(Ns, {parent, tom, {'X'}})),
        ?assertMatch({ok, [#{'P' := ann}], _}, rp(Ns, {parent, {'P'}, eve})),
        ?assertEqual({ok, ExpectedOutcome}, quod_prolog:outcome(Ref)),
        %% genesis config @1 + two writes @2,@3
        ?assertMatch(#{committed := 3, last_applied := 3}, quod_simplex:stats(Ns))
    end.

%% Faithful code edits cross the real overlay, transaction validation, durable
%% entry and canonical replay paths. Clause order affects both answers and cut.
t_ordered_edit_restart_reload({_Dir, Ns, Cfg}) ->
    fun() ->
        Pid1 = start_ns(Ns, Cfg),
        {ok, _, _} = rp(Ns,
            {',', {assertz, {choose, original}},
                  {assertz, {decision, general}}}),
        Edit = {',', {asserta, {choose, front_one}},
               {',', {assertz, {choose, tail_one}},
               {',', {asserta, {choose, front_two}},
               {',', {assertz, {choose, tail_two}},
               {',', {asserta, {':-', {decision, specific}, '!'}},
                     {findall, {'X'}, {choose, {'X'}}, {'Choices'}}}}}}},
        Expected = [front_two, front_one, original, tail_one, tail_two],
        %% This binding comes from the proof's staged ordered program.
        ?assertMatch({ok, [#{'Choices' := Expected}], _}, rp(Ns, Edit)),
        assert_ordered_program(Ns, Expected),
        stop_ns(Pid1),
        %% A fresh owner must reconstruct the same program from the ledger.
        _Pid2 = start_ns(Ns, Cfg),
        assert_ordered_program(Ns, Expected)
    end.

assert_ordered_program(Ns, Expected) ->
    ?assertMatch(
       {ok, [#{'Choices' := Expected}], _},
       rp(Ns, {findall, {'X'}, {choose, {'X'}}, {'Choices'}})),
    ?assertMatch(
       {ok, [#{'Decisions' := [specific]}], _},
       rp(Ns, {findall, {'X'}, {decision, {'X'}}, {'Decisions'}})).

%% quod_prolog crashes alone (rest_for_one restarts only it); the rebuild handshake
%% must refill the kb from quod_simplex's committed log without an apply_gap crash.
t_prolog_restart_rebuild({_Dir, Ns, Cfg}) ->
    fun() ->
        _Pid = start_ns(Ns, Cfg),
        {ok, _, _} = rp(Ns, {assertz, {item, sword}}),
        {ok, _, _} = rp(Ns, {assertz, {item, shield}}),
        Old = quod_reg:where({quod_prolog, Ns}),
        exit(Old, kill),
        _New = wait_new_pid({quod_prolog, Ns}, Old),
        %% facts survive via rebuild from quod_simplex (which never restarted)
        ?assertMatch({ok, [#{}], _}, rp(Ns, {item, sword})),
        ?assertMatch({ok, [#{}], _}, rp(Ns, {item, shield})),
        ?assertMatch({fail, [_ | _]}, rp(Ns, {item, bow}))
    end.

%% Every failing/unknown proof used to leak its read-set ETS table; after the fix
%% the table count must be stable across many failing proves.
t_failing_proofs_no_ets_leak({_Dir, Ns, Cfg}) ->
    fun() ->
        _Pid = start_ns(Ns, Cfg),
        ?assertMatch({fail, [_ | _]}, rp(Ns, {nope, x})),   %% also waits for readiness
        Before = length(ets:all()),
        _ = [?assertMatch({fail, [_ | _]},
                          quod_prolog:prove(Ns, {undefined_pred, k}))
             || _ <- lists:seq(1, 50)],
        After = length(ets:all()),
        ?assert(After =< Before + 2)
    end.
