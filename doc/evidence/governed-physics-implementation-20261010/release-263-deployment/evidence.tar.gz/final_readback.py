"""Read-only final health and retained-history check after desktop acceptance."""
from pathlib import Path
import datetime, hashlib, json, ssl, urllib.parse, urllib.request

p = Path(__file__).resolve().parent
out = p / 'final-readback'
out.mkdir(exist_ok=False)
nomad = 'http://192.168.1.10:4646'
job = 'quod-finality-candidate-v6-20260926'
context = ssl._create_unverified_context()

def get(origin, path):
    with urllib.request.urlopen(origin + path, context=context, timeout=40) as response:
        return json.load(response)

def save(name, value):
    with (out / name).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

save('intent.json', {'read_only': True, 'at': datetime.datetime.now(datetime.timezone.utc).isoformat()})
candidate = get(nomad, '/v1/job/' + job)
main = get(nomad, '/v1/job/quod')
ingress = get(nomad, '/v1/job/quod27-client-30519')
allocations = get(nomad, '/v1/job/' + job + '/allocations')
deployment = get(nomad, '/v1/deployment/e45ff376-79fd-ad35-cde6-42b65938cf9f')
for name, value in [('candidate', candidate), ('main', main), ('ingress', ingress),
                    ('allocations', allocations), ('deployment', deployment)]:
    save(name + '.json', value)
assert (candidate['Version'], candidate['JobModifyIndex']) == (71, 847862)
assert (main['Version'], main['JobModifyIndex']) == (246, 826727)
assert (ingress['Version'], ingress['JobModifyIndex']) == (1, 846370)
assert deployment['Status'] == 'successful'
fleet = json.loads((p / 'fleet-probe.json').read_text())
assert fleet['passed']
running = [a for a in allocations if a['ClientStatus'] == 'running' and a['DesiredStatus'] == 'run']
assert len(running) == 8
assert {a['ID'] for a in running} == {a['allocation'] for a in fleet['allocations']}
assert all(a['JobVersion'] == 71 and a['TaskStates']['quod']['Restarts'] == 0
           and a['DeploymentStatus']['Healthy'] for a in running)
before = json.loads((p / 'history-before.json').read_text())
summary = get(before['origin'], '/explorer/api/summary')
save('history-summary.json', summary)
checks = []
for item in before['blocks']:
    row = next(x for x in summary['namespaces'] if x['ns'] == item['namespace'])
    assert row['genesis'] == item['anchor'] and not row['syncing']
    original = p / item['file']
    assert hashlib.sha256(original.read_bytes()).hexdigest() == item['sha256']
    block = get(before['origin'], '/explorer/api/block/' +
                urllib.parse.quote(item['namespace'], safe='') + '/' + str(item['height']))
    save(item['file'].replace('-before.', '-final.'), block)
    assert block == json.loads(original.read_text())
    checks.append({'namespace': item['namespace'], 'anchor': item['anchor'],
                   'checked_height': item['height'], 'current_applied': row['applied'],
                   'same_block': True, 'same_anchor': True})
receipt = {'passed': True, 'read_only': True,
           'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'candidate_version': 71, 'candidate_index': 847862,
           'deployment': deployment['ID'], 'healthy_allocations': 8, 'restarts': 0,
           'same_allocations_since_release': True, 'main_unchanged': True,
           'ingress_unchanged': True, 'retained_history': checks}
save('PASSED.json', receipt)
print(json.dumps(receipt))
