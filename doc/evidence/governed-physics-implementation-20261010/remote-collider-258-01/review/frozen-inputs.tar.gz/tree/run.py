from pathlib import Path
import base64, hashlib, json, os, subprocess, time

out = Path(__file__).resolve().parent
deployment = out.parent/'quod27-release-258/deployment/refound'
fleet = json.loads((deployment/'fleet-probe.json').read_text())
assert fleet['passed'] and len(fleet['allocations']) == 8
assert all(r['probe']['version'] == '0.7.258' for r in fleet['allocations'])
nodes = sorted(fleet['allocations'],key=lambda r:r['name'])[:2]
assert nodes[0]['node'] != nodes[1]['node']
execution = out/'execution'; execution.mkdir()
world_ns = 'acceptance:physics:258:gallery'
source_ns = 'acceptance:physics:258:objects'
nomad = 'http://192.168.1.10:4646'

def binary(value):
    return '<<'+','.join(map(str,value.encode()))+'>>'

def save(path,value):
    with path.open('x') as f: json.dump(value,f,indent=2); f.write('\n')

def rpc(node,label,expression):
    command = ['nomad','alloc','exec','-i=false','-t=false','-address='+nomad,
        '-task','quod',nodes[node]['allocation'],'/opt/quod/bin/quod','eval',
        'binary_to_list(base64:encode(iolist_to_binary(json:encode(begin '+expression+' end)))).']
    save(execution/(label+'.intent.json'),{'node':nodes[node],'expression':expression})
    start=time.monotonic()
    result=subprocess.run(command,capture_output=True,text=True)
    (execution/(label+'.stdout')).write_text(result.stdout)
    (execution/(label+'.stderr')).write_text(result.stderr)
    save(execution/(label+'.exit.json'),{'exit':result.returncode,'seconds':time.monotonic()-start})
    assert result.returncode == 0, label+' failed; inspect original result, never resubmit'
    wire=json.loads(result.stdout)
    if isinstance(wire,list): wire=bytes(wire).decode('ascii')
    answer=json.loads(base64.b64decode(wire,validate=True))
    save(execution/(label+'.json'),answer)
    print(label+' completed',flush=True)
    return answer

def call(node,label,function,*args):
    return rpc(node,label,'quod_remote_collider_evidence:'+function+'('+','.join(args)+')')

def operation(): return binary(os.urandom(32).hex().upper())

def signed_args(request): return [binary(request['bytes']),binary(request['signature'])]

def expect_commit(result,label):
    assert result['committed'],label+' did not commit; resolve the retained original identity'

try:
    beam=(out/'quod_remote_collider_evidence.beam').read_bytes()
    digest=hashlib.sha256(beam).hexdigest()
    save(execution/'scope.json',{'world':world_ns,'source':source_ns,'allocations':nodes,
        'root_anchor':nodes[0]['probe']['root_anchor'],'helper_sha256':digest,
        'purpose':'Real remote signed collider transition and unchanged-work measurement; not personal desktop acceptance'})
    for node in (0,1):
        rpc(node,'load-'+str(node),'{module,quod_remote_collider_evidence}=code:load_binary('
            'quod_remote_collider_evidence,'+json.dumps(digest)+',base64:decode('
            +binary(base64.b64encode(beam).decode())+')), #{loaded => true}')
    host=call(0,'physics-host','node')['reference']
    editor=call(1,'source-editor','node')['reference']
    world=call(0,'found-world','found_world',binary(world_ns),binary(editor))
    source=call(1,'found-source','found_source',binary(source_ns),binary(world_ns),
        binary(world['anchor']),binary(host))
    initial=call(0,'nonphysical-baseline','world',binary(world_ns))
    assert initial['worlds'] == []
    request=call(0,'prepare-key-request','preparation',binary(world_ns),binary(world['anchor']),operation())
    prepared=call(0,'prepare-key-submit','submit',*signed_args(request))
    assert 'read_encoded' in prepared
    request=call(0,'activation-request','activation',binary(world_ns),binary(world['anchor']),
        binary(source_ns),binary(source['anchor']),binary(editor),
        '#{key_values => '+binary(prepared['read_encoded'])+',operation => '+operation()+'}')
    expect_commit(call(0,'activation-submit','submit',*signed_args(request)),'activation')
    call(0,'activation-installed','installed',binary(world_ns),'1')
    call(0,'activation-receipt','receipt',*signed_args(request))
    for kind,structure in [('admission',2),('unrelated',2),('edit',3),('withdrawal',4)]:
        request=call(1,kind+'-request','source_operation',binary(source_ns),binary(world_ns),
            binary(world['anchor']),kind,operation())
        measured=call(0,kind+'-measured','observed_submit',binary(world_ns),binary(source_ns),
            str(structure),*signed_args(request))
        expect_commit(measured['outcome'],kind)
        call(1,kind+'-receipt','receipt',*signed_args(request))
        repeat=call(0,kind+'-unchanged','unchanged',binary(world_ns))
        assert repeat['work'] == {},kind+' unchanged checks performed measured work'
        if kind == 'unrelated':
            assert not any('quod_physics_native' in key or 'quod_ledger_store,fold' in key
                or 'quod_foreign_projection,start_monitor' in key for key in measured['work']), measured['work']
        if kind == 'edit':
            assert '{ball,0.6}' in measured['after_change']['worlds'][0]['bodies']
        if kind == 'withdrawal':
            assert '{ball,0.6}' not in measured['after_change']['worlds'][0]['bodies']
    save(execution/'PASSED.json',{'passed':True,'world':world,'source':source,
        'remote_nodes':True,'repeat_checks':80,'personal_desktop_acceptance':False})
except BaseException as error:
    save(execution/'STOP.json',{'reason':str(error),'kind':type(error).__name__,
        'rule':'Inspect recorded original operations. Do not rerun this campaign.'})
    raise
