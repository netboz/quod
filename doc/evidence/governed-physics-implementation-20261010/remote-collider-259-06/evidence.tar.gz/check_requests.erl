-module(check_requests).
-export([run/0]).

run() ->
    {ok,_} = application:ensure_all_started(gproc),
    {ok,_} = application:ensure_all_started(crypto),
    {Pub,_} = Pair = quod_identity:generate(),
    Ref = {agent_instance_ref,<<"request-check-node">>,<<9:256>>,physical_node},
    {ok,Blob} = quod_wire_term:encode_canonical(Ref),
    application:set_env(quod,node_actor_principal,{agent,Blob}),
    application:set_env(quod,node_pubkey,Pub),
    application:set_env(quod,identity_key,quod_identity:key_term(Pair)),
    application:set_env(quod,namespace_desired,
        #{content => #{<<"quod:root">> => #{genesis_hash => <<42:256>>}},brahms => #{}}),
    Ns = <<"acceptance:physics:259:04:gallery">>, A = binary:encode_hex(binary:decode_hex(<<"9587E874C5D93C2FC3249EDD86AF6735E1EB30472293C537BF8880D86A8A6CB1">>)),
    Source = <<"acceptance:physics:259:04:objects">>, SA = binary:encode_hex(<<12:256>>),
    Editor = base64:encode(term_to_binary(Ref)),
    Values = base64:encode(term_to_binary([{<<"V0">>,<<13:256>>}])),
    {ok,Answer} = quod_durable_term:encode_result(#{<<"V0">> => <<13:256>>}),
    Recorded = base64:encode(term_to_binary({ok,#{},
        {normalized,{read,[],{answers,32,[Answer]}}}})),
    #{read_encoded := Values} = quod_remote_collider_evidence:recorded_result(Recorded),
    Target = {Ns,binary:decode_hex(A)}, Tx = {transaction,Ns,binary:decode_hex(A),<<11:256>>},
    Op = {operation,element(2,Ref),element(3,Ref),Blob,<<10:256>>},
    [begin
        Vector = {ok,#{discarded_request_evidence => true},{normalized,
            {committed,[],{operation_outcome,Op,[{Target,{Status,Tx}}]}}}},
        #{committed := Expected} = quod_remote_collider_evidence:recorded_result(
            base64:encode(term_to_binary(Vector)))
     end || {Status,Expected} <- [{committed,true},{{rejected,not_authorized},false}]],
    WorldOptions = quod_remote_collider_evidence:found_options(
        ["agent_instance.pl","space.pl","quod_physics.pl"],
        <<"can_assign_agent_host(H, physics_authority, none, 0, H, _) :- acceptance_authority_host(H).\n">>,
        [{acceptance_actor,Ref},
         {can_prepare_agent_key,Ref,physics_authority,none,0,Ref},
         {acceptance_authority_host,Ref}]),
    {ok,_} = quod_ontology:validate_action({create_ontology,Ns,WorldOptions}),
    Creation = quod_remote_collider_evidence:source_creation(Source,Ns,A,Editor),
    {create_ontology,Source,SourceOptions} =
        binary_to_term(base64:decode(maps:get(action,Creation))),
    Founding = [begin
        Text = proplists:get_value(source,Options),
        {ok,Terms} = erlog_io:read_string_terms(binary_to_list(Text)),
        #{name => Name,ground_options => quod_wire_term:is_ground(Options),
          source_bytes => byte_size(Text),parsed_clauses => length(Terms)}
    end || {Name,Options} <- [{world,WorldOptions},{source,SourceOptions}]],
    Prep = quod_remote_collider_evidence:preparation(Ns,A,operation()),
    Activation = quod_remote_collider_evidence:activation(Ns,A,Source,SA,Editor,
        #{key_values => Values,operation => operation()}),
    Cases = [{preparation,Prep},{activation,Activation}] ++
        [{Kind,quod_remote_collider_evidence:source_operation(Source,Ns,A,Kind,operation())}
         || Kind <- [admission,unrelated,edit,withdrawal]],
    Report = [begin
        Bytes = base64:decode(maps:get(bytes,R)),
        Sig = base64:decode(maps:get(signature,R)),
        {ok,#{request := #{goal_text := Text}}} = quod_client_goal:verify(Bytes,Sig),
        {ok,_} = quod_client_goal_parser:parse(Text,3),
        #{name => Name,wire_bytes => byte_size(Bytes),goal_bytes => byte_size(Text)}
    end || {Name,R} <- Cases],
    ByteOptions = quod_remote_collider_evidence:found_options([],<<>>,
        [{all_bytes,list_to_binary(lists:seq(0,255))}]),
    true = quod_wire_term:is_ground(ByteOptions),
    {ok,_} = quod_ontology:validate_action({create_ontology,Ns,ByteOptions}),
    [{all_bytes,AllBytes}] = proplists:get_value(terms,ByteOptions),
    AllBytes = list_to_binary(lists:seq(0,255)),
    io:format("~s~n",[json:encode(#{read_height_32 => true,founding => Founding,all_256_byte_values => true,
        signed_and_parsed => Report,submitted => false})]),
    halt(0).

operation() -> binary:encode_hex(crypto:strong_rand_bytes(32)).
