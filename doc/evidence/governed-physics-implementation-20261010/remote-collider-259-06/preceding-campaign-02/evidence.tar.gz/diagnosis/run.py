from pathlib import Path
import base64,json,subprocess,time
out=Path(__file__).resolve().parent
prior=out.parent/'execution'
nodes=json.loads((prior/'scope.json').read_text())['allocations']
creation=json.loads((prior/'source-creation-options.json').read_text())
def binary(v):return '<<'+json.dumps(v)+'>>'
def save(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def rpc(node,label,expression):
 cmd=['nomad','alloc','exec','-i=false','-t=false','-address=http://192.168.1.10:4646','-task','quod',nodes[node]['allocation'],'/opt/quod/bin/quod','eval','binary_to_list(base64:encode(iolist_to_binary(json:encode(try begin '+expression+' end catch C:R:S -> #{error => iolist_to_binary(io_lib:format("~0p",[{C,R,S}]))} end)))).']
 save(label+'.intent.json',{'node':node,'expression':expression})
 t=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 save(label+'.exit.json',{'exit':r.returncode,'seconds':time.monotonic()-t})
 assert r.returncode==0
 w=json.loads(r.stdout)
 if isinstance(w,list):w=bytes(w).decode()
 answer=json.loads(base64.b64decode(w));save(label+'.json',answer)
 print(label,json.dumps(answer),flush=True)
 assert 'error' not in answer
 return answer
rpc(1,'source-state-after-rejection','#{source_state => iolist_to_binary(io_lib:format("~0p",[quod_ontology:local_state(<<"acceptance:physics:259:objects">>)])),root_height => quod_prolog:applied(<<"quod:root">>),root_committee => [binary:encode_hex(K) || K <- quod_simplex:committee(<<"quod:root">>)]}')
rpc(0,'revoke-exact-creation-grant','quod_remote_collider_evidence:creation_grant('+binary(creation['principal'])+','+binary(creation['action'])+',revoke)')
