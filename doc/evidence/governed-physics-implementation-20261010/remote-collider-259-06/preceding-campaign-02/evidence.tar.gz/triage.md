# Stopped live campaign 259-02

The driver now authors rules as ordinary Prolog source and supplies grounded anchored facts through the existing `terms` founding option. It performs no binary-to-source conversion. Construction checks validated all256byte values and six signed requests without submission. A prior local canonical-formatting experiment and a stale local BEAM selection failure are preserved separately.

This campaign reused the existing gallery identity. Source creation reached normal custody and returned `{error,not_in_charge}`: node1 followed root but was not its admitted validator. The normal custody author binding refused before signing/retention (`quod_simplex:register_dormant_transaction` / `current_dtx_binding`). Source remained `not_hosted`; rootheight66 contained only the temporary creation grant. The exact grant was revoked at67. Subsequent preflight records active custody0 and reservations0 on both nodes, singleton rootcommittee unchanged, no source hosting. No signed collider operation or physics activation occurred. Never rerun this campaign or replace its STOP.

The next bounded setup uses existing committee admission/withdrawal, under explicit candidate deployment authority and a separate Fable review. It restores root's original committee before measuring the subscribed physics owner. No production code was changed by this driver correction.
