from pathlib import Path
import base64, hashlib, json, os, subprocess, time

out = Path(__file__).resolve().parent
deployment = out.parent/'quod27-release-259/deployment/refound'
fleet = json.loads((deployment/'fleet-probe.json').read_text())
assert fleet['passed'] and len(fleet['allocations']) == 8
assert all(r['probe']['version'] == '0.7.259' for r in fleet['allocations'])
nodes = sorted(fleet['allocations'],key=lambda r:r['name'])[:2]
assert nodes[0]['node'] != nodes[1]['node']
execution = out/'execution'; execution.mkdir()
world_ns = 'acceptance:physics:259:04:gallery'
source_ns = 'acceptance:physics:259:04:objects'
nomad = 'http://192.168.1.10:4646'

def binary(value):
    if value.isascii():
        return '<<'+json.dumps(value)+'>>'
    return '<<'+','.join(map(str,value.encode()))+'>>'

def save(path,value):
    with path.open('x') as f: json.dump(value,f,indent=2); f.write('\n')

def rpc(node,label,expression):
    command = ['nomad','alloc','exec','-i=false','-t=false','-address='+nomad,
        '-task','quod',nodes[node]['allocation'],'/opt/quod/bin/quod','eval',
        'binary_to_list(base64:encode(iolist_to_binary(json:encode(try begin '+expression+
        ' end catch C:R:S -> #{evaluation_error => iolist_to_binary(io_lib:format("~0p",[{C,R,S}]))} end)))).']
    assert max(len(arg.encode()) for arg in command) < 128*1024, 'exec argument too large'
    save(execution/(label+'.intent.json'),{'node':nodes[node],'expression':expression})
    start=time.monotonic()
    result=subprocess.run(command,capture_output=True,text=True)
    (execution/(label+'.stdout')).write_text(result.stdout)
    (execution/(label+'.stderr')).write_text(result.stderr)
    save(execution/(label+'.exit.json'),{'exit':result.returncode,'seconds':time.monotonic()-start})
    assert result.returncode == 0, label+' failed; inspect original result, never resubmit'
    wire=json.loads(result.stdout)
    if isinstance(wire,list): wire=bytes(wire).decode('ascii')
    answer=json.loads(base64.b64decode(wire,validate=True))
    save(execution/(label+'.json'),answer)
    assert 'evaluation_error' not in answer, label+' evaluator failed; inspect original result'
    print(label+' completed',flush=True)
    return answer

def call(node,label,function,*args):
    return rpc(node,label,'quod_remote_collider_evidence:'+function+'('+','.join(args)+')')

def operation(): return binary(os.urandom(32).hex().upper())

def signed_args(request): return [binary(request['bytes']),binary(request['signature'])]

def expect_commit(result,label):
    assert result['committed'],label+' did not commit; resolve the retained original identity'

root_admitted=False
root_withdraw_started=False
creation_settled=True
hosting_grants={}
node0=node1=None

try:
    beam=(out/'quod_remote_collider_evidence.beam').read_bytes()
    digest=hashlib.sha256(beam).hexdigest()
    save(execution/'scope.json',{'world':world_ns,'source':source_ns,'allocations':nodes,
        'root_anchor':nodes[0]['probe']['root_anchor'],'helper_sha256':digest,
        'purpose':'Real remote signed collider transition and unchanged-work measurement; not personal desktop acceptance'})
    for node in (0,1):
        rpc(node,'load-'+str(node),'true=code:soft_purge(quod_remote_collider_evidence),{module,quod_remote_collider_evidence}=code:load_binary('
            'quod_remote_collider_evidence,'+json.dumps(digest)+',base64:decode('
            +binary(base64.b64encode(beam).decode())+')), #{loaded => true}')
    host=call(0,'physics-host','node')['reference']
    editor=call(1,'source-editor','node')['reference']
    node1=json.loads((out/'preflight-02/node-1.json').read_text())
    node0=json.loads((out/'preflight-02/node-0.json').read_text())
    grant=call(0,'world-hosting-grant','hosting_grant',binary(host),binary(world_ns),'grant')
    expect_commit(grant,'world hosting grant'); hosting_grants[world_ns]=host
    creation_settled=False
    world=call(0,'found-world','found_world',binary(world_ns),binary(editor))
    if world['classification']=='refused': creation_settled=True
    if 'unresolved_ref' in world: call(0,'resolve-world-creation','resolve_native',binary(world['unresolved_ref']))
    expect_commit(world,'world creation with hosting')
    call(0,'world-created','created',binary(world_ns),binary(world['anchor']))
    creation_settled=True
    expect_commit(call(0,'world-hosting-grant-revocation','hosting_grant',binary(host),binary(world_ns),'revoke'),'world hosting grant revocation')
    del hosting_grants[world_ns]
    grant=call(0,'source-hosting-grant','hosting_grant',binary(editor),binary(source_ns),'grant')
    expect_commit(grant,'source hosting grant'); hosting_grants[source_ns]=editor
    admitted=call(0,'root-admit-source-founder','membership','admit',binary(node1['node_key']),binary(node1['host']),str(node1['port']))
    if 'unresolved_ref' in admitted: call(0,'resolve-root-admission','resolve_native',binary(admitted['unresolved_ref']))
    expect_commit(admitted,'root admission'); root_admitted=True
    full_committee='['+','.join('binary:decode_hex('+binary(n['node_key'])+')' for n in (node0,node1))+']'
    for n in (0,1):
        call(n,'root-admission-installed-'+str(n),'membership_installed',str(admitted['root_height']),
             'base64:encode(term_to_binary('+full_committee+'))','true')
    creation_settled=False
    source=call(1,'found-source','found_source',binary(source_ns),binary(world_ns),
        binary(world['anchor']),binary(host))
    if source['classification']=='refused': creation_settled=True
    if 'unresolved_ref' in source: call(1,'resolve-source-creation','resolve_native',binary(source['unresolved_ref']))
    expect_commit(source,'source creation with hosting')
    call(1,'source-created','created',binary(source_ns),binary(source['anchor']))
    creation_settled=True
    root_withdraw_started=True
    withdrawn=call(0,'root-withdraw-source-founder','membership','remove',binary(node1['node_key']),binary(node1['host']),str(node1['port']))
    if 'unresolved_ref' in withdrawn: call(0,'resolve-root-withdrawal','resolve_native',binary(withdrawn['unresolved_ref']))
    expect_commit(withdrawn,'root withdrawal'); root_admitted=False
    single='[binary:decode_hex('+binary(node0['node_key'])+')]'
    for n in (0,1):
        call(n,'root-withdrawal-installed-'+str(n),'membership_installed',str(withdrawn['root_height']),
             'base64:encode(term_to_binary('+single+'))','true' if n==0 else 'false')
    expect_commit(call(0,'source-hosting-grant-revocation','hosting_grant',binary(editor),binary(source_ns),'revoke'),'source hosting grant revocation')
    del hosting_grants[source_ns]
    source_route=call(0,'source-route-on-physics-host','route',binary(source_ns),binary(source['anchor']))
    world_route=call(1,'world-route-on-source-host','route',binary(world_ns),binary(world['anchor']))
    assert node1['node_key'] in source_route['keys'] and node0['node_key'] in world_route['keys']
    initial=call(0,'nonphysical-baseline','world',binary(world_ns))
    assert initial['worlds'] == []
    request=call(0,'prepare-key-request','preparation',binary(world_ns),binary(world['anchor']),operation())
    prepared=call(0,'prepare-key-submit','submit',*signed_args(request))
    assert 'read_encoded' in prepared
    request=call(0,'activation-request','activation',binary(world_ns),binary(world['anchor']),
        binary(source_ns),binary(source['anchor']),binary(editor),
        '#{key_values => '+binary(prepared['read_encoded'])+',operation => '+operation()+'}')
    expect_commit(call(0,'activation-submit','submit',*signed_args(request)),'activation')
    call(0,'activation-installed','installed',binary(world_ns),'1')
    call(0,'activation-receipt','receipt',*signed_args(request))
    reader = None
    context_to_review = []
    for kind,structure in [('admission',2),('unrelated',2),('edit',3),('withdrawal',4)]:
        request=call(1,kind+'-request','source_operation',binary(source_ns),binary(world_ns),
            binary(world['anchor']),kind,operation())
        measured=call(0,kind+'-measured','observed_submit',binary(world_ns),binary(source_ns),
            binary(source['anchor']),binary(reader) if reader else 'none',
            str(structure),*signed_args(request))
        expect_commit(measured['outcome'],kind)
        before=measured['before']['worlds'][0]
        after=measured['after_change']['worlds'][0]
        assert before['pid'] == after['pid'] and before['fence'] == after['fence']
        assert after['counters']['navigation_ready']
        expected_installs=0 if kind == 'unrelated' else 1
        assert after['counters']['installs']-before['counters']['installs'] == expected_installs
        expected_bodies=[{'body':1,'revision':1}]
        if kind != 'withdrawal': expected_bodies.append({'body':2,'revision':3 if kind == 'edit' else 2})
        assert after['body_revisions'] == expected_bodies
        reader=measured['source_notice']['reader']
        call(1,kind+'-receipt','receipt',*signed_args(request))
        repeat=call(0,kind+'-unchanged','unchanged',binary(world_ns),binary(reader))
        resource_work={k:v for k,v in repeat['work'].items() if 'quod_physics_native,step' not in k}
        assert resource_work == {},kind+' unchanged checks performed resource work'
        assert repeat['before']['worlds'][0]['counters']['installs'] == repeat['after_checks']['worlds'][0]['counters']['installs']
        if repeat['node_work']: context_to_review.append(kind)
        if kind == 'unrelated':
            assert not any(('quod_physics_native' in key and 'quod_physics_native,step' not in key) or 'quod_ledger_store,fold' in key
                or 'quod_foreign_projection,start_monitor' in key for key in measured['work']), measured['work']
        if kind == 'edit':
            assert '{ball,0.6}' in measured['after_change']['worlds'][0]['bodies']
        if kind == 'withdrawal':
            assert '{ball,0.6}' not in measured['after_change']['worlds'][0]['bodies']
    for node in (0,1):
        rpc(node,'unload-'+str(node),'code:purge(quod_remote_collider_evidence),true=code:delete(quod_remote_collider_evidence),'
            'true=code:soft_purge(quod_remote_collider_evidence),#{unloaded => true}')
    save(execution/'PASSED.json',{'passed':True,'world':world,'source':source,
        'remote_nodes':True,'repeat_checks':80,'personal_desktop_acceptance':False,
        'node_context_requires_attribution':context_to_review})
except BaseException as error:
    save(execution/'STOP.json',{'reason':str(error),'kind':type(error).__name__,
        'rule':'Inspect recorded original operations. Do not rerun this campaign.'})
    raise
finally:
    cleanup={'root_admitted':root_admitted,'root_withdraw_started':root_withdraw_started,
             'creation_settled':creation_settled,'remaining_hosting_grants':list(hosting_grants)}
    if root_admitted and not root_withdraw_started and creation_settled:
        root_withdraw_started=True
        try:
            result=call(0,'cleanup-root-withdrawal','membership','remove',binary(node1['node_key']),binary(node1['host']),str(node1['port']))
            cleanup['root_withdrawal']=result
            if 'unresolved_ref' in result:
                cleanup['resolution']=call(0,'resolve-cleanup-root-withdrawal','resolve_native',binary(result['unresolved_ref']))
            if result['committed']:
                root_admitted=False
                single='[binary:decode_hex('+binary(node0['node_key'])+')]'
                for n in (0,1):
                    call(n,'cleanup-root-installed-'+str(n),'membership_installed',str(result['root_height']),
                        'base64:encode(term_to_binary('+single+'))','true' if n==0 else 'false')
        except BaseException as error:cleanup['root_cleanup_error']=str(error)
    if creation_settled and not root_admitted:
        for name,ref in list(hosting_grants.items()):
            try:
                result=call(0,'cleanup-hosting-grant-'+name.rsplit(':',1)[-1],'hosting_grant',binary(ref),binary(name),'revoke')
                cleanup[name]=result
                if result['committed']:del hosting_grants[name]
            except BaseException as error:cleanup[name]={'error':str(error)}
    cleanup.update(root_admitted_after_cleanup=root_admitted,remaining_hosting_grants_after_cleanup=list(hosting_grants))
    save(execution/'cleanup-status.json',cleanup)
