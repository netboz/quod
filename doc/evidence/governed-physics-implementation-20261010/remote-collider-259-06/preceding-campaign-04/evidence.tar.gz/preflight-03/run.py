from pathlib import Path
import base64,json,subprocess,time
out=Path(__file__).resolve().parent
prior=out.parent.parent/'quod27-remote-collider-259-02/execution'
nodes=json.loads((prior/'scope.json').read_text())['allocations']
creation=json.loads((prior/'source-creation-options.json').read_text())
def binary(v):return '<<'+json.dumps(v)+'>>'
def save(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def rpc(node,label,expression):
 cmd=['nomad','alloc','exec','-i=false','-t=false','-address=http://192.168.1.10:4646','-task','quod',nodes[node]['allocation'],'/opt/quod/bin/quod','eval','binary_to_list(base64:encode(iolist_to_binary(json:encode(try begin '+expression+' end catch C:R:S -> #{error => iolist_to_binary(io_lib:format("~0p",[{C,R,S}]))} end)))).']
 save(label+'.intent.json',{'node':node,'expression':expression})
 t=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 save(label+'.exit.json',{'exit':r.returncode,'seconds':time.monotonic()-t})
 assert r.returncode==0
 w=json.loads(r.stdout)
 if isinstance(w,list):w=bytes(w).decode()
 answer=json.loads(base64.b64decode(w));save(label+'.json',answer)
 print(label,json.dumps(answer),flush=True)
 assert 'error' not in answer
 return answer
for n in (0,1):
 rpc(n,'actor-hosts-'+str(n),'{ok,#{identity := {SelfNs,SelfAnchor}}}=quod_agent_ref:decode(element(2,element(2,quod_node_actor:principal()))),Namespaces=[<<"node:617e237fd538bc0f14e0d65389d9e2e9646bab3a16c782ab0a6d0900172f4d8e">>,<<"node:e47cbf54a87f5c5add6c143671af90b72030ebfbd780819e682556a62b637016">>],#{self => SelfNs,self_anchor => binary:encode_hex(SelfAnchor),states => [#{namespace => N,state => iolist_to_binary(io_lib:format("~0p",[quod_ontology:local_state(N)])),committee => [binary:encode_hex(K) || K <- quod_simplex:committee(N)]} || N <- Namespaces]}')
