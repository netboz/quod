# Campaign04 stop

Both fixture ontologies were created and hosted atomically through the existing owners. Both exact routes were confirmed. Root was restored to its original singleton at height79 and all temporary hosting grants were revoked. The world was still nonphysical at height1.

The signed prepare_agent_key_custody read succeeded and returned one public key. The evidence helper wrongly matched the answers tuple ledger height to literal1; the actual actor ledger height was32. The driver stopped on missing read_encoded. This is a driver interpretation failure, not a refused preparation or activation.

Keep this failure and its frozen inputs unchanged. A separately labeled campaign05 will consume this exact retained read result, preserve both founded identities, and perform only the not-yet-submitted activation and collider operations. No repeated preparation, creation, root admission, or failed campaign resumption.
