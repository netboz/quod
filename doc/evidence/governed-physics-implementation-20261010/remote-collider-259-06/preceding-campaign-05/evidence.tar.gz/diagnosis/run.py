from pathlib import Path
import base64,json,subprocess,time
out=Path(__file__).resolve().parent
prior=out.parent/'execution'
nodes=json.loads((prior/'scope.json').read_text())['allocations']
def binary(v):return '<<'+json.dumps(v)+'>>'
def save(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def rpc(node,label,expression):
 cmd=['nomad','alloc','exec','-i=false','-t=false','-address=http://192.168.1.10:4646','-task','quod',nodes[node]['allocation'],'/opt/quod/bin/quod','eval','binary_to_list(base64:encode(iolist_to_binary(json:encode(try begin '+expression+' end catch C:R:S -> #{error => iolist_to_binary(io_lib:format("~0p",[{C,R,S}]))} end)))).']
 save(label+'.intent.json',{'node':node,'expression':expression})
 t=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 save(label+'.exit.json',{'exit':r.returncode,'seconds':time.monotonic()-t})
 assert r.returncode==0
 w=json.loads(r.stdout)
 if isinstance(w,list):w=bytes(w).decode()
 answer=json.loads(base64.b64decode(w));save(label+'.json',answer)
 print(label,json.dumps(answer),flush=True)
 assert 'error' not in answer
 return answer
request=json.loads((prior/'activation-request.json').read_text())
rpc(0,'original-activation-resolution','R=quod_client_goal_ingress:resolve_operation(base64:decode('+binary(request['bytes'])+'),base64:decode('+binary(request['signature'])+')), S=case R of {ok,_,O}->{ok,O}; E->E end, #{result => iolist_to_binary(io_lib:format("~0p",[S])),encoded => base64:encode(term_to_binary(S))}')
rpc(0,'world-current','quod_remote_collider_evidence:world(<<"acceptance:physics:259:04:gallery">>)')
