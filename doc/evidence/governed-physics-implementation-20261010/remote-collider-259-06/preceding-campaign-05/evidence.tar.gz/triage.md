# Campaign05 stop

The retained successful public-key preparation was decoded without repeating it. A new activation was submitted once. Its command exited0 but stdout was truncated mid-list at48128characters, so the driver stopped without assuming an outcome.

The first read-only diagnostic failed before evaluation (unsafe Erlang variable) and is preserved. Diagnostic02 resolved the original operation: a certified terminal rejection, not_authorized, receipt34. The world remains nonphysical atheight2. No assignment/configuration was applied.

The fixture can_invoke body called current_ontology_identity/2. Strict commit-time authorization prohibits governed queries; the existing quod_agent_custody_tests invalid_acl case already covers this restriction. Correct the fixture to a pure local actor allowlist through its existing native owner, preserving exact identities/history. No production change is needed. The recorded signed request need not be duplicated in each evidence result. Campaign06 handles the current remote application result vector explicitly and treats target rejections as failure.
