from pathlib import Path
import subprocess,json,hashlib,urllib.request,urllib.error,time
out=Path('/tmp/quod-hot-controls/deployment-255');context=out/'image-context';image='192.168.1.11:5000/quod:0.7.255'

manifest=json.loads((out/'image-source-manifest.json').read_text())
try:urllib.request.urlopen(urllib.request.Request('http://192.168.1.11:5000/v2/quod/manifests/0.7.255',method='HEAD'))
except urllib.error.HTTPError as e:assert e.code==404
else:raise RuntimeError('Image tag exists; refusing overwrite')
def run(label,cmd):
 start=time.monotonic()
 with (out/(label+'.log')).open('x') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 (out/(label+'.exit.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'seconds':time.monotonic()-start},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
 print(label+' passed',flush=True)
digest=hashlib.sha256((out/'image-source-manifest.json').read_bytes()).hexdigest()
run('image-build',['docker','build','--progress=plain','--label','org.quod.source-manifest.sha256='+digest,'-t',image,str(context)])
c=subprocess.check_output(['docker','create',image],text=True).strip()
try:subprocess.run(['docker','cp',c+':/opt/quod/lib/quod-0.7.255/priv/explorer',str(out/'image-explorer')],check=True)
finally:subprocess.run(['docker','rm',c],check=True,stdout=subprocess.DEVNULL)
for n,h in manifest['files'].items():
 if n.startswith('priv/explorer/'):
  p=out/'image-explorer'/n.removeprefix('priv/explorer/')
  assert hashlib.sha256(p.read_bytes()).hexdigest()==h,n
run('image-push',['docker','push',image])
info=json.loads(subprocess.check_output(['docker','image','inspect',image]))[0]
ds=[d for d in info['RepoDigests'] if d.startswith('192.168.1.11:5000/quod@sha256:')];assert len(ds)==1
(out/'verified-image.json').write_text(json.dumps({'image':image,'digest':ds[0],'pinned_image':image+'@'+ds[0].split('@')[1],'source_manifest_sha256':digest,'explorer_matches':True},indent=2)+'\n')
print('Verified '+ds[0],flush=True)

request=urllib.request.Request('http://192.168.1.11:5000/v2/quod/manifests/0.7.255',method='HEAD',headers={'Accept':'application/vnd.docker.distribution.manifest.v2+json,application/vnd.oci.image.manifest.v1+json'})
with urllib.request.urlopen(request,timeout=20) as response: assert response.headers['Docker-Content-Digest']==ds[0].split('@')[1]
