from pathlib import Path
import hashlib, json, shutil, subprocess

repo=Path('/home/yan/src/quod')
base=Path('/tmp/quod-hot-controls')
out=base/'deployment-255'
out.mkdir()
tree=base/'clean-09/tree'
assert json.loads((base/'clean-09/PASSED.json').read_text())['passed']
freeze=json.loads((base/'clean-09/manifest.json').read_text())
assert all(hashlib.sha256((tree/n).read_bytes()).hexdigest()==h for n,h in freeze.items())
context=out/'image-context';context.mkdir()
files=['Dockerfile','.dockerignore','rebar.config','rebar.lock','scripts/build-physics.sh']
for root in ['config','include','priv','src','native/quod_physics']:
    files.extend(str(p.relative_to(tree)) for p in (tree/root).rglob('*') if p.is_file()
                 and '/target/' not in str(p.relative_to(tree))
                 and not str(p.relative_to(tree)).startswith('priv/native/')
                 and not (str(p.relative_to(tree)).startswith('priv/certs/') and p.suffix=='.pem'))
for name in sorted(set(files)):
    source=tree/name
    if name in ['rebar.config','src/quod.app.src']:
        source=repo/name
        old=(tree/name).read_text()
        assert source.read_text()==old.replace('0.7.254','0.7.255'),name
    dest=context/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
manifest={n:hashlib.sha256((context/n).read_bytes()).hexdigest() for n in sorted(set(files))}
prior=json.loads((repo/'doc/evidence/ontology-source/deployment-254/image-source-manifest.json').read_text())['files']
allowed=set(json.loads((base/'commit-files.json').read_text()))|{'rebar.config','src/quod.app.src','.dockerignore'}
changed=sorted(n for n in set(prior)|set(manifest) if prior.get(n)!=manifest.get(n))
assert all(n in allowed or n.startswith('priv/explorer/') for n in changed),changed
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
record={'base_commit':head,'uncommitted_source':True,'version':'0.7.255',
        'provenance':'Committed hot controls plus preserved already-deployed .254 ontology-source baseline; generated UI assets from clean-09 frozen UI/client inputs',
        'changed_from_deployed_254':changed,'files':manifest}
(out/'image-source-manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'changed':len(changed),'head':head}))
