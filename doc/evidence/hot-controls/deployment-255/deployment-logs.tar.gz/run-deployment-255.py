from pathlib import Path
import json,os,subprocess,sys,time,urllib.request
b=Path('/tmp/quod-hot-controls');out=b/'deployment-255'
assert json.loads((out/'verified-image.json').read_text())['explorer_matches']
root='D0100AE71106BBFBF381794B68C6D141111E29415BB636FD10897D52541CBBCE'
with (out/'root-info.json').open('x') as f:json.dump({'root_anchor':root},f)
results=[]
for name,cmd in [
 ('prepare',[sys.executable,str(b/'deploy-255.py'),'prepare']),
 ('plan',[sys.executable,str(b/'deploy-255.py'),'plan']),
 ('run',[sys.executable,str(b/'deploy-255.py'),'run']),
 ('watch',[sys.executable,str(b/'deploy-255.py'),'watch']),
 ('fleet',[sys.executable,str(b/'fleet-probe-after.py')]),
 ('signed-source',['node',str(b/'signed-source-check.mjs'),'signed-source-after'])]:
    start=time.monotonic()
    with (out/(name+'-driver.log')).open('x') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,NODE_TLS_REJECT_UNAUTHORIZED='0') if name=='signed-source' else None)
    row={'name':name,'exit':r.returncode,'seconds':round(time.monotonic()-start,2)};row.update({'tls_verification':False,'reason':'Self-signed LAN endpoint; same signed application-authentication smoke fixture as before deployment'} if name=='signed-source' else {});results.append(row)
    (b/'deployment-run-255/results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
    if r.returncode:sys.exit(r.returncode)
with urllib.request.urlopen('http://192.168.1.10:4646/v1/job/quod',timeout=20) as response:main=json.load(response)
before=json.loads((out/'main-before-upgrade.json').read_text())
assert main['JobModifyIndex']==before['JobModifyIndex'] and main['Version']==before['Version'] and main['TaskGroups']==before['TaskGroups']
(out/'main-after-upgrade.json').write_text(json.dumps(main,indent=2)+'\n')
a=json.loads((out/'signed-source-after.json').read_text());s=json.loads((b/'signed-source-before.json').read_text())
assert a['passed'] and a['root_anchor']==s['root_anchor']
assert {r['namespace']:r['sha256'] for r in a['targets']}=={r['namespace']:r['sha256'] for r in s['targets']}
(out/'deployment-PASSED.json').write_text(json.dumps({'passed':True,'main_job_unchanged':True,'signed_sources_unchanged':True,'results':results},indent=2)+'\n')
print('Candidate deployment qualified; main job and durable source state preserved.',flush=True)
