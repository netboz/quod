from pathlib import Path
import gzip,json,shutil,tarfile,subprocess
repo=Path('/home/yan/src/quod');base=Path('/tmp/quod-hot-controls');source=base/'deployment-255'
assert json.loads((source/'deployment-PASSED.json').read_text())['passed']
assert json.loads((base/'image-build-255-post-reboot-01/driver-exit.json').read_text())['exit']==0
assert json.loads((base/'deployment-run-255/driver-exit.json').read_text())['exit']==1
assert json.loads((source/'upgrade-run.exit.json').read_text())['exit']==0
assert json.loads((base/'deployment-verify-255-01/driver-exit.json').read_text())['exit']==0
out=repo/'doc/evidence/hot-controls/deployment-255';out.mkdir()
names=['image-source-manifest.json','verified-image.json','image-build.exit.json','image-push.exit.json','candidate-before-upgrade.json','candidate-after-upgrade.json','image-only-changes.json','upgrade-plan.exit.json','upgrade-run.exit.json','verified-deployment.json','fleet-probe-after.json','signed-source-after.json','deployment-PASSED.json','main-before-upgrade.json','main-after-upgrade.json']
for name in names:shutil.copy2(source/name,out/name)
for name in ['fleet-probe-before.json','signed-source-before.json','release-targets-07.json']:shutil.copy2(base/name,out/name)
files=[p for p in source.iterdir() if p.is_file()]
files.extend([base/'image-build-255/driver-exit.json',base/'image-build-255-driver.log',base/'image-build-255-post-reboot-01/driver-exit.json',base/'image-build-255-post-reboot-01-driver.log',base/'deployment-run-255/driver-exit.json',base/'deployment-run-255-driver.log',base/'start-background.py',base/'run-deployment-255.py',base/'prepare-image.py',base/'build-255.py',base/'deploy-255.py',base/'fleet-probe-after.py',base/'signed-source-check.mjs',base/'fleet-probe-post-reboot.py'])
files.extend(p for p in base.glob('cluster-health-20261009-*') if p.is_file())
files.extend(p for p in base.glob('cluster-health-post-*') if p.is_file())
files.extend(p for p in base.glob('cluster-ip-discovery-01.*') if p.is_file())
files.extend(p for p in base.glob('cluster-*discovery-01.json') if p.is_file())
files.extend(p for p in base.glob('cluster-neighbor-probes-01.json') if p.is_file())
files.extend(p for p in (base/'cluster-health-post-adguard-02').iterdir() if p.is_file())
files.extend(p for p in (base/'deployment-run-255').iterdir() if p.is_file())
files.extend(p for p in (base/'deployment-verify-255-01').iterdir() if p.is_file())
files.extend([base/'verify-deployment-255.py',base/'deployment-verify-255-01-driver.log',base/'seal-deployment-255.py'])
files=list(set(files))
with (out/'deployment-logs.tar.gz').open('wb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for p in sorted(files):
                info=tar.gettarinfo(str(p),arcname=str(p.relative_to(base)));info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
                with p.open('rb') as f:tar.addfile(info,f)
image=json.loads((source/'verified-image.json').read_text())['pinned_image']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
out.joinpath('README.md').write_text(f'''# Candidate release 0.7.255

Image `{image}` was built from the frozen, qualified source tree plus the
separate version-label commit `{head}`. The image includes the preserved,
already deployed 0.7.254 ontology-source baseline, whose unrelated local edits
remain uncommitted. [Source provenance](image-source-manifest.json) records
all inputs; generated explorer files match the frozen UI/client build.

The image-only candidate job update used one checked-index submission.
Eight candidate allocations run 0.7.255 with the existing root anchor,
18 ready catalogue entries, zero rejected entries, completed enrollment and
stored, self-hosting node actors. The main `quod` job was unchanged.

The signed read-only smoke check verifies all 17 public ontology sources,
repeat reads, wrong-anchor/private-root refusal and denied policy invocation.
Source hashes match the pre-deploy snapshot and it performs zero ledger writes.
TLS certificate verification was disabled for the self-signed LAN endpoint,
as in the pre-deploy fixture; this checks application authentication and policy,
and is not a TLS verification test. No chair state was seeded or physical
host-failure injection performed.

[Full deployment logs](deployment-logs.tar.gz) retain build/push exits,
registry digest verification, the plan and single submission, deployment events,
fleet probes and signed application smoke results.

The first image campaign stopped with exit 1 at the registry HEAD check,
before build, push or job submission, while the configured servers were
unreachable. Its failure logs are retained. The separately labelled
`image-build-255-post-reboot-01` campaign ran after the user rebooted the
servers and restarted AdGuard. Read-only checks then confirmed the original
addresses, all eight candidate ontologies ready, and the original root intact.
Nomad reported two healthy voting servers and failure tolerance zero; Caton
was absent from server membership. Consul retained three voting servers.
The application release does not repair this separate infrastructure issue.

The single Nomad submission exited 0 and monitored all eight allocations to
a successful deployment. The subsequent watcher exited 1 because it expected
an `Evaluation ID:` line absent from the actual CLI output. The original
campaign, script and failure remain in the archive. A separately labelled,
read-only `deployment-verify-255-01` campaign qualified the exact deployment
ID, job version, image configuration, eight healthy allocations, recovered
ontology state and signed client checks. No job or uncertain action was
resubmitted.
''')
print(json.dumps({'evidence_files':len(list(out.iterdir())),'source_head':head,'image':image}))
