import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFile, writeFile } from 'node:fs/promises'
import { createKeyProvider, fromB64url, b64url } from '/home/yan/src/quod/client/src/key-provider.js'
import { authenticateKey, readSystemOntologies, signedGoal } from '/home/yan/src/quod/client/src/signed-client.js'
import { readCodeState, readCodeSource } from '/home/yan/src/quod/client/src/prolog-edit.js'
import { anchoredGoal } from '/home/yan/src/quod/client/src/world.js'
import { compound, variable, binary, renderTerm, atom } from '/home/yan/src/quod/client/src/prolog-term.js'
const out='/tmp/quod-hot-controls/deployment-255', origin='https://192.168.1.10:31609'
const root=JSON.parse(await readFile(out+'/root-info.json','utf8')).root_anchor
const nativeFetch=globalThis.fetch
globalThis.fetch=(url,options)=>nativeFetch(new URL(url,origin),options)
const provider=await createKeyProvider(), identity=await authenticateKey(provider)
assert.equal(Buffer.from(identity.networkId).toString('hex').toUpperCase(),root)
const catalogue=await readSystemOntologies(identity)
assert.equal(catalogue.length,18)
const ref=ns=>{const row=catalogue.find(r=>r.namespace===ns);assert(row,ns);return {namespace:ns,anchor:fromB64url(row.anchor)}}
const agent={...ref('quod:signup'),instanceText:renderTerm(compound('signup',[binary(provider.publicKey)]))+'.'}
const tools=ref('quod:prolog'), results=[]
for(const row of catalogue.filter(r=>r.namespace!=='quod:signup')) {
 const workspace={tools,target:ref(row.namespace)}
 const source=await readCodeState(identity,agent,workspace)
 assert(source.includes('can_invoke('),row.namespace)
 assert(source.includes('isa('),row.namespace)
 const policy=await readCodeSource(identity,agent,workspace,compound('/',[atom('can_invoke'),{type:'number',value:4}]))
 assert(source.includes(policy),row.namespace)
 results.push({namespace:row.namespace,anchor:row.anchor,bytes:Buffer.byteLength(source),policyVisible:true,sha256:createHash('sha256').update(source).digest('hex')})
 if(row.namespace==='quod:node') assert(source.includes('node_identity_template('))
 if(row.namespace==='quod:modelling') assert(source.includes('model('))
}
const node={tools,target:ref('quod:node')}
const repeated=await readCodeState(identity,agent,node)
assert.equal(repeated,await readCodeState(identity,agent,node))
const wrong={...node,target:{namespace:'quod:node',anchor:new Uint8Array(32)}}
await assert.rejects(readCodeState(identity,agent,wrong))
const rootTarget={namespace:'quod:root',anchor:identity.networkId}
await assert.rejects(readCodeState(identity,agent,{tools,target:rootTarget}))
const invocation=await signedGoal(identity,{mode:'read',agent,goal:anchoredGoal(node.target,compound('node_identity_template',[variable('Template')]))})
assert.equal(invocation.result,'fail')
const record={passed:true,root_anchor:root,principal:'authenticated key-bound signup applicant; no administrator grant',targets:results,unchangedRepeat:true,wrongAnchorDenied:true,privateRootDenied:true,policyInvocationDenied:true,ledgerWrites:0}
await writeFile(out+'/'+(process.argv[2]||'signed-source-check')+'.json',JSON.stringify(record,null,2)+'\n')
console.log(JSON.stringify({passed:true,targets:results.length,bytes:results.reduce((a,r)=>a+r.bytes,0),ledgerWrites:0}))
