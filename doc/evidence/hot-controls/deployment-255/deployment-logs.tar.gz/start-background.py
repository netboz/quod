from pathlib import Path
import json,subprocess,sys,time
base=Path('/tmp/quod-hot-controls');name=sys.argv[1];script=base/sys.argv[2]
assert script.is_file()
out=base/name;out.mkdir()
with (base/(name+'-driver.log')).open('x') as log:
    p=subprocess.Popen([sys.executable,str(base/'durable-gates.py'),str(script),str(out)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
with (base/(name+'-launch.json')).open('x') as f:json.dump({'pid':p.pid,'script':str(script),'started':time.time()},f,indent=2)
print(json.dumps({'name':name,'pid':p.pid}))
