from pathlib import Path
import json, os, subprocess, sys, time, urllib.request
b=Path('/tmp/quod-hot-controls'); out=b/'deployment-255'; campaign=b/'deployment-verify-255-01'
assert json.loads((b/'deployment-run-255/driver-exit.json').read_text())['exit']==1
assert json.loads((out/'upgrade-run.exit.json').read_text())['exit']==0
assert json.loads((out/'verified-image.json').read_text())['explorer_matches']
address='http://192.168.1.10:4646'
def get(path):
    with urllib.request.urlopen(address+path,timeout=20) as response:return json.load(response)
def save(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
intent=json.loads((out/'candidate-image-upgrade.json').read_text())['Job']
job=get('/v1/job/'+intent['ID'])
assert job['Version']==55 and job['TaskGroups']==intent['TaskGroups']
observed=json.loads((out/'rollout-observation-01.json').read_text())[0]
deployment=get('/v1/deployment/'+observed['ID'])
assert deployment['JobID']==intent['ID'] and deployment['JobVersion']==55 and deployment['Status']=='successful'
groups=deployment['TaskGroups'];assert set(groups)=={'quod-node'}
assert groups['quod-node']['HealthyAllocs']==8 and groups['quod-node']['UnhealthyAllocs']==0
save(out/'verified-deployment.json',deployment)
save(out/'candidate-after-upgrade.json',job)
results=[{'name':'verify-existing-deployment','exit':0,'submission_repeated':False}]
for name,cmd in [('fleet',[sys.executable,str(b/'fleet-probe-after.py')]),('signed-source',['node',str(b/'signed-source-check.mjs'),'signed-source-after'])]:
    started=time.monotonic()
    with (campaign/(name+'.log')).open('x') as log:
        r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,NODE_TLS_REJECT_UNAUTHORIZED='0') if name=='signed-source' else None)
    row={'name':name,'exit':r.returncode,'seconds':round(time.monotonic()-started,2)}
    if name=='signed-source':row.update(tls_verification=False,reason='Self-signed LAN endpoint; application authentication and policy check only')
    results.append(row);(campaign/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
    if r.returncode:sys.exit(r.returncode)
main=get('/v1/job/quod');before=json.loads((out/'main-before-upgrade.json').read_text())
assert main['JobModifyIndex']==before['JobModifyIndex'] and main['Version']==before['Version'] and main['TaskGroups']==before['TaskGroups']
save(out/'main-after-upgrade.json',main)
a=json.loads((out/'signed-source-after.json').read_text());s=json.loads((b/'signed-source-before.json').read_text())
assert a['passed'] and a['root_anchor']==s['root_anchor']
assert {r['namespace']:r['sha256'] for r in a['targets']}=={r['namespace']:r['sha256'] for r in s['targets']}
save(out/'deployment-PASSED.json',{'passed':True,'main_job_unchanged':True,'signed_sources_unchanged':True,'submission_repeated':False,'verification_campaign':'deployment-verify-255-01','earlier_campaign':{'name':'deployment-run-255','exit':1,'reason':'Post-submit CLI output parser failure; Nomad submission exited 0 and completed rollout successfully'},'results':results})
print('Existing deployment qualified by read-only checks; no resubmission.',flush=True)
