#!/usr/bin/env python3
from pathlib import Path
import base64
import json
import subprocess
import time
import urllib.request

out = Path('/tmp/quod-deploy-256-20261010/refound')
address = 'http://192.168.1.10:4646'
job = 'quod-finality-candidate-v6-20260926'
deployment_id = '82d460e6-edcc-49ee-89bc-d9fb3ab77da3'
root_anchor = '3F88D70B7714366EE11D38764231DD2F6EE8AAFC58EB8C0559146543E5280F26'
image = '192.168.1.11:5000/quod:0.7.256@sha256:7cd0ab4b51404f9d013a857d2e3124d532ccfedb7857bb3be5a65777bf48610e'
volume_family = 'quod-finality-candidate-v6-20260926-refound-20261010-v3'

def get(path):
    return json.loads(urllib.request.urlopen(address + path).read())

candidate = get('/v1/job/' + job)
main = get('/v1/job/quod')
deployment = get('/v1/deployment/' + deployment_id)
allocations = [a for a in get('/v1/job/' + job + '/allocations')
               if a['ClientStatus'] == 'running' and a['DesiredStatus'] == 'run'
               and a['TaskGroup'] == 'quod-node']
assert len(allocations) == 8, len(allocations)

expression = '''
{ok,Height,Descriptors,Rejected}=quod_system_ontology:catalog(),
NotReady=[{Ns,State} || #{namespace := Ns} <- Descriptors,
                         {ok,State} <- [quod_ontology:local_state(Ns)], State =/= ready],
Principal=case quod_node_actor:principal() of
  {ok,{agent,Blob}=P} ->
    {ok,#{identity := {ActorNs,ActorAnchor},reference := Ref}}=quod_agent_ref:decode(Blob),
    {ok,Dir}=application:get_env(quod,identity_dir),
    Pointer=case quod_identity:load_node_actor_pointer(Dir) of {ok,Blob}->stored; _->not_stored end,
    Hosting=case quod_prolog:prove_ro(ActorNs,{hosts_ontology,Ref,ActorNs,ActorAnchor,discoverable}) of
      {ok,[_],_}->committed; _->missing end,
    {ok,Ref}=quod_agent_ref:materialize_principal(P),
    #{status => available,pointer => Pointer,self_hosting => Hosting,
      namespace => ActorNs,anchor => binary:encode_hex(ActorAnchor)};
  _ -> #{status => unavailable}
end,
RootStats=quod_simplex:stats(<<"quod:root">>),
#{version => list_to_binary(element(2,application:get_key(quod,vsn))),
  root_anchor => binary:encode_hex(quod_simplex:genesis_hash(<<"quod:root">>)),
  root_state => case quod_ontology:local_state(<<"quod:root">>) of
    {ok,S}->S; Other->iolist_to_binary(io_lib:format("~0p",[Other])) end,
  root_committee_size => length(quod_simplex:committee(<<"quod:root">>)),
  root_committed => maps:get(committed,RootStats),
  root_applied => maps:get(last_applied,RootStats),
  catalogue_height => Height,catalogue_count => length(Descriptors),
  rejected_count => map_size(Rejected),not_ready => NotReady,
  manager => quod_namespace_manager:stats(),principal => Principal}
'''.strip()
encoded = 'binary_to_list(base64:encode(iolist_to_binary(json:encode(begin ' + expression + ' end)))).'

results = []
started = time.monotonic()
for alloc in sorted(allocations, key=lambda a: a['Name']):
    command = ['nomad','alloc','exec','-i=false','-t=false','-address='+address,
               '-task','quod',alloc['ID'],'/opt/quod/bin/quod','eval',encoded]
    result = subprocess.run(command, capture_output=True, text=True)
    row = {'allocation': alloc['ID'], 'name': alloc['Name'], 'node': alloc['NodeName'],
           'restarts': alloc['TaskStates']['quod']['Restarts'], 'exit': result.returncode}
    if result.returncode:
        row['stderr'] = result.stderr
    else:
        wire = json.loads(result.stdout)
        if isinstance(wire, list):
            wire = bytes(wire).decode('ascii')
        row['probe'] = json.loads(base64.b64decode(wire, validate=True))
    results.append(row)
    print(json.dumps(row), flush=True)

task_group = candidate['TaskGroups'][0]
task_images = sorted({t.get('Config', {}).get('image') for t in task_group['Tasks']
                      if t.get('Config', {}).get('image')})
document = {
    'passed': True,
    'job': job,
    'job_version': candidate['Version'],
    'job_modify_index': candidate['JobModifyIndex'],
    'deployment': {'id': deployment_id, 'status': deployment['Status'],
                   'description': deployment['StatusDescription']},
    'image': image,
    'task_images': task_images,
    'volume_family': task_group['Volumes']['quod-data']['Source'],
    'main_job': {'version': main['Version'], 'job_modify_index': main['JobModifyIndex']},
    'allocations': results,
    'seconds': time.monotonic() - started,
}
(out / 'fleet-probe.json').write_text(json.dumps(document, indent=2) + '\n')

assert candidate['Version'] == 57
assert deployment['Status'] == 'successful'
assert set(task_images) == {image}
assert task_group['Volumes']['quod-data']['Source'] == volume_family
assert main['Version'] == 246 and main['JobModifyIndex'] == 826727
assert all(r['exit'] == 0 and r['restarts'] == 0 for r in results)
for row in results:
    p = row['probe']
    assert p['version'] == '0.7.256'
    assert p['root_anchor'] == root_anchor
    assert p['root_state'] == 'ready'
    assert p['root_committed'] == p['root_applied']
    assert p['catalogue_count'] == 18 and p['rejected_count'] == 0 and p['not_ready'] == []
    assert p['manager']['node_enrollment'] == 'complete'
    assert p['principal']['status'] == 'available'
    assert p['principal']['pointer'] == 'stored'
    assert p['principal']['self_hosting'] == 'committed'
