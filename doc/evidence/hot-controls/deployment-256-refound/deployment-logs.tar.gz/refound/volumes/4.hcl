## Dynamic host-volume template for one compute allocation.
## README.md creates quod-node-local[0..N-1] from this file before running the job.

namespace = "default"
name      = "quod-finality-candidate-v6-20260926-refound-20261010-v3[4]"
type      = "host"
plugin_id = "mkdir"
node_id   = "75b1a578-a5f6-e5b9-70cb-9e3aca6baac0"

constraint {
  attribute = "${node.class}"
  value     = "compute"
}

capability {
  access_mode     = "single-node-writer"
  attachment_mode = "file-system"
}
