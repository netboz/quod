#!/usr/bin/env python3
from pathlib import Path
import json
import os
import subprocess
import time

out = Path('/tmp/quod-deploy-256-20261010/refound')
env = dict(os.environ)
env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0'
started = time.time()
result = subprocess.run(
    ['node', '/tmp/quod-deploy-256-20261010/signed_source_check_256.mjs'],
    text=True, capture_output=True, env=env)
(out / 'signed-source-attempt-02.stdout').write_text(result.stdout)
(out / 'signed-source-attempt-02.stderr').write_text(result.stderr)
(out / 'signed-source-attempt-02.exit.json').write_text(json.dumps({
    'exit': result.returncode,
    'started_unix': started,
    'finished_unix': time.time(),
    'fresh_ephemeral_identity': True,
    'tls_verification': 'disabled only for the self-signed LAN endpoint',
}, indent=2) + '\n')
print(result.stdout, end='')
print(result.stderr, end='', file=__import__('sys').stderr)
raise SystemExit(result.returncode)
