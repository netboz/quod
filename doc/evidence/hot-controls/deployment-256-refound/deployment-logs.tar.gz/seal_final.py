#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import subprocess
import time
import urllib.request

out = Path('/tmp/quod-deploy-256-20261010/refound')
address = 'http://192.168.1.10:4646'
job_id = 'quod-finality-candidate-v6-20260926'
deployment_id = '82d460e6-edcc-49ee-89bc-d9fb3ab77da3'
image = '192.168.1.11:5000/quod:0.7.256@sha256:7cd0ab4b51404f9d013a857d2e3124d532ccfedb7857bb3be5a65777bf48610e'
new_family = 'quod-finality-candidate-v6-20260926-refound-20261010-v3'
old_family = 'quod-finality-candidate-v6-20260926-refound-20261007-v2'

def get(path):
    return json.loads(urllib.request.urlopen(address + path).read())

candidate = get('/v1/job/' + job_id)
main = get('/v1/job/quod')
allocations = get('/v1/job/' + job_id + '/allocations')
deployment = get('/v1/deployment/' + deployment_id)
volume_result = subprocess.run(
    ['nomad', 'volume', 'status', '-address=' + address, '-type=host', '-json'],
    capture_output=True, text=True, check=True)
volumes = json.loads(volume_result.stdout)
fresh_volumes = sorted(
    ({'id': row['ID'], 'name': row['Name'], 'node_id': row['NodeID'], 'state': row['State']}
     for row in volumes if row['Name'].startswith(new_family + '[')),
    key=lambda row: row['name'])
old_volumes = [row['Name'] for row in volumes if row['Name'].startswith(old_family + '[')]
live = sorted(({
    'id': row['ID'],
    'name': row['Name'],
    'node': row['NodeName'],
    'client_status': row['ClientStatus'],
    'desired_status': row['DesiredStatus'],
    'restarts': row['TaskStates']['quod']['Restarts'],
} for row in allocations
    if row['TaskGroup'] == 'quod-node' and row['DesiredStatus'] == 'run'),
    key=lambda row: row['name'])
group = candidate['TaskGroups'][0]
task_images = sorted({task.get('Config', {}).get('image') for task in group['Tasks']
                      if task.get('Config', {}).get('image')})
main_canonical = json.dumps(main, sort_keys=True, separators=(',', ':')).encode()
document = {
    'passed': True,
    'captured_unix': time.time(),
    'candidate': {
        'id': candidate['ID'],
        'version': candidate['Version'],
        'job_modify_index': candidate['JobModifyIndex'],
        'status': candidate['Status'],
        'count': group['Count'],
        'images': task_images,
        'volume_family': group['Volumes']['quod-data']['Source'],
    },
    'deployment': {
        'id': deployment_id,
        'status': deployment['Status'],
        'description': deployment['StatusDescription'],
    },
    'allocations': live,
    'fresh_volumes': fresh_volumes,
    'old_volume_family_matches': old_volumes,
    'main_job': {
        'version': main['Version'],
        'job_modify_index': main['JobModifyIndex'],
        'canonical_sha256': hashlib.sha256(main_canonical).hexdigest(),
    },
}
assert candidate['Version'] == 57 and candidate['Status'] == 'running'
assert group['Count'] == 8 and set(task_images) == {image}
assert group['Volumes']['quod-data']['Source'] == new_family
assert deployment['Status'] == 'successful'
assert len(live) == 8
assert all(row['client_status'] == 'running' and row['restarts'] == 0 for row in live)
assert len(fresh_volumes) == 8 and all(row['state'] == 'ready' for row in fresh_volumes)
assert old_volumes == []
assert main['Version'] == 246 and main['JobModifyIndex'] == 826727
(out / 'final-state.json').write_text(json.dumps(document, indent=2) + '\n')
print(json.dumps({
    'passed': True,
    'candidate_version': candidate['Version'],
    'allocations': len(live),
    'fresh_volumes': len(fresh_volumes),
    'old_volumes': len(old_volumes),
    'deployment': deployment['Status'],
    'main_version': main['Version'],
}))
