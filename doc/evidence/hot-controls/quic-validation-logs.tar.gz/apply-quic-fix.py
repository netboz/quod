from pathlib import Path
import subprocess

repo = Path('/home/yan/src/erlang_quic')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo)
p = repo/'src/quic_connection.erl'
s = p.read_text()
old = '                    SendAllowance = min(ConnectionAllowed, StreamAllowed),\n                    case SendAllowance of\n                        0 when ConnectionAllowed =:= 0 ->'
new = '                    %% Accepted queued data reserves stream offsets beyond current credit.\n                    %% Further calls remain blocked until the peer advances that credit.\n                    SendAllowance = max(0, min(ConnectionAllowed, StreamAllowed)),\n                    case SendAllowance of\n                        0 when ConnectionAllowed =< 0 ->'
assert s.count(old) == 1
p.write_text(s.replace(old, new))
p = repo/'test/quic_send_ready_SUITE.erl'
s = p.read_text()
s = s.replace('         oversized_send_precedes_flow_control/1]).', '         oversized_send_precedes_flow_control/1,\n         queued_send_blocks_without_crashing/1]).')
s = s.replace('          oversized_send_precedes_flow_control].', '          oversized_send_precedes_flow_control,\n          queued_send_blocks_without_crashing].')
case = '''queued_send_blocks_without_crashing(_Config) ->
    Parent = self(),
    Handler = fun(Server, _) ->
        ok = quic:set_owner_sync(Server, Parent),
        Parent ! {server_connection, Server},
        {ok, Parent}
    end,
    {ok, Echo} = quic_test_echo_server:start(
      #{max_data => 1024,
        max_stream_data_bidi_local => 64,
        max_stream_data_bidi_remote => 64,
        connection_handler => Handler}),
    try
        {ok, Conn} = connect(maps:get(port, Echo)),
        Server = receive
            {server_connection, S} -> S
        after 5000 ->
            ct:fail(no_server_connection)
        end,
        %% Hold the real peer before it can grant credit. The accepted send
        %% reserves 128 bytes while only 64 can leave the existing queue.
        ok = sys:suspend(Server),
        try
            {ok, Sid} = quic:open_stream(Conn),
            Payload = binary:copy(<<1>>, 128),
            ok = quic:send_data(Conn, Sid, Payload, false),
            ?assertEqual(
              {error, {flow_control_blocked, {stream, Sid}}},
              quic:send_data(Conn, Sid, <<2>>, false)),
            ?assert(is_process_alive(Conn)),
            ok = sys:resume(Server),
            receive
                {quic, Conn, {send_ready, Sid}} -> ok
            after 5000 ->
                ct:fail(no_send_ready_after_queued_send)
            end,
            %% Only the refused byte is submitted again. The previously
            %% accepted payload drains exactly once through the transport.
            ok = quic:send_data(Conn, Sid, <<2>>, true),
            ?assertEqual(<<Payload/binary, 2>>, receive_stream(Server, Sid, <<>>))
        after
            catch sys:resume(Server),
            quic:close(Conn, normal)
        end
    after
        quic_test_echo_server:stop(Echo)
    end.

'''
assert s.count('connect(Port) ->') == 1
p.write_text(s.replace('connect(Port) ->', case+'connect(Port) ->'))
