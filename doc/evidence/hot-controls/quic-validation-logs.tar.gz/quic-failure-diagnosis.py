from pathlib import Path
import json, os, subprocess, time

repo=Path('/home/yan/src/erlang_quic')
out=Path('/tmp/quod-hot-controls/quic-failure-diagnosis');out.mkdir()
resolver=out/'inetrc'
resolver.write_text('{lookup, [file]}.\n{host, {127,0,0,1}, ["localhost", "prospero"]}.\n{host, {0,0,0,0,0,0,0,1}, ["localhost"]}.\n')
env=dict(os.environ,ERL_INETRC=str(resolver),ERL_FLAGS='+S 4:4 +SDio 2 +SDcpu 2')
paths=[str(p) for p in (repo/'_build/test/lib').glob('*/ebin')]+[str(repo/'_build/test/lib/quic/test')]
original='/tmp/quod-hot-controls/clean-04/tree/_build/default/lib/quic/ebin/quic_connection'
for label,expr in [
    ('socket-baseline',f'{{module,quic_connection}}=code:load_abs("{original}"),eunit:test(quic_client_socket_backend_tests,[verbose])'),
    ('socket-fixed','eunit:test(quic_client_socket_backend_tests,[verbose])'),
    ('resolve-file-fixture','eunit:test(quic_resolve_tests,[verbose])')]:
    cmd=['erl','-noshell','-pa',*paths,'-eval',f'R=begin {expr} end,case R of ok->halt(0);_->halt(1) end.']
    start=time.monotonic()
    with (out/(label+'.log')).open('x') as log:
        r=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
    row={'command':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-start,2)}
    (out/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
    print(label,json.dumps(row),flush=True)
