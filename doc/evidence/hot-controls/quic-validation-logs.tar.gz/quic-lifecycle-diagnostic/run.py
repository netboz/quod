from pathlib import Path
import json, os, subprocess, time
repo=Path('/home/yan/src/erlang_quic')
out=Path('/tmp/quod-hot-controls/quic-lifecycle-diagnostic')
paths=[str(p) for p in (repo/'_build/test/lib').glob('*/ebin')]+[str(repo/'_build/test/lib/quic/test')]
env=dict(os.environ,ERL_FLAGS='+S 4:4 +SDio 2 +SDcpu 2',ERL_INETRC='/tmp/quod-hot-controls/quic-failure-diagnosis/inetrc')
for revision in ['baseline','fixed']:
    for case in ['stopped_server_name_is_reusable','stale_registry_death_preserves_replacement']:
        load=''
        if revision=='baseline':
            load=','.join(f'{{module,{m}}}=code:load_abs("{out}/original/{m}")' for m in ['quic_server_sup','quic_server_registry'])+','
        expr=f'''{load}{{module,quic_send_ready_SUITE}}=code:load_abs("{out}/quic_send_ready_SUITE"),
        {{ok,_}}=application:ensure_all_started(quic),
        try quic_send_ready_SUITE:{case}([]) of _->halt(0)
        catch C:R:S->io:format("~p:~p~n~p~n",[C,R,S]),halt(1) end.'''
        cmd=['erl','-noshell','-pa',*paths,'-eval',expr]
        start=time.monotonic();label=revision+'-'+case
        with (out/(label+'.log')).open('x') as f:
            r=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
        row={'revision':revision,'case':case,'exit':r.returncode,'seconds':round(time.monotonic()-start,2)}
        (out/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
        print(json.dumps(row),flush=True)
        assert r.returncode==(1 if revision=='baseline' else 0)
