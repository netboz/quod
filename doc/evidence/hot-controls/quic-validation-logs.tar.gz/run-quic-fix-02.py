from pathlib import Path
import hashlib, json, os, subprocess, sys, time

repo = Path('/home/yan/src/erlang_quic')
base = Path('/tmp/quod-hot-controls/quic-fix-02'); base.mkdir()
# Full formatting also touched two unrelated, previously clean test files.
# Keep those files at their verified starting versions.
for name in ['test/quic_connection_tests.erl', 'test/quic_idle_timeout_tests.erl']:
    (repo/name).write_bytes(subprocess.check_output(['git', 'show', 'HEAD:'+name], cwd=repo))
paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=repo).decode().split('\0')
manifest = {n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in paths if n and (repo/n).is_file()}
(base/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
(base/'diff.patch').write_bytes(subprocess.check_output(['git', 'diff'], cwd=repo))
(base/'freeze.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(), 'repository':str(repo),'files':len(manifest),'publication':'user fork only; no upstream notifications'},indent=2)+'\n')
commands = [('compile',['rebar3','compile']), ('eunit',['rebar3','eunit']),
            ('lint',['rebar3','lint']), ('dialyzer',['rebar3','dialyzer']),
            ('xref',['rebar3','xref']), ('send-ready-ct',['rebar3','ct','--suite=quic_send_ready_SUITE'])]
env = dict(os.environ, ERL_FLAGS='+S 4:4 +SDio 2 +SDcpu 2', ERL_INETRC='/tmp/quod-hot-controls/quic-failure-diagnosis/inetrc')
env.pop('DEBUG',None)
results = [{'name':'fmt','command':['rebar3','fmt'],'exit':0,'scope':'full formatter; unrelated test-only formatting discarded'}]
def unchanged():
    return all(hashlib.sha256((repo/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
for name,cmd in commands:
    assert unchanged(), name
    start=time.monotonic()
    with (base/(name+'.log')).open('x') as log:
        r=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
    row={'name':name,'command':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-start,2)}
    results.append(row)
    (base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if r.returncode:
        (base/'STOP.json').write_text(json.dumps(row,indent=2)+'\n')
        sys.exit(r.returncode)
    assert unchanged(), name
(base/'PASSED.json').write_text(json.dumps({'passed':True,'sources_unchanged':True,'results':results},indent=2)+'\n')
