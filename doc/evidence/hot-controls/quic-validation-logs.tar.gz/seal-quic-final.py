from pathlib import Path
import gzip,json,shutil,tarfile
base=Path('/tmp/quod-hot-controls');out=Path('/home/yan/src/quod/doc/evidence/hot-controls')
passed=json.loads((base/'quic-fix-03/PASSED.json').read_text());assert passed['passed'] and all(r['exit']==0 for r in passed['results'])
for name in ['PASSED.json','freeze.json','manifest.json','diff.patch']:
    shutil.copy2(base/'quic-fix-03'/name,out/('quic-lifecycle-'+name))
files=[]
for root in ['quic-fix-01','quic-fix-02','quic-fix-03','quic-failure-diagnosis','quic-lifecycle-diagnostic']:
    files.extend(p for p in (base/root).rglob('*') if p.is_file() and p.suffix not in ['.beam','.pem'] and '/_build/' not in str(p) and '/original/' not in str(p))
files.extend(p for p in base.glob('*quic*') if p.is_file() and p.suffix in ['.py','.log','.json'])
# Preserve existing transport CT reports from the previous archive as well.
prior=out/'quic-validation-logs.tar.gz'
old=[]
if prior.exists():
    with tarfile.open(prior,'r:gz') as t:
        for member in t.getmembers():
            if member.isfile(): old.append((member,t.extractfile(member).read()))
with prior.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as t:
            paths={str(p.relative_to(base)):p for p in files}
            for info,data in old:
                if info.name not in paths:
                    import io
                    t.addfile(info,io.BytesIO(data))
            for name,p in sorted(paths.items()):
                info=t.gettarinfo(str(p),arcname=name);info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
                with p.open('rb') as content:t.addfile(info,content)
out.joinpath('quic-resolution.md').write_text('''# QUIC credit and listener lifecycle corrections

The original pin crashes with `{case_clause,-64}` when an accepted send has
reserved stream offsets beyond the peer's current window and another send
arrives before credit advances. The direct-QUIC reproduction uses a real peer,
a 64-byte window and a 128-byte accepted payload; no Quod code is involved.
The correction clamps admission allowance to zero and reports exhausted
connection credit as blocked. A production-token comparison confirms those
are the only semantic changes despite formatter output. The regression suspends
the real peer, observes refusal, resumes it, awaits the existing readiness event
and checks exact delivery including only the explicitly retried refused byte.

The following Quod release run exposed a separate listener lifecycle defect:
`stop_server` acknowledged shutdown before the registry processed `DOWN`, so
an immediate restart could report `already_started`. Registration replacement
also retained the old monitor: its delayed death could delete the replacement.
The existing registry now synchronously releases a stopped registration before
the stop acknowledgement, retains any live replacement, clears superseded
monitors and checks that a death notice still names the current owner.
Two deterministic tests hold the real registry during stop and deliver an old
monitor notice after replacement. Both fail on the old implementation and pass
on the correction; no production polling, retry timer or alternative owner was
introduced. The manual `unregister/1` API remains a live Quod test seam.

[Credit checks](quic-PASSED.json) passed 2,206 EUnit tests and eight readiness
Common Test cases. [Final transport checks](quic-lifecycle-PASSED.json) passed
the formatter, compile, 2,206 EUnit tests, lint, Dialyzer, xref and all ten
readiness/lifecycle Common Test cases. The first transport campaign's socket
round-trip timeout and DNS cancellation remain recorded. The unchanged socket
module passes independently with both revisions; the timeout was not reproduced
or suppressed. A private file-only resolver makes localhost and the invalid-name
fixture deterministic without changing assertions or deadlines.

[Full transport evidence](quic-validation-logs.tar.gz) preserves failures,
baseline/fixed reproductions, source freezes and true exits. Credit commit
`fac1f28520d53ebb2aa59fc42d61f2b45384fd94` is followed by lifecycle commit
`9832288e2fca0c848bc6453cfb4ee7cbfd59ddd5`. Quod's configuration and lockfile
pin the latter. Both were published only to Yan's `netboz/erlang_quic` fork;
no original upstream PR, issue, message or push was made.
''')
print('Transport evidence sealed; full Quod release qualification remains pending.')
