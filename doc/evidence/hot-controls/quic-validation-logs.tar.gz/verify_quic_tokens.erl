-module(verify_quic_tokens).
-export([run/0]).
run() ->
    {ok, Original} = file:read_file("/tmp/quod-hot-controls/quic-fix-01/original_connection.erl"),
    Expected0 = binary:replace(Original,
        <<"SendAllowance = min(ConnectionAllowed, StreamAllowed)">>,
        <<"SendAllowance = max(0, min(ConnectionAllowed, StreamAllowed))">>),
    Expected = binary:replace(Expected0, <<"0 when ConnectionAllowed =:= 0 ->">>,
        <<"0 when ConnectionAllowed =< 0 ->">>),
    {ok, Actual} = file:read_file("/home/yan/src/erlang_quic/src/quic_connection.erl"),
    true = tokens(Expected) =:= tokens(Actual),
    io:format("Production token changes are exactly the two intended credit checks.~n").
tokens(Text) ->
    {ok, Tokens, _} = erl_scan:string(binary_to_list(Text)),
    [setelement(2, T, 0) || T <- Tokens].
