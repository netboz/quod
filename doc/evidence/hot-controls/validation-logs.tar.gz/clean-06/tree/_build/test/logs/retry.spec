{cases,"/tmp/quod-hot-controls/clean-06/tree/test",quod_peer_capacity_SUITE,
       [node_key_rotation_replaces_the_retained_slot]}.
