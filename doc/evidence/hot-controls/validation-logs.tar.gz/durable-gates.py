from pathlib import Path
import json, runpy, sys, time, traceback
script=Path(sys.argv[1]);out=Path(sys.argv[2]);start=time.monotonic();code=0
try:
    runpy.run_path(str(script),run_name='__main__')
except SystemExit as error:
    code=error.code if isinstance(error.code,int) else 1
except BaseException:
    code=1
    traceback.print_exc()
finally:
    with (out/'driver-exit.json').open('x') as f:
        json.dump({'script':str(script),'exit':code,'seconds':round(time.monotonic()-start,2)},f,indent=2)
sys.exit(code)
