from pathlib import Path
import hashlib, json, shutil, subprocess

repo = Path('/home/yan/src/quod')
base = Path('/tmp/quod-hot-controls/clean-08')
base.mkdir()
tree = base / 'tree'
tree.mkdir()
paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=repo).decode().split('\0')
extra_roots = ['test', 'src', 'include', 'priv', 'native/quod_physics/src', 'client/src', 'client/test', 'ui/src', 'ui/test']
paths.extend(subprocess.check_output(
    ['git', 'ls-files', '--others', '--exclude-standard', '-z', '--', *extra_roots],
    cwd=repo).decode().split('\0'))
paths.append('doc/player-movement-plan.md')
manifest = {}
for name in sorted(set(paths)):
    p = repo / name
    if not p.is_file():
        continue
    out = tree / name
    out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, out)
    # Explorer files are derived by the UI build; freeze authored inputs.
    if not name.startswith('priv/explorer/'):
        manifest[name] = hashlib.sha256(p.read_bytes()).hexdigest()
for dep in (repo/'_build/default/lib').iterdir():
    if dep.name not in ['quod', 'quic'] and dep.is_dir():
        shutil.copytree(dep, tree/'_build/default/lib'/dep.name,
                        ignore=shutil.ignore_patterns('_build', '*.beam'), symlinks=True)
quic_repo = Path('/home/yan/src/erlang_quic')
quic_sha = subprocess.check_output(['git','rev-parse','HEAD'],cwd=quic_repo,text=True).strip()
assert quic_sha != '2133856ad965f963aa857e2401c9f34f7cdf50a8'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=quic_repo)
assert quic_sha in (repo/'rebar.config').read_text() and quic_sha in (repo/'rebar.lock').read_text()
quic_dest = tree/'_build/default/lib/quic'
subprocess.run(['git','clone','--no-hardlinks',str(quic_repo),str(quic_dest)],check=True)
subprocess.run(['git','remote','set-url','origin','https://github.com/netboz/erlang_quic.git'],cwd=quic_dest,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=quic_dest,text=True).strip()==quic_sha
quic_paths = subprocess.check_output(['git','ls-files','-z'],cwd=quic_dest).decode().split('\0')
quic_manifest = {n:hashlib.sha256((quic_dest/n).read_bytes()).hexdigest() for n in quic_paths if n and (quic_dest/n).is_file()}
(base/'quic-source.json').write_text(json.dumps({'sha':quic_sha,'url':'https://github.com/netboz/erlang_quic.git','files':quic_manifest},indent=2)+'\n')
for area in ['client', 'ui']:
    shutil.copytree(repo/area/'node_modules', tree/area/'node_modules', symlinks=True)
shutil.copytree(repo/'native/quod_physics/target/release', tree/'native/quod_physics/target/release', symlinks=True)
shutil.copy2(repo/'native/quod_physics/target/.rustc_info.json', tree/'native/quod_physics/target/.rustc_info.json')
shutil.copy2(base.parent/'test-inetrc',tree/'test-inetrc')
manifest['test-inetrc']=hashlib.sha256((tree/'test-inetrc').read_bytes()).hexdigest()
(base/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
(base/'freeze.json').write_text(json.dumps({
    'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    'files': len(manifest), 'erlang_cache': 'pinned source only; no BEAMs',
    'cargo_cache': 'release build cache; test targets build normally',
    'derived_outputs': 'priv/explorer regenerated from frozen UI/client inputs',
    'scope': 'current source, preserving already deployed ontology inspection plus required uncommitted control foundations'
},indent=2)+'\n')
print(tree, flush=True)
