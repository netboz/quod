from pathlib import Path
import hashlib, json, os, subprocess, sys, time

base = Path('/tmp/quod-hot-controls/clean-08')
tree = base/'tree'
logs = base/'gates'
logs.mkdir()
manifest = json.loads((base/'manifest.json').read_text())
quic = json.loads((base/'quic-source.json').read_text())
def unchanged():
    return all((tree/n).is_file() and hashlib.sha256((tree/n).read_bytes()).hexdigest()==h for n,h in manifest.items()) and all(hashlib.sha256((tree/'_build/default/lib/quic'/n).read_bytes()).hexdigest()==h for n,h in quic['files'].items())
commands = [
    ('native-tests',['cargo','test','--locked','--manifest-path','native/quod_physics/Cargo.toml']),
    ('native-clippy',['cargo','clippy','--locked','--manifest-path','native/quod_physics/Cargo.toml','--all-targets','--','-D','warnings']),
    ('client-tests',['npm','--prefix','client','test']),
    ('ui-build',['npm','--prefix','ui','run','build']),
    ('ui-lint',['npm','--prefix','ui','run','lint']),
    ('eunit',['rebar3','as','test','eunit']),
    ('ct',['rebar3','as','test','ct']),
    ('xref',['rebar3','xref']),
    ('dialyzer',['rebar3','dialyzer']),
    ('release',['rebar3','as','prod','release'])]
env = dict(os.environ,ERL_FLAGS='+S 4:4 +SDio 2 +SDcpu 2',CARGO_NET_OFFLINE='true',ERL_INETRC=str(tree/'test-inetrc'))
env.pop('DEBUG',None)
assert not list((tree/'_build/default/lib').rglob('*.beam'))
results=[]
for name,cmd in commands:
    if not unchanged(): raise RuntimeError('source freeze changed before '+name)
    start=time.monotonic()
    with (logs/(name+'.log')).open('x') as log:
        r=subprocess.run(cmd,cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT)
    row={'name':name,'command':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-start,2)}
    results.append(row)
    (logs/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
    (logs/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if r.returncode:
        (base/'STOP.json').write_text(json.dumps(row,indent=2)+'\n')
        sys.exit(r.returncode)
    if not unchanged(): raise RuntimeError('source freeze changed after '+name)
outputs={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest()
         for p in (tree/'priv/explorer').rglob('*') if p.is_file()}
(base/'explorer-manifest.json').write_text(json.dumps(outputs,indent=2)+'\n')
(base/'PASSED.json').write_text(json.dumps({'passed':True,'sources_unchanged':True,'results':results},indent=2)+'\n')
