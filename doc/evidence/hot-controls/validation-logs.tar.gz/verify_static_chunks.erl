-module(verify_static_chunks).
-export([run/0]).
run() ->
    Base = "/tmp/quod-hot-controls",
    Out = Base ++ "/static-correction-diagnostic",
    ok = file:make_dir(Out),
    Chunks = ["AtU8", "Code", "StrT", "ImpT", "ExpT", "FunT", "LitT"],
    Results = [begin
        Name = atom_to_list(Module),
        Old = Base ++ "/clean-07/tree/_build/default/lib/quod/ebin/" ++ Name ++ ".beam",
        NewSource = Base ++ "/clean-08/tree/src/" ++ Name ++ ".erl",
        {ok,{Module,[{compile_info,Info}]}} = beam_lib:chunks(Old,[compile_info]),
        Options = proplists:get_value(options,Info),
        Compile = compile:file(NewSource,[{outdir,Out},return_errors,return_warnings|Options]),
        case Compile of {ok,Module} -> ok; {ok,Module,[]} -> ok end,
        New = Out ++ "/" ++ Name ++ ".beam",
        {ok,{Module,A}} = beam_lib:chunks(Old,Chunks, [allow_missing_chunks]),
        {ok,{Module,B}} = beam_lib:chunks(New,Chunks, [allow_missing_chunks]),
        Equal = A =:= B,
        io:format("~p executable_chunks_equal=~p~n",[Module,Equal]),
        #{module => Module, executable_chunks_equal => Equal}
    end || Module <- [quod_physics,quod_proof_session]],
    ok = file:write_file(Out ++ "/result.json",json:encode(Results)),
    case lists:all(fun(#{executable_chunks_equal := E}) -> E end,Results) of
        true -> halt(0); false -> halt(1)
    end.
