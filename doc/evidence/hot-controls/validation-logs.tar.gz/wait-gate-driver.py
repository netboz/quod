from pathlib import Path
import json, os, select, sys
base=Path('/tmp/quod-hot-controls');name=sys.argv[1];out=base/name
pid=json.loads((base/(name+'-launch.json')).read_text())['pid']
try:
    fd=os.pidfd_open(pid)
except ProcessLookupError:
    finished=True
else:
    finished=bool(select.select([fd],[],[],50)[0])
    os.close(fd)
receipt=out/'driver-exit.json'
results=out/'gates/results.json'
if not results.exists():results=out/'results.json'
print(json.dumps({'campaign':name,'finished':finished,'exit':json.loads(receipt.read_text())['exit'] if receipt.exists() else None,'completed':[{'name':r['name'],'exit':r['exit']} for r in json.loads(results.read_text())] if results.exists() else []}))
