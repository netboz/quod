#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time,urllib.request,urllib.error
root=Path('/home/yan/src/quod');out=Path(__file__).resolve().parent;gate=out.parent/'release-gates-03';tree=gate/'tree'
passed=json.loads((gate/'PASSED.json').read_text());assert passed['passed'] and len(passed['results'])==11 and all(r['exit']==0 and r['sources_unchanged'] for r in passed['results'])
manifest=json.loads((gate/'source-manifest.json').read_text());fixed={'Dockerfile','.dockerignore','rebar.config','rebar.lock','scripts/build-physics.sh'}
files=sorted(n for n in manifest if n in fixed or n.startswith(('config/','include/','priv/','src/','native/quod_physics/')))
files=[n for n in files if '/target/' not in n and not n.startswith('priv/native/') and not (n.startswith('priv/certs/') and n.endswith('.pem'))]
context=out/'image-context';context.mkdir()
for n in files:
 p=tree/n;assert hashlib.sha256(p.read_bytes()).hexdigest()==manifest[n],n
 q=context/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for name in ['rebar.config','src/quod.app.src']:
 original=(tree/name).read_text();labelled=original.replace('0.7.269','0.7.270')
 assert original!=labelled and (root/name).read_text()==labelled,name
 (context/name).write_text(labelled)
 manifest[name]=hashlib.sha256(labelled.encode()).hexdigest()
record={'version':'0.7.270','provenance':'Exact frozen and reviewed committed source','source_commit':json.loads((out/'source-commit.json').read_text())['commit'],'base_commit':json.loads((gate/'freeze.json').read_text())['base_commit'],'files':{n:manifest[n] for n in files}}
committed={}
for row in subprocess.check_output(['git','ls-tree','-r','-z',record['source_commit']],cwd=root).split(b'\0'):
 if row:
  metadata,path=row.split(b'\t',1);committed[path.decode()]=metadata.split()[2].decode()
for name in files:
 data=(context/name).read_bytes()
 blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert committed.get(name)==blob,('image input differs from committed source',name)
(out/'image-source-manifest.json').write_text(json.dumps(record,indent=2)+'\n');source_hash=hashlib.sha256((out/'image-source-manifest.json').read_bytes()).hexdigest();image='192.168.1.11:5000/quod:0.7.270'
url='http://192.168.1.11:5000/v2/quod/manifests/0.7.270'
try:urllib.request.urlopen(urllib.request.Request(url,method='HEAD'),timeout=20)
except urllib.error.HTTPError as e:assert e.code==404
else:raise RuntimeError('Tag already exists; no overwrite')
def run(label,cmd):
 start=time.monotonic()
 with (out/(label+'.log')).open('xb') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 (out/(label+'.exit.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'seconds':time.monotonic()-start},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
run('image-build',['docker','build','--progress=plain','--label','org.quod.source-manifest.sha256='+source_hash,'-t',image,str(context)])
cid=subprocess.check_output(['docker','create',image],text=True).strip()
try:subprocess.run(['docker','cp',cid+':/opt/quod/lib/quod-0.7.270/priv/explorer',str(out/'image-explorer')],check=True)
finally:subprocess.run(['docker','rm',cid],check=True,stdout=subprocess.DEVNULL)
for n in files:
 if n.startswith('priv/explorer/'):assert hashlib.sha256((out/'image-explorer'/n.removeprefix('priv/explorer/')).read_bytes()).hexdigest()==manifest[n],n
run('stable-source-path',['docker','run','--rm','--network=none','--entrypoint=/bin/sh',image,'-c','test -L /opt/quod/priv && for f in lobby_instance space agent_instance quod_physics space_view human_user_instance; do test -f /opt/quod/priv/ontologies/$f.pl || exit 1; done'])
run('vault-boot',[sys.executable,str(out/'boot_probe.py'),image,'vault-boot-01'])
assert json.loads((out/'vault-boot-01/boot-result.json').read_text())['version']=='0.7.270'
run('image-push',['docker','push',image]);info=json.loads(subprocess.check_output(['docker','image','inspect',image]))[0];digests=[d for d in info['RepoDigests'] if d.startswith('192.168.1.11:5000/quod@sha256:')];assert len(digests)==1
h={'Accept':'application/vnd.docker.distribution.manifest.v2+json,application/vnd.oci.image.manifest.v1+json'}
with urllib.request.urlopen(urllib.request.Request(url,method='HEAD',headers=h),timeout=20) as r:assert r.headers['Docker-Content-Digest']==digests[0].split('@',1)[1]
verified={'image':image,'pinned_image':image+'@'+digests[0].split('@',1)[1],'digests':digests,'image_id':info['Id'],'source_manifest_sha256':source_hash,'priv_matches':True,'profile':'prod','explorer_matches':True,'registry_digest_matches':True}
(out/'verified-image.json').write_text(json.dumps(verified,indent=2)+'\n');print(json.dumps(verified,indent=2))
