import {chromium} from '../../lobby-toolkit-20260925/browser/node_modules/playwright/index.mjs'
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs'
import {dirname,join,resolve,basename} from 'node:path'
import {fileURLToPath} from 'node:url'
import assert from 'node:assert/strict'
import {readControl} from '../../../client/src/locomotion.js'

process.umask(0o077)
const base=dirname(fileURLToPath(import.meta.url)),root=resolve(base,'../../..')
const label=process.argv[2]??'01';assert.match(label,/^[0-9]{2}$/)
assert.equal(JSON.parse(readFileSync(join(base,'refound/fleet-probe.json'))).passed,true)
const out=join(base,`desktop-${label}`);mkdirSync(out,{mode:0o700})
const profile=join(out,'browser');mkdirSync(profile,{mode:0o700})
const result={desktop:true,physicalVR:false,requests:[],projections:[],samples:[],errors:[]}
const save=()=>writeFileSync(join(out,'observation.json'),JSON.stringify(result,null,2),{mode:0o600})
const context=await chromium.launchPersistentContext(profile,{
  executablePath:'/home/yan/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome',
  headless:false,ignoreHTTPSErrors:true,viewport:{width:1280,height:960}})
const page=context.pages()[0]??await context.newPage();page.setDefaultTimeout(60000)
let latest=null,control=null
const observers=new Set()
page.on('pageerror',e=>{result.errors.push(e.message);save()})
page.on('request',r=>{const path=new URL(r.url()).pathname;if(path.startsWith('/api/'))result.requests.push(path)})
page.on('websocket',s=>s.on('framereceived',event=>{
  try {
    const m=JSON.parse(String(event.payload))
    if(m.type==='projection'){
      result.projections.push({selection:m.selection,marks:m.marks,control:m.control,frame:m.frame})
      if(m.selection==='active')control=readControl(m.control)
    }
    if(m.frame&&(m.type==='projection'||m.type==='simulation_frame')){
      latest=m.frame
      for(const f of [...observers])f(latest)
    }
  }catch(e){result.errors.push(String(e))}
}))
await page.route('**/__acceptance_client/*.js',route=>route.fulfill({contentType:'text/javascript',
  body:readFileSync(join(root,'client/src',basename(new URL(route.request().url()).pathname)),'utf8')}))
const writes=()=>result.requests.filter(p=>p==='/api/goals/execute').length
const pose=()=>latest?.poses.find(p=>p.body===control?.body)?.position
function waitFrame(test,timeout=30000){
  if(latest&&test(latest))return Promise.resolve(latest)
  return new Promise((resolve,reject)=>{
    const done=f=>{if(test(f)){clearTimeout(timer);observers.delete(done);resolve(f)}}
    const timer=setTimeout(()=>{observers.delete(done);reject(Error('Expected physical frame not received'))},timeout)
    observers.add(done)
  })
}
async function release(key){
  const before=BigInt(latest.control_state.sequence)
  await page.keyboard.up(key)
  await waitFrame(f=>BigInt(f.control_state.sequence)>before)
}
async function travel(key,test){
  await page.keyboard.down(key)
  try{await waitFrame(()=>test(pose()))}finally{await release(key)}
}
async function hold(key,ticks=180){
  const tick=BigInt(latest.tick)
  await page.keyboard.down(key)
  try{await waitFrame(f=>BigInt(f.tick)>=tick+BigInt(ticks))}finally{await release(key)}
}
function sample(name){const value={name,position:pose(),frame:latest};result.samples.push(value);save();return value}
async function ownerProbe(note=false){return page.evaluate(async(note)=>{
  const [{loadActiveKeyProvider},{authenticateKey,signedGoal},{accountReference},
    {readPersonalLobby,anchoredGoal},{readTerm}]=await Promise.all([
      import('/__acceptance_client/key-provider.js'),import('/__acceptance_client/signed-client.js'),
      import('/__acceptance_client/accounts.js'),import('/__acceptance_client/world.js'),
      import('/__acceptance_client/prolog-read.js')])
  const identity=await authenticateKey(await loadActiveKeyProvider()),account=accountReference(identity)
  const lobby=await readPersonalLobby(identity,account)
  const text='space_instance(personal_lobby,physical_space), physics_control(personal_lobby,Owner,Epoch,Binding), findall(definition(E,R,D),physics_definition(E,R,D),Definitions)'+(note?', desktop_acceptance(verified)':'')
  const reply=await signedGoal(identity,{mode:'read',agent:account,goal:anchoredGoal(lobby.reference,readTerm(text))})
  return {account,lobby:lobby.reference,reply}
},note)}
try{
  await page.goto('https://192.168.1.10:30519/')
  await page.getByRole('button',{name:'Create account',exact:true}).waitFor()
  writeFileSync(join(out,'signup-intent.json'),JSON.stringify({clickedOnce:true,newIsolatedProfile:true}),{flag:'wx'})
  await page.getByRole('button',{name:'Create account',exact:true}).click()
  await page.getByText('Physical space ready.',{exact:true}).waitFor({timeout:180000})
  await waitFrame(()=>control?.grounded&&pose())
  assert.equal(writes(),3,'signup, lobby founding and physical initialization only')
  assert.equal(await page.getByRole('button',{name:'Finish account setup',exact:true}).count(),0)
  result.owner=await ownerProbe();assert.equal(result.owner.reply.result,'ok');save()
  await page.screenshot({path:join(out,'lobby.png'),fullPage:true})
  await page.locator('canvas').click({position:{x:1050,y:720}})
  await page.waitForFunction(()=>document.pointerLockElement!==null)
  const floor=sample('floor-support')
  assert.ok(floor.position[1]>0.65&&floor.position[1]<0.85,'pilot starts supported by floor')
  await hold('ArrowUp')
  const consoleHit=sample('console-collision')
  assert.ok(consoleHit.position[1]>0.65&&consoleHit.position[1]<1.1,'pilot remains supported by floor or low console base')
  assert.ok(consoleHit.position[2]>2.9&&consoleHit.position[2]<3.5,'console stops forward movement')
  await page.screenshot({path:join(out,'console-collision.png'),fullPage:true})
  await travel('d',p=>Math.abs(p[0])>=6)
  await travel('ArrowDown',p=>p[2]<=0.1)
  await hold('d')
  const roofHit=sample('roof-collision')
  assert.ok(Math.abs(roofHit.position[0])>6&&Math.abs(roofHit.position[0])<8.7,'roof side stops movement before floor edge')
  assert.ok(roofHit.position[1]>0.65&&roofHit.position[1]<0.85)
  await page.screenshot({path:join(out,'roof-collision.png'),fullPage:true})
  await travel('a',p=>Math.abs(p[0])<=6)
  await travel('ArrowUp',p=>p[2]>=5)
  await travel('a',p=>Math.abs(p[0])<=0.15)
  await travel('ArrowUp',p=>p[2]>=8.2)
  const opening=sample('roof-opening')
  assert.ok(opening.position[2]>=8.2&&opening.position[1]>0.65&&opening.position[1]<0.85)
  await page.keyboard.press('Escape')
  await page.screenshot({path:join(out,'roof-opening.png'),fullPage:true})
  await page.getByRole('button',{name:'Open console',exact:true}).click()
  await page.getByRole('region',{name:'Focused console',exact:true}).waitFor()
  await page.screenshot({path:join(out,'console.png'),fullPage:true})
  await page.getByRole('button',{name:'Return to lobby',exact:true}).click()
  await page.getByText('Advanced',{exact:true}).click()
  await page.getByLabel('Inspect',{exact:true}).selectOption({label:result.owner.lobby.namespace})
  await page.getByRole('button',{name:'View Prolog source',exact:true}).click()
  await page.waitForFunction(()=>{
    const a=document.querySelector('textarea[aria-label="Source code"]')
    return a&&!a.disabled&&a.value.includes('physics_space')
  })
  const complete=await page.getByLabel('Source code',{exact:true}).inputValue()
  result.completeSource={characters:complete.length,hasPhysics:complete.includes('physics_space'),
    hasSpace:complete.includes('space_place'),hasConsole:complete.includes('console')}
  assert.ok(result.completeSource.hasSpace&&result.completeSource.hasConsole)
  const physicalBefore={incarnation:latest.incarnation,generation:latest.generation,structure:latest.structure}
  await page.getByLabel('New predicate (name/arity)',{exact:true}).fill('desktop_acceptance/1')
  await page.getByRole('button',{name:'Add predicate',exact:true}).click()
  await page.waitForFunction(()=>{
    const a=document.querySelector('textarea[aria-label="Source code"]')
    return a&&!a.disabled&&a.value===''
  })
  await page.getByLabel('Source code',{exact:true}).fill('desktop_acceptance(verified).\n')
  await page.getByRole('button',{name:'Preview changes',exact:true}).click()
  await page.waitForFunction(()=>[...document.querySelectorAll('button')].some(b=>b.textContent==='Save changes'&&!b.disabled))
  await page.getByRole('button',{name:'Save changes',exact:true}).click()
  await page.waitForFunction(()=>{
    const r=document.querySelector('pre[aria-label="Edit result"]')
    return r&&/^true/.test(r.textContent)&&!document.body.textContent.includes('Discard draft and reload')
  })
  result.edited=await ownerProbe(true);assert.equal(result.edited.reply.result,'ok')
  assert.deepEqual({incarnation:latest.incarnation,generation:latest.generation,structure:latest.structure},physicalBefore)
  await page.screenshot({path:join(out,'source-editor.png'),fullPage:true})
  const before=writes(),incarnation=latest.incarnation
  await page.reload()
  await page.getByText('Physical space ready.',{exact:true}).waitFor({timeout:120000})
  assert.equal(writes(),before,'reload performs no setup write or uncertain resubmission')
  assert.equal(latest.incarnation,incarnation,'reload retains installed physics owner')
  result.after=await ownerProbe(true);assert.deepEqual(result.after.account,result.owner.account)
  assert.deepEqual(result.after.lobby,result.owner.lobby);assert.equal(result.after.reply.result,'ok')
  assert.equal(result.errors.length,0)
  result.body=await page.locator('body').innerText();save()
  writeFileSync(join(out,'PASSED.json'),JSON.stringify({passed:true,desktop:true,physicalVR:false,
    writes:writes(),reloadWrites:0,grounded:true,consoleCollision:true,roofCollision:true,openingPassable:true,
    ownerRead:true,console:true,sourceEditor:true,completeSource:true,sameIdentity:true,sameIncarnation:true}),{flag:'wx'})
  console.log('Desktop physical lobby acceptance passed')
}catch(e){
  result.failure=String(e);result.body=await page.locator('body').innerText().catch(()=>'<unavailable>');save()
  await page.screenshot({path:join(out,'failure.png'),fullPage:true}).catch(()=>{})
  writeFileSync(join(out,'STOP.json'),JSON.stringify({error:String(e),noResubmission:true}),{flag:'wx'})
  throw e
}finally{await context.close()}
