import {chromium} from '../../lobby-toolkit-20260925/browser/node_modules/playwright/index.mjs'
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs'
import {dirname,join,resolve,basename} from 'node:path'
import {fileURLToPath} from 'node:url'
import assert from 'node:assert/strict'
import {readControl} from '../../../client/src/locomotion.js'

process.umask(0o077)
const base=dirname(fileURLToPath(import.meta.url)),root=resolve(base,'../../..')
const label=process.argv[2]??'07';assert.match(label,/^[0-9]{2}$/)
assert.equal(JSON.parse(readFileSync(join(base,'refound/fleet-probe.json'))).passed,true)
const out=join(base,`desktop-${label}`);mkdirSync(out,{mode:0o700})
const profile=join(base,'desktop-01/browser')
const prior=JSON.parse(readFileSync(join(base,'desktop-01/observation.json')))
assert.equal(prior.requests.filter(p=>p==='/api/goals/execute').length,3)
assert.ok(prior.body.includes('Physical space ready.'))
const result={desktop:true,headless:true,physicalVR:false,requests:[],projections:[],samples:[],errors:[]}
const save=()=>{result.latest=latest;return writeFileSync(join(out,'observation.json'),JSON.stringify(result,null,2),{mode:0o600})}
const context=await chromium.launchPersistentContext(profile,{
  executablePath:'/home/yan/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome',
  headless:true,ignoreHTTPSErrors:true,viewport:{width:1280,height:960}})
const page=context.pages()[0]??await context.newPage();page.setDefaultTimeout(60000)
let latest=null,control=null
const observers=new Set()
page.on('pageerror',e=>{result.errors.push(e.message);save()})
page.on('request',r=>{const path=new URL(r.url()).pathname;if(path.startsWith('/api/'))result.requests.push(path)})
page.on('websocket',s=>s.on('framereceived',event=>{
  try {
    const m=JSON.parse(String(event.payload))
    if(m.type==='projection'){
      result.projections.push({selection:m.selection,marks:m.marks,control:m.control,frame:m.frame})
      if(m.selection==='active')control=readControl(m.control)
    }
    if(m.frame&&(m.type==='projection'||m.type==='simulation_frame')){
      latest=m.frame
      for(const f of [...observers])f(latest)
    }
  }catch(e){result.errors.push(String(e))}
}))
await page.route('**/__acceptance_client/*.js',route=>route.fulfill({contentType:'text/javascript',
  body:readFileSync(join(root,'client/src',basename(new URL(route.request().url()).pathname)),'utf8')}))
page.on('response',async response=>{
  if(new URL(response.url()).pathname==='/api/goals/control'){
    try{result.controlReplies??=[];result.controlReplies.push(await response.json())}catch{}
  }
})
const writes=()=>result.requests.filter(p=>p==='/api/goals/execute').length
const pose=()=>latest?.poses.find(p=>p.body===control?.body)?.position
function waitFrame(test,timeout=30000){
  if(latest&&test(latest))return Promise.resolve(latest)
  return new Promise((resolve,reject)=>{
    const done=f=>{if(test(f)){clearTimeout(timer);observers.delete(done);resolve(f)}}
    const timer=setTimeout(()=>{observers.delete(done);reject(Error('Expected physical frame not received'))},timeout)
    observers.add(done)
  })
}
async function release(key){
  result.phase='release:'+key;save()
  const before=BigInt(latest.control_state.sequence)
  await page.keyboard.up(key)
  await waitFrame(f=>BigInt(f.control_state.sequence)>before)
}
async function travel(key,test){
  result.phase='travel:'+key;save()
  await page.keyboard.down(key)
  try{await waitFrame(()=>test(pose()))}finally{await release(key)}
}
async function hold(key,body){
  result.phase='contact:'+key+':'+body;save()
  const before=BigInt(latest.control_state.sequence)
  await page.keyboard.down(key)
  try{
    await waitFrame(f=>BigInt(f.control_state.sequence)>before&&f.control_state.result.startsWith('clipped(')&&f.control_state.result.includes(`contact(${body},`))
    result.contacts??=[];result.contacts.push({body,frame:latest});save()
  }finally{await release(key)}
}
function sample(name){const value={name,position:pose(),frame:latest};result.samples.push(value);save();return value}
async function ownerProbe(note=false){return page.evaluate(async(note)=>{
  const [{loadActiveKeyProvider},{authenticateKey,signedGoal},{accountReference},
    {readPersonalLobby,anchoredGoal},{readTerm}]=await Promise.all([
      import('/__acceptance_client/key-provider.js'),import('/__acceptance_client/signed-client.js'),
      import('/__acceptance_client/accounts.js'),import('/__acceptance_client/world.js'),
      import('/__acceptance_client/prolog-read.js')])
  const identity=await authenticateKey(await loadActiveKeyProvider()),account=accountReference(identity)
  const lobby=await readPersonalLobby(identity,account)
  const base="','(space_instance(personal_lobby,physical_space),','(physics_control(personal_lobby,Owner,Epoch,Binding),findall(definition(E,R,D),physics_definition(E,R,D),Definitions)))"
  const text=note?"','("+base+",desktop_acceptance(verified))":base
  const reply=await signedGoal(identity,{mode:'read',agent:account,goal:anchoredGoal(lobby.reference,readTerm(text))})
  return {account,lobby:lobby.reference,reply}
},note)}
try{
  await page.goto('https://192.168.1.10:30519/')
  await page.getByText('Physical space ready.',{exact:true}).waitFor({timeout:180000})
  await waitFrame(()=>control?.grounded&&pose())
  assert.equal(writes(),0,'same profile reconnect performs no setup writes')
  assert.equal(await page.getByRole('button',{name:'Finish account setup',exact:true}).count(),0)
  result.owner=await ownerProbe();assert.equal(result.owner.reply.result,'ok');save()
  const physics=JSON.parse(readFileSync(join(base,'desktop-06/observation.json')))
  assert.deepEqual(physics.samples.map(s=>s.name),['floor-support','console-collision','roof-collision','roof-opening'])
  assert.deepEqual(physics.contacts.map(c=>c.body),[0,2])
  assert.equal(latest.incarnation,physics.latest.incarnation)
  assert.deepEqual(result.owner.account,physics.owner.account)
  assert.deepEqual(result.owner.lobby,physics.owner.lobby)
  result.physicsEvidence='desktop-06';result.phase='open-console';save()
  await page.getByRole('button',{name:'Open console',exact:true}).click()
  await page.getByRole('region',{name:'Focused console',exact:true}).waitFor()
  await page.screenshot({path:join(out,'console.png'),fullPage:true})
  await page.getByRole('button',{name:'Return to lobby',exact:true}).click()
  result.phase='source-dispatch';save()
  await page.getByText('Advanced',{exact:true}).click()
  await page.getByLabel('Inspect',{exact:true}).selectOption({label:result.owner.lobby.namespace})
  await page.getByRole('button',{name:'View Prolog source',exact:true}).click()
  await page.waitForFunction(()=>{
    const a=document.querySelector('textarea[aria-label="Source code"]')
    return a&&!a.disabled&&a.value.includes('physics_space')
  })
  result.phase='source-edit';save()
  const complete=await page.getByLabel('Source code',{exact:true}).inputValue()
  result.completeSource={characters:complete.length,hasPhysics:complete.includes('physics_space'),
    hasSpace:complete.includes('space_place'),hasConsole:complete.includes('console')}
  assert.ok(result.completeSource.hasSpace&&result.completeSource.hasConsole)
  const physicalBefore={incarnation:latest.incarnation,generation:latest.generation,structure:latest.structure}
  await page.getByLabel('New predicate (name/arity)',{exact:true}).fill('desktop_acceptance/1')
  await page.getByRole('button',{name:'Add predicate',exact:true}).click()
  await page.waitForFunction(()=>{
    const a=document.querySelector('textarea[aria-label="Source code"]')
    return a&&!a.disabled&&a.value===''
  })
  await page.getByLabel('Source code',{exact:true}).fill('desktop_acceptance(verified).\n')
  await page.getByRole('button',{name:'Preview changes',exact:true}).click()
  await page.waitForFunction(()=>[...document.querySelectorAll('button')].some(b=>b.textContent==='Save changes'&&!b.disabled))
  await page.getByRole('button',{name:'Save changes',exact:true}).click()
  await page.waitForFunction(()=>{
    const r=document.querySelector('pre[aria-label="Edit result"]')
    return r&&/^true/.test(r.textContent)&&!document.body.textContent.includes('Discard draft and reload')
  })
  result.edited=await ownerProbe(true);assert.equal(result.edited.reply.result,'ok')
  assert.deepEqual({incarnation:latest.incarnation,generation:latest.generation,structure:latest.structure},physicalBefore)
  await page.screenshot({path:join(out,'source-editor.png'),fullPage:true})
  const before=writes(),incarnation=latest.incarnation
  result.phase='reload';save()
  await page.reload()
  await page.getByText('Physical space ready.',{exact:true}).waitFor({timeout:120000})
  assert.equal(writes(),before,'reload performs no setup write or uncertain resubmission')
  assert.equal(latest.incarnation,incarnation,'reload retains installed physics owner')
  result.after=await ownerProbe(true);assert.deepEqual(result.after.account,result.owner.account)
  assert.deepEqual(result.after.lobby,result.owner.lobby);assert.equal(result.after.reply.result,'ok')
  assert.equal(result.errors.length,0)
  result.body=await page.locator('body').innerText();save()
  writeFileSync(join(out,'PASSED.json'),JSON.stringify({passed:true,desktop:true,headless:true,physicalVR:false,
    priorSignupWrites:3,physicsEvidence:"desktop-06",fixtureRestoreWrites:0,writes:writes(),reconnectWrites:0,reloadWrites:0,grounded:true,consoleCollision:true,roofCollision:true,openingPassable:true,
    ownerRead:true,console:true,sourceEditor:true,completeSource:true,sameIdentity:true,sameIncarnation:true}),{flag:'wx'})
  console.log('Desktop physical lobby acceptance passed')
}catch(e){
  result.failure=String(e);result.body=await page.locator('body').innerText().catch(()=>'<unavailable>');save()
  await page.screenshot({path:join(out,'failure.png'),fullPage:true}).catch(()=>{})
  writeFileSync(join(out,'STOP.json'),JSON.stringify({error:String(e),noResubmission:true}),{flag:'wx'})
  throw e
}finally{await context.close()}
