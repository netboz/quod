from pathlib import Path
import json,subprocess,sys,time
out=Path(__file__).resolve().parent;state=out/'completion-01';state.mkdir()
acceptance=json.loads((out/'desktop-09/PASSED.json').read_text());assert acceptance['passed'] and acceptance['physicsEvidence']=='desktop-06'
for name in ['fleet_probe_after_desktop','purge_old_volumes']:
 cmd=[sys.executable,str(out/(name+'.py'))]
 with (state/(name+'.intent.json')).open('x') as f:json.dump({'command':cmd},f)
 print('Starting '+name,flush=True);start=time.monotonic()
 with (state/(name+'.log')).open('x') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 result={'exit':r.returncode,'seconds':time.monotonic()-start}
 (state/(name+'.exit.json')).write_text(json.dumps(result,indent=2))
 print(json.dumps({'stage':name,**result}),flush=True)
 if r.returncode:
  (state/'STOP.json').write_text(json.dumps(result));sys.exit(r.returncode)
(state/'PASSED.json').write_text(json.dumps({'passed':True,'release':'0.7.270','scope':'candidate network only','desktop_controls':True,'physicalVR':False,'obsolete_candidate_volumes_deleted':8},indent=2)+'\n')
print('Candidate deployment and acceptance complete.',flush=True)
