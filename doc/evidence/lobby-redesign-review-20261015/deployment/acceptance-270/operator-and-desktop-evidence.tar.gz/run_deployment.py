from pathlib import Path
import json,os,shutil,subprocess,sys,time
out=Path('/home/yan/src/quod/_build/lobby-redesign-implementation-20261015/deployment-01')
state=out/'execution';state.mkdir()
def run(label,args,env=None):
 with (state/(label+'.intent.json')).open('x') as f: json.dump({'command':args},f,indent=2)
 print('Starting '+label,flush=True);start=time.monotonic()
 with (state/(label+'.log')).open('x') as log:
  result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'label':label,'command':args,'exit':result.returncode,'seconds':time.monotonic()-start}
 (state/(label+'.exit.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
 if result.returncode:
  (state/'STOP.json').write_text(json.dumps(row,indent=2)+'\n');raise SystemExit(result.returncode)
def script(label):run(label,[sys.executable,str(out/(label+'.py'))])
script('build')
script('prepare_refound')
refound=out/'refound'
script('create_new_volumes')
script('bootstrap')
operator=refound/'fresh_system_operator.py'
for phase in ('load','root-info'):
 run(phase,[sys.executable,str(operator),phase])
root=json.loads((refound/'root-info.json').read_text())['root_anchor']
assert len(root)==64 and root != 'F747AB5E6A43F61C0207C3D8BD9F7537D1840FBAFB3E50FAF22E0F4688096698', 'Invalid or retained prior root anchor'
for phase in ('found','publish'):
 run(phase+'-node',[sys.executable,str(operator),phase,'node'])
for phase in ('policy-node','request-enrollment','wait-principal','enrollment-evidence'):
 run(phase,[sys.executable,str(operator),phase])
script('install_remaining')
for phase in ('policy-apps','delegate-signup','final-gate'):
 run(phase,[sys.executable,str(operator),phase])
script('scale_out')
script('watch_deployment')
script('fleet_probe')
env=dict(os.environ,DISPLAY=os.environ.get('DISPLAY',':1'),WAYLAND_DISPLAY=os.environ.get('WAYLAND_DISPLAY','wayland-1'))
for key in ['LD_LIBRARY_PATH','LD_PRELOAD']:env.pop(key,None)
run('desktop-acceptance',['node',str(out/'desktop-acceptance.mjs'),'01'],env=env)
script('purge_old_volumes')
(state/'PASSED.json').write_text(json.dumps({'passed':True,'release':'0.7.270','scope':'candidate network only','desktop':True,'physicalVR':False},indent=2)+'\n')
print('Candidate refound, fleet, desktop and obsolete volume purge passed.',flush=True)
