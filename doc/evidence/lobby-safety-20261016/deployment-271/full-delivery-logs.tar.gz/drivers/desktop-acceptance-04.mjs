import {chromium} from '../../lobby-toolkit-20260925/browser/node_modules/playwright/index.mjs'
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs'
import {dirname,join,resolve,basename} from 'node:path'
import {fileURLToPath} from 'node:url'
import assert from 'node:assert/strict'
import {readControl} from '../../../client/src/locomotion.js'
import {readTerm} from '../../../client/src/prolog-read.js'
import {createHash} from 'node:crypto'

process.umask(0o077)
const base=dirname(fileURLToPath(import.meta.url)),root=resolve(base,'../../..')
const label=process.argv[2]??'01';assert.match(label,/^[0-9]{2}$/)
assert.equal(JSON.parse(readFileSync(join(base,'refound/fleet-probe.json'))).passed,true)
const out=join(base,`desktop-${label}`);mkdirSync(out,{mode:0o700})
const profile=join(base,'desktop-01/browser')
const result={desktop:true,headless:true,physicalVR:false,requests:[],projections:[],samples:[],errors:[]}
const save=()=>{result.latest=latest;return writeFileSync(join(out,'observation.json'),JSON.stringify(result,null,2),{mode:0o600})}
const context=await chromium.launchPersistentContext(profile,{
  executablePath:'/home/yan/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome',
  headless:true,ignoreHTTPSErrors:true,viewport:{width:1280,height:960}})
const page=context.pages()[0]??await context.newPage();page.setDefaultTimeout(60000)
let latest=null,control=null
const observers=new Set()
page.on('pageerror',e=>{result.errors.push(e.message);save()})
page.on('request',r=>{const path=new URL(r.url()).pathname;if(path.startsWith('/api/'))result.requests.push(path)})
page.on('websocket',s=>s.on('framereceived',event=>{
  try {
    const m=JSON.parse(String(event.payload))
    if(m.type==='projection'){
      result.projections.push({selection:m.selection,marks:m.marks,control:m.control,frame:m.frame})
      if(m.selection==='active')control=readControl(m.control)
    }
    if(m.frame&&(m.type==='projection'||m.type==='simulation_frame')){
      latest=m.frame
      for(const f of [...observers])f(latest)
    }
  }catch(e){result.errors.push(String(e))}
}))
await page.route('**/__acceptance_client/*.js',route=>route.fulfill({contentType:'text/javascript',
  body:readFileSync(join(root,'client/src',basename(new URL(route.request().url()).pathname)),'utf8')}))
page.on('response',async response=>{
  if(new URL(response.url()).pathname==='/api/goals/control'){
    try{result.controlReplies??=[];result.controlReplies.push(await response.json())}catch{}
  }
})
const pendingControl=new Set(),idleObservers=new Set()
page.on('request',r=>{if(new URL(r.url()).pathname==='/api/goals/control')pendingControl.add(r)})
const finished=r=>{pendingControl.delete(r);if(!pendingControl.size)for(const f of [...idleObservers])f()}
page.on('requestfinished',finished);page.on('requestfailed',finished)
async function controlIdle(){
 if(!pendingControl.size)return
 await new Promise((resolve,reject)=>{
  const done=()=>{clearTimeout(timer);idleObservers.delete(done);resolve()}
  const timer=setTimeout(()=>{idleObservers.delete(done);reject(Error('Control reply still pending'))},10000)
  idleObservers.add(done)
 })
}
const writes=()=>result.requests.filter(p=>p==='/api/goals/execute').length
const pose=()=>latest?.poses.find(p=>p.body===control?.body)?.position
function waitFrame(test,timeout=30000){
  if(latest&&test(latest))return Promise.resolve(latest)
  return new Promise((resolve,reject)=>{
    const done=f=>{if(test(f)){clearTimeout(timer);observers.delete(done);resolve(f)}}
    const timer=setTimeout(()=>{observers.delete(done);reject(Error('Expected physical frame not received'))},timeout)
    observers.add(done)
  })
}
async function release(key){
  result.phase='release:'+key;save()
  const before=BigInt(latest.control_state.sequence)
  await page.keyboard.up(key)
  await waitFrame(f=>BigInt(f.control_state.sequence)>before)
  await controlIdle()
}
async function travel(key,test){
  result.phase='travel:'+key;save()
  if(test(pose()))return
  await page.keyboard.down(key)
  try{await waitFrame(()=>test(pose()))}finally{await release(key)}
}
async function hold(key,body){
  result.phase='contact:'+key+':'+body;save()
  const before=BigInt(latest.control_state.sequence)
  await page.keyboard.down(key)
  try{
    await waitFrame(f=>BigInt(f.control_state.sequence)>before&&f.control_state.result.startsWith('clipped(')&&f.control_state.result.includes(`contact(${body},`))
    result.contacts??=[];result.contacts.push({body,frame:latest});save()
  }finally{await release(key)}
}
function sample(name){const value={name,position:pose(),frame:latest};result.samples.push(value);save();return value}
async function ownerProbe(note=false){return page.evaluate(async(note)=>{
  const [{loadActiveKeyProvider},{authenticateKey,signedGoal},{accountReference},
    {readPersonalLobby,anchoredGoal},{readTerm}]=await Promise.all([
      import('/__acceptance_client/key-provider.js'),import('/__acceptance_client/signed-client.js'),
      import('/__acceptance_client/accounts.js'),import('/__acceptance_client/world.js'),
      import('/__acceptance_client/prolog-read.js')])
  const identity=await authenticateKey(await loadActiveKeyProvider()),account=accountReference(identity)
  const lobby=await readPersonalLobby(identity,account)
  const base="','(space_instance(personal_lobby,physical_space),','(physics_control(personal_lobby,Owner,Epoch,Binding),findall(definition(E,R,D),physics_definition(E,R,D),Definitions)))"
  const text=note?"','("+base+",desktop_acceptance(verified))":base
  const reply=await signedGoal(identity,{mode:'read',agent:account,goal:anchoredGoal(lobby.reference,readTerm(text))})
  return {account,lobby:lobby.reference,reply}
},note)}
async function jump(){
  result.phase='jump';save();await controlIdle()
  const before=BigInt(latest.control_state.sequence)
  const received=waitFrame(f=>BigInt(f.control_state.sequence)>before&&!f.control_state.pending&&f.control_state.result==='jumped',10000)
  await page.keyboard.press('Space')
  const frame=await received
  result.jumpFrames??=[];result.jumpFrames.push(frame);save()
  assert.equal(frame.control_state.result,'jumped')
}

try{
  await page.goto('https://192.168.1.10:30519/')
  await waitFrame(()=>control?.grounded&&pose(),120000)
  result.resumedFrom='desktop-01'
  assert.equal(writes(),0,'same completed account resumes without setup writes')
  result.journal=await page.evaluate(async()=>{
    const [{loadActiveKeyProvider},{authenticateKey,pendingSignedOperations}]=await Promise.all([
      import('/__acceptance_client/key-provider.js'),import('/__acceptance_client/signed-client.js')])
    return (await pendingSignedOperations(await authenticateKey(await loadActiveKeyProvider()))).length
  })
  assert.equal(result.journal,0,'no unresolved operation may be resubmitted')
  assert.equal(control.speed,2.5)
  assert.equal(control.jump,3000)
  result.owner=await ownerProbe();assert.equal(result.owner.reply.result,'ok')
  const original=JSON.parse(readFileSync(join(base,'desktop-01/observation.json')))
  assert.deepEqual(JSON.parse(JSON.stringify(result.owner.account)),original.owner.account)
  assert.deepEqual(JSON.parse(JSON.stringify(result.owner.lobby)),original.owner.lobby)
  const digest='766c7015b7281f6009838145a06ae8c8b61c37bfc6116be16aaeaba1d8b817ee'
  const asset=await page.request.get(`https://192.168.1.10:30519/assets/models/${digest}.glb`)
  assert.equal(asset.status(),200);const bytes=await asset.body()
  assert.equal(createHash('sha256').update(bytes).digest('hex'),digest)
  result.asset={digest,bytes:bytes.length}
  const oldAsset=await page.request.get('https://192.168.1.10:30519/assets/models/6520d8b8c35a72cf99cd061c05f6badda2aa8d357446b9856f247ab06d4eb07f.glb')
  result.oldAssetStatus=oldAsset.status();assert.equal(oldAsset.status(),200)
  await page.screenshot({path:join(out,'lobby.png'),fullPage:true})
  await page.locator('canvas').click({position:{x:1050,y:720}})
  await page.waitForFunction(()=>document.pointerLockElement!==null)
  await travel('ArrowUp',p=>p[2]<=0.15)
  await waitFrame(()=>pose()[1]>.18&&pose()[1]<.65)
  const glass=sample('glass-support'),baseY=glass.position[1]
  await page.screenshot({path:join(out,'glass.png'),fullPage:true})
  const startTick=BigInt(latest.tick);let peak=baseY
  const record=f=>{peak=Math.max(peak,f.poses.find(p=>p.body===control.body).position[1])};observers.add(record)
  await jump()
  await waitFrame(()=>pose()[1]>baseY+.2)
  result.phase='jump-landing';save()
  await waitFrame(f=>BigInt(f.tick)>startTick+30n&&pose()[1]<=baseY+.04)
  observers.delete(record);result.jump={baseY,peak,rise:peak-baseY,airJumpRefusalEvidence:"owner-tests"}
  assert.ok(peak-baseY>.35&&peak-baseY<.55)
  await page.screenshot({path:join(out,'jump-landed.png'),fullPage:true})
  await travel('ArrowUp',p=>p[2]<=-1.5)
  await controlIdle();await jump()
  await travel('ArrowUp',p=>p[2]<=-5)
  const flat=sample('flat-walk-start')
  await travel('ArrowUp',p=>p[2]<=-7)
  const flatEnd=sample('flat-walk-end')
  const seconds=Number(BigInt(flatEnd.frame.tick)-BigInt(flat.frame.tick))*0.016667
  result.speed={metresPerSecond:(flat.position[2]-flatEnd.position[2])/seconds,seconds}
  assert.ok(result.speed.metresPerSecond>2.1&&result.speed.metresPerSecond<2.8)
  await page.keyboard.down('ArrowUp')
  try{
    await waitFrame(f=>{
      if(!f.control_state.result.startsWith('clipped('))return false
      const answer=readTerm(f.control_state.result)
      return answer.args[1].items.some(c=>Number(c.args[1].args[2].value)>.5)
    })
  }finally{await release('ArrowUp')}
  const rim=sample('outer-rim-contact')
  assert.ok(rim.position[2]>-8.6&&rim.position[2]<-8&&rim.position[1]>.7)
  await page.screenshot({path:join(out,'rim.png'),fullPage:true})
  assert.equal(writes(),0,'resumed account, movement and jumps use no ledger writes')
  await page.evaluate(()=>document.exitPointerLock())
  await page.getByRole('button',{name:'Open console',exact:true}).click()
  await page.getByRole('region',{name:'Focused console',exact:true}).waitFor()
  await page.screenshot({path:join(out,'console.png'),fullPage:true})
  await page.getByRole('button',{name:'Return to lobby',exact:true}).click()
  const before=writes(),incarnation=latest.incarnation
  latest=null;control=null;await page.reload();await waitFrame(()=>control?.grounded&&pose())
  assert.equal(writes(),before,'reload performs no setup write or uncertain resubmission')
  assert.equal(latest.incarnation,incarnation,'reload retains physics owner')
  result.after=await ownerProbe();assert.deepEqual(result.after.account,result.owner.account)
  assert.deepEqual(result.after.lobby,result.owner.lobby);assert.equal(result.after.reply.result,'ok')
  assert.equal(result.errors.length,0)
  result.body=await page.locator('body').innerText();save()
  writeFileSync(join(out,'PASSED.json'),JSON.stringify({passed:true,desktop:true,headless:true,physicalVR:false,
    writes:writes(),initialSetupWrites:3,resumedFrom:'desktop-01',reloadWrites:0,glassSupport:true,rimContact:true,jump:true,airJumpRefusalOwnerTests:true,
    fasterWalk:true,ownerRead:true,console:true,sameIdentity:true,sameIncarnation:true}),{flag:'wx'})
  console.log('Desktop glass, rim, jump and walking acceptance passed')
}catch(e){
  result.failure=String(e);result.body=await page.locator('body').innerText().catch(()=>'<unavailable>');save()
  await page.screenshot({path:join(out,'failure.png')}).catch(()=>{})
  writeFileSync(join(out,'STOP.json'),JSON.stringify({error:String(e),noResubmission:true}),{flag:'wx'});throw e
}finally{await context.close()}
