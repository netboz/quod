from pathlib import Path
import json,subprocess,sys,time
out=Path(__file__).resolve().parent;state=out/'completion-01';state.mkdir()
acceptance=json.loads((out/'desktop-04/PASSED.json').read_text())
assert acceptance['passed'] and acceptance['glassSupport'] and acceptance['rimContact'] and acceptance['jump'] and acceptance['fasterWalk']
for name in ['fleet_probe_after_desktop','purge_old_volumes']:
 command=[sys.executable,str(out/(name+'.py'))]
 with (state/(name+'.intent.json')).open('x') as f:json.dump({'command':command},f)
 print('Starting '+name,flush=True);start=time.monotonic()
 with (state/(name+'.log')).open('x') as f:result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 row={'exit':result.returncode,'seconds':time.monotonic()-start}
 (state/(name+'.exit.json')).write_text(json.dumps(row,indent=2))
 print(json.dumps({'stage':name,**row}),flush=True)
 if result.returncode:
  (state/'STOP.json').write_text(json.dumps(row,indent=2));sys.exit(result.returncode)
(state/'PASSED.json').write_text(json.dumps({'passed':True,'release':'0.7.271','scope':'candidate network only','desktop':True,'physicalVR':False,'obsolete_candidate_volumes_deleted':8},indent=2)+'\n')
print('Candidate deployment and acceptance complete.',flush=True)
