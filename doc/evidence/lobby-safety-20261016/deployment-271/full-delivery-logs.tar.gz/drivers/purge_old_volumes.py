from pathlib import Path
import json,subprocess,time,urllib.request
out=Path(__file__).resolve().parent/'refound'
scope=json.loads((out/'scope.json').read_text());address='http://192.168.1.10:4646'
assert json.loads((out/'fleet-probe-after-desktop.json').read_text())['passed']
assert json.loads((out.parent/'desktop-04/PASSED.json').read_text())['passed']
def get(path):
 with urllib.request.urlopen(address+path,timeout=40) as response:return json.load(response)
def run(label,command):
 (out/(label+'.intent.json')).write_text(json.dumps({'command':command},indent=2))
 start=time.monotonic();r=subprocess.run(command,capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 (out/(label+'.exit.json')).write_text(json.dumps({'exit':r.returncode,'seconds':time.monotonic()-start},indent=2))
 assert r.returncode==0,(label,r.returncode)
 return r
candidate=get('/v1/job/'+scope['job']);main=get('/v1/job/quod')
assert candidate['Version']==scope['candidate_version']+2
assert main['Version']==scope['main_version'] and main['JobModifyIndex']==scope['main_modify_index']
for group in candidate['TaskGroups']:
 assert group['Volumes']['quod-data']['Source'] in [scope['new_family'],scope['new_family']+'-cloud']
old_allocations={a['ID'] for a in json.loads((out/'allocations-before.json').read_text())}
assert not [a for a in get('/v1/job/'+scope['job']+'/allocations?all=true') if a['ID'] in old_allocations and a['ClientStatus']=='running']
old_ids={row['id'] for row in scope['volumes']}
deleted = []
for row in scope['volumes']:
    current = json.loads(subprocess.check_output(
        ['nomad', 'volume', 'status', '-address=' + address,
         '-type=host', '-json'], text=True))
    exact = [v for v in current if v['ID'] == row['id']]
    assert len(exact) == 1 and exact[0]['Name'] == row['name']
    command = ['nomad', 'volume', 'delete', '-address=' + address,
               '-type=host', row['id']]
    result = run(f'delete-old-volume-{row["index"]}', command)
    deleted.append({'index': row['index'], 'id': row['id'], 'name': row['name'],
                    'stdout': result.stdout})
(out / 'old-volumes-deleted.json').write_text(json.dumps(deleted, indent=2) + '\n')
remaining = json.loads(subprocess.check_output(
    ['nomad', 'volume', 'status', '-address=' + address, '-type=host', '-json'],
    text=True))
assert not [v for v in remaining if v['ID'] in old_ids]
print(json.dumps({'old_candidate_volumes_deleted':len(deleted),'main_unchanged':True}))
