from pathlib import Path
import json,os,shutil,subprocess,sys,time
out=Path('/home/yan/src/quod/_build/lobby-safety-20261016/deployment-01')
state=out/'execution';state.mkdir()
def run(label,args,env=None):
 with (state/(label+'.intent.json')).open('x') as f: json.dump({'command':args},f,indent=2)
 print('Starting '+label,flush=True);start=time.monotonic()
 with (state/(label+'.log')).open('x') as log:
  result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'label':label,'command':args,'exit':result.returncode,'seconds':time.monotonic()-start}
 (state/(label+'.exit.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
 if result.returncode:
  (state/'STOP.json').write_text(json.dumps(row,indent=2)+'\n');raise SystemExit(result.returncode)
def script(label):run(label,[sys.executable,str(out/(label+'.py'))])
script('build')
script('prepare_refound')
refound=out/'refound'
script('create_new_volumes')
script('bootstrap')
operator=refound/'fresh_system_operator.py'
for phase in ('load','root-info'):
 run(phase,[sys.executable,str(operator),phase])
root=json.loads((refound/'root-info.json').read_text())['root_anchor']
assert len(root)==64 and root != 'CC6CD171CC07D771F5F44A8B6DD4FB04B16B104C456E09EE1B81C1D775C77F05', 'Invalid or retained prior root anchor'
for phase in ('found','publish'):
 run(phase+'-node',[sys.executable,str(operator),phase,'node'])
for phase in ('policy-node','request-enrollment','wait-principal','enrollment-evidence'):
 run(phase,[sys.executable,str(operator),phase])
script('install_remaining')
for phase in ('policy-apps','delegate-signup','final-gate'):
 run(phase,[sys.executable,str(operator),phase])
script('scale_out')
script('watch_deployment')
script('fleet_probe')
(state/'FLEET-PASSED.json').write_text(json.dumps({'passed':True,'release':'0.7.271','desktop':False},indent=2)+'\n')
print('Candidate fleet ready; desktop acceptance and obsolete-volume purge remain.',flush=True)
