import {chromium} from '../../lobby-toolkit-20260925/browser/node_modules/playwright/index.mjs'
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs'
import {dirname,join,resolve,basename} from 'node:path'
import {fileURLToPath} from 'node:url'
import assert from 'node:assert/strict'
import {readControl} from '../../../client/src/locomotion.js'

process.umask(0o077)
const base=dirname(fileURLToPath(import.meta.url)),root=resolve(base,'../../..')
const label=process.argv[2]??'09';assert.match(label,/^[0-9]{2}$/)
const out=join(base,'blue-fall-01');mkdirSync(out,{mode:0o700})
const profile='/home/yan/src/quod/_build/lobby-redesign-implementation-20261015/deployment-01/desktop-01/browser'
const result={desktop:true,headless:true,physicalVR:false,requests:[],projections:[],samples:[],errors:[]}
const save=()=>{result.latest=latest;return writeFileSync(join(out,'observation.json'),JSON.stringify(result,null,2),{mode:0o600})}
const context=await chromium.launchPersistentContext(profile,{
  executablePath:'/home/yan/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome',
  headless:true,ignoreHTTPSErrors:true,viewport:{width:1280,height:960}})
const page=context.pages()[0]??await context.newPage();page.setDefaultTimeout(60000)
let latest=null,control=null
const observers=new Set()
page.on('pageerror',e=>{result.errors.push(e.message);save()})
page.on('request',r=>{const path=new URL(r.url()).pathname;if(path.startsWith('/api/'))result.requests.push(path)})
page.on('websocket',s=>s.on('framereceived',event=>{
  try {
    const m=JSON.parse(String(event.payload))
    if(m.type==='projection'){
      result.projections.push({selection:m.selection,marks:m.marks,control:m.control,frame:m.frame})
      if(m.selection==='active')control=readControl(m.control)
    }
    if(m.frame&&(m.type==='projection'||m.type==='simulation_frame')){
      latest=m.frame
      for(const f of [...observers])f(latest)
    }
  }catch(e){result.errors.push(String(e))}
}))
await page.route('**/__acceptance_client/*.js',route=>route.fulfill({contentType:'text/javascript',
  body:readFileSync(join(root,'client/src',basename(new URL(route.request().url()).pathname)),'utf8')}))
page.on('response',async response=>{
  if(new URL(response.url()).pathname==='/api/goals/control'){
    try{result.controlReplies??=[];result.controlReplies.push(await response.json())}catch{}
  }
})
const writes=()=>result.requests.filter(p=>p==='/api/goals/execute').length
const pose=()=>latest?.poses.find(p=>p.body===control?.body)?.position
function waitFrame(test,timeout=30000){
  if(latest&&test(latest))return Promise.resolve(latest)
  return new Promise((resolve,reject)=>{
    const done=f=>{if(test(f)){clearTimeout(timer);observers.delete(done);resolve(f)}}
    const timer=setTimeout(()=>{observers.delete(done);reject(Error('Expected physical frame not received'))},timeout)
    observers.add(done)
  })
}
async function release(key){
  result.phase='release:'+key;save()
  const before=BigInt(latest.control_state.sequence)
  await page.keyboard.up(key)
  await waitFrame(f=>BigInt(f.control_state.sequence)>before)
}
async function travel(key,test){
  result.phase='travel:'+key;save()
  await page.keyboard.down(key)
  try{await waitFrame(()=>test(pose()))}finally{await release(key)}
}
async function hold(key,body){
  result.phase='contact:'+key+':'+body;save()
  const before=BigInt(latest.control_state.sequence)
  await page.keyboard.down(key)
  try{
    await waitFrame(f=>BigInt(f.control_state.sequence)>before&&f.control_state.result.startsWith('clipped(')&&f.control_state.result.includes(`contact(${body},`))
    result.contacts??=[];result.contacts.push({body,frame:latest});save()
  }finally{await release(key)}
}
function sample(name){const value={name,position:pose(),frame:latest};result.samples.push(value);save();return value}
async function ownerProbe(note=false){return page.evaluate(async(note)=>{
  const [{loadActiveKeyProvider},{authenticateKey,signedGoal},{accountReference},
    {readPersonalLobby,anchoredGoal},{readTerm}]=await Promise.all([
      import('/__acceptance_client/key-provider.js'),import('/__acceptance_client/signed-client.js'),
      import('/__acceptance_client/accounts.js'),import('/__acceptance_client/world.js'),
      import('/__acceptance_client/prolog-read.js')])
  const identity=await authenticateKey(await loadActiveKeyProvider()),account=accountReference(identity)
  const lobby=await readPersonalLobby(identity,account)
  const base="','(space_instance(personal_lobby,physical_space),','(physics_control(personal_lobby,Owner,Epoch,Binding),findall(definition(E,R,D),physics_definition(E,R,D),Definitions)))"
  const text=note?"','("+base+",desktop_acceptance(verified))":base
  const reply=await signedGoal(identity,{mode:'read',agent:account,goal:anchoredGoal(lobby.reference,readTerm(text))})
  return {account,lobby:lobby.reference,reply}
},note)}
async function restore(){
  const previous=latest.structure
  const reply=await page.evaluate(async({body,revision,structure})=>{
    const [{loadActiveKeyProvider},{authenticateKey,signedGoal,pendingSignedOperations},{accountReference},{readPersonalLobby,anchoredGoal},{readTerm}]=await Promise.all([
      import('/__acceptance_client/key-provider.js'),import('/__acceptance_client/signed-client.js'),import('/__acceptance_client/accounts.js'),import('/__acceptance_client/world.js'),import('/__acceptance_client/prolog-read.js')])
    const identity=await authenticateKey(await loadActiveKeyProvider()),account=accountReference(identity)
    if((await pendingSignedOperations(identity)).length)throw Error('Unresolved operation; no restore submitted')
    const lobby=await readPersonalLobby(identity,account)
    return signedGoal(identity,{mode:'execute',agent:account,goal:anchoredGoal(lobby.reference,readTerm(`physics_move_body(personal_lobby,${body},${revision},${structure},vector(0,760,2800))`))})
  },{body:control.body,revision:control.bodyRevision,structure:latest.structure})
  result.restores??=[];result.restores.push(reply);save();assert.equal(reply.result,'ok')
  await waitFrame(f=>f.structure!==previous&&pose()?.[1]>0.65&&pose()?.[1]<0.85)
}
try{
  await page.goto('https://192.168.1.10:30519/')
  await waitFrame(()=>control?.grounded&&pose())
  result.owner=await ownerProbe();assert.equal(result.owner.reply.result,'ok')
  await restore()
  latest=null;control=null;await page.reload();await waitFrame(()=>control?.grounded&&pose())
  await page.locator('canvas').click({position:{x:1050,y:720}})
  await page.waitForFunction(()=>document.pointerLockElement!==null)
  await page.keyboard.down('ArrowUp')
  await waitFrame(()=>pose()?.[1]<-45)
  await release('ArrowUp')
  result.fall=sample('outside-sky')
  result.body=await page.locator('body').innerText()
  await page.screenshot({path:join(out,'blue.png')})
  assert.equal(result.errors.length,0)
  assert.ok(result.projections.at(-1).selection==='active')
  assert.ok(Math.hypot(...result.fall.position)>40)
  await restore()
  result.restored=sample('restored')
  save();writeFileSync(join(out,'PASSED.json'),JSON.stringify({passed:true,activeWhileBlue:true,cameraOutsideFixedSky:true,errors:0,restored:true}),{flag:'wx'})
  console.log('Blue fall reproduced with active physics, no browser error; test avatar restored')
}catch(e){
  result.failure=String(e);result.body=await page.locator('body').innerText().catch(()=>'<unavailable>');save()
  await page.screenshot({path:join(out,'failure.png')}).catch(()=>{})
  writeFileSync(join(out,'STOP.json'),JSON.stringify({error:String(e),noResubmission:true}),{flag:'wx'});throw e
}finally{await context.close()}
