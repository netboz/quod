from pathlib import Path
import sys,json,hashlib,ssl,socket,urllib.request,urllib.parse,datetime
b=Path(__file__).resolve().parent;phase=sys.argv[1];assert phase in ('before','after')
origin='https://192.168.1.10:30519';ctx=ssl._create_unverified_context()
def get(path):
 with urllib.request.urlopen(origin+path,context=ctx,timeout=40) as r:return json.load(r)
def save(n,x):
 with (b/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
s=get('/explorer/api/summary');save('history-summary-'+phase+'.json',s)
if phase=='before':
 checks=[]
 for i,row in enumerate(s['namespaces']):
  if row.get('syncing') or row.get('applied',0)<1:continue
  ns=row['ns'];height=row['applied'];block=get('/explorer/api/block/'+urllib.parse.quote(ns,safe='')+'/'+str(height));name=f'history-tip-{i}-before.json';save(name,block)
  checks.append({'file':name,'namespace':ns,'height':height,'anchor':row['genesis'],'sha256':hashlib.sha256((b/name).read_bytes()).hexdigest()})
 save('history-before.json',{'captured':datetime.datetime.now(datetime.timezone.utc).isoformat(),'origin':origin,'blocks':checks,'read_only':True});print('Saved anchored current tips:',len(checks))
else:
 checks=[]
 for item in json.loads((b/'history-before.json').read_text())['blocks']:
  row=next(r for r in s['namespaces'] if r['ns']==item['namespace']);assert row['genesis']==item['anchor'] and row['applied']>=item['height'] and not row.get('syncing')
  assert hashlib.sha256((b/item['file']).read_bytes()).hexdigest()==item['sha256']
  block=get('/explorer/api/block/'+urllib.parse.quote(item['namespace'],safe='')+'/'+str(item['height']));assert block==json.loads((b/item['file']).read_text()),item['namespace']
  checks.append({'namespace':item['namespace'],'height':item['height'],'same_anchor':True,'same_committed_block':True,'applied':row['applied']})
 with socket.create_connection(('192.168.1.10',30519),timeout=20) as conn:
  with ctx.wrap_socket(conn,server_hostname='192.168.1.10') as tls:certificate=hashlib.sha256(tls.getpeercert(binary_form=True)).hexdigest()
 assert certificate==json.loads((b/'certificate-before.json').read_text())['sha256']
 save('history-after.json',{'passed':True,'read_only':True,'checks':checks,'same_certificate':True,'certificate_sha256':certificate});print('Verified unchanged anchored committed tips:',len(checks))
