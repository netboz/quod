"""One CAS image-only rolling update. Original submission is never repeated."""
from pathlib import Path
import json,hashlib,copy,datetime,time,urllib.request
b=Path(__file__).resolve().parent;gate=b.parent/'release-gates-02';job='quod-finality-candidate-v6-20260926';address='http://192.168.1.10:4646'
def save(n,x):
 with (b/n).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def req(path,data=None,timeout=40):
 q=urllib.request.Request(address+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(q,timeout=timeout) as r:return json.load(r),r.headers.get('X-Nomad-Index','0')
def get(path):return req(path)[0]
def boundary():
 for name in ['quod','quod27-client-30519']:
  current=get('/v1/job/'+name);prior=json.loads((b/(name+'-before.json')).read_text());assert (current['Version'],current['JobModifyIndex'])==(prior['Version'],prior['JobModifyIndex']),name
passed=json.loads((gate/'PASSED.json').read_text());assert passed['passed'] and len(passed['results'])==11 and all(r['exit']==0 and r['sources_unchanged'] for r in passed['results'])
assert json.loads((b.parent/'focused-03/exit.json').read_text())['exit']==0
review=json.loads((b.parent/'review-02/result.json').read_text());assert not review['is_error'] and '**Verdict: APPROVE**' in review['result']
assert json.loads((b.parent/'review-02/exit.json').read_text())['inputs_unchanged']
before=json.loads((b/(job+'-before.json')).read_text());assert get('/v1/job/'+job)['JobModifyIndex']==before['JobModifyIndex'];boundary()
image=json.loads((b/'verified-image.json').read_text())['pinned_image'];assert image.startswith('192.168.1.11:5000/quod:0.7.272@sha256:')
desired=copy.deepcopy(before);replaced=[]
for g in desired['TaskGroups']:
 for t in g['Tasks']:
  if t['Config'].get('image','').startswith('192.168.1.11:5000/quod:0.7.271@sha256:'):
   t['Config']['image']=image;replaced.append([g['Name'],t['Name']])
assert len(replaced)==5 and next(g for g in desired['TaskGroups'] if g['Name']=='quod-node')['Count']==8
save('desired-job.json',desired)
volumes=get('/v1/volumes?type=host');family=next(g for g in before['TaskGroups'] if g['Name']=='quod-node')['Volumes']['quod-data']['Source']
selected=[v for v in volumes if v['Name'].startswith(family+'[')];assert len(selected)==8;save('volumes-before.json',selected)
plan,_=req('/v1/job/'+job+'/plan',{'Job':desired,'Diff':True});save('plan.json',plan)
assert plan['JobModifyIndex']==before['JobModifyIndex'] and not plan.get('FailedTGAllocs') and not plan.get('Warnings')
updates=plan['Annotations']['DesiredTGUpdates']
for group,counts in updates.items():
 actual={k:v for k,v in counts.items() if v and k!='Ignore'}
 assert actual==({'DestructiveUpdate':1} if group=='quod-node' else {}),(group,actual)
 if group=='quod-node':
  assert counts['Ignore']==7
  assert next(g for g in desired['TaskGroups'] if g['Name']==group)['Update']['MaxParallel']==1
assert get('/v1/job/'+job)['JobModifyIndex']==before['JobModifyIndex'];boundary()
payload={'Job':desired,'EnforceIndex':True,'JobModifyIndex':before['JobModifyIndex']};save('request.json',payload)
save('intent.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'job':job,'expected_index':before['JobModifyIndex'],'expected_version':before['Version']+1,'request_sha256':hashlib.sha256((b/'request.json').read_bytes()).hexdigest(),'image_only':True,'preserve_volume_family':family,'replaced_images':replaced})
try:
 response,_=req('/v1/jobs',payload);save('submission.json',response)
except Exception as e:
 # Only inspect the original CAS identity; no repeat submission on lost reply.
 record={'error':type(e).__name__}
 try:
  current=get('/v1/job/'+job);record.update({'version':current['Version'],'index':current['JobModifyIndex']});save('uncertain-observed-job.json',current)
 except Exception as observed:record['observation_error']=type(observed).__name__
 save('UNCERTAIN.json',record);raise
current=get('/v1/job/'+job);save('job-after.json',current)
assert current['Version']==before['Version']+1 and current['JobModifyIndex']==response['JobModifyIndex']
confirm,_=req('/v1/job/'+job+'/plan',{'Job':desired,'Diff':True});save('plan-after.json',confirm);assert confirm['Diff']['Type']=='None'
deadline=time.monotonic()+1200;index='0';events=[]
while time.monotonic()<deadline:
 rows,index=req('/v1/job/'+job+'/deployments?index='+index+'&wait=30s',timeout=min(40,max(1,deadline-time.monotonic())))
 matches=[r for r in rows if r['JobVersion']==current['Version']];assert len(matches)<=1
 d=matches[0] if matches else {'Status':'pending'};events.append(d);(b/'deployment-events.json').write_text(json.dumps(events,indent=2))
 print(json.dumps({'version':current['Version'],'deployment':d.get('ID'),'status':d['Status'],'groups':d.get('TaskGroups')}),flush=True)
 assert d['Status'] not in ['failed','blocked','cancelled'],d
 if d['Status']=='successful':
  assert d['TaskGroups']['quod-node']['HealthyAllocs']==8;boundary();save('deployment-success.json',d);break
else:raise RuntimeError('Original deployment did not complete within its deadline')
after=[v for v in get('/v1/volumes?type=host') if v['Name'].startswith(family+'[')]
assert {(v['ID'],v['Name'],v['NodeID']) for v in after}=={(v['ID'],v['Name'],v['NodeID']) for v in selected}
save('volumes-after.json',after);save('PASSED.json',{'passed':True,'image':image,'job_version':current['Version'],'job_modify_index':current['JobModifyIndex'],'same_eight_volumes':True,'no_refound':True,'main_and_ingress_unchanged':True})
