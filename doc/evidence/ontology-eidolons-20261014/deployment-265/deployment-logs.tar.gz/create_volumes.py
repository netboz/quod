from pathlib import Path
import json,subprocess,time,urllib.request
b=Path(__file__).resolve().parent;s=json.loads((b/'scope.json').read_text());assert json.loads((b/'maintenance/PASSED.json').read_text())['passed']
rows=[]
for i in range(8):
 p=b/'volumes'/f'{i}.hcl';assert p.is_file();intent=b/f'volume-{i}.intent.json'
 with intent.open('x') as f:json.dump({'index':i,'file':str(p),'retries':0},f)
 r=subprocess.run(['nomad','volume','create','-address=http://192.168.1.10:4646',str(p)],capture_output=True,text=True)
 rows.append({'index':i,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(b/'volume-create-results.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert r.returncode==0,rows[-1]
with urllib.request.urlopen('http://192.168.1.10:4646/v1/volumes?type=host',timeout=30) as r:v=json.load(r)
new=[x for x in v if x['Name'].startswith(s['new_family']+'[')];old=[x for x in v if x['Name'].startswith(s['old_family']+'[')]
assert len(new)==8 and all(x['State']=='ready' for x in new);assert len(old)==8
(b/'volumes-created.json').write_text(json.dumps(new,indent=2)+'\n');print(json.dumps({'created':8,'old_retained':8}))
