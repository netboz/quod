from pathlib import Path
import base64,json,subprocess,time,urllib.request,sys
b=Path(__file__).resolve().parent;s=json.loads((b/'scope.json').read_text());label=sys.argv[1] if len(sys.argv)>1 else 'before-restart'
def get(path):
 with urllib.request.urlopen('http://192.168.1.10:4646'+path,timeout=40) as r:return json.load(r)
j=get('/v1/job/'+s['job']);main=get('/v1/job/quod');ingress=get('/v1/job/quod27-client-30519');phase=json.loads((b/'join-02/PASSED.json').read_text())
assert (j['Version'],j['JobModifyIndex'])==(phase['version'],phase['index']);assert (main['Version'],main['JobModifyIndex'])==(246,826727);assert ingress==json.loads((b/'ingress-before.json').read_text())
allocs=sorted([a for a in get('/v1/job/'+s['job']+'/allocations') if a['DesiredStatus']=='run' and a['ClientStatus']=='running'],key=lambda a:a['Name']);assert len(allocs)==8
root=json.loads((b/'root-info.json').read_text())['root_anchor'];image=json.loads((b/'verified-image.json').read_text())['pinned_image'];assert j['TaskGroups'][0]['Volumes']['quod-data']['Source']==s['new_family']
assert all(t.get('Config',{}).get('image')==image for g in j['TaskGroups'] for t in g['Tasks'] if t.get('Config',{}).get('image','').startswith('192.168.1.11:5000/quod:'))
expr=(b/'fleet-expression.txt').read_text().strip();encoded='binary_to_list(base64:encode(iolist_to_binary(json:encode(begin '+expr+' end)))).';rows=[]
for a in allocs:
 cmd=['nomad','alloc','exec','-i=false','-t=false','-address=http://192.168.1.10:4646','-task','quod',a['ID'],'/opt/quod/bin/quod','eval',encoded]
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=90);row={'allocation':a['ID'],'name':a['Name'],'node':a['NodeName'],'exit':r.returncode,'restarts':a['TaskStates']['quod']['Restarts'],'stdout':r.stdout,'stderr':r.stderr};rows.append(row)
 if r.returncode==0:
  wire=json.loads(r.stdout);wire=bytes(wire).decode() if isinstance(wire,list) else wire;row['probe']=json.loads(base64.b64decode(wire,validate=True))
 (b/('fleet-'+label+'.json')).write_text(json.dumps({'passed':False,'allocations':rows},indent=2)+'\n');assert r.returncode==0
 p=row['probe'];assert p['version']=='0.7.265' and p['root_anchor']==root and p['root_state']=='ready';assert p['root_committed']==p['root_applied'];assert p['catalogue_count']==18 and p['rejected_count']==0 and p['not_ready']==[];assert p['manager']['node_enrollment']=='complete';assert p['principal']['status']=='available' and p['principal']['pointer']=='stored' and p['principal']['self_hosting']=='committed';assert p['outcome_formats']==[9];assert p['vault_ready'] and p['vault_provider_disabled'];assert p['custody_limits']=={'count':64,'prepared_bytes':'unlimited'}
 assert row['restarts']==(1 if label=='after-restart' and a['Name'].endswith('[0]') else 0)
 print(json.dumps({'name':a['Name'],'version':p['version'],'ready':True,'root':root,'restarts':row['restarts']}),flush=True)
volumes=get('/v1/volumes?type=host');assert len([v for v in volumes if v['Name'].startswith(s['old_family']+'[')])==8
record={'passed':True,'job_version':j['Version'],'job_modify_index':j['JobModifyIndex'],'root_anchor':root,'allocations':rows,'old_volumes_retained':8,'main_unchanged':True,'ingress_unchanged':True};(b/('fleet-'+label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
if label=='before-restart':
 (b/'founder-allocation.json').write_text(json.dumps(allocs[0],indent=2)+'\n');(b/'client-endpoint.json').write_text(json.dumps({'origin':s['origin'],'root_anchor':root,'allocation':allocs[0]['ID']},indent=2)+'\n')
