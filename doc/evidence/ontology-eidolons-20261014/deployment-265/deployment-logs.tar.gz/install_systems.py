from pathlib import Path
import subprocess,sys,json,time
b=Path(__file__).resolve().parent;op=b/'run_operation.py';steps=[['fresh_system_operator','root-info'],['fresh_system_operator','found','node'],['fresh_system_operator','publish','node'],['fresh_system_operator','policy-node'],['fresh_system_operator','wait-principal'],['fresh_system_operator','enrollment-evidence'],['install_remaining'],['fresh_system_operator','policy-apps'],['fresh_system_operator','delegate-signup'],['fresh_system_operator','final-gate']]
completed=[]
with (b/'install-system-sequence.intent.json').open('x') as f:json.dump({'steps':steps,'retries':0},f,indent=2)
for args in steps:
 print('Running '+ ' '.join(args),flush=True);r=subprocess.run([sys.executable,str(op),*args])
 completed.append({'args':args,'exit':r.returncode});(b/'install-system-sequence.results.json').write_text(json.dumps(completed,indent=2)+'\n')
 if r.returncode:sys.exit(r.returncode)
print('All system installation steps completed',flush=True)
