from pathlib import Path
import json,subprocess,time,urllib.request,base64
b=Path(__file__).resolve().parent;s=json.loads((b/'scope.json').read_text());ep=json.loads((b/'client-endpoint.json').read_text());allocation=ep['allocation'];o=b/'gateway-restart';o.mkdir()
def get(path):
 with urllib.request.urlopen('http://192.168.1.10:4646'+path,timeout=40) as r:return json.load(r),r.headers.get('X-Nomad-Index','0')
def check():
 j,_=get('/v1/job/'+s['job']);m,_=get('/v1/job/quod');i,_=get('/v1/job/quod27-client-30519');p=json.loads((b/'join-02/PASSED.json').read_text());assert (j['Version'],j['JobModifyIndex'])==(p['version'],p['index']);assert (m['Version'],m['JobModifyIndex'])==(246,826727);assert i==json.loads((b/'ingress-before.json').read_text())
check();before,index=get('/v1/allocation/'+allocation);assert before['TaskStates']['quod']['Restarts']==0;(o/'allocation-before.json').write_text(json.dumps(before,indent=2)+'\n');command=['nomad','alloc','restart','-address=http://192.168.1.10:4646','-task','quod',allocation]
(o/'intent.json').write_text(json.dumps({'allocation':allocation,'command':command,'retries':0,'purpose':'same-ledger recovery verification'},indent=2)+'\n');r=subprocess.run(command,capture_output=True,text=True);(o/'command.stdout').write_text(r.stdout);(o/'command.stderr').write_text(r.stderr);(o/'command-exit.json').write_text(json.dumps({'exit':r.returncode})+'\n');assert r.returncode==0
start=before['TaskStates']['quod']['StartedAt'];deadline=time.monotonic()+300;events=[]
while time.monotonic()<deadline:
 a,index=get('/v1/allocation/'+allocation+'?index='+index+'&wait=30s');t=a['TaskStates']['quod'];events.append({'state':t['State'],'restarts':t['Restarts'],'started':t['StartedAt']});(o/'events.json').write_text(json.dumps(events,indent=2)+'\n')
 assert not t.get('Failed')
 if t['State']=='running' and t['Restarts']==1 and t['StartedAt']!=start:break
else:raise RuntimeError('Original restart did not finish by its absolute deadline')
# Subscribe before inspecting the real runtime snapshot; wait only for owner notices.
expr='Ns=<<"quod:root">>,true=quod_reg:subscribe({runtime,Ns}),Deadline=quod_time:mono_ms()+60000,Wait=fun F()->case quod_ontology:local_state(Ns) of {ok,ready}->ok; _->receive _->F() after max(0,Deadline-quod_time:mono_ms())->error(root_readiness_timeout) end end end,ok=Wait(),quod_reg:unsubscribe({runtime,Ns}),#{ready=>true,root=>binary:encode_hex(quod_simplex:genesis_hash(Ns)),helper_loaded=>code:is_loaded(quod_fresh_systems)=/=false}'
encoded='binary_to_list(base64:encode(iolist_to_binary(json:encode(begin '+expr+' end)))).';cmd=['nomad','alloc','exec','-i=false','-t=false','-address=http://192.168.1.10:4646','-task','quod',allocation,'/opt/quod/bin/quod','eval',encoded]
r=subprocess.run(cmd,capture_output=True,text=True,timeout=90);(o/'readiness.stdout').write_text(r.stdout);(o/'readiness.stderr').write_text(r.stderr);assert r.returncode==0
wire=json.loads(r.stdout);wire=bytes(wire).decode() if isinstance(wire,list) else wire;v=json.loads(base64.b64decode(wire));assert v['ready'] and v['root']==ep['root_anchor'] and not v['helper_loaded'];check();(o/'PASSED.json').write_text(json.dumps({'passed':True,'allocation':allocation,'task_restarts':1,'same_root':True,'temporary_helper_unloaded':True,'readiness':v},indent=2)+'\n');print(json.dumps(v))
