import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFile, writeFile } from 'node:fs/promises'
import { createKeyProvider, fromB64url } from '/home/yan/src/quod/client/src/key-provider.js'
import { authenticateKey, readSystemOntologies, signedGoal } from '/home/yan/src/quod/client/src/signed-client.js'
import { readCodeState, readCodeSource } from '/home/yan/src/quod/client/src/prolog-edit.js'
import { ontologySubject, readEntityEidolons, readEidolon, readTextProjection, anchoredGoal, codeForm } from '/home/yan/src/quod/client/src/world.js'
import { compound, binary, variable, atom, renderTerm, number } from '/home/yan/src/quod/client/src/prolog-term.js'
const out = '/home/yan/src/quod/_build/ontology-eidolons-20261014/deployment-01'
const label = process.argv[2]
assert(['before-restart', 'after-restart'].includes(label))
const endpoint = JSON.parse(await readFile(out + '/client-endpoint.json', 'utf8'))
const nativeFetch = globalThis.fetch
let executeRequests = 0
globalThis.fetch = (url, options) => {
  if (options?.body && typeof options.body === 'string') {
    try { if (JSON.parse(options.body).mode === 'execute') executeRequests++ } catch {}
  }
  return nativeFetch(new URL(url, endpoint.origin), options)
}
const provider = await createKeyProvider()
const identity = await authenticateKey(provider)
assert.equal(Buffer.from(identity.networkId).toString('hex').toUpperCase(), endpoint.root_anchor)
const catalogue = await readSystemOntologies(identity)
assert.equal(catalogue.length, 18)
const ref = namespace => {
  const row = catalogue.find(r => r.namespace === namespace)
  assert(row, namespace)
  return { namespace, anchor: fromB64url(row.anchor) }
}
const agent = { ...ref('quod:signup'), instanceText: renderTerm(compound('signup', [binary(provider.publicKey)])) + '.' }
const tools = ref('quod:prolog')
const results = []
for (const row of catalogue.filter(r => r.namespace !== 'quod:signup')) {
  const target = ref(row.namespace), subject = ontologySubject(target)
  const choices = await readEntityEidolons(identity, agent, subject)
  const chosen = style => { const c = choices.filter(x => x.style === style); assert.equal(c.length, 1, row.namespace + ':' + style); return c[0] }
  const sourceView = await readEidolon(identity, agent, subject, chosen('source'))
  assert.equal(sourceView.kind, 'workspace')
  assert.equal(codeForm(sourceView.workspace.view).editable, false)
  const source = await readCodeState(identity, agent, sourceView.workspace)
  assert(source.includes('can_invoke(') && source.includes('isa('))
  assert(!source.includes('ontology_eidolons('), row.namespace)
  const policy = await readCodeSource(identity, agent, sourceView.workspace, compound('/', [atom('can_invoke'), number(4)]))
  assert(source.includes(policy))
  const projections = {}
  for (const style of ['policy', 'interfaces', 'routes']) {
    const lens = await readEidolon(identity, agent, subject, chosen(style))
    assert.equal(lens.kind, 'lens')
    assert.equal(lens.target.namespace, row.namespace)
    assert.deepEqual(lens.target.anchor, target.anchor)
    const text = await readTextProjection(identity, agent, lens.lens,
      compound('view', [binary(new TextEncoder().encode(lens.view)), lens.parameters, variable('View')]), 'View')
    if (style === 'policy') assert(text.includes('can_invoke('))
    if (style === 'routes') assert(text.includes('route_status('))
    projections[style] = { bytes: Buffer.byteLength(text), sha256: createHash('sha256').update(text).digest('hex') }
  }
  results.push({ namespace: row.namespace, anchor: row.anchor, sourceBytes: Buffer.byteLength(source), sourceSha256: createHash('sha256').update(source).digest('hex'), readOnly: true, projections })
}
const node = { tools, target: ref('quod:node') }
const repeated = await readCodeState(identity, agent, node)
assert.equal(repeated, await readCodeState(identity, agent, node))
await assert.rejects(readCodeState(identity, agent, { ...node, target: { namespace: 'quod:node', anchor: new Uint8Array(32) } }))
const root = { namespace: 'quod:root', anchor: identity.networkId }
await assert.rejects(readCodeState(identity, agent, { tools, target: root }))
const privateChoices = await readEntityEidolons(identity, agent, ontologySubject(node.target))
for (const c of privateChoices) await assert.rejects(readEidolon(identity, agent, ontologySubject(root), c))
const invocation = await signedGoal(identity, { mode: 'read', agent, goal: anchoredGoal(node.target, compound('node_identity_template', [variable('Template')])) })
assert.equal(invocation.result, 'fail')
assert.equal(executeRequests, 0)
if (label === 'after-restart') {
  const earlier = JSON.parse(await readFile(out + '/signed-inspection-before-restart.json', 'utf8'))
  assert.deepEqual(results.map(x => [x.namespace, x.anchor, x.sourceSha256, x.projections.policy.sha256, x.projections.interfaces.sha256]), earlier.targets.map(x => [x.namespace, x.anchor, x.sourceSha256, x.projections.policy.sha256, x.projections.interfaces.sha256]))
}
const answer = { passed: true, origin: endpoint.origin, root_anchor: endpoint.root_anchor, principal: 'authenticated signup applicant; no administrator grant', targets: results, ordinaryEidolonSelection: true, exactTargets: true, unchangedSourceRepeat: true, wrongAnchorDenied: true, privateRootDenied: true, privateRecipesDenied: true, policyInvocationDenied: true, executeRequests, completeSourceAndLenses: true, recoverySourceHashesMatch: label === 'after-restart' }
await writeFile(out + '/signed-inspection-' + label + '.json', JSON.stringify(answer, null, 2) + '\n', { flag: 'wx' })
console.log(JSON.stringify({ passed: true, label, targets: results.length, executeRequests }))
