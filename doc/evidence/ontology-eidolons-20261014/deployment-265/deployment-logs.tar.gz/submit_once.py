"""One recorded indexed Nomad change; uncertain results are observed, never retried."""
from pathlib import Path
import json,sys,time,hashlib,datetime,urllib.request
b=Path(__file__).resolve().parent;s=json.loads((b/'scope.json').read_text());phase=sys.argv[1]
def req(path,data=None,timeout=40):
 q=urllib.request.Request('http://192.168.1.10:4646'+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(q,timeout=timeout) as r:return json.load(r),r.headers.get('X-Nomad-Index','0')
def matches(current,expected):
 fields={'CreateIndex','ModifyIndex','JobModifyIndex','Version','SubmitTime','Status','StatusDescription','Stable'}
 assert (current['Version'],current['JobModifyIndex'])==(expected['Version'],expected['JobModifyIndex'])
 assert {k:v for k,v in current.items() if k not in fields}=={k:v for k,v in expected.items() if k not in fields}
def invariant():
 m,_=req('/v1/job/quod');i,_=req('/v1/job/quod27-client-30519')
 assert (m['Version'],m['JobModifyIndex'])==(s['main_version'],s['main_modify_index'])
 assert i==json.loads((b/'ingress-before.json').read_text())
def save(name,obj):
 with (out/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
assert json.loads((b.parent/'release-265-gates-01/PASSED.json').read_text())['passed']
assert json.loads((b/'verified-image.json').read_text())['registry_digest_matches']
phases={'maintenance':('candidate-maintenance.json','candidate-before.json'),
 'founder':('candidate-founder.json','maintenance/job-after.json'),
 'seal':('candidate-seal.json','founder/job-after.json'),
 'join-02':('candidate-join.json','seal/job-after.json')}
name,prior=phases[phase];desired=json.loads((b/name).read_text());expected=json.loads((b/prior).read_text());out=b/phase;out.mkdir()
invariant();current,_=req('/v1/job/'+s['job']);matches(current,expected)
plan,_=req('/v1/job/'+s['job']+'/plan',{'Job':desired,'Diff':True});save('plan.json',plan)
assert plan['JobModifyIndex']==expected['JobModifyIndex'] and not plan.get('FailedTGAllocs') and not plan.get('Warnings')
updates={g:{k:v for k,v in c.items() if v and k!='Ignore'} for g,c in plan['Annotations']['DesiredTGUpdates'].items()}
if phase=='maintenance':assert updates.get('quod-node')=={'Stop':8},updates
if phase=='founder':assert updates.get('quod-node')=={'Place':1},updates
if phase=='seal':assert updates.get('quod-node')=={'Stop':1},updates
if phase=='join-02':assert updates.get('quod-node')=={'Place':8},updates
invariant();current,_=req('/v1/job/'+s['job']);matches(current,expected)
payload={'Job':desired,'EnforceIndex':True,'JobModifyIndex':expected['JobModifyIndex']};save('request.json',payload)
save('intent.json',{'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':phase,'request_sha256':hashlib.sha256((out/'request.json').read_bytes()).hexdigest(),'expected_version':expected['Version']+1})
try:r,_=req('/v1/jobs',payload);save('submission.json',r)
except Exception as error:
 observation={'error_type':type(error).__name__}
 try:c,_=req('/v1/job/'+s['job']);observation.update(version=c['Version'],index=c['JobModifyIndex'])
 except Exception as e:observation['observation_error_type']=type(e).__name__
 save('UNCERTAIN.json',observation);raise
current,_=req('/v1/job/'+s['job']);save('job-after.json',current)
assert current['Version']==expected['Version']+1 and current['JobModifyIndex']==r['JobModifyIndex']
p,_=req('/v1/job/'+s['job']+'/plan',{'Job':desired,'Diff':True});save('plan-after.json',p)
assert p['Diff']['Type']=='None' and not p.get('FailedTGAllocs') and not p.get('Warnings')
print(json.dumps({'phase':phase,'version':current['Version'],'index':current['JobModifyIndex'],'evaluation':r['EvalID']}),flush=True)
index='0';deadline=time.monotonic()+1200;events=[]
while time.monotonic()<deadline:
 if phase in ('maintenance','seal'):
  rows,index=req('/v1/job/'+s['job']+'/allocations?all=true&index='+index+'&wait=30s')
  required={a['ID'] for a in json.loads((b/'allocations-before.json').read_text()) if a['DesiredStatus']=='run' and a['ClientStatus']=='running'} if phase=='maintenance' else {json.loads((b/'founder-allocation.json').read_text())['ID']}
  selected=[a for a in rows if a['ID'] in required];assert len(selected)==len(required)
  active=[a for a in selected if a['DesiredStatus']!='stop' or a['ClientStatus'] not in ('complete','failed')]
  state={'remaining':len(active)};done=not active
 else:
  rows,index=req('/v1/job/'+s['job']+'/deployments?all=true&index='+index+'&wait=30s');selected=[d for d in rows if d['JobVersion']==current['Version']];assert len(selected)<=1
  state=selected[0] if selected else {'Status':'awaiting'};assert state['Status'] not in ('failed','cancelled','blocked'),state
  done=state['Status']=='successful'
 events.append(state);(out/'events.json').write_text(json.dumps(events,indent=2)+'\n');print(json.dumps({'phase':phase,'status':state.get('Status'),'remaining':state.get('remaining')}),flush=True)
 if done:
  invariant();save('PASSED.json',{'passed':True,'version':current['Version'],'index':current['JobModifyIndex'],'state':state,'main_and_ingress_unchanged':True});break
else:raise RuntimeError('Original change did not complete by its absolute deadline')
