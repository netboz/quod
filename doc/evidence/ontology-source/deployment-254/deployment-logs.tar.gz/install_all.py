from pathlib import Path
import subprocess,json,time,sys
out=Path('/tmp/quod-source-refound-254');op=out/'fresh_system_operator.py';start=time.monotonic()
phases=[['load'],['root-info'],['found','node'],['publish','node'],['policy-node'],['request-enrollment'],['enrollment-evidence']]
names=['agent','environment','environment:eidolons','gui','human_user','lens','licence','measure','material','material:eidolons','rendering','modelling','names','prolog','prolog:eidolons','lobby','signup']
for n in names:phases.extend([['found',n],['publish',n]])
phases.extend([['policy-apps'],['delegate-signup'],['final-gate']])
(out/'install-all.intent.json').write_text(json.dumps({'phases':phases,'retries':0,'procedure':'existing reviewed clean-refound founding actions'},indent=2)+'\n')
completed=[]
for phase in phases:
 print(' '.join(phase),flush=True)
 r=subprocess.run([sys.executable,str(op),*phase])
 if r.returncode:
  (out/'install-all.STOP.json').write_text(json.dumps({'phase':phase,'exit':r.returncode,'completed':completed,'seconds':time.monotonic()-start},indent=2)+'\n');sys.exit(r.returncode)
 completed.append(phase)
(out/'install-all.complete.json').write_text(json.dumps({'completed':completed,'seconds':time.monotonic()-start},indent=2)+'\n')
