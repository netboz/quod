from pathlib import Path
import urllib.request,json,subprocess,time,sys
out=Path('/tmp/quod-source-refound-254');base='http://192.168.1.10:4646';job='quod-finality-candidate-v6-20260926'
def get(path,index=None):
 q='?index='+str(index)+'&wait=30s' if index is not None else ''
 with urllib.request.urlopen(base+path+q,timeout=40) as r:return json.load(r),r.headers.get('X-Nomad-Index','0')
def save(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
mode=sys.argv[1]
if mode=='restart':
 allocs,_=get('/v1/job/'+job+'/allocations');a=next(a for a in allocs if a['DesiredStatus']=='run' and a['ClientStatus']=='running' and a['Name'].endswith('quod-node[0]'))
 before,_=get('/v1/allocation/'+a['ID']);save('recovery-before-allocation.json',before)
 cmd=['nomad','alloc','restart','-address='+base,'-task','quod',a['ID']];save('recovery-restart.intent.json',{'command':cmd})
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True)
 (out/'recovery-restart.stdout').write_text(r.stdout);(out/'recovery-restart.stderr').write_text(r.stderr)
 save('recovery-restart.exit.json',{'exit':r.returncode,'seconds':time.monotonic()-start});r.check_returncode();print('Restarted candidate gateway task.')
elif mode=='watch':
 before=json.loads((out/'recovery-before-allocation.json').read_text());index=0;deadline=time.monotonic()+300
 with (out/'recovery-allocation-events.jsonl').open('x') as f:
  while time.monotonic()<deadline:
   a,index=get('/v1/allocation/'+before['ID'],index);f.write(json.dumps(a)+'\n');f.flush();t=a['TaskStates']['quod']
   if t['State']=='running' and t['StartedAt']!=before['TaskStates']['quod']['StartedAt']:
    save('recovery-restarted-allocation.json',a);print('New task incarnation is running.');break
   if a['ClientStatus']=='failed':raise RuntimeError('Restart failed')
  else:raise RuntimeError('Restart deadline exceeded')
