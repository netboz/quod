from pathlib import Path
import copy,json,subprocess,urllib.request,time,sys,re
out=Path('/tmp/quod-source-refound-254');base='http://192.168.1.10:4646';job='quod-finality-candidate-v6-20260926';family=job+'-refound-20261007-v2'
def get(path,index=None):
 q=('&' if '?' in path else '?')+'index='+str(index)+'&wait=30s' if index is not None else ''
 with urllib.request.urlopen(base+path+q,timeout=40) as r:return json.load(r),r.headers.get('X-Nomad-Index','0')
def save(name,v):
 with (out/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def run(label,cmd):
 save(label+'.intent.json',{'command':cmd});start=time.monotonic()
 r=subprocess.run(cmd,capture_output=True,text=True)
 (out/(label+'.stdout')).write_text(r.stdout);(out/(label+'.stderr')).write_text(r.stderr)
 save(label+'.exit.json',{'exit':r.returncode,'seconds':time.monotonic()-start})
 print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 return r.stdout
mode=sys.argv[1]
if mode=='prepare':
 before=json.loads((out/'candidate-before.json').read_text());live,_=get('/v1/job/'+job)
 assert live['JobModifyIndex']==before['JobModifyIndex']
 assert {g['Name']:g['Count'] for g in live['TaskGroups']}=={'quod-node':8,'quod-cloud':0}
 stopped=copy.deepcopy(live)
 for g in stopped['TaskGroups']:g['Count']=0
 save('stop-job.json',{'Job':stopped})
 volumes=json.loads((out/'volumes-before.json').read_text());selected=[v for v in volumes if v.get('Name','').startswith(family+'[')]
 assert len(selected)==8
 assert {v['Name'] for v in selected}=={family+'['+str(i)+']' for i in range(8)}
 nodes=json.loads((out/'nodes-before.json').read_text());ready={v['ID'] for v in nodes if v['Status']=='ready'}
 assert all(v['NodeID'] in ready for v in selected)
 save('purge-scope.json',{'job':job,'family':family,'volumes':selected,'main_job_excluded':'quod'})
 template=Path('/home/yan/src/quod/deploy/volumes/quod-node-local.hcl').read_text()
 for v in selected:
  index=re.search(r'\[(\d+)\]$',v['Name']).group(1)
  text=template.replace('quod-node-local[0]',v['Name']).replace('__COMPUTE_NODE_ID__',v['NodeID'])
  (out/'volumes'/f'{index}.hcl').write_text(text)
 source=Path('/home/yan/src/quod/doc/evidence/refound-20261007/candidate-refound.nomad')
 (out/'candidate-refound.nomad').write_bytes(source.read_bytes())
 print('Prepared exact purge scope: eight candidate volumes.')
elif mode=='stop':
 assert json.loads((out/'verified-image.json').read_text())['explorer_matches']
 live,_=get('/v1/job/'+job);before=json.loads((out/'candidate-before.json').read_text());assert live['JobModifyIndex']==before['JobModifyIndex']
 run('stop-job',['nomad','job','run','-address='+base,'-json','-detach','-check-index='+str(live['JobModifyIndex']),str(out/'stop-job.json')])
elif mode=='wait-stopped':
 index=0;deadline=time.monotonic()+300
 with (out/'stop-allocation-events.jsonl').open('x') as f:
  while time.monotonic()<deadline:
   allocs,index=get('/v1/job/'+job+'/allocations',index);f.write(json.dumps(allocs)+'\n');f.flush()
   active=[a for a in allocs if a['ClientStatus'] in ['pending','running']]
   print('Active candidate allocations:',len(active),flush=True)
   if not active:save('all-stopped.json',{'active':0});break
  else:raise RuntimeError('Candidate stop deadline exceeded')
elif mode=='purge':
 assert json.loads((out/'all-stopped.json').read_text())['active']==0
 current,_=get('/v1/job/'+job+'/allocations');assert not [a for a in current if a['ClientStatus'] in ['pending','running']]
 scope=json.loads((out/'purge-scope.json').read_text());ids=[]
 for v in sorted(scope['volumes'],key=lambda v:v['Name']):
  fresh,_=get('/v1/volume/host/'+v['ID']);assert fresh['Name']==v['Name'] and fresh['NodeID']==v['NodeID']
  run('delete-volume-'+v['Name'].rsplit('[',1)[1].rstrip(']'),['nomad','volume','delete','-address='+base,'-type=host',v['ID']]);ids.append(v['ID'])
 save('purge-complete.json',{'deleted_ids':ids,'count':len(ids)})
elif mode=='create-volumes':
 assert json.loads((out/'purge-complete.json').read_text())['count']==8
 for i in range(8):run('create-volume-'+str(i),['nomad','volume','create','-address='+base,str(out/'volumes'/f'{i}.hcl')])
elif mode in ['bootstrap','scale-out']:
 image=json.loads((out/'verified-image.json').read_text())['pinned_image'].split('quod:',1)[1]
 live,_=get('/v1/job/'+job)
 args=['nomad','job','run','-address='+base,'-detach','-check-index='+str(live['JobModifyIndex']),'-var=image_tag='+image,'-var=cloud_node_count=0']
 if mode=='bootstrap':args+=['-var=bootstrap=true','-var=genesis_hash=']
 else:
  anchor=json.loads((out/'root-info.json').read_text())['root_anchor'];assert re.fullmatch('[0-9A-F]{64}',anchor)
  args+=['-var=node_count=8','-var=genesis_hash='+anchor]
 args.append(str(out/'candidate-refound.nomad'));run(mode,args)
elif mode=='watch':
 label=sys.argv[2];deadline=time.monotonic()+1200;index=0
 with (out/(label+'-allocation-events.jsonl')).open('x') as f:
  while time.monotonic()<deadline:
   allocs,index=get('/v1/job/'+job+'/allocations',index);f.write(json.dumps(allocs)+'\n');f.flush()
   active=[a for a in allocs if a['DesiredStatus']=='run'];need=1 if label=='bootstrap' else 8
   print(label,[(a['Name'],a['ClientStatus']) for a in active],flush=True)
   if len(active)==need and all(a['ClientStatus']=='running' and a.get('TaskStates',{}).get('quod',{}).get('State')=='running' for a in active):
    save(label+'-running.json',{'allocations':active});break
   if any(a['ClientStatus']=='failed' and a['DesiredStatus']=='run' for a in active):raise RuntimeError('Allocation failed')
  else:raise RuntimeError('Allocation deadline exceeded')
else:raise ValueError(mode)
