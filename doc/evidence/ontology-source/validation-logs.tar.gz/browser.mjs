import { chromium } from '/home/yan/src/quod/_build/lobby-toolkit-20260925/browser/node_modules/playwright/index.mjs'
import { checkPrologEditor } from '/home/yan/src/quod/ui/test/prolog-editor.browser.mjs'
const browser = await chromium.launch({ executablePath: '/home/yan/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome', headless: true })
try {
 const page = await browser.newPage()
 page.setDefaultTimeout(15000)
 const errors=[]
 page.on('pageerror', e=>errors.push(String(e)))
 console.log(JSON.stringify(await checkPrologEditor(page, 'http://127.0.0.1:5186')))
 if(errors.length) throw new Error(errors.join('\n'))
} finally { await browser.close() }
