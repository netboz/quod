from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('/home/yan/src/quod'); base=Path('/tmp/quod-source-inspection'); out=root/'doc/evidence/ontology-source'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
backend=json.loads((base/'clean-03/manifest.json').read_text())
ui=json.loads((base/'ui-final-02/manifest.json').read_text())
backend_scope={n:h for n,h in backend.items() if n.startswith(('src/','priv/ontologies/','test/','include/')) or n in ['rebar.config','rebar.lock']}
assert all(sha(root/n)==h for n,h in backend_scope.items()), 'Backend freeze mismatch'
assert all(sha(root/n)==h for n,h in ui.items()), 'Final UI freeze mismatch'
assets={str(p.relative_to(root)):sha(p) for p in (root/'priv/explorer').rglob('*') if p.is_file()}
assert all(sha(base/'ui-final-02/tree'/n)==h for n,h in assets.items()), 'Generated UI mismatch'
assert json.loads((base/'clean-03/PASSED.json').read_text())['passed']
assert json.loads((base/'ui-final-02/PASSED.json').read_text())['passed']
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
paths=[n for n in changed if n.startswith(('src/','priv/ontologies/','client/','ui/','test/')) or n=='doc/system-ontology-acls.md']
manifest={n:sha(root/n) for n in paths if (root/n).is_file()};manifest.update(assets)
(out/'source-manifest.json').write_text(json.dumps(dict(sorted(manifest.items())),indent=2)+'\n')
stat=subprocess.check_output(['git','diff','--numstat','--','src','priv/ontologies','client/src','ui/src'],cwd=root,text=True)
rows=[r.split('\t',2) for r in stat.splitlines()]; adds=sum(int(r[0]) for r in rows); removes=sum(int(r[1]) for r in rows)
(out/'line-delta.json').write_text(json.dumps({'production_added':adds,'production_removed':removes,'production_net':adds-removes,'scope':['src','priv/ontologies','client/src','ui/src'],'excludes':['tests','documentation','generated browser assets'],'files':{r[2]:{'added':int(r[0]),'removed':int(r[1])} for r in rows}},indent=2)+'\n')
(out/'verification.json').write_text(json.dumps({'backend_campaign':'clean-03','final_ui_campaign':'ui-final-02','current_backend_matches_frozen_inputs':True,'current_ui_matches_frozen_inputs':True,'browser_assets_match_final_ui_build':True,'browser_acceptance':'browser-04.log; actual child exit 0','backend_results':json.loads((base/'clean-03/PASSED.json').read_text()),'final_ui_results':json.loads((base/'ui-final-02/PASSED.json').read_text()),'detailed_client_results':json.loads((base/'ui-final-02/client-tap.json').read_text())},indent=2)+'\n')
# Preserve every campaign receipt, runner, complete stdout log, and CT report.
with tarfile.open(out/'validation-logs.tar.gz','w:gz') as archive:
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if not p.is_file() or p.is_symlink():continue
  if 'tree' in rel.parts:
   if not (len(rel.parts)>5 and rel.parts[0] in ['clean-02','clean-03'] and rel.parts[2:5]==('_build','test','logs')):continue
  archive.add(p,arcname=str(rel),recursive=False)
print(json.dumps({'added':adds,'removed':removes,'net':adds-removes,'files':len(manifest),'archive_bytes':(out/'validation-logs.tar.gz').stat().st_size}))
