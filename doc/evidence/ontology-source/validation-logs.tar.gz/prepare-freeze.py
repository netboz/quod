from pathlib import Path
import shutil,subprocess,hashlib,json,os
repo=Path('/home/yan/src/quod'); base=Path('/tmp/quod-source-inspection/clean-03'); tree=base/'tree'; tree.mkdir(parents=True)
paths=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')
paths += [str(p.relative_to(repo)) for p in (repo/'priv/explorer').rglob('*') if p.is_file()]
manifest={}
for name in sorted(set(paths)):
 p=repo/name
 if not p.is_file(): continue
 out=tree/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out)
 manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest()
# Source-only local dependency cache; application/dependency BEAMs rebuild.
for dep in (repo/'_build/default/lib').iterdir():
 if dep.name=='quod' or not dep.is_dir(): continue
 shutil.copytree(dep,tree/'_build/default/lib'/dep.name,ignore=shutil.ignore_patterns('_build','*.beam'),symlinks=True)
for area in ['client','ui']:
 shutil.copytree(repo/area/'node_modules',tree/area/'node_modules',symlinks=True)
# Native cache is unchanged by this scope, as in CI's Cargo cache.
shutil.copytree(repo/'native/quod_physics/target/release',tree/'native/quod_physics/target/release',symlinks=True)
(tree/'native/quod_physics/target/.rustc_info.json').write_bytes((repo/'native/quod_physics/target/.rustc_info.json').read_bytes())
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(base/'freeze.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':len(manifest),'dependency_cache':'normal pinned source checkouts with original metadata; no BEAM files; all Erlang beams rebuild','cargo_cache':'unchanged release cache'},indent=2)+'\n')
print(tree)
