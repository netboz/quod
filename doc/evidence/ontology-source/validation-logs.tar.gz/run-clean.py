from pathlib import Path
import subprocess, json, hashlib, os, time, sys
base=Path('/tmp/quod-source-inspection/clean-03');tree=base/'tree'; logs=base/'gates';logs.mkdir()
manifest=json.loads((base/'manifest.json').read_text())
def unchanged():
 return all((tree/n).is_file() and hashlib.sha256((tree/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
commands=[('client-tests',['npm','--prefix','client','test']),('ui-build',['npm','--prefix','ui','run','build']),('ui-lint',['npm','--prefix','ui','run','lint']),('eunit',['rebar3','as','test','eunit']),('ct',['rebar3','as','test','ct']),('xref',['rebar3','xref']),('dialyzer',['rebar3','dialyzer']),('release',['rebar3','as','prod','release'])]
env=dict(os.environ,ERL_FLAGS='+S 4:4 +SDio 2 +SDcpu 2',CARGO_NET_OFFLINE='true');env.pop('DEBUG',None)
assert not list((tree/'_build/default/lib').rglob('*.beam'))
results=[]
for name,cmd in commands:
 if not unchanged(): raise RuntimeError('source freeze changed before '+name)
 start=time.monotonic()
 with (logs/(name+'.log')).open('x') as log:r=subprocess.run(cmd,cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-start,2)}
 results.append(row);(logs/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 (logs/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:sys.exit(r.returncode)
 if not unchanged(): raise RuntimeError('source freeze changed after '+name)
(base/'PASSED.json').write_text(json.dumps({'passed':True,'sources_unchanged':True,'results':results},indent=2)+'\n')
