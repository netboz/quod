from pathlib import Path
import subprocess,json
p=Path('/tmp/quod-source-inspection')
name='focused-08'
cmd=['rebar3','as','test','eunit','--module=quod_prolog_ontology_tests,quod_lobby_tests,quod_lens_tests,quod_ask_tests']
with (p/(name+'.log')).open('x') as log:
 r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
(p/(name+'.exit.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode})+'\n')
print(r.returncode)
