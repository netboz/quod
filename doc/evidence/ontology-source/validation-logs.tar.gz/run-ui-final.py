from pathlib import Path
import shutil,subprocess,json,hashlib,os,time
repo=Path('/home/yan/src/quod');base=Path('/tmp/quod-source-inspection/ui-final-01');tree=base/'tree';tree.mkdir(parents=True)
for area in ['client','ui']:
 shutil.copytree(repo/area,tree/area,ignore=shutil.ignore_patterns('node_modules','_build','*.tsbuildinfo','.vite'))
 (tree/area/'node_modules').symlink_to(repo/area/'node_modules',target_is_directory=True)
(tree/'priv').mkdir()
paths=[p for area in ['client','ui'] for p in (tree/area).rglob('*') if p.is_file() and 'node_modules' not in p.parts]
manifest={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
def unchanged():return all(hashlib.sha256((tree/n).read_bytes()).hexdigest()==h for n,h in manifest.items())
results=[]
for name,cmd in [('client-tests',['npm','--prefix','client','test']),('ui-build',['npm','--prefix','ui','run','build']),('ui-lint',['npm','--prefix','ui','run','lint'])]:
 assert unchanged();start=time.monotonic()
 with (base/(name+'.log')).open('x') as log:r=subprocess.run(cmd,cwd=tree,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-start,2)};results.append(row);print(json.dumps(row),flush=True)
 (base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 assert r.returncode==0 and unchanged()
(base/'PASSED.json').write_text(json.dumps({'passed':True,'sources_unchanged':True,'results':results},indent=2)+'\n')
