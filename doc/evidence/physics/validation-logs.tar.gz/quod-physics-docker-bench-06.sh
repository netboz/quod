#!/bin/sh
set -eu
docker run --rm --network none --mount type=bind,source=/tmp/quod-physics-packaged-bench-06,target=/bench,readonly --entrypoint /bin/sh quod-physics-validation:final06 -c '
physics_boot=$(echo /opt/quod/releases/*/start_clean.boot)
exec /opt/quod/erts-*/bin/erl +S 2:2 +SDcpu 2 +SDio 1 +Q 65536 -boot "${physics_boot%.boot}" -pa /opt/quod/lib/*/ebin /bench -noshell -eval '\''io:format("~s~n",[erlang:system_info(system_version)]),quod_physics_bench:run(),halt().'\'''
