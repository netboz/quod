#!/bin/sh
set -eu
cd /home/yan/src/quod
export REBAR_BASE_DIR=/tmp/quod-physics-clean-build-05
python3 - <<'PY'
import subprocess,hashlib,json
files=sorted(set(subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0'))-{''})
manifest={p:hashlib.sha256(open(p,'rb').read()).hexdigest() for p in files if not p.startswith('doc/')}
open('/tmp/quod-physics-gates-05-tree.json','w').write(json.dumps(manifest,indent=2)+'\n')
PY
for gate in native clippy eunit ct xref dialyzer release; do
    case "$gate" in
        native) set -- cargo test --locked --manifest-path native/quod_physics/Cargo.toml ;;
        clippy) set -- cargo clippy --locked --manifest-path native/quod_physics/Cargo.toml --all-targets -- -D warnings ;;
        eunit) set -- rebar3 as test eunit ;;
        ct) set -- rebar3 as test ct ;;
        xref) set -- rebar3 xref ;;
        dialyzer) set -- rebar3 dialyzer ;;
        release) set -- rebar3 as prod release ;;
    esac
    printf '%s\n' "starting $gate"
    if "$@" > "/tmp/quod-physics-gates-05-$gate.log" 2>&1; then
        printf '%s\n' "$gate=0" >> /tmp/quod-physics-gates-05.status
        printf '%s\n' "passed $gate"
    else
        code=$?
        printf '%s\n' "$gate=$code" >> /tmp/quod-physics-gates-05.status
        tail -60 "/tmp/quod-physics-gates-05-$gate.log"
        exit "$code"
    fi
done
