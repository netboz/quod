#!/bin/sh
set -eu
docker run --rm --network none --entrypoint /bin/sh quod-physics-validation:final04 -c '
mv /opt/quod/lib/quod-*/priv/native/quod_physics.so /tmp/quod_physics.so
printf "content = []\n" > /tmp/optional.conf
export QUOD_CONF=/tmp/optional.conf
physics_boot=$(echo /opt/quod/releases/*/start.boot)
exec /opt/quod/erts-*/bin/erl +S 2:2 +SDcpu 2 +Q 65536 -boot "${physics_boot%.boot}" -boot_var RELEASE_LIB /opt/quod/lib -config /opt/quod/releases/*/sys.config -mode embedded -noshell -eval '\''
true=lists:keymember(quod,1,application:which_applications()),
false=quod_physics_native:available(),
{error,{load_failed,_}}=quod_physics_native:load_error(),
io:format("embedded release boot: Quod running without physics library; load error retained~n"),halt().'\'''
