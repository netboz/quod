#!/bin/sh
set -eu
docker run --rm --network none --entrypoint /bin/sh quod-physics-validation:final04 -c '
physics_boot=$(echo /opt/quod/releases/*/start_clean.boot)
exec /opt/quod/erts-*/bin/erl +S 2:2 +SDcpu 2 +Q 65536 -boot "${physics_boot%.boot}" -mode embedded -pa /opt/quod/lib/*/ebin -noshell -eval '\''
{module,quod_physics_native}=code:load_file(quod_physics_native),
true=quod_physics_native:available(),
{ok,R}=quod_physics_native:new_world({2,2,2,1000.0},1/60,-9.81),
{ok,2}=quod_physics_native:install(R,[{1,1,false,{0.0,-0.5,0.0},{10.0,0.5,10.0},1.0},{2,1,true,{0.0,3.0,0.0},{0.5,0.5,0.5},1.0}]),
[{ok,_}=quod_physics_native:step(R)||_<-lists:seq(1,30)],
{ok,{_,Poses,_}}=quod_physics_native:sample(R),
{2,{_,Y,_},_,_}=lists:keyfind(2,1,Poses),
true=Y<3.0,
ok=quod_physics_native:retire(R),
{error,retired}=quod_physics_native:sample(R),
io:format("packaged Rapier: finite falling body Y=~p; clean retirement~n",[Y]),halt().'\'''
