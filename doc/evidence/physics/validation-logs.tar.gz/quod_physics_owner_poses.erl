-module(quod_physics_owner_poses).
-export([run/0]).
run() ->
    {module,quod_physics} = code:ensure_loaded(quod_physics),
    Collector = spawn_link(fun() -> collect([]) end),
    Trace = trace:session_create(owner_pose_evidence,Collector,[]),
    1 = trace:function(Trace,{quod_physics,snapshot,2},[{'_',[],[{return_trace}]}],[local]),
    trace:process(Trace,self(),true,[call]),
    try
        {timeout,_,Retained} = quod_physics_tests:optional_retained_world_test_(), Retained(),
        {timeout,_,Sleeping} = quod_physics_tests:sleeping_world_and_unchanged_cost_test_(), Sleeping(),
        Ref = trace:delivered(Trace,all),
        receive {trace_delivered,all,Ref} -> ok after 5000 -> error(trace_timeout) end,
        Collector ! {finish,self()},
        Heights = receive {heights,Rows} -> Rows after 5000 -> error(missing_heights) end,
        true = lists:any(fun({1,Y}) -> Y > 2.0 andalso Y < 3.0; (_) -> false end,Heights),
        true = lists:any(fun({2,Y}) -> Y > 4.0 andalso Y < 5.0; (_) -> false end,Heights),
        true = lists:any(fun({1,Y}) -> Y > 0.4 andalso Y < 0.6; (_) -> false end,Heights),
        io:format("real owner body 2 {revision, height_metres}: ~p~n",[Heights]),
        io:format("PASS: authored 3m body falls; revision 2 installs at 5m and falls; sleeping body rests on ground near 0.5m.~n")
    after trace:session_destroy(Trace),unlink(Collector),exit(Collector,kill) end.
collect(Acc) ->
    receive
        {trace,_,return_from,{quod_physics,snapshot,2},{ok,#{poses := Poses},_}} ->
            collect(Acc ++ [{Rev,Y} || {2,Rev,world,{_,Y,_},_,_} <- Poses]);
        {finish,From} -> From ! {heights,Acc};
        _ -> collect(Acc)
    end.
