import hashlib
import json
import pathlib
import subprocess
import sys

root = pathlib.Path('/home/yan/src/quod')
out = pathlib.Path('/tmp/quod-pose-gates-03')
out.mkdir(exist_ok=False)
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root).decode().splitlines()
changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root).decode().splitlines()
manifest = {p: hashlib.sha256((root / p).read_bytes()).hexdigest() if (root / p).is_file() else None for p in changed}
(out / 'source-before-build.json').write_text(json.dumps(manifest, indent=2) + '\n')
(out / 'prior-invalid-run.txt').write_text(
    '2026-10-07: rebar3 as test eunit --help | head -48 ran tests instead of help.\n'
    'Sandbox denied Ranch loopback listen with eperm in quod_agent_vault_tests.\n'
    'head closed stdout, producing epipe and terminated writer. Shell pipeline reported 0;\n'
    'this is not a test success or usable gate. Full output was not captured.\n'
    'Correct help command: rebar3 help eunit. Campaign 01 below is a separately labeled run.\n')
commands = [
    ('clean-test', ['rebar3', 'as', 'test', 'clean']),
    ('clean-default', ['rebar3', 'clean']),
    ('client', ['npm', '--prefix', 'client', 'test']),
    ('ui', ['npm', '--prefix', 'ui', 'run', 'build']),
    ('eunit', ['rebar3', 'as', 'test', 'eunit']),
    ('ct', ['rebar3', 'as', 'test', 'ct']),
    ('xref', ['rebar3', 'xref']),
    ('dialyzer', ['rebar3', 'dialyzer']),
    ('release', ['rebar3', 'as', 'prod', 'release']),
]
for name, command in commands:
    print('START', name, flush=True)
    with (out / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    with (out / 'exits.jsonl').open('a') as exits:
        exits.write(json.dumps({'gate': name, 'command': command, 'exit': result.returncode}) + '\n')
    print('EXIT', name, result.returncode, flush=True)
    if result.returncode:
        (out / 'STOP').write_text(name + ' failed; campaign stopped.\n')
        sys.exit(result.returncode)
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root).decode().splitlines()
changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root).decode().splitlines()
manifest = {p: hashlib.sha256((root / p).read_bytes()).hexdigest() if (root / p).is_file() else None for p in changed}
(out / 'source-after-build.json').write_text(json.dumps(manifest, indent=2) + '\n')
