import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/home/yan/src/quod')
out = root / 'doc/evidence/poses'
campaign = Path('/tmp/quod-pose-gates-03')
exits = [json.loads(line) for line in (campaign / 'exits.jsonl').read_text().splitlines()]
assert len(exits) == 9 and all(row['exit'] == 0 for row in exits), exits
assert not (campaign / 'STOP').exists()
before = json.loads((campaign / 'source-before-build.json').read_text())
after = json.loads((campaign / 'source-after-build.json').read_text())
changed = sorted(set(before) | set(after))
code_changes = [p for p in changed if not p.startswith('doc/') and before.get(p) != after.get(p)]
assert not code_changes, code_changes
paths = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root).decode().splitlines()
paths += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root).decode().splitlines()
manifest = {p: hashlib.sha256((root / p).read_bytes()).hexdigest() if (root / p).is_file() else None
            for p in sorted(set(paths)) if not p.startswith('doc/evidence/poses/')}
(out / 'source-manifest.json').write_text(json.dumps({
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip(),
    'campaign': '03', 'production_and_test_sources_unchanged_during_gates': True,
    'files': manifest,
}, indent=2) + '\n')
with tarfile.open(out / 'validation-logs.tar.gz', 'w:gz') as tar:
    for path in sorted(Path('/tmp').glob('quod-pose-*')):
        if path.is_file() or path.name in ('quod-pose-gates-01', 'quod-pose-gates-02', 'quod-pose-gates-03'):
            tar.add(path, arcname=path.name)
with tarfile.open(out / 'common-test-reports.tar.gz', 'w:gz') as tar:
    logs = root / '_build/test/logs'
    for path in sorted(logs.glob('ct_run.*2026-10-07*')):
        if path.name.split('2026-10-07_')[1] >= '08.28.59':
            tar.add(path, arcname=path.name)
    for name in ('ct_default.css', 'jquery-latest.js', 'jquery.tablesorter.min.js'):
        tar.add(logs / name, arcname=name)
lines = [hashlib.sha256(path.read_bytes()).hexdigest() + '  ' + path.name
         for path in sorted(out.iterdir()) if path.is_file() and path.name != 'SHA256SUMS']
(out / 'SHA256SUMS').write_text('\n'.join(lines) + '\n')
print('Frozen source check passed; evidence packaged:', len(manifest), 'changed source/artifact paths')
